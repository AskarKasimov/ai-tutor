"""Build a reproducible, prerequisite-first semantic dependency graph.

This script intentionally uses an explicit, auditable human-authored
requirement map instead of treating embedding similarity as causality.
"""
from __future__ import annotations

import csv
import json
import re
import subprocess
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import networkx as nx

ROOT = Path(__file__).resolve().parent
SRC = ROOT / 'topics_reviewed_v2.json'
TOPICS = json.loads(SRC.read_text(encoding='utf-8'))['topics']
BY_ID = {topic['id']: topic for topic in TOPICS}
MISSING_GRADES = {'missing_RPD_only'}
GAP_IDS = {x['id'] for x in TOPICS if x['evidence_grade'] in MISSING_GRADES}


def normal_id(value: str) -> str:
    value = value.strip()
    return value if value.startswith('AI-') else 'AI-' + value


def load_mappings() -> dict[str, list[list[str]]]:
    mapped = {}
    for line in (ROOT / 'requirement_mapping.txt').read_text(encoding='utf-8').splitlines():
        if not line.startswith('AI-'):
            continue
        topic_id, raw = line.split(':', 1)
        fields = [part.strip() for part in raw.split(';')]
        assert topic_id in BY_ID
        assert len(fields) == len(BY_ID[topic_id]['requires']), (topic_id, fields)
        fields = [([] if field == '-' else [normal_id(y) for y in field.split('+')]) for field in fields]
        for sources in fields:
            assert all(s in BY_ID and s != topic_id for s in sources), (topic_id, sources)
        mapped[topic_id] = fields
    assert len(mapped) == len(BY_ID)
    return mapped


MAP = load_mappings()

# Related knowledge is intentionally excluded from the hard-precondition graph.
HELPFUL_ONLY = [
    ('AI-03-01', 'AI-03-06', 'Expert-systems architecture contextualizes Prolog but is not needed for Prolog syntax.'),
    ('AI-04-09', 'AI-05-03', 'Minimax is a useful comparison with MCTS, not needed to execute MCTS.'),
    ('AI-07-01', 'AI-09-01', 'Evolutionary algorithms help compare swarm search but PSO can be learned independently.'),
    ('AI-07-01', 'AI-09-06', 'General population optimization helps contextualize ACO but is not required.'),
    ('AI-01-10', 'AI-10-12', 'Autonomous-decision ethics informs GenAI risk discussion but is not a strict technical prerequisite.'),
    ('AI-08-06', 'AI-10-06', 'MLP architecture is a helpful neural-network example, but not strictly necessary for the token-prediction concept.'),
    ('AI-04-01', 'AI-09-01', 'State-space search is a helpful analogy, not necessary for defining a PSO particle.'),
    ('AI-02-04', 'AI-07-19', 'Environment classifications help describe swarms, but do not teach multiagent interactions.'),
]


def source_pages(t: dict[str, Any]) -> list[str]:
    fragments = t.get('clean_core_fragments', []) or t.get('shared_context_fragments', [])
    seen = set()
    result = []
    for fragment in fragments:
        key = (fragment.get('file'), fragment.get('page'))
        if key in seen:
            continue
        seen.add(key)
        result.append(f"{fragment.get('file', '?')} p.{fragment.get('page', '?')}")
        if len(result) >= 8:
            break
    return result


def direct_explanation(src: dict[str, Any], req: str) -> str:
    # No claim that any single sentence matches automatically; retain the complete
    # candidate competence statement and required competence statement for review.
    prov = ' / '.join(src['provides'])
    return f"Для изучения требуется «{req}». Тема «{src['title']}» обучает: {prov}."


matches: list[dict[str, Any]] = []
candidate_edges: dict[tuple[str, str], dict[str, Any]] = {}
for t in TOPICS:
    for idx, (req, sources) in enumerate(zip(t['requires'], MAP[t['id']]), 1):
        rm_id = f"{t['id']}:R{idx:02d}"
        state = 'not_mapped_external_or_gap' if not sources else 'mapped'
        if t['id'] in GAP_IDS:
            state = 'uncovered_target'
        if any(src in GAP_IDS for src in sources):
            state = 'uncovered_source'
        matches.append({
            'requirement_id': rm_id,
            'target_id': t['id'],
            'target_title': t['title'],
            'requirement': req,
            'source_ids': sources,
            'status': state,
            'target_material_status': t['evidence_grade'],
        })
        for src in sources:
            tp = BY_ID[src]
            pair = (src, t['id'])
            e = candidate_edges.setdefault(pair, {
                'source': src, 'target': t['id'], 'requirements': [],
                'requirement_ids': [], 'reasons': [], 'source_pages': source_pages(tp),
                'provider_competencies': tp['provides'],
                'source_material_status': tp['evidence_grade'],
                'target_material_status': t['evidence_grade'],
                'cross_section': tp['section_number'] != t['section_number'],
                'status': 'curriculum_gap_planned' if (src in GAP_IDS or t['id'] in GAP_IDS) else 'accepted_provisional',
            })
            if req not in e['requirements']:
                e['requirements'].append(req)
            e['requirement_ids'].append(rm_id)
            e['reasons'].append(direct_explanation(tp, req))

# Accepted edges are a grounded, instructor-unconfirmed draft, not measured prerequisite effects.
G = nx.DiGraph()
for t in TOPICS:
    if t['id'] not in GAP_IDS:
        G.add_node(t['id'])
for (src, dst), e in candidate_edges.items():
    if e['status'] == 'accepted_provisional':
        G.add_edge(src, dst)

assert nx.is_directed_acyclic_graph(G), list(nx.simple_cycles(G))[:4]
assert len(G) == 132
TR = nx.transitive_reduction(G)
REMOVED = sorted(set(G.edges()) - set(TR.edges()))

levels = {v: (0 if G.in_degree(v) == 0 else 1 + max(levels[p] for p in G.predecessors(v)))
          for levels in [{}] for v in []}  # replaced below with topological pass
levels = {}
for v in nx.topological_sort(TR):
    levels[v] = 1 + max((levels[p] for p in TR.predecessors(v)), default=-1)

# Persistent attributes for standalone GraphML and machine-readable JSON.
for t in TOPICS:
    t['graph_level'] = levels.get(t['id'])
    t['graph_status'] = 'uncovered_curricular_topic' if t['id'] in GAP_IDS else 'material_present'
    t['in_degree'] = G.in_degree(t['id']) if t['id'] in G else 0
    t['out_degree'] = G.out_degree(t['id']) if t['id'] in G else 0


def graphml_write() -> None:
    gg = nx.DiGraph()
    for t in TOPICS:
        gg.add_node(t['id'], title=t['title'], section=t['section'], section_number=int(t['section_number']),
                    question=t['question'], provides=' | '.join(t['provides']), requires=' | '.join(t['requires']),
                    material_status=t['evidence_grade'], level=int(t['graph_level'] or 0),
                    node_status=t['graph_status'])
    for src, dst in TR.edges():
        e = candidate_edges[src, dst]
        gg.add_edge(src, dst, status='accepted_provisional',
                    required_knowledge=' | '.join(e['requirements']),
                    source_evidence=' | '.join(e['source_pages']),
                    explanation=' | '.join(e['reasons']))
    nx.write_graphml(gg, ROOT/'prerequisite_graph.graphml')


def write_csv(path: str, columns: list[str], data: list[dict[str, Any]]) -> None:
    with (ROOT / path).open('w', encoding='utf-8-sig', newline='') as f:
        out = csv.DictWriter(f, fieldnames=columns, extrasaction='ignore')
        out.writeheader()
        for record in data:
            out.writerow({key: ' ; '.join(map(str, record[key])) if isinstance(record.get(key), list) else record.get(key, '')
                          for key in columns})


def layout_for(nodes: list[str], edges: list[tuple[str,str]], name: str) -> dict[str, Any]:
    # Uses Graphviz's own engine only for layout (not for deciding edges).
    fname = ROOT / f'{name}.dot'
    lines = ['digraph G {', 'graph [rankdir=BT, nodesep=0.34, ranksep=0.66, pad=0.22, overlap=false];',
             'node [shape=box, style="rounded,filled", color="#cbd5e1", fillcolor="#f8fafc", fontname="Arial", fontsize=10, margin="0.1,0.07"];',
             'edge [color="#9aa9bd", arrowsize=0.65];']
    for id in nodes:
        t=BY_ID[id]
        title=t['title']
        brief=title[:34]+'…' if len(title)>35 else title
        label=(id+'\\n'+brief).replace('"','\\"')
        colors=['#eaf2ff','#eaf6ef','#fef3dc','#edf1fe','#fff0f0','#ecfdf5','#fff7ed','#f3e8ff','#ebf9ff','#f1f5f9']
        fill= '#fee2e2' if id in GAP_IDS else colors[(t['section_number']-1)%len(colors)]
        lines.append(f'"{id}" [label="{label}", fillcolor="{fill}", width=2.45, height=0.48];')
    for u,v in edges:
        lines.append(f'"{u}" -> "{v}";')
    lines.append('}')
    fname.write_text('\n'.join(lines),encoding='utf8')
    plain=ROOT/f'{name}.plain'
    subprocess.run(['dot','-Tplain',str(fname),'-o',str(plain)],check=True,timeout=40)
    subprocess.run(['dot','-Tsvg',str(fname),'-o',str(ROOT/f'{name}.svg')],check=True,timeout=40)
    import shlex
    pnodes={}
    for line in plain.read_text().splitlines():
        cells=shlex.split(line)
        if cells and cells[0]=='node':
            _,id,x,y,w,h,*_=cells
            pnodes[id]={'x':round(float(x),3),'y':round(float(y),3),'w':float(w),'h':float(h)}
    return pnodes


def create_graph_datasets() -> dict[str, Any]:
    # Layout within each section; visible external dependencies appear in sidebar when filtered.
    layouts={}
    full_nodes=[t['id'] for t in TOPICS]
    full_edges=sorted(TR.edges())
    layouts['all']=layout_for(full_nodes,full_edges,'all_topics_graph')
    for s in sorted(set(t['section_number'] for t in TOPICS)):
        nodes=[t['id'] for t in TOPICS if t['section_number']==s]
        local_edges=[(u,v) for u,v in full_edges if u in nodes and v in nodes]
        layouts[str(s)]=layout_for(nodes,local_edges,f'section_{s:02d}')
    return layouts


def longest_paths_report() -> dict[str, Any]:
    sinks=sorted([n for n in TR if TR.out_degree(n)==0])
    sources=sorted([n for n in TR if TR.in_degree(n)==0])
    longest=[]
    for end in sinks:
        path=[end]; pos=end
        while TR.in_degree(pos):
            pos=max(TR.predecessors(pos),key=lambda node: levels[node])
            path.insert(0,pos)
        longest.append((end, levels[end],path))
    section_summary=[]
    for s in sorted({t['section_number'] for t in TOPICS}):
        nodes=[t['id'] for t in TOPICS if t['section_number']==s and t['id'] in TR]
        sg=TR.subgraph(nodes).copy()
        locdepth={}
        for id in nx.topological_sort(sg):
            locdepth[id]=max((locdepth[p]+1 for p in sg.predecessors(id)),default=0)
        d=Counter(locdepth.values())
        section_summary.append({
            'section_number':s,
            'section': next(t['section'] for t in TOPICS if t['section_number']==s),
            'nodes':len(nodes), 'within_section_direct_edges':len(sg.edges()),
            'section_max_depth':max(locdepth.values(),default=0),
            'section_depth_distribution':dict(sorted(d.items())),
            'cross_section_incoming':sum(1 for u,v in TR.edges() if v in nodes and u not in nodes),
        })
    return {'atomic_nodes':sources, 'upper_nodes':sinks, 'longest_paths':sorted(longest,key=lambda i:-i[1]),
            'sections':section_summary, 'weak_components':list(nx.weakly_connected_components(TR))}


def create_html(layouts: dict[str,Any], direct_edges: list[dict[str,Any]]) -> None:
    from html import escape
    compact_nodes=[{'id':t['id'], 'title':t['title'], 'section':t['section_number'],
                    'level':t['graph_level'],'question':t['question'],
                    'provides':t['provides'],'requires':t['requires'],
                    'status':t['graph_status'],'grade':t['evidence_grade'],
                    'source_pages':source_pages(t),'full_text':t.get('selected_full_text_with_context','')} for t in TOPICS]
    data={'nodes':compact_nodes, 'edges':[{'source':e['source'],'target':e['target'],
                    'why':e['requirements'], 'pages':e['source_pages'], 'status':e['status']}
                    for e in direct_edges], 'layouts':layouts}
    (ROOT/'graph_view_data.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf8')
    data_js=json.dumps(data,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
    html=r'''<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Карта предпосылок Introduction to AI</title>
<style>
:root{font-family:Inter,system-ui,Arial,sans-serif;color:#14243b;background:#f5f7fb}*{box-sizing:border-box}
header{padding:18px 25px;background:white;border-bottom:1px solid #e2e8f0;display:flex;align-items:center;gap:22px;flex-wrap:wrap}
h1{font-size:18px;margin:0} header small{display:block;color:#64748b;margin-top:4px;font-size:12px}
nav{display:flex;align-items:center;gap:9px;flex-wrap:wrap}select,input,button{border:1px solid #cbd5e1;border-radius:7px;padding:8px 10px;background:white;font-size:13px;color:#14243b}
button{cursor:pointer}button:hover{background:#eaf2ff}
.main{display:grid;grid-template-columns:minmax(0,1fr) 340px;height:calc(100vh - 91px);min-height:520px}
#canvas{overflow:hidden;background:#fff;position:relative;cursor:grab;touch-action:none}#canvas:active{cursor:grabbing}
#map{width:100%;height:100%;display:block;background-image:radial-gradient(#e9eef5 .75px,transparent .75px);background-size:22px 22px}
.edge{stroke:#b4bfd0;fill:none;stroke-width:1.55;opacity:.55;vector-effect:non-scaling-stroke}
.edge.active{stroke:#1173c3;stroke-width:3.3;opacity:1}.edge.faded{opacity:.05}
.node rect{fill:#eaf2fc;stroke:#8ea9ce;stroke-width:1.2}.node.gap rect{fill:#fee2e2;stroke:#db6666;stroke-dasharray:5 3}
.node text{font-size:11.8px;pointer-events:none;fill:#1f3658}.node .nid{font-size:9.4px;fill:#64748b}
.node{cursor:pointer}.node.selected rect{stroke:#0f73bd;stroke-width:3}.node.connected rect{stroke:#448ec5;stroke-width:2}.node.faded{opacity:.12}
.aside{border-left:1px solid #e2e8f0;background:#fafcff;overflow:auto;padding:18px 18px 32px}
.aside h2{margin:5px 0 8px;font-size:17px}.aside h3{font-size:12px;color:#475569;margin:20px 0 6px;text-transform:uppercase;letter-spacing:.055em}
.aside p,.aside li{font-size:13px;line-height:1.48}.aside ul{padding-left:19px;margin:6px 0}.aside pre{white-space:pre-wrap;overflow-wrap:anywhere;background:#f1f5f9;border:1px solid #e2e8f0;border-radius:6px;padding:10px;font-size:11px;line-height:1.4;max-height:420px;overflow:auto}.aside details{font-size:12px;color:#334155;cursor:pointer}
.idtag{font-size:12px;font-weight:700;color:#0369a1}.muted{color:#64748b}.legend{display:flex;gap:10px;flex-wrap:wrap;padding:7px 24px;background:#f9fbfe;border-top:1px solid #e2e8f0;font-size:11px;color:#556781}
.link{color:#075fab;cursor:pointer;border:0;background:none;padding:0;font-size:12px;text-align:left;display:block;margin:6px 0;line-height:1.35}
#hint{position:absolute;left:12px;bottom:12px;font-size:11px;padding:8px;background:#ffffffdd;border:1px solid #e2e8f0;border-radius:7px;pointer-events:none}
@media(max-width:850px){.main{grid-template-columns:1fr;grid-template-rows:minmax(420px,62vh) auto;height:auto}.aside{border-left:none;border-top:1px solid #e2e8f0;max-height:500px}header{padding:14px}}
</style></head><body>
<header><div><h1>Граф зависимостей — Introduction to AI</h1><small>Стрелка A → B: для B требуется знание, предоставляемое A. Предварительная семантическая разметка.</small></div>
<nav><label>Раздел <select id="section"><option value="all">Все разделы</option></select></label>
<input id="query" placeholder="ID или название темы" aria-label="Поиск темы" size="22"><button id="reset">Вписать в экран</button><button id="clear">Снять выделение</button></nav></header>
<div class="main"><div id="canvas"><svg id="map" xmlns="http://www.w3.org/2000/svg"><defs><marker id="arrow" markerWidth="10" markerHeight="8" refX="9" refY="4" orient="auto" markerUnits="userSpaceOnUse"><path d="M0 0 L10 4 L0 8 Z" fill="#93a8be"/></marker><marker id="arrowactive" markerWidth="10" markerHeight="8" refX="9" refY="4" orient="auto" markerUnits="userSpaceOnUse"><path d="M0 0 L10 4 L0 8 Z" fill="#1173c3"/></marker></defs><g id="viewport"><g id="edges"></g><g id="nodes"></g></g></svg>
<div id="hint">Колёсико — масштаб · Перетаскивание — перемещение · Клик по ноде — предпосылки</div></div>
<aside class="aside" id="details"><h2>Выберите тему на графе</h2><p>Покажу диагностический вопрос, provides/requires и все непосредственно связанные ноды с обоснованием стрелок.</p>
<p class="muted">Разделы можно переключать; межраздельные связи сохраняются при выборе темы. Красная пунктирная нода означает тему без учебного материала.</p></aside></div>
<div class="legend"><span>● Синяя нода — есть учебный текст</span><span>● Красная пунктирная — материал отсутствует</span><span>→ Обязательная предпосылка (предварительно)</span><span>Выделение показывает непосредственные связи</span></div>
<script>const DATA=__INJECT__; const $=id=>document.getElementById(id);
const nodes=Object.fromEntries(DATA.nodes.map(x=>[x.id,x]));const edges=DATA.edges;const sections=[...new Map(DATA.nodes.map(n=>[n.section,n.id.slice(3,5)+' · '+n.section])).keys()];
const labels={1:'Введение в ИИ и логика',2:'Агенты',3:'Экспертные системы и Prolog',4:'Поиск',5:'MCTS',6:'PDDL',7:'Эволюционные вычисления',8:'Нейронные сети',9:'PSO и ACO',10:'Генеративный ИИ'};
for(const s of sections){let opt=document.createElement('option');opt.value=s;opt.textContent=s+' — '+labels[s];$('section').append(opt)}
let current='all',selected=null,coords={},state={scale:1,dx:0,dy:0},bbox=[0,0,1,1];const svg=$('map'),edgeLayer=$('edges'),nodeLayer=$('nodes'),vp=$('viewport');
const svgns='http://www.w3.org/2000/svg';function e(tag,attrs){let o=document.createElementNS(svgns,tag);for(const[k,v]of Object.entries(attrs))o.setAttribute(k,v);return o}
function textN(id){const n=nodes[id];return n?.title || id}function esc(s){return String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;')}
function ellipsis(s,n){return s.length>n?s.slice(0,n-1)+'…':s}
function draw(){
  const pos=DATA.layouts[current];const ids=Object.keys(pos);coords={};edgeLayer.replaceChildren();nodeLayer.replaceChildren();
  for(const [id,p] of Object.entries(pos))coords[id]={x:p.x*122,y:-p.y*98,w: Math.max(190,p.w*90),h:52};
  for(const ed of edges){if(!coords[ed.source]||!coords[ed.target])continue;
    const a=coords[ed.source],b=coords[ed.target],x1=a.x,y1=a.y-a.h/2,x2=b.x,y2=b.y+b.h/2;
    const mid=(y1+y2)/2;const path=e('path',{d:`M${x1},${y1} C${x1},${mid} ${x2},${mid} ${x2},${y2}`,'data-src':ed.source,'data-dst':ed.target,'class':'edge','marker-end':'url(#arrow)'});
    const title=e('title',{});title.textContent=ed.why.join(' · ');path.appendChild(title);edgeLayer.appendChild(path);
  }
  for(const id of ids){const n=nodes[id],p=coords[id];const g=e('g',{'class':'node'+(n.status==='uncovered_curricular_topic'?' gap':''),'data-id':id,transform:`translate(${p.x},${p.y})`});
   g.append(e('rect',{x:-p.w/2,y:-p.h/2,width:p.w,height:p.h,rx:7}));
   let a=e('text',{x:0,y:-4,'text-anchor':'middle','class':'nid'});a.textContent=id;g.append(a);
   let b=e('text',{x:0,y:12,'text-anchor':'middle'});b.textContent=ellipsis(n.title,33);g.append(b);
   let t=e('title',{});t.textContent=n.title;g.append(t);g.addEventListener('click',ev=>{ev.stopPropagation();select(id)});nodeLayer.append(g);
  }
  const all=Object.values(coords);const x0=Math.min(...all.map(p=>p.x-p.w/2))-35,x1=Math.max(...all.map(p=>p.x+p.w/2))+35;
  const y0=Math.min(...all.map(p=>p.y-p.h/2))-35,y1=Math.max(...all.map(p=>p.y+p.h/2))+35;
  bbox=[x0,y0,x1-x0,y1-y0];fit();highlight();
}
function apply(){vp.setAttribute('transform',`translate(${state.dx},${state.dy}) scale(${state.scale})`)}
function fit(){let width=svg.clientWidth,height=svg.clientHeight,[x,y,w,h]=bbox;let sc=Math.min(width/w,height/h)*.94;state={scale:sc,dx:(width-w*sc)/2-x*sc,dy:(height-h*sc)/2-y*sc};apply()}
function highlight(){const id=selected;const q=$('query').value.trim().toLowerCase();const related=new Set();if(id){related.add(id);for(const ed of edges)if(ed.source===id||ed.target===id){related.add(ed.source);related.add(ed.target)}}
 for(const g of nodeLayer.children){const n=g.dataset.id;const search=!q||nodes[n].title.toLowerCase().includes(q)||n.toLowerCase().includes(q);
   g.setAttribute('class','node'+(nodes[n].status==='uncovered_curricular_topic'?' gap':'')+(n===id?' selected':related.has(n)?' connected':id&&!related.has(n)||!search?' faded':''))}
 for(const l of edgeLayer.children){const incident=id&&(l.dataset.src===id||l.dataset.dst===id);l.setAttribute('class','edge'+(id?(incident?' active':' faded'):''));l.setAttribute('marker-end',incident?'url(#arrowactive)':'url(#arrow)')}
}
function link(id,why){return `<button class="link" data-go="${id}">${esc(id+' '+ellipsis(textN(id),53))}${why?'<br><span class="muted">'+esc(why)+'</span>':''}</button>`}
function select(id){selected=id;let n=nodes[id];if(!n)return;highlight();let inp=edges.filter(x=>x.target===id),out=edges.filter(x=>x.source===id);
 let html=`<div class="idtag">${id}</div><h2>${esc(n.title)}</h2><p class="muted">Раздел ${n.section} · Уровень ${n.level??'—'} · ${n.status==='uncovered_curricular_topic'?'Нет материала':'Материал привязан'}</p>`;
 html+=`<h3>Диагностический вопрос</h3><p>${esc(n.question)}</p><h3>Provides</h3><ul>${n.provides.map(x=>'<li>'+esc(x)+'</li>').join('')}</ul>`;
 html+=`<h3>Requires</h3><ul>${n.requires.map(x=>'<li>'+esc(x)+'</li>').join('')}</ul>`;
 html+=`<h3>Непосредственные предпосылки (${inp.length})</h3>${inp.length?inp.map(x=>link(x.source,x.why.join('; '))).join(''):'<p class="muted">Не выявлены среди тем курса</p>'}`;
 html+=`<h3>Непосредственные последующие темы (${out.length})</h3>${out.length?out.map(x=>link(x.target,x.why.join('; '))).join(''):'<p class="muted">Не выявлены</p>'}`;
 html+=`<h3>Страницы источника</h3><p class="muted">${n.source_pages.map(esc).join('<br>')||'Привязка отсутствует'}</p><details><summary>Полный текст привязанных PDF-страниц</summary><pre>${esc(n.full_text||'Материал отсутствует')}</pre></details>`;
 $('details').innerHTML=html;$('details').querySelectorAll('[data-go]').forEach(el=>el.onclick=()=>{let target=el.dataset.go;if(!coords[target]){$('section').value='all';current='all';draw()}select(target)});
}
$('section').onchange=()=>{current=$('section').value;selected=null;draw();$('details').innerHTML='<h2>Выберите тему</h2><p>В этом разделе показаны внутрисекционные стрелки. Межраздельные доступны через карточку выбранной темы в режиме «Все разделы».</p>'};
$('reset').onclick=fit;$('clear').onclick=()=>{selected=null;$('query').value='';highlight()};$('query').oninput=highlight;
$('query').addEventListener('keydown',ev=>{if(ev.key!=='Enter')return;const q=$('query').value.trim().toLowerCase();const match=DATA.nodes.find(n=>n.id.toLowerCase()===q)||DATA.nodes.find(n=>n.id.toLowerCase().includes(q)||n.title.toLowerCase().includes(q));if(!match)return;current=String(match.section);$('section').value=current;draw();select(match.id);const p=coords[match.id];if(p){state.scale=Math.min(2,Math.max(.9,state.scale));state.dx=svg.clientWidth/2-p.x*state.scale;state.dy=svg.clientHeight/2-p.y*state.scale;apply()}});
svg.addEventListener('wheel',ev=>{ev.preventDefault();const f=ev.deltaY>0?.82:1.22;const r=svg.getBoundingClientRect();const x=ev.clientX-r.left,y=ev.clientY-r.top;
 state.dx=x-(x-state.dx)*f;state.dy=y-(y-state.dy)*f;state.scale*=f;apply()},{passive:false});
let drag=null;svg.addEventListener('pointerdown',ev=>{if(ev.button!==0)return;drag={x:ev.clientX,y:ev.clientY,dx:state.dx,dy:state.dy};svg.setPointerCapture(ev.pointerId)});
svg.addEventListener('pointermove',ev=>{if(!drag)return;state.dx=drag.dx+ev.clientX-drag.x;state.dy=drag.dy+ev.clientY-drag.y;apply()});
svg.addEventListener('pointerup',()=>drag=null);svg.addEventListener('click',()=>{selected=null;highlight()});
window.addEventListener('resize',fit);draw();
</script></body></html>'''.replace('__INJECT__',data_js)
    (ROOT/'interactive_graph.html').write_text(html,encoding='utf8')


def main() -> None:
    graphml_write()
    extended_edges=list(candidate_edges.values())
    direct_edges=[candidate_edges[edge] for edge in sorted(TR.edges())]
    transitive=[{**candidate_edges[e], 'status':'transitive_redundant',
                 'alternate_path':nx.shortest_path(nx.DiGraph([edge for edge in G.edges() if edge!=e]),e[0],e[1])} for e in REMOVED]
    helpful=[{'source':src,'target':dst,'reason':reason,'status':'helpful_not_required'} for src,dst,reason in HELPFUL_ONLY]
    anomalies=[{'source':src,'target':dst, **{'reason':'No material for source or target', 'status':'curriculum_gap_planned'}}
               for (src,dst), e in candidate_edges.items() if e['status']=='curriculum_gap_planned']
    report=longest_paths_report()
    layouts=create_graph_datasets()
    create_html(layouts,direct_edges)
    stats={
       'total_nodes':len(TOPICS),'material_nodes':len(G.nodes()),'uncovered_nodes':len(GAP_IDS),
       'all_mapped_requirements':len(matches),
       'internally_matched_requirements':sum(x['status']=='mapped' for x in matches),
       'unmapped_requirements':sum(x['status']=='not_mapped_external_or_gap' for x in matches),
       'requirements_of_uncovered_topics':sum(x['target_id'] in GAP_IDS for x in matches),
       'accepted_edges_before_reduction':len(G.edges()),'direct_edges':len(TR.edges()),
       'transitive_removed':len(REMOVED),'gap_candidate_edges':len(anomalies),
       'helpful_omitted':len(helpful),'atomic_topics':len(report['atomic_nodes']),
       'upper_topics':len(report['upper_nodes']),
       'connected_components':len(report['weak_components']),
       'longest_path_edges':nx.dag_longest_path_length(TR),
       'inter_section_direct_edges':sum(x['cross_section'] for x in direct_edges),
    }
    json_out={
        'metadata':{'name':'Introduction to AI — prerequisite-first DAG v1', 'source':str(SRC),
                    'edge_semantics':'source knowledge is an essential prerequisite for target knowledge; drafts require instructor verification',
                    'material_policy':'uncovered RPD-only topics excluded from hard DAG and kept as candidates',
                    'algorithm':'explicit requirement-to-provides semantic mapping, DAG check, transitive reduction',
                    'neural_embeddings_used':False, 'scores_are_not_probabilities':True},
        'stats':stats,
        'nodes':[{'id':t['id'],'title':t['title'],'section':t['section'],'section_number':t['section_number'],
                  'question':t['question'],'provides':t['provides'],'requires':t['requires'],
                  'level':t['graph_level'],'status':t['graph_status'], 'source_quality':t['evidence_grade'],
                  'source_pages':source_pages(t),'full_text':t.get('selected_full_text_with_context','')} for t in TOPICS],
        'edges':direct_edges,'full_direct_candidate_edges':extended_edges,
        'transitive_edges_removed':transitive,'helpful_only':helpful,
        'gap_planned_edges':anomalies, 'requirement_matches':matches,
        'sections':report['sections'],
        'isolated_nodes':list(nx.isolates(TR)),
        'atomic_topics':report['atomic_nodes'],
        'upper_topics':report['upper_nodes'],
    }
    (ROOT/'graph.json').write_text(json.dumps(json_out,ensure_ascii=False,indent=2),encoding='utf8')
    full_out={**json_out,'nodes':TOPICS,'includes_full_source_text':True}
    (ROOT/'graph_full_text.json').write_text(json.dumps(full_out,ensure_ascii=False,indent=2),encoding='utf8')
    write_csv('edges_direct.csv',['source','target','requirements','requirement_ids','source_pages','source_material_status','target_material_status','cross_section','status'],direct_edges)
    write_csv('requirements_coverage.csv',['requirement_id','target_id','target_title','requirement','source_ids','status','target_material_status'],matches)
    write_csv('nodes.csv',['id','section_number','section','title','question','provides','requires','graph_level','graph_status','evidence_grade'],TOPICS)
    write_csv('transitive_edges.csv',['source','target','requirements','alternate_path'],transitive)
    write_csv('gap_proposed_edges.csv',['source','target','reason','status'],anomalies)
    write_csv('helpful_only_edges.csv',['source','target','reason','status'],helpful)
    # Human-readable audit summary.
    sec_rows='\n'.join(f"| {s['section_number']} · {s['section']} | {s['nodes']} | {s['within_section_direct_edges']} | {s['section_max_depth']} | {s['cross_section_incoming']} |" for s in report['sections'])
    deep='\n'.join(f"- {' → '.join(path)} ({depth} шагов)" for _,depth,path in report['longest_paths'][:8])
    cross='\n'.join(f"- **{u} → {v}**: {', '.join(candidate_edges[(u,v)]['requirements'])}" for u,v in TR.edges() if BY_ID[u]['section_number']!=BY_ID[v]['section_number'])
    md=f'''# Проверка DAG — v1

Это **первоначальная семантическая гипотеза**, не экспертное подтверждение обязательности. Все рёбра связаны с текстом `requires` и заявленными `provides`.

## Сводка

```json
{json.dumps(stats,ensure_ascii=False,indent=2)}
```

В графе **с исходным учебным материалом** {len(G)} ноды. Ещё {len(GAP_IDS)} тем РПД без учебного источника показаны отдельно и не создают подтверждённых предпосылок.

## Контроль качества

- Циклы: отсутствуют.
- Транзитивно избыточные рёбра: {len(REMOVED)} удалены только из визуального графа; сохранены в полном журнале.
- Изолированные по отношению к другим темам курса узлы: {len(list(nx.isolates(TR)))}.
- Обязательность каждого ребра пока **нуждается в экспертном контроле**, особенно если PDF содержит только графику, ошибочное распознавание формул или общие слайды.
- Нельзя считать все `{stats['unmapped_requirements']}` ненайденных сопоставления пробелами РПД: часть — математика, программирование, общая эрудиция, входные знания.
- Направление стрелки: от предварительного знания к изучаемому.

## Глубина по разделам (только внутренние рёбра)

| Раздел | Ноды с материалом | Прямых внутренних рёбер | Макс. глубина | Входящие из других разделов |
|---|---:|---:|---:|---:|
{sec_rows}

## Самые длинные цепочки
{deep}

## Межраздельные прямые рёбра
{cross}

## Что не является ребром

Подобие темы, соседство в учебной программе, близость эмбеддингов и сравнение методов без необходимости владения методом A **не создают** зависимость A → B.

## Файлы

- `graph.json`: все ноды, прямые/полные рёбра, требует/обеспечивает, покрытие.
- `interactive_graph.html`: автономный граф со списком связанных нод и диагностическими вопросами.
- `prerequisite_graph.graphml`: импорт в Gephi, yEd и другие редакторы.
- `requirements_coverage.csv`: 261 требование и найденные поставщики.
- `edges_direct.csv`: обоснования оставленных прямых рёбер.
- `transitive_edges.csv`: убранные только из прямого рисунка рёбра.
- `helpful_only_edges.csv`: сознательно исключённые полезные связи.
- `gap_proposed_edges.csv`: связи, затрагивающие ноды РПД без учебного источника.
- `section_*.svg`: локальные схемы.
'''
    (ROOT/'QA_report.md').write_text(md,encoding='utf8')
    print(json.dumps(stats,ensure_ascii=False,indent=2))
    print('longest examples',report['longest_paths'][:4])
    print('isolated',list(nx.isolates(TR)))

if __name__=='__main__':
    main()
