"""Export readable, filterable dependency-review tables using artifact_tool."""
from __future__ import annotations

import json
from pathlib import Path
from artifact_tool import Workbook, SpreadsheetFile

ROOT = Path(__file__).resolve().parent
D = json.loads((ROOT/'graph.json').read_text(encoding='utf8'))
wb = Workbook.create()

TABLES = [
    ('Edges', ['Откуда ID','Куда ID','Тема-источник','Целевая тема','Необходимое знание','Заявленные provides источника','Страницы источника','Межраздельная','Качество источника'],
      [[e['source'],e['target'],next(n['title'] for n in D['nodes'] if n['id']==e['source']),
        next(n['title'] for n in D['nodes'] if n['id']==e['target']),
        '; '.join(e['requirements']), '; '.join(e['provider_competencies']),
        '; '.join(e['source_pages']), 'Да' if e['cross_section'] else 'Нет', e['source_material_status']]
       for e in D['edges']]),
    ('Nodes', ['ID','Раздел','Название','Вопрос','Provides','Requires','Уровень','Входящая степень','Исходящая степень','Статус источника'],
      [[n['id'],n['section_number'],n['title'],n['question'],'; '.join(n['provides']),'; '.join(n['requires']),n['level'] if n['level'] is not None else '-',
        sum(1 for e in D['edges'] if e['target']==n['id']),sum(1 for e in D['edges'] if e['source']==n['id']),n['source_quality']]
       for n in D['nodes']]),
    ('Requires audit', ['ID требования','Нода','Тема','Требуется','Поставщики','Статус сопоставления','Качество темы'],
      [[r['requirement_id'],r['target_id'],r['target_title'],r['requirement'], '; '.join(r['source_ids']),r['status'],r['target_material_status']]
       for r in D['requirement_matches']]),
    ('Sections', ['№','Раздел','Нод с материалом','Прямых внутренних рёбер','Макс. внутренняя глубина','Прямых входящих рёбер извне'],
      [[s['section_number'],s['section'],s['nodes'],s['within_section_direct_edges'],s['section_max_depth'],s['cross_section_incoming']]
       for s in D['sections']]),
    ('Missing material', ['ID','Тема','Вопрос','Признак'],
      [[n['id'],n['title'],n['question'],'Нода только из РПД, нет PDF-материала'] for n in D['nodes'] if n['status']=='uncovered_curricular_topic']),
    ('Non-hard links', ['Откуда','Куда','Причина','Тип'],
      [[e['source'],e['target'],e['reason'],'Полезная, но не обязательная'] for e in D['helpful_only']]
      + [[e['source'],e['target'],e['reason'],'Неподтверждённая: отсутствует материал'] for e in D['gap_planned_edges']]),
]

for name, headers, rows in TABLES:
    sh=wb.worksheets.add(name)
    sh.get_range_by_indexes(0,0,len(rows)+1,len(headers)).values=[headers]+rows
    sh.freeze_panes.freeze_rows(1)
    hdr=sh.get_range_by_indexes(0,0,1,len(headers))
    hdr.format.fill='#163A5F'
    hdr.format.font.color='#FFFFFF'
    hdr.format.font.bold=True
    hdr.format.row_height=30
    sh.get_range_by_indexes(1,0,len(rows),len(headers)).format.row_height=27
    sh.get_range_by_indexes(1,0,len(rows),len(headers)).format.font.size=10
    sh.get_range_by_indexes(0,0,len(rows)+1,len(headers)).format.wrap_text=True
    widths={
      'Edges':[16,16,31,31,44,46,27,15,25],
      'Nodes':[16,9,35,52,52,52,11,19,19,28],
      'Requires audit':[22,16,36,49,22,30,27],
      'Sections':[9,37,20,25,27,32],
      'Missing material':[16,42,58,35],
      'Non-hard links':[18,18,85,32],
    }[name]
    for j,w in enumerate(widths):
        sh.get_range_by_indexes(0,j,len(rows)+1,1).format.column_width=w
    # Built-in Excel table adds accessible filtering for each distinct audit sheet.
    if rows:
        from artifact_tool import RangeFormatConfig
        sh.tables.add(f"A1:{chr(64+len(headers))}{len(rows)+1}",True, name.replace(' ','').replace('-','')+'Table')

summary=wb.worksheets.add('Read me')
summary.get_range('A1:B10').values=[
    ['Introduction to AI · Dependencies v1','Значение'],
    ['Всего нод',D['stats']['total_nodes']],
    ['С учебным материалом',D['stats']['material_nodes']],
    ['Без материалов из РПД',D['stats']['uncovered_nodes']],
    ['Прямых рёбер',D['stats']['direct_edges']],
    ['Рёбер до транзитивной редукции',D['stats']['accepted_edges_before_reduction']],
    ['Не сопоставлено требований',D['stats']['unmapped_requirements']],
    ['Связей между разделами',D['stats']['inter_section_direct_edges']],
    ['Максимальная глубина',D['stats']['longest_path_edges']],
    ['Циклов',0],
]
summary.get_range('A1:B1').format.fill='#163A5F'
summary.get_range('A1:B1').format.font.color='#FFFFFF'
summary.get_range('A1:B1').format.font.bold=True
summary.get_range('A1:B10').format.row_height=27
summary.get_range('A1:A15').format.column_width=44
summary.get_range('B1:B15').format.column_width=24
summary.get_range('A12:B16').values=[
    ['Направление','A → B означает необходимую предпосылку A для B'],
    ['Уровень','Самые базовые ноды = 0'],
    ['Прямые рёбра','Транзитивно избыточные убраны из отображения'],
    ['Статус','Предварительный; не преподавательская валидация'],
    ['Важная оговорка','Пустая привязка не означает, что знания нигде не существует'],
]
summary.get_range('B12:B16').format.column_width=65
summary.get_range('A12:B16').format.wrap_text=True
summary.freeze_panes.freeze_rows(1)

out=ROOT/'dependency_review.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(out))
print('saved',out,round(out.stat().st_size/1024),'KB')
print(wb.inspect({'kind':'table','range':'Read me!A1:B10','include':'values','table_max_rows':10}).ndjson[:1800])
