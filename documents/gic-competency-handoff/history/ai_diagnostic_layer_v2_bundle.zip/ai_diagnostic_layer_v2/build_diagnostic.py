"""Build a diagnostic routing layer without altering prerequisite DAG semantics."""
from __future__ import annotations

import csv
import html
import json
from collections import Counter
from datetime import date
from pathlib import Path

import networkx as nx

BASE = Path('/mnt/data/ai_dependency_graph_v1/graph.json')
OUT = Path('/mnt/data/ai_diagnostic_layer_v2')
OUT.mkdir(exist_ok=True)
raw = json.loads(BASE.read_text(encoding='utf-8'))
nodes = {n['id']:n for n in raw['nodes']}
material = {k for k,v in nodes.items() if v.get('source_quality') != 'missing_RPD_only'}
G = nx.DiGraph()
G.add_nodes_from(material)
G.add_edges_from((e['source'],e['target']) for e in raw['edges'] if e['source'] in material and e['target'] in material)
assert nx.is_directed_acyclic_graph(G)
UP = {k for k in G if G.out_degree(k) == 0}

# id, title, terminal IDs, mode, one scenario/prompt; modes are review statuses, not validated assessment properties.
PROPOSALS = [
 ('DG-01','Понимание и философия искусственного интеллекта', ['AI-01-02','AI-01-03','AI-01-06','AI-01-08','AI-01-19'], 'routing_only',
  'Представь два мысленных эксперимента о машинном интеллекте. Разбери критерий интеллектуальности, возможность понимания и роль обоснования. Для историко-культурных аспектов используй дополнительный независимый подпункт.'),
 ('DG-02','Общественные последствия и этика ИИ',['AI-01-04','AI-01-09','AI-01-10'],'pilot_integrated',
  'Разбери внедрение автономной ИИ-системы в общественно важную профессию: последствия для людей, конфликтующие правила поведения робота, ответственность и риск причинения вреда.'),
 ('DG-03','Логика, доказательства и изменение состояний',['AI-01-20','AI-01-21','AI-01-23','AI-01-24'],'routing_only',
  'Разбери формальное описание меняющейся системы и свойства логического доказательства. Индукцию и необходимые/достаточные условия проверь отдельными независимыми подпунктами.'),
 ('DG-04','Проектирование рациональных агентов',['AI-02-02','AI-02-06','AI-02-08','AI-02-09'],'pilot_integrated',
  'Спроектируй агента для частично наблюдаемой среды: выбери рациональное действие, используй внутреннюю модель, функцию полезности и механизм обучения по обратной связи. Обоснуй каждый компонент.'),
 ('DG-05','Экспертные системы: применение и ограничения',['AI-03-02','AI-03-03','AI-03-04'],'routing_only',
  'Рассмотри разработку экспертной системы: получение правил от специалиста, различие шаблонного диалога и знания, а также исторические ограничения и причины спада интереса.'),
 ('DG-06','Программирование знаний в Prolog',['AI-03-09','AI-03-10'],'pilot_integrated',
  'Спроектируй Prolog-базу семейных отношений, напиши рекурсивный предикат, выполни нетривиальный запрос и пошагово объясни поиск решения.'),
 ('DG-07','Формализация задач поиска и ограничений',['AI-04-02','AI-04-05','AI-04-21'],'routing_only',
  'Сравни постановки поисковых задач для N-ферзей и мира Wumpus, выделив пространства состояний, ограничения и доступную информацию. Непохожие задачи проверь отдельными подзадачами.'),
 ('DG-08','Эвристический поиск пути',['AI-04-08','AI-04-17','AI-04-18'],'pilot_integrated',
  'Для сеточной карты выбери модель соседства, задай эвристику, проверь её согласованность и проведи A* с OPEN/CLOSED до получения пути.'),
 ('DG-09','Состязательный поиск и Monte Carlo Tree Search',['AI-04-10','AI-05-02','AI-05-05','AI-05-07','AI-05-08'],'pilot_integrated',
  'Для игровой задачи сравни alpha-beta и MCTS: проведи отсечения на малом дереве, объясни частичное построение дерева, рассчитай UCT, выбери финальное действие и предложи вариант параллелизации.'),
 ('DG-10','Локальный поиск и оптимизационные ландшафты',['AI-04-13','AI-04-14','AI-04-20','AI-04-23'],'pilot_integrated',
  'Для ландшафта оптимизации выяви плато или локальный оптимум, сравни simulated annealing и tabu search и предложи измерение сложности ландшафта через случайные блуждания.'),
 ('DG-11','Планирование и исполнение в PDDL',['AI-06-07','AI-06-08'],'pilot_integrated',
  'Опиши робототехнический сценарий с ограничениями во времени: задай ключевые элементы PDDL, объясни длительные действия, связь планировщика с ROSPlan и обратную связь при исполнении.'),
 ('DG-12','Генетические алгоритмы: представление и отбор',['AI-07-03','AI-07-04','AI-07-13','AI-07-14','AI-07-20'],'pilot_integrated',
  'Спроектируй генетический алгоритм для задачи маршрута: выбери кодирование, объясни roulette/rank/tournament selection, проведи кроссовер перестановок и разъясни роль эпистаза.'),
 ('DG-13','Генетическое программирование и эволюция структур',['AI-07-08','AI-07-09','AI-07-18'],'pilot_integrated',
  'Сравни генетическое программирование деревьями, CGP и поведенческими деревьями: выполни структурную мутацию, проверь корректность и объясни bloat.'),
 ('DG-14','Эволюционные парадигмы и коэволюция',['AI-07-10','AI-07-11','AI-07-16','AI-07-19'],'routing_only',
  'Подбери методы эволюционной оптимизации для управления: сравни ES, EP, коэволюцию и эволюцию контроллера роя; для каждой парадигмы приведи отдельный проверяемый пример.'),
 ('DG-15','Перцептрон и границы линейных классификаторов',['AI-08-03','AI-08-04'],'pilot_integrated',
  'Реализуй линейно разделимые логические функции перцептроном и затем объясни невозможность XOR на одном перцептроне и способ решения многослойной сетью.'),
 ('DG-16','Ограничения и гибридные применения нейросетей',['AI-08-08','AI-08-09','AI-08-12'],'routing_only',
  'Разбери нейросеть с ошибками и её интерпретируемость, затем отдельно проверь поиск весов эволюцией и сочетание обучения с поиском в AlphaGo.'),
 ('DG-17','Оптимизация роем частиц PSO',['AI-09-03','AI-09-04','AI-09-05','AI-09-12','AI-09-13'],'pilot_integrated',
  'Спроектируй PSO для оптимизации: задай инерцию и gbest/lbest, правило остановки, адаптацию к дискретным вариантам и схему обмена лучшими решениями.'),
 ('DG-18','Муравьиные алгоритмы и коллективное поведение',['AI-09-09','AI-09-11'],'routing_only',
  'Покажи решение TSP муравьиным алгоритмом, а затем отдельно объясни правила flocking. Общая идея коллективного поведения не заменяет оценку обоих механизмов.'),
 ('DG-19','Архитектуры генеративных моделей',['AI-10-02','AI-10-03','AI-10-04','AI-10-05'],'pilot_integrated',
  'Для генерации изображений сравни VAE, GAN и диффузионную модель: опиши принципы обучения, ограничения и обоснованный выбор, связав методы с историей развития.'),
 ('DG-20','LLM-системы: RAG, инструменты и риски',['AI-10-10','AI-10-11','AI-10-12'],'pilot_integrated',
  'Спроектируй LLM-ассистента с RAG и инструментами: покажи контур получения фактов, планирование действий, управление состоянием и контроль рисков/ошибок.'),
]
assert len(PROPOSALS) == 20
flat = [k for x in PROPOSALS for k in x[2]]
assert len(flat) == len(set(flat)) == len(UP), (len(flat),len(set(flat)),len(UP))
assert set(flat)==UP, ('miss', UP-set(flat),'extra',set(flat)-UP)

rules = [
 {'rule': 'pass_requires_evidence', 'description': 'Прохождение gate не закрывает темы автоматически до валидации задания по каждой заявленной ветви.'},
 {'rule': 'partial_scoring', 'description': 'Оценивать evidence для каждой terminal competency отдельно; не сводить к одному бинарному баллу по блоку.'},
 {'rule': 'mastery_closure', 'description': 'Закрывать ancestors только при достаточной подтверждённости каждого prerequisite; иначе помечать как inferred_tentative.'},
 {'rule': 'fail_drill_down', 'description': 'При частичном/неверном ответе переходить к не подтверждённым terminal темам, затем по incoming prerequisite edges.'},
 {'rule': 'learning_order', 'description': 'Учебный маршрут строить топологически от неосвоенных атомарных предпосылок к целевым темам.'},
]

gates=[]
for gid,title,terminals,mode,prompt in PROPOSALS:
 closure=set(terminals)
 for t in terminals: closure.update(nx.ancestors(G,t))
 source_sections=sorted(set(nodes[t]['section_number'] for t in terminals))
 gates.append({
  'id':gid,'name':title,'role':'diagnostic_assessment_group_not_prerequisite_topic',
  'assessment_type':mode,'validation_status':'draft_not_calibrated', 'fast_close_allowed':False,
  'composite_prompt_draft':prompt,'terminal_topic_ids':terminals,
  'terminal_topics':[{'id':t,'name':nodes[t]['title'],'diagnostic_question':nodes[t]['question'], 'provides':nodes[t]['provides']} for t in terminals],
  'num_terminal_topics':len(terminals), 'covered_topic_ids':sorted(closure),
  'num_unique_topics_in_closure':len(closure),
  'source_sections':source_sections,
  'evidence_rubric_draft':[{'topic_id':t,'criterion':'Продемонстрировано: '+('; '.join(nodes[t]['provides'])),'status':'unvalidated'} for t in terminals],
  'diagnostic_note':('Только маршрутизатор: нужен набор независимых подпроверок.' if mode=='routing_only' else 'Кандидат на комплексный кейс: необходима проверка того, что каждый пункт действительно оценивается.'),
 })

# Coverage overlap between groups is expected in a DAG because ancestors are shared.
all_closures = {x['id']:set(x['covered_topic_ids']) for x in gates}
node_gate_counts=Counter(k for s in all_closures.values() for k in s)
link_rows=[]
for g in gates:
 for t in g['terminal_topic_ids']:
  link_rows.append({'gate_id':g['id'],'gate_name':g['name'],'upper_topic_id':t,'topic_title':nodes[t]['title'],'assessment_type':g['assessment_type']})

source_edges=[{'source':e['source'],'target':e['target'],'type':'prerequisite'} for e in raw['edges']]
routing_edges=[{'source':t,'target':g['id'],'type':'assessed_by', 'meaning':'Объединение проверки, НЕ необходимое знание'} for g in gates for t in g['terminal_topic_ids']]
assert len(routing_edges)==69
assert len(source_edges)==145
stats={
 'material_topics':len(G), 'original_prerequisite_edges':len(source_edges),'original_upper_topics':len(UP),
 'diagnostic_groups':len(gates),'routing_links':len(routing_edges),
 'group_size_min':min(g['num_unique_topics_in_closure'] for g in gates),
 'group_size_max':max(g['num_unique_topics_in_closure'] for g in gates),
 'group_size_median':sorted(g['num_unique_topics_in_closure'] for g in gates)[len(gates)//2],
 'terminal_count_min':min(g['num_terminal_topics'] for g in gates),
 'terminal_count_max':max(g['num_terminal_topics'] for g in gates),
 'pilot_integrated_groups':sum(g['assessment_type']=='pilot_integrated' for g in gates),
 'routing_only_groups':sum(g['assessment_type']=='routing_only' for g in gates),
 'covered_material_topic_count':len(node_gate_counts),
 'shared_ancestor_nodes':sum(c>1 for c in node_gate_counts.values()),
 'all_69_terminal_topics_mapped_once':len(flat)==len(UP)==len(set(flat)),
 'prerequisite_graph_still_acyclic':nx.is_directed_acyclic_graph(G),
 'fast_pass_groups_validated':0,
 'missing_rpd_topics':sorted(set(nodes)-material),
}
out={
 'metadata':{'title':'Diagnostic overlay v2; original knowledge DAG v1 unchanged','version':'2.0-draft','date':str(date.today()),'prerequisite_source':'ai_dependency_graph_v1/graph.json', 'semantics':'prerequisite and assessed_by edges MUST NOT be merged into one prerequisite graph'},
 'stats':stats,'gates':gates,'source_prerequisite_edges':source_edges,'diagnostic_routing_edges':routing_edges,
 'rules':rules,'missing_material_nodes':[{'id':k,'title':nodes[k]['title']} for k in sorted(set(nodes)-material)],
}
(OUT/'diagnostic_overlay.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')


def write_csv(name, records):
 with (OUT/name).open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=list(records[0])); w.writeheader();w.writerows(records)

write_csv('diagnostic_groups.csv', [{
 'gate_id':g['id'],'name':g['name'],'mode':g['assessment_type'],'number_upper_topics':g['num_terminal_topics'],
 'unique_prerequisite_closure':g['num_unique_topics_in_closure'], 'sections':','.join(map(str,g['source_sections'])),
 'top_topic_ids':','.join(g['terminal_topic_ids']), 'validation_status':g['validation_status'],'composite_prompt_draft':g['composite_prompt_draft']
} for g in gates])
write_csv('upper_topic_to_gate.csv',link_rows)
write_csv('routing_edges.csv',[{'source':r['source'],'target':r['target'],'edge_type':r['type']} for r in routing_edges])

with (OUT/'GROUPS_AND_QUESTIONS.md').open('w',encoding='utf-8') as f:
 f.write('# Диагностические супертемы (проект)\n\nОтдельная надстройка, НЕ новые prerequisite-рёбра. Пока нет ни одной эмпирически валидированной «быстрой закрывающей» задачи.\n\n')
 for g in gates:
  f.write(f"## {g['id']} — {g['name']}\n\n")
  f.write(f"**Режим:** {g['assessment_type']}; **верхних исходных тем:** {g['num_terminal_topics']}; **уникальных нод с предпосылками:** {g['num_unique_topics_in_closure']}.\n\n")
  f.write(f"**Черновой кейс:** {g['composite_prompt_draft']}\n\n")
  for t in g['terminal_topics']:
   f.write(f"- **{t['id']} — {t['name']}**: {t['diagnostic_question']}\n")
  f.write('\n')

# Offline HTML viewer. No CDN/network dependencies.
PAYLOAD=json.dumps({'gates':gates,'stats':stats, 'nodes':[{'id':n['id'],'title':n['title'],'section':n['section'],'question':n['question']} for n in raw['nodes'] if n['id'] in material], 'edges':source_edges},ensure_ascii=False).replace('</','<\\/')
html_body=r'''<!doctype html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Диагностическая надстройка — AI</title>
<style> :root{color-scheme:light;--bg:#f5f7fa;--paper:#fff;--ink:#182b3d;--dim:#526576;--line:#dce2eb;--accent:#115e80}*{box-sizing:border-box}body{font:14px/1.5 system-ui,-apple-system,Segoe UI,sans-serif;color:var(--ink);background:var(--bg);margin:0}header{padding:23px 28px;background:#0f2b43;color:white}header h1{margin:0;font-size:21px}header p{margin:5px 0 0;color:#d2e3ed}main{max-width:1450px;margin:auto;padding:18px;display:grid;grid-template-columns:360px minmax(500px,1fr);gap:16px}.panel{background:var(--paper);border:1px solid var(--line);border-radius:13px;padding:15px;box-shadow:0 1px 2px #152a3e10}input{width:100%;border:1px solid #bac8d5;border-radius:7px;padding:10px;font:inherit;margin:9px 0 14px}#gatelist{max-height:calc(100vh - 242px);overflow:auto}.g{border:1px solid var(--line);padding:11px;margin-bottom:9px;border-radius:8px;cursor:pointer;background:#fff}.g:hover,.g.active{border-color:var(--accent);background:#eff8fc}.g b{font-size:13px}.g small{display:block;color:var(--dim);margin-top:3px}.tag{display:inline-block;background:#e9f1f6;color:#174863;border-radius:5px;font-size:12px;padding:2px 6px;margin-right:5px}.alert{background:#fff7e6;padding:10px 12px;border-left:3px solid #ddaa4c;border-radius:5px;margin-bottom:16px}h2{margin:0 0 6px;font-size:20px}h3{font-size:15px;margin:21px 0 6px}p{margin:8px 0}.terminal{margin:7px 0;border:1px solid #d7e1e9;border-radius:7px;padding:10px}.terminal summary{cursor:pointer;font-weight:650}.terminal p{margin:7px 0;color:#344e64}.stat{display:inline-block;padding:4px 9px;border-radius:7px;background:#edf2f7;margin-right:7px;font-size:12px}.muted{color:var(--dim)}.mono{font-family:ui-monospace,monospace}#ancestorlist{columns:2;margin-top:10px;font-size:12px}.small{font-size:12px}@media(max-width:820px){main{display:block}.panel{margin-bottom:12px}#gatelist{max-height:330px}#ancestorlist{columns:1}}</style></head><body><header><h1>Диагностическая надстройка • Introduction to AI</h1><p>Отдельные связи assessment-group ≠ prerequisite. Исходный учебный DAG сохраняется без изменений.</p></header><main><aside class="panel"><strong>Диагностические блоки</strong><p id="counts" class="muted"></p><input id="search" placeholder="Название, тема или ID..."/><div id="gatelist"></div></aside><section class="panel"><div class="alert"><strong>Пока это прототип.</strong> Отметка «пройден» не должна автоматически закрывать все предпосылки до проверки надёжности задания для каждой ветви.</div><div id="details"></div></section></main>
<script id="data" type="application/json">__DATA__</script><script>
const DATA=JSON.parse(document.getElementById('data').textContent);
const $=id=>document.getElementById(id);let selected=DATA.gates[0].id;
const escapeHtml=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
$('counts').textContent=`${DATA.stats.diagnostic_groups} блоков • ${DATA.stats.original_upper_topics} верховных тем • ${DATA.stats.material_topics} нод`;
function list(){let q=$('search').value.toLowerCase();$('gatelist').innerHTML=DATA.gates.filter(g=>(g.id+' '+g.name+' '+g.terminal_topics.map(t=>t.name+' '+t.id).join(' ')).toLowerCase().includes(q)).map(g=>`<div class="g ${g.id===selected?'active':''}" data-id="${g.id}"><b>${g.id} — ${escapeHtml(g.name)}</b><small>${g.num_terminal_topics} верхних тем · ${g.num_unique_topics_in_closure} нод в покрытии · ${g.assessment_type==='routing_only'?'маршрутизация':'интегрированный кейс (черновик)'}</small></div>`).join('');document.querySelectorAll('.g').forEach(el=>el.addEventListener('click',()=>{selected=el.dataset.id;list();details()}))}
function details(){let g=DATA.gates.find(x=>x.id===selected);if(!g)return;
const allNodes=new Map(DATA.nodes.map(n=>[n.id,n]));const cover=g.covered_topic_ids.filter(x=>!g.terminal_topic_ids.includes(x));
$('details').innerHTML=`<h2>${escapeHtml(g.id)} — ${escapeHtml(g.name)}</h2><span class="stat">${g.num_terminal_topics} верхних тем</span><span class="stat">${g.num_unique_topics_in_closure} нод в покрытии</span><span class="stat">${g.assessment_type==='routing_only'?'Отдельные подпроверки':'Возможный интегрированный кейс'}</span><h3>Диагностическая задача — черновик</h3><p>${escapeHtml(g.composite_prompt_draft)}</p><h3>Проверяемые терминальные компетенции</h3>${g.terminal_topics.map(t=>`<details class="terminal"><summary><span class="mono">${t.id}</span> ${escapeHtml(t.name)}</summary><p><b>Исходный вопрос:</b> ${escapeHtml(t.diagnostic_question)}</p><p><b>Наблюдаемое умение:</b> ${escapeHtml(t.provides.join('; '))}</p></details>`).join('')}<h3>Предпосылки (не отдельные цели супервопроса)</h3><p class="muted small">Эти ноды относятся к prerequisite-closure. Они не считаются подтверждёнными одной правильной репликой без доказательств покрытия.</p><div id="ancestorlist">${cover.map(id=>`<div><span class="mono">${id}</span> ${escapeHtml(allNodes.get(id)?.title||id)}</div>`).join('')}</div>`;}
$('search').addEventListener('input',list);list();details();
</script></body></html>'''
(OUT/'diagnostic_dashboard.html').write_text(html_body.replace('__DATA__',PAYLOAD),encoding='utf-8')

# GraphML exports with typed edge relationships; independent from original DAG.
H=nx.DiGraph()
for k in G:
 H.add_node(k,label=nodes[k]['title'],kind='topic')
for gate in gates:
 H.add_node(gate['id'],label=gate['name'],kind='diagnostic_group')
for e in source_edges:
 H.add_edge(e['source'],e['target'],relationship='prerequisite')
for e in routing_edges:
 H.add_edge(e['source'],e['target'],relationship='assessed_by')
nx.write_graphml(H,OUT/'multiplex_graph.graphml')

readme=f"""# Диагностическая надстройка v2\n\nИсходный учебный DAG: {len(G)} нод с материалами, {G.number_of_edges()} prerequisite-рёбер, {len(UP)} верховных тем.\nДиагностическая надстройка: {len(gates)} блоков, {len(flat)} терминальных тем распределены однозначно по блокам.\n\nУ исходных {len(G)} нод и {G.number_of_edges()} рёбер структура **не изменена**. Связи `assessed_by` являются логикой группировки диагностики, но не prerequisite. Их нельзя смешивать в циклически-нейтральной модели обучения.\n\nСтатусы: {stats['pilot_integrated_groups']} pilot integrated (составные кейсы на проверку), {stats['routing_only_groups']} routing only (одним вопросом диагностировать всю группу пока нельзя). Ни один блок не валидирован для автоматического закрытия всех prerequisites.\n\nРазмеры покрытий: от {stats['group_size_min']} до {stats['group_size_max']} нод, медиана (верхний срединный элемент) {stats['group_size_median']}. Из-за общих предков суммы покрытий не равны числу нод.\n\nФайлы:\n- `diagnostic_overlay.json`: группы, их цели, их closures, правила, исходные рёбра и routing edges.\n- `diagnostic_groups.csv`: компактная таблица.\n- `upper_topic_to_gate.csv`: 69 исходных верховных тем и назначенные проверки.\n- `GROUPS_AND_QUESTIONS.md`: черновики групповых кейсов + исходные вопросы.\n- `diagnostic_dashboard.html`: интерактивный офлайн-просмотр групп, кейсов и покрытий.\n- `multiplex_graph.graphml`: граф с типами связей, не превращать assessed_by в prerequisite.\n- `diagnostic_design.xlsx`: обзор, блоки, соответствие терминальных тем, охват (если создан).\n\nКлючевая оговорка: снижение 69 верховных нод до 20 assessment-групп не означает автоматически снижение до 20 независимых вопросов. Пока это 20 блоков маршрутизации/комплексных заданий, не доказанная экономия времени.\n\nДля эмпирической оптимизации потребуется набор ответов учеников разного уровня и измерение чувствительности/специфичности по каждой ветви, среднее число вопросов и вероятность пропущенного пробела.\n"""
(OUT/'README.md').write_text(readme,encoding='utf-8')

print(json.dumps(stats,ensure_ascii=False,indent=2))
for g in gates:
 print(g['id'],g['num_terminal_topics'],g['num_unique_topics_in_closure'],g['name'])
