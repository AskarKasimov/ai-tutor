"""Create reviewer workbook from diagnostic overlay."""
import json
from pathlib import Path
from artifact_tool import Workbook, SpreadsheetFile

ROOT=Path('/mnt/data/ai_diagnostic_layer_v2')
d=json.loads((ROOT/'diagnostic_overlay.json').read_text(encoding='utf-8'))
wb=Workbook.create()
blue='#123B55'
head={'fill':blue,'font':{'color':'#FFFFFF','bold':True},'row_height':27,'vertical_alignment':'center'}

specs=[
('Обзор', ['Метрика','Значение','Примечание'],[
 ['Тем с материалом',d['stats']['material_topics'],'Исходный DAG сохранён'],
 ['Прямых prerequisite рёбер',d['stats']['original_prerequisite_edges'],'Не изменены'],
 ['Исходных верховных тем',d['stats']['original_upper_topics'],'Не имеют исходящих рёбер'],
 ['Диагностических групп',d['stats']['diagnostic_groups'],'Каждая группа — отдельный слой диагностики'],
 ['Интегрированных кейсов на проверку',d['stats']['pilot_integrated_groups'],'Без эмпирической валидации'],
 ['Только маршрутизация',d['stats']['routing_only_groups'],'Требуют нескольких независимых проверок'],
 ['Размер охвата: минимум',d['stats']['group_size_min'],'Уникальных нод с prerequisite-closure'],
 ['Размер охвата: максимум',d['stats']['group_size_max'],'Уникальных нод с prerequisite-closure'],
 ['Все верховные темы разложены по группам',str(d['stats']['all_69_terminal_topics_mapped_once']),'Ровно по одной группе'],
 ['Автоматически валидированных супервопросов',0,'Нельзя автоматически закрывать ветви'],
 ['Ключевое различие','prerequisite vs assessed_by','Не объединять типы связей'],
 ]),
('Группы', ['ID','Название','Режим','Верхних тем','Уникальных нод','Разделы РПД','Верхние ID','Комплексный вопрос (черновик)'],[
 [g['id'],g['name'],g['assessment_type'],g['num_terminal_topics'],g['num_unique_topics_in_closure'],', '.join(map(str,g['source_sections'])),', '.join(g['terminal_topic_ids']),g['composite_prompt_draft']] for g in d['gates']
 ]),
('Верхние ноды', ['Диагностическая группа','Тема ID','Название','Исходный вопрос','Provides'],[
 [g['id'],t['id'],t['name'],t['diagnostic_question'],'; '.join(t['provides'])] for g in d['gates'] for t in g['terminal_topics']
 ]),
('Охват', ['Группа','Нода, входящая в prerequisite-closure','Входит в исходные верхние темы'],[
 [g['id'],n,'да' if n in g['terminal_topic_ids'] else 'нет'] for g in d['gates'] for n in g['covered_topic_ids']
 ]),
('Правила', ['Правило','Описание'],[[x['rule'],x['description']] for x in d['rules']]),
('Пропуски РПД',['Нода','Название','Статус'],[[n['id'],n['title'],'нет учебного материала'] for n in d['missing_material_nodes']]),
]
widths={
 'Обзор':[36,26,70],
 'Группы':[14,48,21,14,18,18,49,88],
 'Верхние ноды':[21,15,56,92,95],
 'Охват':[19,46,30],
 'Правила':[30,98],
 'Пропуски РПД':[18,56,28],
}
for name,cols,rows in specs:
 sh=wb.worksheets.add(name)
 matr=[cols]+rows
 sh.get_range_by_indexes(0,0,len(matr),len(cols)).values=matr
 sh.get_range_by_indexes(0,0,1,len(cols)).format=head
 sh.freeze_panes.freeze_rows(1)
 for i,w in enumerate(widths[name]):
  sh.get_range_by_indexes(0,i,len(matr),1).format.column_width=w
 sh.get_range_by_indexes(1,0,len(rows),len(cols)).format.row_height=25 if name not in ('Верхние ноды','Группы') else 32
 sh.get_range_by_indexes(1,0,len(rows),len(cols)).format.wrap_text=True
 if name in ('Группы','Верхние ноды','Охват'):
  sh.tables.add(sh.get_range_by_indexes(0,0,len(matr),len(cols)),True,'Tbl'+('Groups' if name=='Группы' else 'Topics' if name=='Верхние ноды' else 'Coverage'))

path=ROOT/'diagnostic_design.xlsx'
SpreadsheetFile.export_xlsx(wb).save(str(path))
print('saved',path)
try:
 print(wb.inspect({'kind':'table','range':'Обзор!A1:C7','include':'values','table_max_rows':7,'table_max_cols':3}).ndjson[:1800])
except Exception as e:
 print('inspection warning',str(e)[:400])
