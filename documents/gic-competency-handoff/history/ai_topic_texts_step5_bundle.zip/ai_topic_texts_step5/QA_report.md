# Контроль качества извлечения текста

## Объём и покрытие

- Тем: **133**; с учебным текстом: **128**; без привязанных источников: **5**.
- Уникальных привязанных PDF-страниц: **781**, из них **14** добавлены при дополнительном аудите.
- Всего привязок тема → страница: **964**.
- Совместно используемых несколькими темами страниц: **168**; у **77** тем есть такие страницы.
- Объём текста с повторением общих страниц: **291329** символов.
- Ещё не назначенных никакой теме страниц с учебным текстом: **24** (из них **7** длиннее 60 символов).

## Не найден учебный текст

- **AI-01-05** Четвёртая промышленная революция (RPD-03)
- **AI-01-11** Справедливость, прозрачность и подотчётность ИИ (RPD-42)
- **AI-08-10** Практическая классификация датасета Moons (RPD-48)
- **AI-08-11** Практическая классификация MNIST (RPD-49)
- **AI-10-13** Полноценный жизненный цикл этически ответственного ИИ ()

## Привязанные страницы без извлечённых строк категории educational

- **AI-01-01** Подходы к определению искусственного интеллекта: D27:14
- **AI-01-09** Законы робототехники Азимова и их ограничения: D17:23, D17:27
- **AI-01-16** Предикаты, отношения и формулы первого порядка: D17:19
- **AI-01-18** Корректность логического вывода: D07:9
- **AI-04-10** Альфа-бета-отсечение: D09:5
- **AI-09-06** Муравьиная оптимизация и стигмергия: D15:12

Некоторые из этих страниц состоят только из рисунков, ссылок либо элементов, отнесённых первичной очисткой к другим категориям. Рекомендуется просмотреть исходный PDF.

## Не распределённые страницы с учебным текстом

| PDF | Страница | Символов | Первые строки |
|---|---:|---:|---|
| D01 | 16 | 138 | Recap & Next Steps - Generative AI creates new content using learned patterns - LLMs are powerful but can hall |
| D02 | 2 | 30 | Learning by Searching Part 1 2 |
| D03 | 3 | 30 | Learning by Searching Part I 3 |
| D03 | 56 | 75 | Summary - Uniformed Search - Informed Search - Backtracking - Hill Climbers |
| D10 | 2 | 25 | Expert Systems – Prolog 2 |
| D11 | 3 | 32 | Evolutionary Algorithms Part I 3 |
| D11 | 55 | 146 | Summary - Evolutionary Algorithms history and idea - Genetic Algorithms - Genetic Programming - Evolutionary P |
| D12 | 3 | 33 | Evolutionary Algorithms Part II 3 |
| D13 | 3 | 28 | Artificial Neural Networks 3 |
| D13 | 37 | 26 | Summary - ANN - Perceptron |
| D14 | 43 | 63 | Summary - Particle Swarm Optimization - Ant Colony Optimization |
| D15 | 39 | 13 | DEMO (PYTHON) |
| D16 | 3 | 31 | Introduction to Generative AI 3 |
| D16 | 14 | 37 | - Generative AI Summary Next term: ML |
| D17 | 30 | 93 | Summary - Turing Test - Chinese Room - First-Order and Propositional Logic - Laws of Robotics |
| D19 | 3 | 23 | Agents Mr. Anderson…. 3 |
| D19 | 27 | 83 | Summary - What is an Agent - PEAS - Properties of the Environment - Types of Agents |
| D20 | 34 | 33 | Summary - Expert Systems - Prolog |
| D21 | 2 | 29 | Learning by Searching Part II |
| D22 | 3 | 31 | Learning by Searching Part II 3 |
| D22 | 56 | 79 | Summary - Simulated Annealing - Exploration and Exploitation - A* - Tabu Search |
| D25 | 3 | 25 | Monte Carlo Tree Search 3 |
| D25 | 37 | 14 | Summary  MCTS |
| D26 | 2 | 44 | Planning Domain Definition Language (PDDL) 2 |

## Как интерпретировать «полный текст»

1. Текст собран по всему предварительно привязанному диапазону PDF-страниц. Это предотвращает потерю связанного материала, но может добавить небольшие фрагменты соседних тем.
2. Из использованного слоя `cleaned.json` сохранены записи с пометкой `educational`. Колонтитулы, дубли OCR, навигация, организационные страницы и сомнительные распознавания не смешиваются с учебным текстом.
3. Категория `review` (сомнительные распознавания, в том числе фрагменты формул) сохранена отдельно в `uncertain_ocr_by_topic.json`, с ID и координатами.
4. Текст рисунков, диаграмм и формул, представленных только изображениями, не гарантированно извлечён. Слайды нужно проверять визуально на следующем шаге.
5. Для формального утверждения «собран весь текст темы» ещё нужна проверка неподхваченных страниц и ручное/полуавтоматическое разделение общих страниц по смысловым фрагментам.

## Файлы

- `topics/*.md`: отдельный Markdown для каждой темы.
- `all_topics_full_text.md`: один документ со всеми темами и исходным текстом.
- `topics_with_full_text.json`: структурированный результат, исходные ID строк, координаты и статус.
- `topic_texts.xlsx`: таблица по темам и отдельным страницам с полным текстом.
- `topics_index.csv`: компактный индекс.
- `topic_pages.csv`: все пары тема/страница.
- `unassigned_educational_pages.*`: аудит непривязанных страниц.
- `uncertain_ocr_by_topic.json`: кандидаты на восстановление формул и сложных фрагментов OCR.
