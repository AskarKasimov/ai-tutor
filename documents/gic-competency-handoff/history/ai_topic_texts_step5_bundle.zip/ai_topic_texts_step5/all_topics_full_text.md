# Извлечённый учебный текст всех тем

# AI-01-01 — Подходы к определению искусственного интеллекта

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Классифицируй три описанные системы по подходам к определению ИИ и объясни пограничный случай.
**Пункты РПД:** RPD-01

**Связанные страницы:** 4; **символов извлечённого текста:** 431.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D27 — week1 lecture.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=13`
Строки (ID элементов): D27:p0013:u0001, D27:p0013:u0002

````text
Introduction
The Introduction to the Introduction to AI
````

## D27 — week1 lecture.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=14`
Строки (ID элементов): нет

*На привязанной странице нет текста в категории educational; проверь изображение слайда.*

## D27 — week1 lecture.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=15`
Строки (ID элементов): D27:p0015:u0001, D27:p0015:u0002, D27:p0015:u0003, D27:p0015:u0004, D27:p0015:u0005, D27:p0015:u0006, D27:p0015:u0007, D27:p0015:u0008, D27:p0015:u0009, D27:p0015:u0010, D27:p0015:u0011, D27:p0015:u0012, D27:p0015:u0013

````text
Artificial Intelligence
- Breaks down into four major definitions classes:
- Thinking Humanly
- Thinking Rationally
- Acting Humanly
- Acting Rationally
- Six major areas of concern (Russel & Norvig)
- Natural Language Processing
- Knowledge Representation
- Automated Reasoning
- Machine Learning
- Computer Vision
- Robotics
````

## D27 — week1 lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=16`
Строки (ID элементов): D27:p0016:u0001, D27:p0016:u0002, D27:p0016:u0003
**Непроверенные OCR/формулы:** 11 исключённых из основного текста кандидатов; см. JSON.

````text
AI Onwards
- Computational Creativity
- Biomimicry
````


---

# AI-01-02 — Сильный и слабый искусственный интеллект

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Сопоставь сильный и слабый ИИ на двух примерах и объясни, что из этого реально продемонстрировано.
**Пункты РПД:** RPD-02

**Связанные страницы:** 3; **символов извлечённого текста:** 470.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D27 — week1 lecture.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=27`
Строки (ID элементов): D27:p0027:u0001, D27:p0027:u0002, D27:p0027:u0003, D27:p0027:u0004, D27:p0027:u0005, D27:p0027:u0006, D27:p0027:u0007, D27:p0027:u0008

````text
Strong & Weak AI
- Strong AI
- Human-based design
- Human-based constructions
- Weak AI
- Problem Solving for specific tasks
- May or may not have human aspects
- Majority of AI work is on this issue
````

## D27 — week1 lecture.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=28`
Строки (ID элементов): D27:p0028:u0001, D27:p0028:u0002, D27:p0028:u0003, D27:p0028:u0004, D27:p0028:u0005

````text
Welcome to the Course
- Think about what products you use every day will be obsolete due to AI in
the near future
- Will this be good for humanity or bad – make a list of pros and cons
- What is Intelligence?
````

## D27 — week1 lecture.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=29`
Строки (ID элементов): D27:p0029:u0001, D27:p0029:u0004, D27:p0029:u0005, D27:p0029:u0006

````text
Summary
- AI definitions
- AI is Situational
- Strong & Weak AI
````


---

# AI-01-03 — Контекстная и ситуационная природа интеллекта

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Почему одинаковая система может считаться интеллектуальной в одной среде, но не в другой?
**Пункты РПД:** —

**Связанные страницы:** 7; **символов извлечённого текста:** 2404.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D27 — week1 lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=19`
Строки (ID элементов): D27:p0019:u0001, D27:p0019:u0002, D27:p0019:u0003, D27:p0019:u0004, D27:p0019:u0005, D27:p0019:u0006, D27:p0019:u0007, D27:p0019:u0008
**Общая страница с:** AI-01-04
**Непроверенные OCR/формулы:** 7 исключённых из основного текста кандидатов; см. JSON.

````text
Why Should We Care?
- Via the analysis of building something we learn more about it
- In order to understand our own process of thought
- Build something which “thinks”
- Explore what it means to be “rational”
- What does it mean to be “intelligent”?
- Is there something beyond mechanical action to our brains
- Free Will
````

## D27 — week1 lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=20`
Строки (ID элементов): D27:p0020:u0001, D27:p0020:u0002, D27:p0020:u0003, D27:p0020:u0004, D27:p0020:u0005, D27:p0020:u0006, D27:p0020:u0007, D27:p0020:u0008, D27:p0020:u0009
**Общая страница с:** AI-01-04
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Why Should We Care?
- Fear is defeated by knowledge
- If our future is going to be a terrifying world of the robots and AI
- “I, for one, welcome our new overlords”
- The wars of the future will not be fought on the battlefield or at sea. They
will be fought in space, or possibly on top of a very tall mountain. In either
case, most of the actual fighting will be done by small robots. And as you
go forth today remember always your duty is clear: To build and maintain
those robots. - Simpsons
````

## D27 — week1 lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=21`
Строки (ID элементов): D27:p0021:u0001, D27:p0021:u0002, D27:p0021:u0003, D27:p0021:u0004, D27:p0021:u0005, D27:p0021:u0006, D27:p0021:u0007, D27:p0021:u0008, D27:p0021:u0009, D27:p0021:u0010, D27:p0021:u0011, D27:p0021:u0012, D27:p0021:u0013, D27:p0021:u0014, D27:p0021:u0015, D27:p0021:u0016, D27:p0021:u0017
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Intelligence is Situational
- 
Highly depends on cultural factors
- 
People of Indigenous tribes
- Plants/Animals
- Navigation of waters
- 
Methods of Transport
- Horse
- Do you know how to ride one?
- Do you know how to feed, water, and resaddle one?
- Do you know how to breed them?
- Cars
- Do you know how to drive?
- Do you know how to refuel, put in washer fluid, do an oil change?
- Do you know how an engine works enough to make repairs or build one?
````

## D27 — week1 lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=22`
Строки (ID элементов): D27:p0022:u0001, D27:p0022:u0002, D27:p0022:u0003, D27:p0022:u0004, D27:p0022:u0005, D27:p0022:u0006, D27:p0022:u0007, D27:p0022:u0008, D27:p0022:u0009, D27:p0022:u0010, D27:p0022:u0011, D27:p0022:u0012, D27:p0022:u0013, D27:p0022:u0014, D27:p0022:u0015, D27:p0022:u0016, D27:p0022:u0017, D27:p0022:u0025
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Self Driving Cars – Offloading
Intelligence into Technology
- 
AI is taking the act of driving a car away from us
- 
Gradual Process
- Powered Steering
- Clutch assists
- Automatic Transmissions
- ABS
- Four wheel skid prevention systems
- Backup Cameras
- Drive-by-wire
- 
What was once a skill required to live will become a domain-specific skill
- Much like horses are to us now a skill which is reserved for those who are interested
- Special teams of off-board drivers who will fix what cannot be done by AI now
@ fee pace
````

## D27 — week1 lecture.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=23`
Строки (ID элементов): D27:p0023:u0001, D27:p0023:u0002, D27:p0023:u0003, D27:p0023:u0004, D27:p0023:u0005, D27:p0023:u0023
**Непроверенные OCR/формулы:** 11 исключённых из основного текста кандидатов; см. JSON.

````text
Human Decision Making
- Decision Trees
- Game Trees
- Expert Systems
- Neural Networks
5
````

## D27 — week1 lecture.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=24`
Строки (ID элементов): D27:p0024:u0001, D27:p0024:u0002, D27:p0024:u0003, D27:p0024:u0004, D27:p0024:u0005, D27:p0024:u0006, D27:p0024:u0007, D27:p0024:u0008, D27:p0024:u0009
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Bioinspired
- Humans are perhaps not the only type of intelligence we mimic
- Swarms
- Birds Flocking
- Ant Colonies seeking food
- Bees finding flowers
- Evolution and Breeding
- Genetics
- Movement in Robotics
````

## D27 — week1 lecture.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=25`
Строки (ID элементов): D27:p0025:u0001, D27:p0025:u0002, D27:p0025:u0003, D27:p0025:u0004, D27:p0025:u0005, D27:p0025:u0006, D27:p0025:u0007

````text
Embodied AIs
- A robot without a program is soulless
- An AI without a body is just a ghost
- AIs now have more physical (robot) or digital (agent) embodiment
- Siri/Galaxy/Cortana/Alexa/Alisa – Digital Embodiment
- Video Game Characters
- Humans love to make non-human things have human characteristics
````


---

# AI-01-04 — Влияние ИИ на профессии и общество

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** частично; ядро
**Диагностический вопрос (черновик):** Проанализируй внедрение ИИ в выбранную профессию с выгодами, потерями и вторичными последствиями.
**Пункты РПД:** —

**Связанные страницы:** 4; **символов извлечённого текста:** 2022.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D27 — week1 lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=17`
Строки (ID элементов): D27:p0017:u0001, D27:p0017:u0002, D27:p0017:u0003, D27:p0017:u0004, D27:p0017:u0005, D27:p0017:u0006, D27:p0017:u0007, D27:p0017:u0008, D27:p0017:u0012, D27:p0017:u0013, D27:p0017:u0014, D27:p0017:u0015, D27:p0017:u0016, D27:p0017:u0024, D27:p0017:u0028, D27:p0017:u0030, D27:p0017:u0032, D27:p0017:u0034, D27:p0017:u0037, D27:p0017:u0038, D27:p0017:u0039, D27:p0017:u0040, D27:p0017:u0043, D27:p0017:u0044
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
Why Should We Care?
- The future job situation:
- The Guardian, Sept. 13, 2016, “Robots will eliminate 6% of all US jobs by
2021, report says”
- BBC News, May 25, 2016, “Foxconn replaces '60,000 factory workers with
robots‘”
- The Economist, Jun. 25, 2016, “The impact on jobs: Automation and
anxiety”
Catalogue of fears
Probability of computerisation of different
occupations, 2013
(1= certain)
Job
0.008)
tors
Actors
Health technologists :
Economists
Real-estate sales agents
Technical writers
Retail salespeople
Telemarketers
Source: “The Future of Employment: How Susceptible are Jobs
to Computerisation?, by C. Frey and M. Osborne (2013)
````

## D27 — week1 lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=18`
Строки (ID элементов): D27:p0018:u0001, D27:p0018:u0002, D27:p0018:u0003, D27:p0018:u0004, D27:p0018:u0005, D27:p0018:u0006, D27:p0018:u0007, D27:p0018:u0008, D27:p0018:u0009, D27:p0018:u0010, D27:p0018:u0011

````text
Why Should We Care?
- Forbes Article - Automation, COVID, And The Future Of Work
- Oct 2020 by Adi Gaskell
- Questions the automation of jobs
- Jobs in companies where AI has been engaged have actually INCREASED 15%
- Firms productivity which engaged with AI was increased
- This lead the firms to engage with new locations and move into new markets
- Young people are the most vulnerable to employment issues
- Most younger people are in jobs which are consumer facing
- Retail, Services, etc.
- These are also more gig work or temporary employment opportunities
````

## D27 — week1 lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=19`
Строки (ID элементов): D27:p0019:u0001, D27:p0019:u0002, D27:p0019:u0003, D27:p0019:u0004, D27:p0019:u0005, D27:p0019:u0006, D27:p0019:u0007, D27:p0019:u0008
**Общая страница с:** AI-01-03
**Непроверенные OCR/формулы:** 7 исключённых из основного текста кандидатов; см. JSON.

````text
Why Should We Care?
- Via the analysis of building something we learn more about it
- In order to understand our own process of thought
- Build something which “thinks”
- Explore what it means to be “rational”
- What does it mean to be “intelligent”?
- Is there something beyond mechanical action to our brains
- Free Will
````

## D27 — week1 lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=20`
Строки (ID элементов): D27:p0020:u0001, D27:p0020:u0002, D27:p0020:u0003, D27:p0020:u0004, D27:p0020:u0005, D27:p0020:u0006, D27:p0020:u0007, D27:p0020:u0008, D27:p0020:u0009
**Общая страница с:** AI-01-03
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Why Should We Care?
- Fear is defeated by knowledge
- If our future is going to be a terrifying world of the robots and AI
- “I, for one, welcome our new overlords”
- The wars of the future will not be fought on the battlefield or at sea. They
will be fought in space, or possibly on top of a very tall mountain. In either
case, most of the actual fighting will be done by small robots. And as you
go forth today remember always your duty is clear: To build and maintain
those robots. - Simpsons
````


---

# AI-01-05 — Четвёртая промышленная революция

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** не найдено; ядро
**Диагностический вопрос (черновик):** Назови признаки четвёртой промышленной революции и объясни роль ИИ на конкретном примере.
**Пункты РПД:** RPD-03

**Исходный текст не найден.** В текущей карте отсутствуют ссылки на учебные материалы.
Текст не генерировался и не заменялся сведениями из РПД.


---

# AI-01-06 — Знание, обоснование и контрпримеры Геттиера

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Покажи на собственном примере, почему обоснованное истинное убеждение может не считаться знанием.
**Пункты РПД:** RPD-43

**Связанные страницы:** 3; **символов извлечённого текста:** 1311.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D17 — Week 2 Lecture.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=3`
Строки (ID элементов): D17:p0003:u0001, D17:p0003:u0003

````text
What is Intelligence?
3
````

## D17 — Week 2 Lecture.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=4`
Строки (ID элементов): D17:p0004:u0001, D17:p0004:u0002, D17:p0004:u0003, D17:p0004:u0004, D17:p0004:u0005, D17:p0004:u0006, D17:p0004:u0007, D17:p0004:u0008, D17:p0004:u0009, D17:p0004:u0010, D17:p0004:u0011
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Philosophy
- Epistemology – fr. Greek - from Greek ἐπιστήµη, epistēmē, meaning
"knowledge", and λόγος, logos, meaning “logical discourse”
- Study of how we know what we know
- Many epistemologist see a separation of Truth/Belief/Justification that gives
Knowledge
- Truth is the objective reality
- Belief is the subjective idea of what reality is
- Justification is an explanation
- Knowledge is True Belief with Justification aka JTB (comes from Socrates)
- Example: I had a coffee this morning to keep myself awake for class
````

## D17 — Week 2 Lecture.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=5`
Строки (ID элементов): D17:p0005:u0001, D17:p0005:u0002, D17:p0005:u0003, D17:p0005:u0004, D17:p0005:u0005, D17:p0005:u0006, D17:p0005:u0007, D17:p0005:u0008, D17:p0005:u0009, D17:p0005:u0010, D17:p0005:u0011, D17:p0005:u0012, D17:p0005:u0013, D17:p0005:u0014, D17:p0005:u0015, D17:p0005:u0016, D17:p0005:u0017, D17:p0005:u0018, D17:p0005:u0019, D17:p0005:u0020

````text
Gettier Cases
- 
In 1963 Edmund Gettier described 2 cases disagreeing with JTB. One of them below:
- 
Smith and Jones apply for a job
- 
Smith asks Jones for some change and knows Jones has 10 Rouble coins in his pocket
- 
Smith is informed by the head that it is Jones who will be given the job
- Head told that Jones has ten coins in his pocket and that Jones will get the job
- Smith now believes that the man with 10 coins in his pocket will get the job
- 
Assume there is a change of plan and Smith is selected; also unknown to Smith was that in
his pocket were 10 coins
- 
So, the above propositions were True, were Beliefs, were Justified
- 
But Smith didn’t KNOW!
- Includes a justified false beliefs
- A Justification must also be necessarily the cause
````


---

# AI-01-07 — Тест Тьюринга и его интерпретация

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Спроектируй испытание Тьюринга и объясни, что прохождение теста доказывает, а чего не доказывает.
**Пункты РПД:** RPD-04

**Связанные страницы:** 4; **символов извлечённого текста:** 1615.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D17 — Week 2 Lecture.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=6`
Строки (ID элементов): D17:p0006:u0001, D17:p0006:u0002, D17:p0006:u0003, D17:p0006:u0004, D17:p0006:u0005, D17:p0006:u0006, D17:p0006:u0007, D17:p0006:u0008, D17:p0006:u0009, D17:p0006:u0010, D17:p0006:u0011, D17:p0006:u0012, D17:p0006:u0013, D17:p0006:u0014, D17:p0006:u0015, D17:p0006:u0016

````text
Alan Mathison Turing OBE FRS
- Born 23 June 1912 to an English civil servant for India
- Studied mathematics at King's College, Cambridge,
and was elected a fellow
- Developed the Universal Turing Machine as part of
the Church-Turing Thesis
- PhD from Princeton; offered a postdoctoral position by John von Neumann but
instead returns to England to Cambridge
- Went on to work at Bletchley Park
- Developed the Bombe decoder
- The Applications of Probability to Cryptography and Paper on Statistics of Repetitions
not released by UK Govt. for 70 years
- Developed and popularized the Turing Test
- Went on to studies of new computers, biology, and mathematics
- He was prosecuted in 1952, public government apology 2009, full pardon in 2013
- Died 1954 of cyanide poisoning (Apple) – most likely at his own hand
````

## D17 — Week 2 Lecture.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=7`
Строки (ID элементов): D17:p0007:u0001, D17:p0007:u0002, D17:p0007:u0003, D17:p0007:u0004, D17:p0007:u0005, D17:p0007:u0006, D17:p0007:u0007, D17:p0007:u0012, D17:p0007:u0014, D17:p0007:u0016, D17:p0007:u0017, D17:p0007:u0018
**Непроверенные OCR/формулы:** 12 исключённых из основного текста кандидатов; см. JSON.

````text
Turing Test
- Published in 1952
- Interrogator
- Human v. Computer
- Can the Interrogator detect the computer
- Solved in some limited areas
- Inverse of this test used as a human detector
MIND
A QUARTERLY REVIEW
PSYCHOLOGY AND PHILOSOPHY
1-COMPUTING MACHINERY AND
INTELLIGENCE
````

## D17 — Week 2 Lecture.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=8`
Строки (ID элементов): D17:p0008:u0001, D17:p0008:u0002, D17:p0008:u0003, D17:p0008:u0004, D17:p0008:u0005, D17:p0008:u0006, D17:p0008:u0007, D17:p0008:u0008, D17:p0008:u0009, D17:p0008:u0010, D17:p0008:u0011, D17:p0008:u0012, D17:p0008:u0013, D17:p0008:u0014, D17:p0008:u0020, D17:p0008:u0023, D17:p0008:u0029, D17:p0008:u0031
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
CAPTCHA aka Completely Automated
Public Turing test to tell Computers and
Humans Apart
- Utilized in a number of systems
- Email
- Online ordering
- Account creation
- Cost effective
- Has been utilized in order to
decode optical character
recognition (OCR) issues
- Other versions exist
- Audio CAPTCHA
- Picking right picture/photo
Prove you're not a robot
Mills,
Type the two pieces of text:
Cancel
````

## D17 — Week 2 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=9`
Строки (ID элементов): D17:p0009:u0001, D17:p0009:u0002, D17:p0009:u0003, D17:p0009:u0004, D17:p0009:u0005, D17:p0009:u0006, D17:p0009:u0012, D17:p0009:u0018
**Непроверенные OCR/формулы:** 11 исключённых из основного текста кандидатов; см. JSON.

````text
Computers don’t think like us?
- Image Recognition
- Segmentation
- Detection
- Conceptualization
- Verbalization
LIKE A
Human
````


---

# AI-01-08 — Аргумент китайской комнаты и возражения

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Объясни китайскую комнату, приведи одно содержательное возражение и ответ на него.
**Пункты РПД:** RPD-05

**Связанные страницы:** 4; **символов извлечённого текста:** 1191.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D17 — Week 2 Lecture.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=10`
Строки (ID элементов): D17:p0010:u0001, D17:p0010:u0002, D17:p0010:u0003
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Syntax v. Semantics
- Chair has a meaning conceptually and as
an object
````

## D17 — Week 2 Lecture.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=11`
Строки (ID элементов): D17:p0011:u0001, D17:p0011:u0002, D17:p0011:u0003, D17:p0011:u0004, D17:p0011:u0005, D17:p0011:u0006, D17:p0011:u0007, D17:p0011:u0008, D17:p0011:u0009, D17:p0011:u0010
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
Chinese Room Argument
- Thought experiment presented in 1980 by John Searle
- Imagine yourself as someone who has no knowledge of the language of
Chinese
- Rather easy for most of us – but feel free to substitute any language you don’t
know
- You are locked in the room with a large book of instructions, a pile of
paper, and two slots labeled in and out
- From the in slot comes a page of Chinese characters, the instructions tell
you what to do and to write before putting it on the out slot
````

## D17 — Week 2 Lecture.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=12`
Строки (ID элементов): D17:p0012:u0001, D17:p0012:u0002, D17:p0012:u0003, D17:p0012:u0004, D17:p0012:u0005, D17:p0012:u0006, D17:p0012:u0007

````text
Does This Mean That You KNOW
Chinese?
- You don’t know what the characters mean – semantics
- You know actions to be produced on symbols – syntax
- You will be slow to begin with, but as you learn the rule system you before
better and better at your actions
- This is how a computer makes actions. But is it all it does?
````

## D17 — Week 2 Lecture.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=13`
Строки (ID элементов): D17:p0013:u0001, D17:p0013:u0002, D17:p0013:u0003, D17:p0013:u0004, D17:p0013:u0005, D17:p0013:u0006, D17:p0013:u0007, D17:p0013:u0008

````text
Arguments Against the Room
- You are not processing meaningless symbols
- They have a meaning internally and a different external meaning
- This might be only part of the bigger system
- Many Chinese rooms
- Who writes the rule book?
- Can the rules be changed?
- Development of rules is now part of many AI
````


---

# AI-01-09 — Законы робототехники Азимова и их ограничения

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Разреши конфликт двух приказов роботу, используя иерархию законов, и укажи границу подхода.
**Пункты РПД:** RPD-07

**Связанные страницы:** 10; **символов извлечённого текста:** 1012.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D17 — Week 2 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=20`
Строки (ID элементов): D17:p0020:u0001, D17:p0020:u0003

````text
Laws of Robotics
20
````

## D17 — Week 2 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=21`
Строки (ID элементов): D17:p0021:u0001, D17:p0021:u0010
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
Isaac Asimov
4
````

## D17 — Week 2 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=22`
Строки (ID элементов): D17:p0022:u0001, D17:p0022:u0002, D17:p0022:u0003, D17:p0022:u0004, D17:p0022:u0005, D17:p0022:u0006, D17:p0022:u0007, D17:p0022:u0008

````text
“
”
A robot may not injure a
human being or, through
inaction, allow a human being
to come to harm.
LAW ONE – DO NO HARM
22
````

## D17 — Week 2 Lecture.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=23`
Строки (ID элементов): нет
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

*На привязанной странице нет текста в категории educational; проверь изображение слайда.*

## D17 — Week 2 Lecture.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=24`
Строки (ID элементов): D17:p0024:u0001, D17:p0024:u0002, D17:p0024:u0003, D17:p0024:u0004, D17:p0024:u0005, D17:p0024:u0006, D17:p0024:u0007, D17:p0024:u0008
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
“
”
A robot must obey the orders
given to it by human beings,
except where such orders would
conflict with the First Law.
LAW TWO – OBEY HUMANS
24
````

## D17 — Week 2 Lecture.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=25`
Строки (ID элементов): D17:p0025:u0005, D17:p0025:u0006, D17:p0025:u0007, D17:p0025:u0008
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
EEP
CALM
AND
AVOID
````

## D17 — Week 2 Lecture.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=26`
Строки (ID элементов): D17:p0026:u0001, D17:p0026:u0002, D17:p0026:u0003, D17:p0026:u0004, D17:p0026:u0005, D17:p0026:u0006, D17:p0026:u0007, D17:p0026:u0008

````text
“
”
A robot must protect its own
existence as long as such
protection does not conflict
with the First or Second Law.
LAW THREE – SELF-PRESERVATION
26
````

## D17 — Week 2 Lecture.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=27`
Строки (ID элементов): нет
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

*На привязанной странице нет текста в категории educational; проверь изображение слайда.*

## D17 — Week 2 Lecture.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=28`
Строки (ID элементов): D17:p0028:u0001, D17:p0028:u0002, D17:p0028:u0003, D17:p0028:u0004, D17:p0028:u0005, D17:p0028:u0006, D17:p0028:u0007
**Общая страница с:** AI-01-10

````text
Robots that Kill
- Where does this place military and police drones?
- Police/Military are required to use force which is reasonable at the time for the
action (police bound by constitutional laws and militaries by international law)
- Dallas police utilized a robot with a grenade strapped on it to subdue a suspect who
shot at officers
- Numerous militaries with semi-autonomous drones with missiles
````

## D17 — Week 2 Lecture.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=29`
Строки (ID элементов): D17:p0029:u0001, D17:p0029:u0002, D17:p0029:u0003, D17:p0029:u0004
**Общая страница с:** AI-01-10

````text
Zeroth Law
- A robot may not injure HUMANITY, or, through inaction, allow HUMANITY to
come to harm
- What does this say for ethical calculus?
````


---

# AI-01-10 — Этические риски автономных решений

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** частично; ядро
**Диагностический вопрос (черновик):** Разбери решение автономного робота с точки зрения ответственности, вреда и человеческого контроля.
**Пункты РПД:** RPD-42

**Связанные страницы:** 4; **символов извлечённого текста:** 1017.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=12`
Строки (ID элементов): D16:p0012:u0001, D16:p0012:u0002, D16:p0012:u0003, D16:p0012:u0004, D16:p0012:u0005, D16:p0012:u0006
**Общая страница с:** AI-10-07, AI-10-12

````text
Advantages
- Decreases the costs
- Increases effectiveness and efficiency
- Expanding creative possibilities
- Accessibility and democratization of technology
- …
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=13`
Строки (ID элементов): D16:p0013:u0001, D16:p0013:u0002, D16:p0013:u0003, D16:p0013:u0004, D16:p0013:u0005, D16:p0013:u0006, D16:p0013:u0007, D16:p0013:u0008, D16:p0013:u0009, D16:p0013:u0010, D16:p0013:u0011, D16:p0013:u0012, D16:p0013:u0013, D16:p0013:u0014, D16:p0013:u0015, D16:p0013:u0016, D16:p0013:u0017, D16:p0013:u0018, D16:p0013:u0019, D16:p0013:u0020, D16:p0013:u0021, D16:p0013:u0022
**Общая страница с:** AI-01-12, AI-10-08, AI-10-12

````text
Issues
- 
Quality and reliability of generated content
- Hallucinations
- 
Ethical issues
- Deepfakes
- 
Legal uncertainties
- 
Bias and discrimination
- 
Technical and resource limitations
- 
Overtraining and generalization
- 
Safety and Abuse
- 
Verification and trust issues
- Watermarks?
- 
Human substitution
````

## D17 — Week 2 Lecture.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=28`
Строки (ID элементов): D17:p0028:u0001, D17:p0028:u0002, D17:p0028:u0003, D17:p0028:u0004, D17:p0028:u0005, D17:p0028:u0006, D17:p0028:u0007
**Общая страница с:** AI-01-09

````text
Robots that Kill
- Where does this place military and police drones?
- Police/Military are required to use force which is reasonable at the time for the
action (police bound by constitutional laws and militaries by international law)
- Dallas police utilized a robot with a grenade strapped on it to subdue a suspect who
shot at officers
- Numerous militaries with semi-autonomous drones with missiles
````

## D17 — Week 2 Lecture.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=29`
Строки (ID элементов): D17:p0029:u0001, D17:p0029:u0002, D17:p0029:u0003, D17:p0029:u0004
**Общая страница с:** AI-01-09

````text
Zeroth Law
- A robot may not injure HUMANITY, or, through inaction, allow HUMANITY to
come to harm
- What does this say for ethical calculus?
````


---

# AI-01-11 — Справедливость, прозрачность и подотчётность ИИ

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** не найдено; ядро
**Диагностический вопрос (черновик):** Проанализируй ошибочную рекомендацию модели по критериям fairness, transparency и accountability.
**Пункты РПД:** RPD-42

**Исходный текст не найден.** В текущей карте отсутствуют ссылки на учебные материалы.
Текст не генерировался и не заменялся сведениями из РПД.


---

# AI-01-12 — Когнитивные искажения, надёжность данных и оценка выдачи ИИ

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** частично; ядро
**Диагностический вопрос (черновик):** Построй проверку ненадёжного результата ИИ с учётом источников, смещений и способов верификации.
**Пункты РПД:** —

**Связанные страницы:** 3; **символов извлечённого текста:** 916.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D01 — 14 Tutorial.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=9`
Строки (ID элементов): D01:p0009:u0001, D01:p0009:u0002, D01:p0009:u0003, D01:p0009:u0004, D01:p0009:u0005, D01:p0009:u0006
**Общая страница с:** AI-10-08, AI-10-12

````text
Limitations of Generative AI
- No real understanding – pattern matching, not reasoning like
humans
- Can hallucinate: invents facts, references, dates, locations
- Sensitive to prompt phrasing and hidden biases in training data
- Needs careful use and evaluation, especially in critical contexts
````

## D01 — 14 Tutorial.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=10`
Строки (ID элементов): D01:p0010:u0001, D01:p0010:u0002, D01:p0010:u0003, D01:p0010:u0004, D01:p0010:u0005, D01:p0010:u0006, D01:p0010:u0007, D01:p0010:u0008
**Общая страница с:** AI-10-10, AI-10-12

````text
Grounding the Model (RAG)
- Instead of letting the model invent answers, give it trusted
data
- Use event schedule, venue info, FAQs as context
- Retrieval-Augmented Generation (RAG):
- 1. Retrieve relevant documents
- 2. Feed them into the prompt as context
- 3. Ask the LLM to answer only from that context
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=13`
Строки (ID элементов): D16:p0013:u0001, D16:p0013:u0002, D16:p0013:u0003, D16:p0013:u0004, D16:p0013:u0005, D16:p0013:u0006, D16:p0013:u0007, D16:p0013:u0008, D16:p0013:u0009, D16:p0013:u0010, D16:p0013:u0011, D16:p0013:u0012, D16:p0013:u0013, D16:p0013:u0014, D16:p0013:u0015, D16:p0013:u0016, D16:p0013:u0017, D16:p0013:u0018, D16:p0013:u0019, D16:p0013:u0020, D16:p0013:u0021, D16:p0013:u0022
**Общая страница с:** AI-01-10, AI-10-08, AI-10-12

````text
Issues
- 
Quality and reliability of generated content
- Hallucinations
- 
Ethical issues
- Deepfakes
- 
Legal uncertainties
- 
Bias and discrimination
- 
Technical and resource limitations
- 
Overtraining and generalization
- 
Safety and Abuse
- 
Verification and trust issues
- Watermarks?
- 
Human substitution
````


---

# AI-01-13 — Высказывания и логические связки

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Переведи словесную задачу в формулы логики высказываний, пояснив каждую связку.
**Пункты РПД:** RPD-06

**Связанные страницы:** 10; **символов извлечённого текста:** 2854.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D06 — Tutorial 2.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=3`
Строки (ID элементов): D06:p0003:u0001, D06:p0003:u0002, D06:p0003:u0003, D06:p0003:u0004, D06:p0003:u0005, D06:p0003:u0006, D06:p0003:u0007, D06:p0003:u0008

````text
PROPOSITIONAL LOGIC
-
Sentences considered in propositional logic are not arbitrary
sentences but are the ones that are either true or false, but not both.
This kind of sentences are called propositions. By reading a
sentence and basing your conclusion directly from the facts
mentioned in the sentence only, you can conclude the truth or falsity
of the statement.
````

## D06 — Tutorial 2.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=4`
Строки (ID элементов): D06:p0004:u0001

````text
Examples ?? (Discussion)
````

## D06 — Tutorial 2.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=5`
Строки (ID элементов): D06:p0005:u0001, D06:p0005:u0002, D06:p0005:u0003, D06:p0005:u0004, D06:p0005:u0005, D06:p0005:u0006, D06:p0005:u0007

````text
Examples
- Grass is green
- 2 + 5 = 5
- x + 3 = 3
- x +3 > 5
- John is in the classroom.
- Mary is enrolled in 270A.
````

## D06 — Tutorial 2.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=6`
Строки (ID элементов): D06:p0006:u0001, D06:p0006:u0002, D06:p0006:u0003, D06:p0006:u0004, D06:p0006:u0005, D06:p0006:u0006, D06:p0006:u0007, D06:p0006:u0008, D06:p0006:u0009, D06:p0006:u0010, D06:p0006:u0011, D06:p0006:u0012, D06:p0006:u0013, D06:p0006:u0014, D06:p0006:u0015, D06:p0006:u0016, D06:p0006:u0017, D06:p0006:u0018

````text
•
A statement is a sentence that is either true or false, but not both.
•
Statements:
–
It is raining.
–
I am carrying an umbrella.
•
Non-statements:
–
a. (Question): Why are you late?
–
b. (Command): Open the door.
–
c. (Wish): If only I had studied a little harder…
–
d. (Something Vague): x + y = 4.
````

## D06 — Tutorial 2.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=7`
Строки (ID элементов): D06:p0007:u0001, D06:p0007:u0002, D06:p0007:u0003, D06:p0007:u0004, D06:p0007:u0005, D06:p0007:u0006, D06:p0007:u0007, D06:p0007:u0008, D06:p0007:u0009, D06:p0007:u0010, D06:p0007:u0011, D06:p0007:u0012, D06:p0007:u0013, D06:p0007:u0014, D06:p0007:u0015

````text
A compound statement is one with two or more simple statements as
parts - components. A component of a compound is any whole statement
that is part of a larger statement.
Simple sentences which are true or false are basic propositions.
Complex sentences are constructed from basic propositions by combining
them with connectives.
- propositions and connectives are the basic elements of propositional
logic.   Five basic connectives here:
IF and ONLY IF
IF_THEN
OR
AND
or ~
NOT
COMPOUND STATEMENTS
````

## D06 — Tutorial 2.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=8`
Строки (ID элементов): D06:p0008:u0001, D06:p0008:u0002, D06:p0008:u0003, D06:p0008:u0004, D06:p0008:u0005, D06:p0008:u0006, D06:p0008:u0007, D06:p0008:u0008, D06:p0008:u0009, D06:p0008:u0010, D06:p0008:u0011, D06:p0008:u0012, D06:p0008:u0013, D06:p0008:u0014, D06:p0008:u0015, D06:p0008:u0016, D06:p0008:u0017, D06:p0008:u0018, D06:p0008:u0019

````text
•
Binary operators
–
Conjunction – “and”.
–
Disjunction – “or”.
•
Unary operator
–
Negation – “not”.
•
Other operators
–
XOR – “exclusive or”
–
NAND – “not both”
–
NOR – “neither”
Logical Operators
````

## D06 — Tutorial 2.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=9`
Строки (ID элементов): D06:p0009:u0001, D06:p0009:u0002, D06:p0009:u0003, D06:p0009:u0004, D06:p0009:u0005, D06:p0009:u0006, D06:p0009:u0007, D06:p0009:u0008, D06:p0009:u0009, D06:p0009:u0010, D06:p0009:u0011

````text
Elements of Propositional Logic
Simple sentences.
A simple statement is one that does not contain any other statement
as a part. We will use the lower-case letters, p, q, r, ..., as symbols for
simple statements.
If p or q, then r
Therefore, if not r, then not p and not q.
E.g. If Jane is a math major or Jane is a computer science major, then
Jane will take Math 150.
Jane is a computer science major.
Therefore, Jane will take Math 150.
````

## D06 — Tutorial 2.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=10`
Строки (ID элементов): D06:p0010:u0001, D06:p0010:u0002, D06:p0010:u0003, D06:p0010:u0004, D06:p0010:u0005, D06:p0010:u0006, D06:p0010:u0007, D06:p0010:u0008, D06:p0010:u0009, D06:p0010:u0010, D06:p0010:u0011, D06:p0010:u0012

````text
Examples
• P means “It is hot.”
• Q means “It is humid.”
• R means “It is raining.”
• (P ∧Q) → R
“If it is hot and humid, then it is raining”
• Q → P
“If it is humid, then it is hot”
• A better way:
Hot = “It is hot”
Humid = “It is humid”
Raining = “It is raining”
````

## D06 — Tutorial 2.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=11`
Строки (ID элементов): D06:p0011:u0001, D06:p0011:u0002, D06:p0011:u0003, D06:p0011:u0004, D06:p0011:u0005, D06:p0011:u0006, D06:p0011:u0007, D06:p0011:u0008, D06:p0011:u0009, D06:p0011:u0010, D06:p0011:u0011, D06:p0011:u0012, D06:p0011:u0013, D06:p0011:u0014, D06:p0011:u0015

````text
Translation into Propositional Logic
•
If it rains, then the game will be cancelled.
•
If the game is cancelled, then we clean house.
•
Can we conclude?
– If it rains, then we clean house.
•
p = it rains,  q = game cancelled r = we clean house.
•
If p then q.               not p or q
•
If q then r.                not q or r
• if p then r.                 not p or r  (resolution)
````

## D06 — Tutorial 2.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=12`
Строки (ID элементов): D06:p0012:u0001, D06:p0012:u0002, D06:p0012:u0003, D06:p0012:u0004, D06:p0012:u0005, D06:p0012:u0006, D06:p0012:u0007, D06:p0012:u0008

````text
Translation into Propositional Logic
- Basic statements
➢p = “It is raining.”
➢q = “I am carrying an umbrella.”
- Compound statements
➢p ∧q = “It is raining and I am carrying an umbrella.”
➢p ∨q = “ It is raining or I am carrying an umbrella.”
➢~p = “It is not raining.”
````


---

# AI-01-14 — Таблицы истинности

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Построй и интерпретируй таблицу истинности составной формулы с тремя переменными.
**Пункты РПД:** RPD-06

**Связанные страницы:** 5; **символов извлечённого текста:** 2172.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D06 — Tutorial 2.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=13`
Строки (ID элементов): D06:p0013:u0001, D06:p0013:u0002, D06:p0013:u0003, D06:p0013:u0004, D06:p0013:u0005, D06:p0013:u0006, D06:p0013:u0007, D06:p0013:u0008, D06:p0013:u0009, D06:p0013:u0010, D06:p0013:u0011, D06:p0013:u0012, D06:p0013:u0013, D06:p0013:u0014, D06:p0013:u0015, D06:p0013:u0016, D06:p0013:u0017

````text
TRUTH VALUES
Each simple statement comprising a compound statement is a
statement in its own right, that is it has a truth value, that is it can be true
or false but not both.
The truth values of each individual statements affect the truth value of
the compound statement of which they are part of.
NEGATION
If p is a statement variable, the negation of p is “not p” or “It is
not the case that p” and is denoted as ~p. It has opposite truth values as
p. Wherever p is true, ~p is false and vice versa. The truth values for
negation summarized in a truth table are
p
~p
T
F
F
T
````

## D06 — Tutorial 2.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=14`
Строки (ID элементов): D06:p0014:u0001, D06:p0014:u0002, D06:p0014:u0003, D06:p0014:u0004, D06:p0014:u0005, D06:p0014:u0006, D06:p0014:u0007, D06:p0014:u0008, D06:p0014:u0009, D06:p0014:u0010, D06:p0014:u0011, D06:p0014:u0012, D06:p0014:u0013, D06:p0014:u0014, D06:p0014:u0015, D06:p0014:u0016, D06:p0014:u0017, D06:p0014:u0018, D06:p0014:u0019, D06:p0014:u0020

````text
If p and q are statement variables, the conjunction of p and q is “p and
q” denoted p       q. It is true when, and only when, both p and q are
true. If either p or q is false, or if both are false, p       q is false. The
truth values for and summarized in a truth table are
F
F
T
F
T
F
F
T
q
F
F
T
T
p     q
p
LOGICAL AND
````

## D06 — Tutorial 2.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=15`
Строки (ID элементов): D06:p0015:u0001, D06:p0015:u0002, D06:p0015:u0003, D06:p0015:u0004, D06:p0015:u0005, D06:p0015:u0006, D06:p0015:u0007, D06:p0015:u0008, D06:p0015:u0009, D06:p0015:u0010, D06:p0015:u0011, D06:p0015:u0012, D06:p0015:u0013, D06:p0015:u0014, D06:p0015:u0015, D06:p0015:u0016, D06:p0015:u0017, D06:p0015:u0018, D06:p0015:u0019, D06:p0015:u0020

````text
If p and q are statement variables, the disjunction of p and q is “p or q”
denoted p       q. It is true when at least one of  p or q is true and is false
only when both p and q are false. The truth values for p or q summarized
in a truth table are
T
F
T
T
T
F
F
T
q
F
F
T
T
p     q
p
LOGICAL OR
````

## D06 — Tutorial 2.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=16`
Строки (ID элементов): D06:p0016:u0001, D06:p0016:u0002, D06:p0016:u0003, D06:p0016:u0004, D06:p0016:u0005, D06:p0016:u0006, D06:p0016:u0007, D06:p0016:u0008, D06:p0016:u0009, D06:p0016:u0010, D06:p0016:u0011, D06:p0016:u0012, D06:p0016:u0013

````text
The general rule for constructing truth tables is:
1.
List all the variables mentioned in the statement in separate columns
and then list all the combinations of truth values for them.
2.
Add columns for operations mentioned in the statement with all the
combinations of truth values for them starting from inside out the
parenthesis if there exist any.
3.
Evaluate the final result
Exercise. Construct truth table for:
- p   OR (p  AND   q)
TRUTH TABLES
````

## D06 — Tutorial 2.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=17`
Строки (ID элементов): D06:p0017:u0001, D06:p0017:u0002, D06:p0017:u0003, D06:p0017:u0004, D06:p0017:u0005, D06:p0017:u0006, D06:p0017:u0007, D06:p0017:u0008, D06:p0017:u0009, D06:p0017:u0010, D06:p0017:u0011, D06:p0017:u0012, D06:p0017:u0013, D06:p0017:u0014

````text
The general rule for constructing truth tables is:
1.
List all the variables mentioned in the statement in separate columns
and then list all the combinations of truth values for them.
2.
Add columns for operations mentioned in the statement with all the
combinations of truth values for them starting from inside out the
parenthesis if there exist any.
3.
Evaluate the final result
Exercise. Construct truth table for:
- p   OR (p  AND   q)
Result: https://web.stanford.edu/class/cs103/tools/truth-table-tool/
TRUTH TABLES
````


---

# AI-01-15 — Логическая эквивалентность и законы преобразования

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Проверь эквивалентность двух формул и преобразуй одну в другую законами логики.
**Пункты РПД:** —

**Связанные страницы:** 15; **символов извлечённого текста:** 4563.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D06 — Tutorial 2.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=18`
Строки (ID элементов): D06:p0018:u0001, D06:p0018:u0002, D06:p0018:u0003, D06:p0018:u0004, D06:p0018:u0005, D06:p0018:u0006, D06:p0018:u0007, D06:p0018:u0008, D06:p0018:u0009, D06:p0018:u0010, D06:p0018:u0011, D06:p0018:u0012, D06:p0018:u0013

````text
- Two statements are said to be logically equivalent if and only if,
they’ve identical truth values for each possible substitution of
statements for their statement variables.
- It is denoted as
Follow this procedure:
- Construct the truth table for P
- Construct the truth table for Q using the same statement variables for
identical component statements.
- Check each combination of truth values of the statement variables:
a. If in each row the truth value of P is the same as the truth value
of Q, then P and Q are logically equivalent.
b. Otherwise, P and Q are not logically equivalent.
Logical Equivalence
````

## D06 — Tutorial 2.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=19`
Строки (ID элементов): D06:p0019:u0001, D06:p0019:u0002

````text
Are  (p ∧q) ∨(~p ∧~q) and  (p ∨~q) ∧
(~p ∨q) logically equivalent?
````

## D06 — Tutorial 2.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=20`
Строки (ID элементов): D06:p0020:u0001, D06:p0020:u0002, D06:p0020:u0003, D06:p0020:u0004, D06:p0020:u0005, D06:p0020:u0006, D06:p0020:u0007, D06:p0020:u0008, D06:p0020:u0009, D06:p0020:u0010, D06:p0020:u0011, D06:p0020:u0012, D06:p0020:u0013, D06:p0020:u0014, D06:p0020:u0015, D06:p0020:u0016, D06:p0020:u0017, D06:p0020:u0018, D06:p0020:u0019, D06:p0020:u0020, D06:p0020:u0021

````text
(p ∧q) ∨(~p ∧~q) ≡ (p ∨~q) ∧(~p ∨q)
p
q
(p ∧q) ∨(~p ∧~q)
(p ∨~q) ∧(~p ∨q)
T
T
T
T
T
F
F
F
F
T
F
F
F
F
T
T
````

## D06 — Tutorial 2.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=21`
Строки (ID элементов): D06:p0021:u0001, D06:p0021:u0002, D06:p0021:u0003, D06:p0021:u0004, D06:p0021:u0005

````text
•¬(p       q)       ¬p  V   ¬q  the negation of and is logically equivalent to
the or of the negated components
•¬(p  V     q)       ¬p     ¬q  the negation of oris logically equivalent to the
and of the negated components
De Morgan’s law
````

## D06 — Tutorial 2.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=22`
Строки (ID элементов): D06:p0022:u0001, D06:p0022:u0002, D06:p0022:u0003, D06:p0022:u0004, D06:p0022:u0005, D06:p0022:u0006, D06:p0022:u0007, D06:p0022:u0008, D06:p0022:u0009

````text
A tautology is a logical expression that is true regardless of the values of
its variables. Thus, for a tautology, the value of the expression is TRUE in
every row of the truth table. The column of a tautology in a truth table
contains only T's.
Example??
A proposition which is always false is called a contradiction. The column
of a contradiction in a truth table contains only F's.
Example??
Tautology and Contradiction
````

## D06 — Tutorial 2.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=23`
Строки (ID элементов): D06:p0023:u0001, D06:p0023:u0002, D06:p0023:u0003, D06:p0023:u0004, D06:p0023:u0005, D06:p0023:u0006, D06:p0023:u0007, D06:p0023:u0008, D06:p0023:u0009

````text
A tautology is a logical expression that is true regardless of the values of
its variables. Thus, for a tautology, the value of the expression is TRUE in
every row of the truth table. The column of a tautology in a truth table
contains only T's.
Example: P V (NOT P)
A proposition which is always false is called a contradiction. The column
of a contradiction in a truth table contains only F's.
Example: P ∧(NOT P)
Tautology and Contradiction
````

## D06 — Tutorial 2.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=24`
Строки (ID элементов): D06:p0024:u0001, D06:p0024:u0002, D06:p0024:u0003, D06:p0024:u0004, D06:p0024:u0005, D06:p0024:u0006, D06:p0024:u0007, D06:p0024:u0008, D06:p0024:u0009, D06:p0024:u0010, D06:p0024:u0011, D06:p0024:u0012, D06:p0024:u0013, D06:p0024:u0014, D06:p0024:u0015, D06:p0024:u0016, D06:p0024:u0017, D06:p0024:u0018, D06:p0024:u0019, D06:p0024:u0020, D06:p0024:u0021

````text
Conditional statements
If p and q are statement variables, the conditional of q by p is “if  p then
q” or “p implies q” and is denoted by         .
It is false when p is true and q is false.
A conditional statement is vacuously true or true by default if
its hypothesis is false.
T
T
F
T
F
F
F
F
T
T
T
T
p                        q
q
p
````

## D06 — Tutorial 2.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=25`
Строки (ID элементов): D06:p0025:u0001, D06:p0025:u0002, D06:p0025:u0003, D06:p0025:u0004, D06:p0025:u0005, D06:p0025:u0006, D06:p0025:u0007, D06:p0025:u0008, D06:p0025:u0009

````text
p → q ≡ ¬p V q
“If  p then q” is logically equivalent to “not p or  q”.
The negation of a conditional statement. The negation of “if p then q” is
logically equivalent to “p and not q”.
¬ (p → q) ≡ p ∧¬q
The proposition ¬q → ¬p is called the contrapositive of the proposition p
→ q. They are logically equivalent. p → q ≡ ¬q → ¬p
Symbolically the contrapositive of
A conditional statement is logically equivalent to its contrapositive.
````

## D06 — Tutorial 2.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=26`
Строки (ID элементов): D06:p0026:u0001, D06:p0026:u0003, D06:p0026:u0004, D06:p0026:u0007, D06:p0026:u0010, D06:p0026:u0012, D06:p0026:u0015, D06:p0026:u0019, D06:p0026:u0021, D06:p0026:u0022, D06:p0026:u0025, D06:p0026:u0033, D06:p0026:u0034, D06:p0026:u0035, D06:p0026:u0036
**Непроверенные OCR/формулы:** 21 исключённых из основного текста кандидатов; см. JSON.

````text
(aA B)
(av 8)
(8Va) commutativity of V
associativity of
associativity of V
a double-negation elimination
contraposition
implication elimination
((a > B)A(B => a))
biconditional elimination
De Morgan
distributivity of V over A
Figure 7.11
Standard logical equivalences. The symbols a, 3, and ¥ stand for arbitrary
sentences of propositional logic.
````

## D06 — Tutorial 2.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=27`
Строки (ID элементов): D06:p0027:u0001, D06:p0027:u0002, D06:p0027:u0003, D06:p0027:u0004, D06:p0027:u0005, D06:p0027:u0006, D06:p0027:u0007, D06:p0027:u0008, D06:p0027:u0009, D06:p0027:u0010, D06:p0027:u0011, D06:p0027:u0012, D06:p0027:u0013, D06:p0027:u0014, D06:p0027:u0015

````text
Propositional logic (Recap)
• Logical constants: true, false
• Propositional symbols: P, Q, S, ...  (atomic sentences)
• Wrapping parentheses: ( … )
• Sentences are combined by connectives:
∧...and
[conjunction]
∨...or
[disjunction]
⇒...implies [implication / conditional]
⇔..is equivalent
[biconditional]
¬ ...not
[negation]
• Literal: atomic sentence or negated atomic sentence
````

## D06 — Tutorial 2.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=28`
Строки (ID элементов): D06:p0028:u0001, D06:p0028:u0002, D06:p0028:u0003, D06:p0028:u0004, D06:p0028:u0005, D06:p0028:u0006, D06:p0028:u0007, D06:p0028:u0008, D06:p0028:u0009, D06:p0028:u0010, D06:p0028:u0011, D06:p0028:u0012, D06:p0028:u0013, D06:p0028:u0014, D06:p0028:u0015

````text
Propositional Logic  (Recap)
• A simple language useful for showing key ideas and definitions
• User defines a set of propositional symbols, like P and Q.
• User defines the semantics of each propositional symbol:
– P means “It is hot”
– Q means “It is humid”
– R means “It is raining”
• A sentence (well formed formula) is defined as follows:
– A symbol is a sentence
– If S is a sentence, then ¬S is a sentence
– If S is a sentence, then (S) is a sentence
– If S and T are sentences, then (S ∨T), (S ∧T), (S → T), and (S
T) are
sentences
– A sentence results from a finite number of applications of the above rules
````

## D06 — Tutorial 2.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=29`
Строки (ID элементов): D06:p0029:u0001, D06:p0029:u0002, D06:p0029:u0012, D06:p0029:u0013, D06:p0029:u0015, D06:p0029:u0016, D06:p0029:u0020, D06:p0029:u0022, D06:p0029:u0025, D06:p0029:u0027, D06:p0029:u0029, D06:p0029:u0032, D06:p0029:u0034
**Непроверенные OCR/формулы:** 24 исключённых из основного текста кандидатов; см. JSON.

````text
Truth tables
The five logical operators:
False
False
False
False
The
False
False
False
False
False
The
````

## D06 — Tutorial 2.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=30`
Строки (ID элементов): D06:p0030:u0001
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Truth Tables through SETs
````

## D06 — Tutorial 2.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=31`
Строки (ID элементов): D06:p0031:u0001, D06:p0031:u0002, D06:p0031:u0003

````text
Exercise
Are the statements P →(Q ∨R) and (P→Q)∨(P→R) logically
equivalent? Explain your answer.
````

## D06 — Tutorial 2.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=32`
Строки (ID элементов): D06:p0032:u0001, D06:p0032:u0002, D06:p0032:u0003, D06:p0032:u0004, D06:p0032:u0005, D06:p0032:u0006, D06:p0032:u0007, D06:p0032:u0008

````text
Exercise
Are the statements P →(Q ∨R)(1) and (P→Q)∨(P→R) (2)logically equivalent?
Explain your answer.
Solution 1. Truth Table.
Solution 2.
Step 1. (Implication Elimination) (1) P →(Q ∨R) ≡¬ p ∨(q ∧r).
Step 2. (Implication Elimination) (2) (p → q) ∧(p → r) ≡ (¬ p ∨q) ∧(¬ p ∨r)
Step 3. (Distribution law) (2) (¬ p ∨q) ∧(¬ p ∨r) ≡ ¬p ∨(q ∧r)  (1)
````


---

# AI-01-16 — Предикаты, отношения и формулы первого порядка

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Объясни, почему данное высказывание не выразить пропозиционально, и запиши его в FOL.
**Пункты РПД:** RPD-06

**Связанные страницы:** 13; **символов извлечённого текста:** 2777.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D06 — Tutorial 2.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=33`
Строки (ID элементов): D06:p0033:u0001, D06:p0033:u0002, D06:p0033:u0003

````text
How can we express “Every person is
mortal.”
with propositional logic?
````

## D06 — Tutorial 2.pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=34`
Строки (ID элементов): D06:p0034:u0001, D06:p0034:u0002, D06:p0034:u0003, D06:p0034:u0004, D06:p0034:u0005

````text
How can we express “Every person is
mortal.”
with propositional logic?
WE CAN NOT. WE NEED
FIRST-ORDER LOGIC!!!
````

## D06 — Tutorial 2.pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=35`
Строки (ID элементов): D06:p0035:u0001

````text
First-Order Logic
````

## D06 — Tutorial 2.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=36`
Строки (ID элементов): D06:p0036:u0001, D06:p0036:u0002, D06:p0036:u0003, D06:p0036:u0004, D06:p0036:u0005, D06:p0036:u0006, D06:p0036:u0007, D06:p0036:u0008, D06:p0036:u0009, D06:p0036:u0010, D06:p0036:u0011

````text
Propositional logic is a weak language
• Hard to identify “individuals” (e.g., Mary, 3)
• Can’t directly talk about properties of individuals or relations
between individuals (e.g., “Bill is tall”)
• Generalizations, patterns, regularities can’t easily be represented
(e.g., “all triangles have 3 sides”)
• First-Order Logic (abbreviated FOL) is expressive enough to
concisely represent this kind of information
FOL adds relations, variables, and quantifiers, e.g.,
• “Every elephant is gray”: ∀x (elephant(x) → gray(x))
• “There is a white alligator”: ∃x (alligator(X) ^ white(X))
````

## D06 — Tutorial 2.pdf, PDF-страница 37
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=37`
Строки (ID элементов): D06:p0037:u0001, D06:p0037:u0002, D06:p0037:u0003, D06:p0037:u0004, D06:p0037:u0005, D06:p0037:u0006, D06:p0037:u0007, D06:p0037:u0008, D06:p0037:u0009, D06:p0037:u0010, D06:p0037:u0011, D06:p0037:u0012, D06:p0037:u0013

````text
First-order logic
• First-order logic (FOL) models the world in terms of
– Objects, which are things with individual identities
– Properties of objects that distinguish them from others
– Relations that hold among sets of objects
– Functions, which are a subset of relations where there is only
one “value” for any given “input”
• Examples:
– Objects: Students, lectures, companies, cars ...
– Relations: Brother-of, bigger-than, outside, part-of, has-color,
occurs-after, owns, visits, precedes, ...
– Properties: blue, oval, even, large, ...
– Functions: father-of, best-friend, second-half, more-than ...
````

## D06 — Tutorial 2.pdf, PDF-страница 38
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=38`
Строки (ID элементов): D06:p0038:u0001, D06:p0038:u0002, D06:p0038:u0003, D06:p0038:u0004, D06:p0038:u0005, D06:p0038:u0006, D06:p0038:u0007, D06:p0038:u0008, D06:p0038:u0009, D06:p0038:u0010

````text
FOL Provides
• Variable symbols
–E.g., x, y, foo
• Connectives
–Same as in propositional logic: not (¬), and (∧), or (∨), implies
(→), iff (
)
• Quantifiers
–Universal ∀x or  (Ax)
–Existential ∃x or (Ex)
````

## D06 — Tutorial 2.pdf, PDF-страница 39
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=39`
Строки (ID элементов): D06:p0039:u0001, D06:p0039:u0002, D06:p0039:u0003, D06:p0039:u0004, D06:p0039:u0005, D06:p0039:u0006, D06:p0039:u0007, D06:p0039:u0008, D06:p0039:u0009, D06:p0039:u0010

````text
Sentences: built from terms and
atoms
• quantified sentences adds quantifiers ∀and ∃
–∀x loves(x, mother(x))
–∃x number(x) ∧greater(x, 100) ∧prime(x)
• A well-formed formula (wff) is a sentence containing no “free”
variables, i.e., all variables are “bound” by either a universal or
existential quantifiers
(∀x)P(x,y) has x bound as a universally quantified variable, but y
is free
````

## D17 — Week 2 Lecture.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=14`
Строки (ID элементов): D17:p0014:u0001, D17:p0014:u0003

````text
First-Order and Propositional Logic
14
````

## D17 — Week 2 Lecture.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=15`
Строки (ID элементов): D17:p0015:u0001, D17:p0015:u0002, D17:p0015:u0003, D17:p0015:u0004, D17:p0015:u0005, D17:p0015:u0006

````text
Why Do We Care?
- Utilized in a number of AI systems
- Allows us to have a basic idea of ‘knowledge’
- Categories
- Binary predicates
- Part of the set/Not part of the set
````

## D17 — Week 2 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=16`
Строки (ID элементов): D17:p0016:u0001, D17:p0016:u0002, D17:p0016:u0003, D17:p0016:u0004, D17:p0016:u0005, D17:p0016:u0006, D17:p0016:u0007, D17:p0016:u0008, D17:p0016:u0009, D17:p0016:u0010, D17:p0016:u0011, D17:p0016:u0012, D17:p0016:u0013, D17:p0016:u0014, D17:p0016:u0015, D17:p0016:u0016, D17:p0016:u0017, D17:p0016:u0018, D17:p0016:u0019, D17:p0016:u0020, D17:p0016:u0021

````text
Operations
- 
For Every ∀
- For Every X its value is 3; ∀x=3
- 
There exists ∃
- There is an X which is 3; ∃x=3
- 
Conjunction ∧
- X and Y; x ∧y
- 
Disjunction v
- X or Y; x v y
- 
Implication →
- If x then y; x → y
- 
Biconditional ↔
- X if and only if Y; x ↔y
- 
Such that (s.t.) or :
````

## D17 — Week 2 Lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=17`
Строки (ID элементов): D17:p0017:u0001, D17:p0017:u0002, D17:p0017:u0003, D17:p0017:u0004, D17:p0017:u0005

````text
Example Propositions
- REDHAIR(X) – X has red hair
- EVIL(X) – X is evil
- GLASSES(X) – X wears glasses
- FEMALE(X) – X is female
````

## D17 — Week 2 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=18`
Строки (ID элементов): D17:p0018:u0001, D17:p0018:u0002, D17:p0018:u0003, D17:p0018:u0004, D17:p0018:u0005, D17:p0018:u0006

````text
Example
- All female redheads are evil
- ∀X, REDHAIR(X) ∧FEMALE(X) → EVIL(X)
- ∀X FEMALE(X) → ∃X REDHAIR(X) ∨EVIL(X)
- For all females there exists one who has
red hair or who is evil
````

## D17 — Week 2 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/17_Week 2 Lecture/source.pdf#page=19`
Строки (ID элементов): нет

*На привязанной странице нет текста в категории educational; проверь изображение слайда.*


---

# AI-01-17 — Кванторы и области действия

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Переведи две фразы с разным порядком кванторов и покажи различие на модели.
**Пункты РПД:** RPD-06

**Связанные страницы:** 9; **символов извлечённого текста:** 3842.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D06 — Tutorial 2.pdf, PDF-страница 40
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=40`
Строки (ID элементов): D06:p0040:u0001, D06:p0040:u0002, D06:p0040:u0003, D06:p0040:u0004, D06:p0040:u0005, D06:p0040:u0006, D06:p0040:u0007, D06:p0040:u0008, D06:p0040:u0009, D06:p0040:u0010, D06:p0040:u0011

````text
Quantifiers
• Universal quantification
–(∀x)P(x) means P holds for all values of x in domain associated
with variable
–E.g., (∀x) dolphin(x) → mammal(x)
• Existential quantification
–(∃x)P(x) means P holds for some value of x in domain
associated with variable
–E.g., (∃x) mammal(x) ∧lays_eggs(x)
–This lets us make a statement about some object without
naming it
````

## D06 — Tutorial 2.pdf, PDF-страница 41
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=41`
Строки (ID элементов): D06:p0041:u0001, D06:p0041:u0002, D06:p0041:u0003, D06:p0041:u0004, D06:p0041:u0005, D06:p0041:u0006, D06:p0041:u0007, D06:p0041:u0008, D06:p0041:u0009, D06:p0041:u0010

````text
Quantifier Scope
• FOL sentences have structure, like programs
• In particular, the variables in a sentence have a scope
• For example, suppose we want to say
–“everyone who is alive loves someone”
–(∀x) alive(x) → (∃y) loves(x,y)
• Here’s how we scope the variables
(∀x) alive(x) → (∃y) loves(x,y)
Scope of x
Scope of y
````

## D06 — Tutorial 2.pdf, PDF-страница 42
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=42`
Строки (ID элементов): D06:p0042:u0001, D06:p0042:u0002, D06:p0042:u0003, D06:p0042:u0004, D06:p0042:u0005, D06:p0042:u0006, D06:p0042:u0007, D06:p0042:u0008, D06:p0042:u0009, D06:p0042:u0010, D06:p0042:u0011, D06:p0042:u0012, D06:p0042:u0013, D06:p0042:u0014

````text
Quantifier Scope
• Switching order of universal quantifiers does not change the
meaning
– (∀x)(∀y)P(x,y)
(∀y)(∀x) P(x,y)
– “Dogs hate cats” (i.e., “all dogs hate all cats”)
• You can switch order of existential quantifiers
– (∃x)(∃y)P(x,y)
(∃y)(∃x) P(x,y)
– “A cat killed a dog”
• Switching order of universal and existential quantifiers does
change meaning:
– Everyone likes someone: (∀x)(∃y) likes(x,y)
– Someone is liked by everyone: (∃y)(∀x) likes(x,y)
````

## D06 — Tutorial 2.pdf, PDF-страница 43
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=43`
Строки (ID элементов): D06:p0043:u0001, D06:p0043:u0002, D06:p0043:u0003, D06:p0043:u0004, D06:p0043:u0005, D06:p0043:u0006, D06:p0043:u0007, D06:p0043:u0008, D06:p0043:u0009, D06:p0043:u0010, D06:p0043:u0011, D06:p0043:u0012, D06:p0043:u0013, D06:p0043:u0014, D06:p0043:u0015, D06:p0043:u0016, D06:p0043:u0017, D06:p0043:u0018, D06:p0043:u0019, D06:p0043:u0020
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
Connections between ∀and ∃
• We can relate sentences involving ∀and ∃using extensions to  De
Morgan’s laws:
1.(∀x) ¬P(x)
¬(∃x) P(x)
2.¬(∀x) P
(∃x) ¬P(x)
3.(∀x) P(x)
¬ (∃x) ¬P(x)
4.(∃x) P(x)
¬(∀x) ¬P(x)
• Examples
1. All dogs don’t like cats
No dogs like cats
2. Not all dogs dance
There is a dog that doesn’t dance
3. All dogs sleep
There is no dog that doesn’t sleep
4. There is a dog that talks
Not all dogs can’t talk
````

## D06 — Tutorial 2.pdf, PDF-страница 44
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=44`
Строки (ID элементов): D06:p0044:u0001, D06:p0044:u0002, D06:p0044:u0003, D06:p0044:u0004

````text
Exercise I
Translate these English statements into First Order Logic.
1. Every student takes Introduction to AI.
2. There is some course that every student has not taken.
````

## D06 — Tutorial 2.pdf, PDF-страница 45
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=45`
Строки (ID элементов): D06:p0045:u0001, D06:p0045:u0002, D06:p0045:u0003, D06:p0045:u0004, D06:p0045:u0005, D06:p0045:u0006

````text
Exercise I  - Solutions
Translate these English statements into First Order Logic.
1. Every student takes Introduction to AI.
Solution: ∀x, Student(x) => Takes(x, Introduction to AI)
2. There is some course that every student has not taken.
Solution:  ∃x, Course (x) [∀y, Student(y)=> ¬Taken (y, x)]
````

## D06 — Tutorial 2.pdf, PDF-страница 46
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=46`
Строки (ID элементов): D06:p0046:u0001, D06:p0046:u0002, D06:p0046:u0003, D06:p0046:u0004, D06:p0046:u0005, D06:p0046:u0006, D06:p0046:u0007, D06:p0046:u0008, D06:p0046:u0009, D06:p0046:u0010, D06:p0046:u0011, D06:p0046:u0012

````text
Exercise II
This exercise uses the function  Borders(x,y) and Country(x) whose
arguments are geographical regions, along with constant symbols
for various regions. We give an English sentence and a number of
candidate logical expressions. For each of the logical expressions,
state whether it (1) correctly expresses the English sentence; or (2)
is syntactically valid but does not express the meaning of the
English sentence.
All countries that border Ecuador are in South America.
1.  ∀cCountry(c)∧Border(c,Ecuador)∧In(c,SouthAmerica)
2.  ∀cCountry(c)∧Border(c,Ecuador)⇒In(c,SouthAmerica)
3.  ∀cCountry(c)⇒[Border(c,Ecuador)⇒In(c,SouthAmerica)]
````

## D06 — Tutorial 2.pdf, PDF-страница 47
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=47`
Строки (ID элементов): D06:p0047:u0001, D06:p0047:u0002, D06:p0047:u0003, D06:p0047:u0004, D06:p0047:u0005, D06:p0047:u0006, D06:p0047:u0007, D06:p0047:u0008, D06:p0047:u0009, D06:p0047:u0010, D06:p0047:u0011, D06:p0047:u0012

````text
1. ∀cCountry(c)∧Border(c,Ecuador)∧In(c,SouthAmerica)
Answer: Does not correctly express the sentence. It reads:
“Every country borders Ecuador and is in South America”
2.  ∀cCountry(c)∧Border(c,Ecuador)⇒In(c,SouthAmerica)
Answer: Correctly express the English sentence.
3.  ∀cCountry(c)⇒[Border(c,Ecuador)⇒In(c,SouthAmerica)] ≡
∀c  ¬Country(c) V [¬Border(c,Ecuador) V In(c,SouthAmerica)] ≡
∀c  [¬Country(c) V ¬Border(c,Ecuador)] V In(c,SouthAmerica) ≡
∀c ¬ [(Country(c) ∧¬Border(c,Ecuador)] V In(c,SouthAmerica) ≡
∀cCountry(c)∧Border(c,Ecuador)⇒In(c,SouthAmerica) -
Answer: Equivalent with 2.
Exercise II - Solution
````

## D06 — Tutorial 2.pdf, PDF-страница 48
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=48`
Строки (ID элементов): D06:p0048:u0001, D06:p0048:u0002, D06:p0048:u0003, D06:p0048:u0004, D06:p0048:u0005, D06:p0048:u0006, D06:p0048:u0007, D06:p0048:u0008, D06:p0048:u0009, D06:p0048:u0010, D06:p0048:u0011, D06:p0048:u0012

````text
Exercise III
(a) If a person is 18 years or older, then he/she is eligible to vote.
(b) (b) A person does not graduate from high school if he/she is not
at least 18 years old.
(c) (c) Sarah is a person and she attended the high school graduation
ceremony last week.
(d)
(d) If a person completes high school graduation requirements,
then he/she is considered to be graduated from high school.
(e) (e) if a high school student attends the graduation ceremony, then
the student has completed high school graduation requirements.
Is Sarah eligible to vote?
````


---

# AI-01-18 — Корректность логического вывода

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Построй доказательство следствия из базы знаний и обоснуй применённые правила.
**Пункты РПД:** —

**Связанные страницы:** 29; **символов извлечённого текста:** 10292.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D06 — Tutorial 2.pdf, PDF-страница 49
Источник в ZIP: `AI_course_cleaned/06_Tutorial 2/source.pdf#page=49`
Строки (ID элементов): D06:p0049:u0001, D06:p0049:u0002, D06:p0049:u0003, D06:p0049:u0004, D06:p0049:u0005, D06:p0049:u0006, D06:p0049:u0007
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.

````text
Logic Puzzle
1. Adam doesn’t live on the top floor
2. Bill doesn’t live on the bottom floor
3. Claire doesn’t live on either the top or the buttom floor
4. David lives on a higher floor than Bill’s
5. Eric doesn’t live on a floor adjacent to Claire’s
6. Claire doesn’t live on a floor adjacent to Bill’s
````

## D07 — Tutorial 3.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=3`
Строки (ID элементов): D07:p0003:u0001, D07:p0003:u0002, D07:p0003:u0003, D07:p0003:u0004, D07:p0003:u0005, D07:p0003:u0006

````text
Types of reasoning
Deductive Reasoning: Using general statements to draw specific conclusions with
certainty.
Inductive Reasoning: a method of drawing conclusions by going from the specific to the
general. (bottom-up approach)
Counterexamples: Providing a specific example that disproves a universal statement.
````

## D07 — Tutorial 3.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=4`
Строки (ID элементов): D07:p0004:u0001, D07:p0004:u0003, D07:p0004:u0004, D07:p0004:u0005, D07:p0004:u0006, D07:p0004:u0007, D07:p0004:u0008, D07:p0004:u0009, D07:p0004:u0010

````text
Logic Proof Techniques
Constructing a step-by-step logical
argument to prove a given statement
directly.
Assuming the negation of the statement
and deriving a contradiction to prove
the original statement.
Breaking the proof into different cases
and proving each case individually.
````

## D07 — Tutorial 3.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=5`
Строки (ID элементов): D07:p0005:u0001, D07:p0005:u0002, D07:p0005:u0003, D07:p0005:u0004, D07:p0005:u0005, D07:p0005:u0006

````text
Induction: Example in Mathematics
Principle of Induction. Let 𝑃be any property of natural numbers.
Suppose P holds of zero, and whenever
P holds of a natural number n, then it holds of its successor,  𝑛+1.
Then 𝑃holds of every natural number.
Theorem. For every natural number 𝑛,  1+2+…+2𝑛=2𝑛+1−1.
````

## D07 — Tutorial 3.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=6`
Строки (ID элементов): D07:p0006:u0001, D07:p0006:u0002, D07:p0006:u0005, D07:p0006:u0006, D07:p0006:u0007, D07:p0006:u0009, D07:p0006:u0010
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Example in Mathematics (2)
Theorem. For every natural number 𝑛,  1+2+…+2𝑛=2𝑛+1−1.
Proof. We prove this by induction on n. In the base case, when n = 0, we have 1 = 2°+! — 1, as
required.
For the induction step, fix n, and assume the inductive hypothesis
We need to show that this same claim holds with n replaced by n + 1. But this is just a
calculation:
````

## D07 — Tutorial 3.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=7`
Строки (ID элементов): D07:p0007:u0001, D07:p0007:u0002, D07:p0007:u0003, D07:p0007:u0004, D07:p0007:u0005, D07:p0007:u0006, D07:p0007:u0007

````text
Deduction Reasoning
In a simple deductive logic argument, you’ll often begin with a
premise, and add another premise. Then, you form a conclusion
based on these two premises. This format is called “premise-
premise-conclusion.”
Here, A proof is an argument from hypotheses (assumptions) to a
conclusion. Each step of the argument follows the laws of logic.
````

## D07 — Tutorial 3.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=8`
Строки (ID элементов): D07:p0008:u0001, D07:p0008:u0002, D07:p0008:u0003, D07:p0008:u0004, D07:p0008:u0005, D07:p0008:u0006, D07:p0008:u0007, D07:p0008:u0008, D07:p0008:u0009

````text
Axioms and theorems
• Axioms are facts and rules that attempt to capture all of the
(important) facts and concepts about a domain; axioms can be
used to prove theorems
– Mathematicians don’t want any unnecessary (dependent)
axioms –ones that can be derived from other axioms
– Dependent axioms can make reasoning faster, however
– Choosing a good set of axioms for a domain is a kind of
design problem
````

## D07 — Tutorial 3.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=9`
Строки (ID элементов): нет

*На привязанной странице нет текста в категории educational; проверь изображение слайда.*

## D07 — Tutorial 3.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=10`
Строки (ID элементов): D07:p0010:u0001, D07:p0010:u0002, D07:p0010:u0003, D07:p0010:u0004, D07:p0010:u0005, D07:p0010:u0006, D07:p0010:u0007, D07:p0010:u0008, D07:p0010:u0009

````text
• Model: an interpretation of a set of sentences where every sentence is
True. (a possible world).
• E.g.having x men and y women sitting at a table playing bridge, and the
sentence x + y = 4 is true when there are four people in total. Formally,
the possible models are just all possible assignments of real numbers to
the variables x and y. Each such assignment fixes the truth of any
sentence of arithmetic whose variables are x and y. If a sentence α is
true in model m, we say that m satisfies α or m is a model of α.
GENERAL CONCEPTS
````

## D07 — Tutorial 3.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=11`
Строки (ID элементов): D07:p0011:u0001, D07:p0011:u0002, D07:p0011:u0003, D07:p0011:u0004, D07:p0011:u0005, D07:p0011:u0006, D07:p0011:u0007, D07:p0011:u0008, D07:p0011:u0009, D07:p0011:u0010, D07:p0011:u0011

````text
• A sentence is
– satisfiable if it is true under some interpretation
– valid if it is true under all possible interpretations
– inconsistent if there does not exist any interpretation under which the
sentence is true
• Logical consequence: S |= X if all models of S are also
models of X
–
involves the relation of logical entailment between sentences—the idea
that a sentence follows logically from another sentence.
GENERAL CONCEPTS (2)
````

## D07 — Tutorial 3.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=12`
Строки (ID элементов): D07:p0012:u0001, D07:p0012:u0002, D07:p0012:u0003, D07:p0012:u0004, D07:p0012:u0005, D07:p0012:u0006, D07:p0012:u0007, D07:p0012:u0008, D07:p0012:u0009

````text
Entailment and derivation
• Entailment: KB |= Q
– Q is entailed by KB (a set of premises or assumptions) if and only if
there is no logically possible world in which Q is false while all the
premises in KB are true.
• Derivation: KB |- Q
– We can derive Q from KB if there is a proof consisting of a
sequence of valid inference steps starting from the premises in KB
and resulting in Q
````

## D07 — Tutorial 3.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=13`
Строки (ID элементов): D07:p0013:u0001, D07:p0013:u0002, D07:p0013:u0003, D07:p0013:u0004, D07:p0013:u0005, D07:p0013:u0006, D07:p0013:u0007, D07:p0013:u0008, D07:p0013:u0009, D07:p0013:u0010

````text
Two important properties for inference
Soundness: If KB |- Q then KB |= Q
– If Q is derived from a set of sentences KB using a given set of rules
of inference, then Q is entailed by KB.
– Soundness: only true statements can be proven using the inference
rules.
Completeness: If KB |= Q then KB |- Q
– If Q is entailed by a set of sentences KB, then Q can be derived from
KB using the rules of inference.
– Completeness guarantees that we can prove everything that is true
````

## D07 — Tutorial 3.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=14`
Строки (ID элементов): D07:p0014:u0001, D07:p0014:u0002, D07:p0014:u0003, D07:p0014:u0004, D07:p0014:u0005, D07:p0014:u0006, D07:p0014:u0007, D07:p0014:u0008

````text
Basic rules of inferences
Modus Ponens: If P implies Q, and P is true, then Q is true.
Modus Tollens: If P implies Q, and Q is false, then P is false.
Constructing a Conjunction: If P is true and Q is true, then P and Q is true.
Rule of Simplification: If P and Q is true, then P is true.
Rule of Addition: If P is true, then P or Q is true.
Rule of Disjunctive Syllogism: If P or Q is true, and P is false, then Q is true.
Rule of Hypothetical Syllogism: If P implies Q, and Q implies R, then P implies R.
````

## D07 — Tutorial 3.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=15`
Строки (ID элементов): D07:p0015:u0001, D07:p0015:u0002, D07:p0015:u0003, D07:p0015:u0004, D07:p0015:u0005, D07:p0015:u0006, D07:p0015:u0007, D07:p0015:u0008, D07:p0015:u0009, D07:p0015:u0010, D07:p0015:u0011, D07:p0015:u0012, D07:p0015:u0013, D07:p0015:u0014, D07:p0015:u0015, D07:p0015:u0016, D07:p0015:u0017, D07:p0015:u0018, D07:p0015:u0019, D07:p0015:u0020, D07:p0015:u0021, D07:p0015:u0022

````text
Some of the rules of inference
• Each can be shown to be sound using a truth table
RULE
PREMISE
CONCLUSION
Modus Ponens
A, A → B
B
And Introduction
A, B
A ∧B
And Elimination
A ∧B
A
Double Negation
¬¬A
A
Unit Resolution
A ∨B, ¬B
A
Resolution
A ∨B, ¬B ∨C      A ∨C
````

## D07 — Tutorial 3.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=16`
Строки (ID элементов): D07:p0016:u0001, D07:p0016:u0002, D07:p0016:u0003, D07:p0016:u0004

````text
Example of Modus Ponens
Premise 1: (A ∨¬B) → ¬ C
Premise 2: ¬D
Premise 3: (A ∨¬B)
````

## D07 — Tutorial 3.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=17`
Строки (ID элементов): D07:p0017:u0001, D07:p0017:u0002, D07:p0017:u0003, D07:p0017:u0004, D07:p0017:u0005

````text
Example of Modus Ponens
Premise 1: (A ∨¬B) → ¬ C
Premise 2: ¬D
Premise 3: (A ∨¬B)
Conclusion: ¬C (Modus Ponens (1,3))
````

## D07 — Tutorial 3.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=18`
Строки (ID элементов): D07:p0018:u0001, D07:p0018:u0002, D07:p0018:u0003, D07:p0018:u0004, D07:p0018:u0005, D07:p0018:u0006, D07:p0018:u0007, D07:p0018:u0008, D07:p0018:u0009, D07:p0018:u0010, D07:p0018:u0011, D07:p0018:u0012, D07:p0018:u0013, D07:p0018:u0014, D07:p0018:u0015, D07:p0018:u0016, D07:p0018:u0017, D07:p0018:u0018, D07:p0018:u0019, D07:p0018:u0020, D07:p0018:u0021

````text
Soundness of modus ponens
√
√
√
√
OK?
True
False
False
True
True
False
False
False
True
True
True
True
A → B
B
A
````

## D07 — Tutorial 3.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=19`
Строки (ID элементов): D07:p0019:u0001, D07:p0019:u0002, D07:p0019:u0006, D07:p0019:u0009, D07:p0019:u0010, D07:p0019:u0011, D07:p0019:u0014, D07:p0019:u0015, D07:p0019:u0017, D07:p0019:u0018, D07:p0019:u0021, D07:p0019:u0023, D07:p0019:u0025, D07:p0019:u0026, D07:p0019:u0027, D07:p0019:u0031, D07:p0019:u0032, D07:p0019:u0035, D07:p0019:u0041, D07:p0019:u0047, D07:p0019:u0051, D07:p0019:u0052, D07:p0019:u0055, D07:p0019:u0056
**Непроверенные OCR/формулы:** 30 исключённых из основного текста кандидатов; см. JSON.

````text
Soundness of the
resolution inference rule
ave
False
False
Fulse
False
False
Thte
False
False
False
False
False
Fulse
Tre
True
False
Thte
False
Trite
Thte
Trite
Trite
````

## D07 — Tutorial 3.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=20`
Строки (ID элементов): D07:p0020:u0001, D07:p0020:u0002, D07:p0020:u0003, D07:p0020:u0004, D07:p0020:u0005

````text
Exercise I
Premise 1: ¬A → (C ∧D)
Premise 2: A  → B.
Premise 3: ¬B
Prove: C.
````

## D07 — Tutorial 3.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=21`
Строки (ID элементов): D07:p0021:u0001, D07:p0021:u0002, D07:p0021:u0003, D07:p0021:u0004, D07:p0021:u0005

````text
Exercise II
Premise 1: ¬(A V B) → C
Premise 2: ¬A
Premise 3: ¬C
Prove: B.
````

## D07 — Tutorial 3.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=22`
Строки (ID элементов): D07:p0022:u0001, D07:p0022:u0002, D07:p0022:u0003, D07:p0022:u0004, D07:p0022:u0005, D07:p0022:u0006, D07:p0022:u0007, D07:p0022:u0008, D07:p0022:u0009, D07:p0022:u0010, D07:p0022:u0011, D07:p0022:u0012, D07:p0022:u0013, D07:p0022:u0014, D07:p0022:u0015, D07:p0022:u0016, D07:p0022:u0017, D07:p0022:u0018, D07:p0022:u0019, D07:p0022:u0020, D07:p0022:u0021, D07:p0022:u0022, D07:p0022:u0023, D07:p0022:u0024, D07:p0022:u0025, D07:p0022:u0026, D07:p0022:u0027, D07:p0022:u0028, D07:p0022:u0029, D07:p0022:u0030, D07:p0022:u0031, D07:p0022:u0032

````text
Exercise III
Suppose we have the following scenario with a large knowledge base (KB) consisting of
the following statements:
1.
If it is raining, then the streets are wet.
2.
If the streets are wet, then people use umbrellas.
3.
It is raining.
4.
All dogs are mammals.
5.
All mammals have hair.
6.
Some animals have fur.
7.
All birds have feathers.
8.
Penguins are birds.
9.
Penguins cannot fly.
10. All fruits have seeds.
11. Apples are fruits.
12. Oranges are fruits.
13. Bananas are fruits.
14. All vegetables are healthy.
15. Spinach is a vegetable.
16. Carrots are vegetables.
17. Broccoli is a vegetable.
18. All cars have wheels.
19. A Tesla is a car.
20. Teslas are electric vehicles.
````

## D07 — Tutorial 3.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=23`
Строки (ID элементов): D07:p0023:u0001, D07:p0023:u0002, D07:p0023:u0003, D07:p0023:u0004, D07:p0023:u0005, D07:p0023:u0006, D07:p0023:u0007, D07:p0023:u0008, D07:p0023:u0009, D07:p0023:u0010, D07:p0023:u0011, D07:p0023:u0012, D07:p0023:u0013, D07:p0023:u0014, D07:p0023:u0015, D07:p0023:u0016, D07:p0023:u0017, D07:p0023:u0018, D07:p0023:u0019, D07:p0023:u0020, D07:p0023:u0021, D07:p0023:u0022, D07:p0023:u0023, D07:p0023:u0024, D07:p0023:u0025, D07:p0023:u0026, D07:p0023:u0027, D07:p0023:u0028, D07:p0023:u0029, D07:p0023:u0030, D07:p0023:u0031, D07:p0023:u0032, D07:p0023:u0033, D07:p0023:u0034, D07:p0023:u0035, D07:p0023:u0036, D07:p0023:u0037, D07:p0023:u0038, D07:p0023:u0039, D07:p0023:u0040, D07:p0023:u0041, D07:p0023:u0042, D07:p0023:u0043, D07:p0023:u0044, D07:p0023:u0045, D07:p0023:u0046, D07:p0023:u0047, D07:p0023:u0048, D07:p0023:u0049, D07:p0023:u0050, D07:p0023:u0051, D07:p0023:u0052, D07:p0023:u0053

````text
Exercise III
Suppose we have the following scenario with a large knowledge base (KB) consisting of the following statements:
1.
If it is raining, then the streets are wet.
2.
If the streets are wet, then people use umbrellas.
3.
It is raining.
4.
All dogs are mammals.
5.
All mammals have hair.
6.
Some animals have fur.
7.
All birds have feathers.
8.
Penguins are birds.
9.
Penguins cannot fly.
10.
All fruits have seeds.
11.
Apples are fruits.
12.
Oranges are fruits.
13.
Bananas are fruits.
14.
All vegetables are healthy.
15.
Spinach is a vegetable.
16.
Carrots are vegetables.
17.
Broccoli is a vegetable.
18.
All cars have wheels.
19.
A Tesla is a car.
20.
Teslas are electric vehicles.
Prove the statements:
- 
People are using umbrellas because it is raining.
- 
Penguins have feathers.
- 
Spinach is healthy.
- 
All dogs have hair.
- 
Penguins cannot fly.
````

## D07 — Tutorial 3.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=24`
Строки (ID элементов): D07:p0024:u0001, D07:p0024:u0002, D07:p0024:u0003, D07:p0024:u0004, D07:p0024:u0005, D07:p0024:u0006

````text
Exercise IV
If the unicorn is mythical, then it is immortal, but if it is not mythical,
then it is a mortal mammal. If the unicorn is either immortal or a
mammal, then it is horned. The unicorn is magical if it is horned.
Given the above, can you prove that the unicorn is mythical? How
about magical? Horned?
````

## D07 — Tutorial 3.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=25`
Строки (ID элементов): D07:p0025:u0001, D07:p0025:u0002, D07:p0025:u0003, D07:p0025:u0004, D07:p0025:u0005, D07:p0025:u0006, D07:p0025:u0007, D07:p0025:u0008, D07:p0025:u0009, D07:p0025:u0010, D07:p0025:u0011, D07:p0025:u0012, D07:p0025:u0013, D07:p0025:u0014

````text
Solution.
Propositional logic statements of the given facts:
(1) Mythical → ¬Mortal
(2) ¬Mythical → Mortal ∧Mammal
(3) ¬Mortal ∨Mammal → Horned
(4) Horned → Magical
We show how inference is done by direct application.
(5) ¬Mythical ∨¬Mortal From (1)
(6a) (Mythical ∨Mortal) From (2)
(6b) (Mythical ∨Mammal) From (2)
(7) ¬Mortal ∨Mammal Resolution on (5) and (6b)
(8) Horned Modus Ponens on (3) and (7)
(9) Magical Modus Ponens on (4) and (8) Thus the unicorn is both
magical and horned.
````

## D07 — Tutorial 3.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=26`
Строки (ID элементов): D07:p0026:u0001, D07:p0026:u0002, D07:p0026:u0003, D07:p0026:u0004

````text
Necessary and sufficient conditions
• A necessary condition must be satisfied for a statement to be true.
• A sufficient condition, if satisfied, assures the statement’s truth.
• Duality:  “P is sufficient for Q” is the same as “Q is necessary for P.”
````

## D07 — Tutorial 3.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=27`
Строки (ID элементов): D07:p0027:u0001, D07:p0027:u0002, D07:p0027:u0003, D07:p0027:u0004, D07:p0027:u0005, D07:p0027:u0006, D07:p0027:u0007, D07:p0027:u0008, D07:p0027:u0009, D07:p0027:u0010, D07:p0027:u0011, D07:p0027:u0012, D07:p0027:u0013, D07:p0027:u0014, D07:p0027:u0015, D07:p0027:u0016, D07:p0027:u0017, D07:p0027:u0018, D07:p0027:u0019, D07:p0027:u0020

````text
Necessary and sufficient conditions
P(x)
S(x)
S(x) is a
necessary
condition of P(x)
(∀x) P(x) => S(x)
S(x)
P(x)
S(x) is a
sufficient
condition of P(x)
(∀x) P(x) <= S(x)
P(x)
S(x)
S(x) is a
necessary and
sufficient
condition of P(x)
(∀x) P(x) <=> S(x)
````

## D07 — Tutorial 3.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=28`
Строки (ID элементов): D07:p0028:u0001, D07:p0028:u0002, D07:p0028:u0003, D07:p0028:u0004, D07:p0028:u0005, D07:p0028:u0006, D07:p0028:u0007, D07:p0028:u0008, D07:p0028:u0009, D07:p0028:u0010, D07:p0028:u0011, D07:p0028:u0012, D07:p0028:u0013, D07:p0028:u0014, D07:p0028:u0015, D07:p0028:u0016, D07:p0028:u0017

````text
Common mistakes to avoid in Rules of
Inference and Logic Proofs
1.
Starting with a false premise: If you start with a false premise, you can prove anything. It is important to ensure that
your premises are true before proceeding with the proof.
2.
The fallacy of equivocation: Errors can result from using undefined symbols, misplacing parentheses, or using
symbols incorrectly. Using a term with multiple meanings inconsistently throughout an argument.
3.
The fallacy of affirming the consequent: Using the wrong rule of inference can lead to an incorrect conclusion. It is
important to understand the different rules of inference and when to use them.
4.
Failing to justify each step: Each step of the argument must follow the laws of logic. It is important to justify each
step of the proof to ensure that it is valid.
5.
Making errors in form: When dealing with arguments in natural language, making errors in form is quite common. It
is important to be familiar with the different forms of arguments and to ensure that the form of your argument is valid.
````

## D07 — Tutorial 3.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=29`
Строки (ID элементов): D07:p0029:u0001, D07:p0029:u0002, D07:p0029:u0003, D07:p0029:u0004, D07:p0029:u0005, D07:p0029:u0006, D07:p0029:u0007, D07:p0029:u0008, D07:p0029:u0009, D07:p0029:u0010

````text
Summary
• The process of deriving new sentences from old one is called
inference.
– Sound inference processes derives true conclusions given true
premises
– Complete inference processes derive all true conclusions from a
set of premises
• A valid sentence is true in all worlds under all interpretations
• If an implication sentence can be shown to be valid, then—given its
premise—its consequent can be derived
````

## D07 — Tutorial 3.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=30`
Строки (ID элементов): D07:p0030:u0001, D07:p0030:u0002, D07:p0030:u0003, D07:p0030:u0004, D07:p0030:u0005, D07:p0030:u0006, D07:p0030:u0007, D07:p0030:u0008, D07:p0030:u0009

````text
Summary
• Different logics make different commitments about what the world
is made of and what kind of beliefs we can have regarding the facts
• Propositional logic commits only to the existence of facts that may
or may not be the case in the world being represented
– It has a simple syntax and simple semantics. It suffices to
illustrate the process of inference
– Propositional logic quickly becomes impractical, even for very
small worlds
````


---

# AI-01-19 — Исторические и культурные образы искусственного разума

**Раздел РПД:** 1. Введение в искусственный интеллект
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Сопоставь древний образ искусственного существа с современным агентом и объясни принципиальное различие.
**Пункты РПД:** —

**Связанные страницы:** 1; **символов извлечённого текста:** 404.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D27 — week1 lecture.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/27_week1 lecture/source.pdf#page=26`
Строки (ID элементов): D27:p0026:u0001, D27:p0026:u0002, D27:p0026:u0003, D27:p0026:u0004, D27:p0026:u0005, D27:p0026:u0006, D27:p0026:u0007, D27:p0026:u0008, D27:p0026:u0009, D27:p0026:u0010, D27:p0026:u0011, D27:p0026:u0021
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Greek Mythos
- Ovid's narrative poem Metamorphoses
- Pygmalion (sculptor) fell in love with a statue he had
carved
- Statue comes to life due to inference of the Gods
(Aphrodite)
- Daedalus (inventor) put voice to a statue using
quicksilver (i.e. mercury)
- Talos is an artificial man made of Bronze (Hephaestus)
- Pandora was the first mortal woman who was made of
clay (Hephaestus at request of Zeus)
4
````


---

# AI-02-01 — Понятие агента и агентной функции

**Раздел РПД:** 2. Агенты
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Спроектируй агента и объясни соответствие между наблюдениями и действиями.
**Пункты РПД:** RPD-08

**Связанные страницы:** 5; **символов извлечённого текста:** 1818.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D14 — Week 13 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=18`
Строки (ID элементов): D14:p0018:u0001

````text
Agents
````

## D14 — Week 13 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=19`
Строки (ID элементов): D14:p0019:u0001, D14:p0019:u0002, D14:p0019:u0003, D14:p0019:u0004, D14:p0019:u0005, D14:p0019:u0006, D14:p0019:u0007, D14:p0019:u0008, D14:p0019:u0009, D14:p0019:u0010, D14:p0019:u0011

````text
Agents
- "An agent is anything that can be viewed as perceiving its environment
through sensors and acting upon that environment through effectors."
- Russell, Stuart J. and Peter Norvig (1995), Artificial Intelligence: A Modern
Approach
- “Autonomous agents are computational systems that inhabit some
complex dynamic environment, sense and act autonomously in this
environment, and by doing so realize a set of goals or tasks for which they
are designed.”
- Maes, Pattie (1995), Artificial Life Meets Entertainment: Life like Autonomous
Agents, Communications of the ACM, 38, 11, 108-114
````

## D14 — Week 13 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=20`
Строки (ID элементов): D14:p0020:u0001, D14:p0020:u0002, D14:p0020:u0003, D14:p0020:u0004, D14:p0020:u0005, D14:p0020:u0006, D14:p0020:u0007, D14:p0020:u0008, D14:p0020:u0009, D14:p0020:u0010, D14:p0020:u0011, D14:p0020:u0012, D14:p0020:u0013

````text
Agents
- “Let us define an agent as a persistent software entity dedicated to a
specific purpose. 'Persistent' distinguishes agents from subroutines; agents
have their own ideas about how to accomplish tasks, their own agendas.
'Special purpose' distinguishes them from entire multifunction applications;
agents are typically much smaller.”
- Smith, D. C., A. Cypher and J. Spohrer (1994), KidSim: Programming Agents
Without a Programming Language, Communications of the ACM, 37, 7, 55-67
- "Autonomous agents are systems capable of autonomous, purposeful
action in the real world.“
- Brustoloni, Jose C. (1991), Autonomous Agents: Characterization and
Requirements, Carnegie Mellon Technical Report CMU-CS-91-204, Pittsburgh:
Carnegie Mellon University
````

## D19 — Week 3 Lecture.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=4`
Строки (ID элементов): D19:p0004:u0001, D19:p0004:u0002, D19:p0004:u0003, D19:p0004:u0004, D19:p0004:u0005, D19:p0004:u0006, D19:p0004:u0007, D19:p0004:u0008, D19:p0004:u0009

````text
What is an Agent?
- An agent is anything which:
- Lives in an environment
- Can perceive the environment via its sensors
- Can act upon the environment via its actuators
- Agents also have memory of the current and past perceptions of the
environment
- Percept – the current state
- Percept Sequence – the complete history of Percepts
````

## D19 — Week 3 Lecture.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=5`
Строки (ID элементов): D19:p0005:u0001, D19:p0005:u0002, D19:p0005:u0003, D19:p0005:u0004, D19:p0005:u0005, D19:p0005:u0006, D19:p0005:u0007, D19:p0005:u0008, D19:p0005:u0009, D19:p0005:u0010, D19:p0005:u0011, D19:p0005:u0014, D19:p0005:u0015, D19:p0005:u0016, D19:p0005:u0017
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Humans as Agents
- Environments
- Home
- School
- Work
- Sensors
- Eyes
- Ears
- Mouth
- Nose
- Skin
- Actuators
- Hands
- Feet
- Speech
````


---

# AI-02-02 — Рациональность и ограниченность знаний агента

**Раздел РПД:** 2. Агенты
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Выбери рациональное действие при неполной информации и объясни отличие рациональности от всеведения.
**Пункты РПД:** —

**Связанные страницы:** 2; **символов извлечённого текста:** 963.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D19 — Week 3 Lecture.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=6`
Строки (ID элементов): D19:p0006:u0001, D19:p0006:u0002, D19:p0006:u0003, D19:p0006:u0004, D19:p0006:u0005, D19:p0006:u0006, D19:p0006:u0007, D19:p0006:u0008, D19:p0006:u0009, D19:p0006:u0010, D19:p0006:u0011
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Rationality
- What is rational at any given time depends upon:
- The performance measure defines success
- The agent’s prior knowledge of the environment
- The actions which an agent can perform
- The agent’s percept sequence to date
- Definition:
- For Each possible percept sequence, a rational agent should select an action
that is expected to maximize its performance measure, given the evidence
provided by the percept sequence and whatever built-in knowledge the agent
has
````

## D19 — Week 3 Lecture.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=7`
Строки (ID элементов): D19:p0007:u0001, D19:p0007:u0002, D19:p0007:u0003, D19:p0007:u0004, D19:p0007:u0005, D19:p0007:u0006, D19:p0007:u0007, D19:p0007:u0008, D19:p0007:u0009, D19:p0007:u0010, D19:p0007:u0011
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Agents are Rational,
Not Necessarily Omniscient
- A jester knocks over the king’s wine
- “What an idiot!”
- Did the jester make a cartwheel and miss the landing?
- Did the jester see it being poisoned and the king did not?
- Agents need to gather information before making a decision of an action
- “Why did you spill my wine jester?!”
- Note that agents may perceive differently from each other
- Agents have a degree of autonomy
- The King does not control every action of the jester
````


---

# AI-02-03 — Описание задачи с помощью PEAS

**Раздел РПД:** 2. Агенты
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Составь PEAS для нового агента и обоснуй каждую компоненту.
**Пункты РПД:** RPD-09

**Связанные страницы:** 11; **символов извлечённого текста:** 3832.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D18 — Week 3 Lab.pptx.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/18_Week 3 Lab.pptx/source.pdf#page=3`
Строки (ID элементов): D18:p0003:u0001, D18:p0003:u0002, D18:p0003:u0004, D18:p0003:u0005
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.

````text
Task
?
?
Select a scenario of an Artificially Intelligent System
````

## D18 — Week 3 Lab.pptx.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/18_Week 3 Lab.pptx/source.pdf#page=4`
Строки (ID элементов): D18:p0004:u0001, D18:p0004:u0004, D18:p0004:u0005, D18:p0004:u0006, D18:p0004:u0007

````text
PEAS
Performance measure
Environment
Actuators
Sensors
````

## D18 — Week 3 Lab.pptx.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/18_Week 3 Lab.pptx/source.pdf#page=5`
Строки (ID элементов): D18:p0005:u0001, D18:p0005:u0005, D18:p0005:u0006, D18:p0005:u0007, D18:p0005:u0008, D18:p0005:u0009, D18:p0005:u0010, D18:p0005:u0011, D18:p0005:u0012, D18:p0005:u0013, D18:p0005:u0014, D18:p0005:u0015, D18:p0005:u0016, D18:p0005:u0017, D18:p0005:u0018, D18:p0005:u0019, D18:p0005:u0020, D18:p0005:u0021

````text
Example from the book
Agent Type
Performance
Environment
Actuators
Sensors
Measure
Medical
diagnosi
system
Satellite image
analysis system
Part-picking
robot
Refinery
controller
Interactive
English tutor
````

## D18 — Week 3 Lab.pptx.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/18_Week 3 Lab.pptx/source.pdf#page=6`
Строки (ID элементов): D18:p0006:u0001, D18:p0006:u0005, D18:p0006:u0006, D18:p0006:u0007, D18:p0006:u0008, D18:p0006:u0009, D18:p0006:u0010, D18:p0006:u0011, D18:p0006:u0012, D18:p0006:u0013, D18:p0006:u0014, D18:p0006:u0015, D18:p0006:u0016, D18:p0006:u0017, D18:p0006:u0018, D18:p0006:u0019, D18:p0006:u0020, D18:p0006:u0021, D18:p0006:u0022, D18:p0006:u0023, D18:p0006:u0024, D18:p0006:u0025, D18:p0006:u0026, D18:p0006:u0027, D18:p0006:u0028, D18:p0006:u0029, D18:p0006:u0030, D18:p0006:u0031, D18:p0006:u0032

````text
Example from the book
Agent Type
Performance
Environment
Actuators
Sensors
Measure
Medical
Healthy patient,
Patient, hospital,
Display of
Touchscreen/voice
diagnosis system
reduced costs
staff
questions, tests,
entry of
diagnoses,
symptoms and
treatments
findings
Satellite image
analysis system
Part-picking
robot
Refinery
controller
Interactive
English tutor
````

## D18 — Week 3 Lab.pptx.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/18_Week 3 Lab.pptx/source.pdf#page=7`
Строки (ID элементов): D18:p0007:u0001, D18:p0007:u0005, D18:p0007:u0006, D18:p0007:u0007, D18:p0007:u0008, D18:p0007:u0009, D18:p0007:u0010, D18:p0007:u0011, D18:p0007:u0012, D18:p0007:u0013, D18:p0007:u0014, D18:p0007:u0015, D18:p0007:u0016, D18:p0007:u0017, D18:p0007:u0018, D18:p0007:u0019, D18:p0007:u0020, D18:p0007:u0021, D18:p0007:u0022, D18:p0007:u0023, D18:p0007:u0024, D18:p0007:u0025, D18:p0007:u0026, D18:p0007:u0027, D18:p0007:u0028, D18:p0007:u0029, D18:p0007:u0030, D18:p0007:u0031, D18:p0007:u0032, D18:p0007:u0033, D18:p0007:u0034, D18:p0007:u0035, D18:p0007:u0036, D18:p0007:u0037, D18:p0007:u0038, D18:p0007:u0039, D18:p0007:u0040, D18:p0007:u0041, D18:p0007:u0042

````text
Example from the book
Agent Type
Performance
Environment
Actuators
Sensors
Measure
Medical
Healthy patient,
Patient, hospital,
Display of
Touchscreen/voice
diagnosis system
reduced costs
staff
questions, tests,
entry of
diagnoses,
symptoms and
treatments
findings
Satellite image
Correct
Orbiting satellite,
Display of scene
High-resolution
downlink,
analysis system
categorization of
categorization
digital camera
objects, terrain
weather
Part-picking
robot
Refinery
controller
Interactive
English tutor
````

## D18 — Week 3 Lab.pptx.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/18_Week 3 Lab.pptx/source.pdf#page=8`
Строки (ID элементов): D18:p0008:u0001, D18:p0008:u0005, D18:p0008:u0006, D18:p0008:u0007, D18:p0008:u0008, D18:p0008:u0009, D18:p0008:u0010, D18:p0008:u0011, D18:p0008:u0012, D18:p0008:u0013, D18:p0008:u0014, D18:p0008:u0015, D18:p0008:u0016, D18:p0008:u0017, D18:p0008:u0018, D18:p0008:u0019, D18:p0008:u0020, D18:p0008:u0021, D18:p0008:u0022, D18:p0008:u0023, D18:p0008:u0024, D18:p0008:u0025, D18:p0008:u0026, D18:p0008:u0027, D18:p0008:u0028, D18:p0008:u0029, D18:p0008:u0030, D18:p0008:u0031, D18:p0008:u0032, D18:p0008:u0033, D18:p0008:u0034, D18:p0008:u0035, D18:p0008:u0036, D18:p0008:u0037, D18:p0008:u0038, D18:p0008:u0039, D18:p0008:u0040, D18:p0008:u0041, D18:p0008:u0042, D18:p0008:u0043, D18:p0008:u0044, D18:p0008:u0045, D18:p0008:u0046, D18:p0008:u0047, D18:p0008:u0048, D18:p0008:u0049, D18:p0008:u0050, D18:p0008:u0051, D18:p0008:u0052

````text
Example from the book
Agent Type
Performance
Environment
Actuators
Sensors
Measure
Medical
Healthy patient,
Patient, hospital,
Display of
Touchscreen/voice
diagnosis system
reduced costs
staff
questions, tests,
entry of
diagnoses,
symptoms and
treatments
findings
Satellite image
Correct
Orbiting satellite,
Display of scene
High-resolution
downlink,
analysis system
categorization of
categorization
digital camera
objects, terrain
weather
Part-picking
Percentage of
Conveyor belt
Jointed arm and
‘Camera, tactile
robot
parts in correct
with parts; bins
hand
and joint angle
bins
sensors
Refinery
controller
Interactive
English tutor
````

## D18 — Week 3 Lab.pptx.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/18_Week 3 Lab.pptx/source.pdf#page=9`
Строки (ID элементов): D18:p0009:u0001, D18:p0009:u0005, D18:p0009:u0006, D18:p0009:u0007, D18:p0009:u0008, D18:p0009:u0009, D18:p0009:u0010, D18:p0009:u0011, D18:p0009:u0012, D18:p0009:u0013, D18:p0009:u0014, D18:p0009:u0015, D18:p0009:u0016, D18:p0009:u0017, D18:p0009:u0018, D18:p0009:u0019, D18:p0009:u0020, D18:p0009:u0021, D18:p0009:u0022, D18:p0009:u0023, D18:p0009:u0024, D18:p0009:u0025, D18:p0009:u0026, D18:p0009:u0027, D18:p0009:u0028, D18:p0009:u0029, D18:p0009:u0030, D18:p0009:u0031, D18:p0009:u0032, D18:p0009:u0033, D18:p0009:u0034, D18:p0009:u0035, D18:p0009:u0036, D18:p0009:u0037, D18:p0009:u0038, D18:p0009:u0039, D18:p0009:u0040, D18:p0009:u0041, D18:p0009:u0042, D18:p0009:u0043, D18:p0009:u0044, D18:p0009:u0045, D18:p0009:u0046, D18:p0009:u0047, D18:p0009:u0048, D18:p0009:u0049, D18:p0009:u0050, D18:p0009:u0051, D18:p0009:u0052, D18:p0009:u0053, D18:p0009:u0054, D18:p0009:u0055, D18:p0009:u0056, D18:p0009:u0057, D18:p0009:u0058, D18:p0009:u0059, D18:p0009:u0060, D18:p0009:u0061, D18:p0009:u0062, D18:p0009:u0063

````text
Example from the book
Agent Type
Performance
Environment
Actuators
Sensors
Measure
Medical
Healthy patient,
Patient, hospital,
Display of
Touchscreen/voice
diagnosis system
reduced costs
staff
questions, tests,
entry of
diagnoses,
symptoms and
treatments
findings
Satellite image
Correct
Orbiting satellite,
Display of scene
High-resolution
downlink,
analysis system
categorization of
categorization
digital camera
objects, terrain
weather
Part-picking
Percentage of
Conveyor belt
Jointed arm and
‘Camera, tactile
robot
parts in correct
with parts; bins
hand
and joint angle
bins
sensors
Refinery
Purity, yield,
Refinery, raw
Valves, pumps,
‘Temperature,
controller
safety
material
heaters, stirrers,
pressure, flow,
chemical sensors
‘operators
displays
Interactive
English tutor
````

## D18 — Week 3 Lab.pptx.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/18_Week 3 Lab.pptx/source.pdf#page=10`
Строки (ID элементов): D18:p0010:u0001, D18:p0010:u0005, D18:p0010:u0006, D18:p0010:u0007, D18:p0010:u0008, D18:p0010:u0009, D18:p0010:u0010, D18:p0010:u0011, D18:p0010:u0012, D18:p0010:u0013, D18:p0010:u0014, D18:p0010:u0015, D18:p0010:u0016, D18:p0010:u0017, D18:p0010:u0018, D18:p0010:u0019, D18:p0010:u0020, D18:p0010:u0021, D18:p0010:u0022, D18:p0010:u0023, D18:p0010:u0024, D18:p0010:u0025, D18:p0010:u0026, D18:p0010:u0027, D18:p0010:u0028, D18:p0010:u0029, D18:p0010:u0030, D18:p0010:u0031, D18:p0010:u0032, D18:p0010:u0033, D18:p0010:u0034, D18:p0010:u0035, D18:p0010:u0036, D18:p0010:u0037, D18:p0010:u0038, D18:p0010:u0039, D18:p0010:u0040, D18:p0010:u0041, D18:p0010:u0042, D18:p0010:u0043, D18:p0010:u0044, D18:p0010:u0045, D18:p0010:u0046, D18:p0010:u0047, D18:p0010:u0048, D18:p0010:u0049, D18:p0010:u0050, D18:p0010:u0051, D18:p0010:u0052, D18:p0010:u0053, D18:p0010:u0054, D18:p0010:u0055, D18:p0010:u0056, D18:p0010:u0057, D18:p0010:u0058, D18:p0010:u0059, D18:p0010:u0060, D18:p0010:u0061, D18:p0010:u0062, D18:p0010:u0064, D18:p0010:u0065, D18:p0010:u0066, D18:p0010:u0067, D18:p0010:u0068, D18:p0010:u0069, D18:p0010:u0070, D18:p0010:u0071, D18:p0010:u0072
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Example from the book
Agent Type
Performance
Environment
Actuators
Sensors
Measure
Medical
Healthy patient,
Patient, hospital,
Display of
Touchscreen/voice
diagnosis system
reduced costs
staff
questions, tests,
entry of
diagnoses,
symptoms and
treatments
findings
Satellite image
Correct
Orbiting satellite,
Display of scene
High-resolution
downlink,
analysis system
categorization of
categorization
digital camera
objects, terrain
weather
Part-picking
Percentage of
Conveyor belt
Jointed arm and
‘Camera, tactile
robot
parts in correct
with parts; bins
hand
and joint angle
bins
sensors
Refinery
Purity, yield,
Refinery, raw
Valves, pumps,
‘Temperature,
controller
safety
material
heaters, stirrers,
pressure, flow,
chemical sensors
‘operators
displays
Interactive
Set of students,
Display of
Keyboard entry,
on test
exercises,
voice
English tutor
testing agency
feedback, speech
````

## D18 — Week 3 Lab.pptx.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/18_Week 3 Lab.pptx/source.pdf#page=11`
Строки (ID элементов): D18:p0011:u0001, D18:p0011:u0002, D18:p0011:u0003, D18:p0011:u0004

````text
Task
?
Present your selected system on PEAS
?
````

## D19 — Week 3 Lecture.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=8`
Строки (ID элементов): D19:p0008:u0001, D19:p0008:u0002, D19:p0008:u0011
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
PEAS – Performance Measure,
Environment, Actuators, Sensors
Actions
````

## D19 — Week 3 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=9`
Строки (ID элементов): D19:p0009:u0001, D19:p0009:u0002, D19:p0009:u0003, D19:p0009:u0004, D19:p0009:u0005, D19:p0009:u0006, D19:p0009:u0007, D19:p0009:u0008, D19:p0009:u0009, D19:p0009:u0010, D19:p0009:u0011, D19:p0009:u0012, D19:p0009:u0015, D19:p0009:u0016, D19:p0009:u0017
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
PEAS – Performance Measure,
Environment, Actuators, Sensors
- Agent Type
- Jester
- Performance measure
- The King is Happy
- Environment
- The Court
- Actuators
- Tumbling
- Juggling
- Joke Telling
- Sensors
- Hearing Laughter
- Seeing Smiles
````


---

# AI-02-04 — Свойства среды агента

**Раздел РПД:** 2. Агенты
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Классифицируй среду по наблюдаемости, детерминизму, динамичности и остальным осям.
**Пункты РПД:** RPD-10

**Связанные страницы:** 6; **символов извлечённого текста:** 2467.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D19 — Week 3 Lecture.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=10`
Строки (ID элементов): D19:p0010:u0001, D19:p0010:u0002, D19:p0010:u0003, D19:p0010:u0004, D19:p0010:u0005, D19:p0010:u0006, D19:p0010:u0007, D19:p0010:u0008

````text
Properties of the Environment (1)
- Fully Observable v. Partially Observable
- Single v. Multiple Agent
- Deterministic v. Stochastic
- Episodic v. Sequential
- Static v. Dynamic
- Discrete v. Continuous
- Known v. Unknown
````

## D19 — Week 3 Lecture.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=11`
Строки (ID элементов): D19:p0011:u0001, D19:p0011:u0002, D19:p0011:u0003, D19:p0011:u0004, D19:p0011:u0005, D19:p0011:u0006, D19:p0011:u0007, D19:p0011:u0008, D19:p0011:u0009, D19:p0011:u0010, D19:p0011:u0011
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Properties of the
Environment (2)
- Fully Observable v. Partially Observable
- Can the agent see everything in the world via its sensors?
- Does it miss elements which are relevant to the decision making process?
- Unobservable for agent without sensors
- Single-agent v. Multiagent
- Is there only one agent within the space?
- Does there need to be some form of competitive or cooperation between
agents?
- How do the agents communicate?
````

## D19 — Week 3 Lecture.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=12`
Строки (ID элементов): D19:p0012:u0001, D19:p0012:u0002, D19:p0012:u0003, D19:p0012:u0004, D19:p0012:u0005, D19:p0012:u0006, D19:p0012:u0007, D19:p0012:u0008, D19:p0012:u0009, D19:p0012:u0010, D19:p0012:u0011
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Properties of the
Environment (3)
- Deterministic v. Stochastic
- Can we determine the next state of the environment given the previous state
and the action we are applying into it?
- We can be certain in environments which are fully observable and deterministic
- Episodic v. Sequential
- Episodic environments allow for atomic actions not dependant upon those
previous
- Sequential actions are those which the current decision has consequences on
future actions
````

## D19 — Week 3 Lecture.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=13`
Строки (ID элементов): D19:p0013:u0001, D19:p0013:u0002, D19:p0013:u0003, D19:p0013:u0004, D19:p0013:u0005, D19:p0013:u0006, D19:p0013:u0007, D19:p0013:u0008, D19:p0013:u0009, D19:p0013:u0010, D19:p0013:u0011, D19:p0013:u0012, D19:p0013:u0013, D19:p0013:u0014
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Properties of the
Environment (4)
- Static v. Dynamic
- Does the environment change as the agent is thinking about its actions?
- Semi-dynamic if the environment does not change as the time passes by but the
agent’s performance score does
- Discrete v. Continuous
- Are there states in the environment, or does the environment smoothly act over
time
- Chess – discrete movements
- Jenga – continuous actions of physics on the blocks
- Known v. Unknown
- Does the designer of the agent have full knowledge of the rules of the
environment?
````

## D19 — Week 3 Lecture.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=14`
Строки (ID элементов): D19:p0014:u0001, D19:p0014:u0002, D19:p0014:u0003, D19:p0014:u0004, D19:p0014:u0005, D19:p0014:u0006, D19:p0014:u0007, D19:p0014:u0008, D19:p0014:u0009, D19:p0014:u0010, D19:p0014:u0011, D19:p0014:u0012
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
The Worst Case
- An environment which is partially observable,
multiagent, stochastic, sequential, dynamic,
continuous, and unknown
- Ordering in a new restaurant in a new country
- Can’t see how they make the food
- Have to deal with the waiter, other customers
- Can’t predict when the food will come or how exactly it will taste
- Depending on what I order, I might order more or might order an ambulance
- Maybe they don’t have anymore what I would like to order
- Time keeps on ticking
- Don’t know the cultural rules
````

## D19 — Week 3 Lecture.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=15`
Строки (ID элементов): D19:p0015:u0001, D19:p0015:u0002, D19:p0015:u0003, D19:p0015:u0004, D19:p0015:u0005, D19:p0015:u0006, D19:p0015:u0007, D19:p0015:u0008, D19:p0015:u0009, D19:p0015:u0010
**Непроверенные OCR/формулы:** 10 исключённых из основного текста кандидатов; см. JSON.

````text
Testing an AI
- We do not just want one environment but an environment class
- Run multiple simulations with many different changes to the environment
- Self-driving Car
- Traffic level
- Lights
- Weather
- Collectable Card Game Player
- Against many other decks
- Other player agents
````


---

# AI-02-05 — Простой рефлексный агент

**Раздел РПД:** 2. Агенты
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Построй набор condition-action правил и назови сценарий, где он неизбежно ошибётся.
**Пункты РПД:** RPD-11

**Связанные страницы:** 3; **символов извлечённого текста:** 339.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D19 — Week 3 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=16`
Строки (ID элементов): D19:p0016:u0001, D19:p0016:u0002, D19:p0016:u0003, D19:p0016:u0004, D19:p0016:u0005

````text
Types of Agents
1. Simple reflex agents
2. Model-based reflex agents
3. Goal-based agents
4. Utility-based agents
````

## D19 — Week 3 Lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=17`
Строки (ID элементов): D19:p0017:u0001, D19:p0017:u0006, D19:p0017:u0009, D19:p0017:u0010, D19:p0017:u0011, D19:p0017:u0012
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Simple Reflex Agents
Agent
What the world
is like now
What action I
should do now
````

## D19 — Week 3 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=18`
Строки (ID элементов): D19:p0018:u0001, D19:p0018:u0002, D19:p0018:u0003, D19:p0018:u0004

````text
Simple Reflex Agents
- Only current percept matters
- Work only in fully observable environment
- Too many condition-action rules may be required
````


---

# AI-02-06 — Рефлексный агент с внутренней моделью

**Раздел РПД:** 2. Агенты
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Объясни, как обновляется состояние агента при частичной наблюдаемости, на примере.
**Пункты РПД:** RPD-11

**Связанные страницы:** 2; **символов извлечённого текста:** 462.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D19 — Week 3 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=19`
Строки (ID элементов): D19:p0019:u0001, D19:p0019:u0011, D19:p0019:u0012, D19:p0019:u0013, D19:p0019:u0014, D19:p0019:u0015, D19:p0019:u0018
**Непроверенные OCR/формулы:** 10 исключённых из основного текста кандидатов; см. JSON.

````text
Model-based Reflex Agents
What the world
( How the world evolves }-——a>
is like now
What action I
should do now
gent
````

## D19 — Week 3 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=20`
Строки (ID элементов): D19:p0020:u0001, D19:p0020:u0002, D19:p0020:u0003, D19:p0020:u0004, D19:p0020:u0005, D19:p0020:u0006, D19:p0020:u0007, D19:p0020:u0008

````text
Model-based Reflex Agents
- Work better in partially observable environment because of keeping track
of the world
- Internal state exists
- In partially observable environment not always possible to answer “What
the world is like now?”. Sometimes agent tries to guess
- Still, too many condition-action rules may be required
- Not flexible enough
````


---

# AI-02-07 — Целеориентированный агент

**Раздел РПД:** 2. Агенты
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Выбери действия агента по цели и объясни, почему одних рефлексов недостаточно.
**Пункты РПД:** RPD-11

**Связанные страницы:** 4; **символов извлечённого текста:** 1146.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D03 — Lecture 5.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=7`
Строки (ID элементов): D03:p0007:u0001, D03:p0007:u0002, D03:p0007:u0003, D03:p0007:u0004, D03:p0007:u0005, D03:p0007:u0006, D03:p0007:u0007, D03:p0007:u0008, D03:p0007:u0009, D03:p0007:u0010, D03:p0007:u0011
**Общая страница с:** AI-04-01

````text
Goal-based Agent
- Four Steps in the Agent:
1. Define Goals
- What are the states which are considered to be satisfying the goal?
2. Problem Formulation
- What actions are available to move towards the goal?
- What states are available to move towards the goal?
3. Search
- Determine the pathway of states in order to meet with the goal
4. Execute
- Move through the series of states
````

## D03 — Lecture 5.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=8`
Строки (ID элементов): D03:p0008:u0001, D03:p0008:u0002, D03:p0008:u0003, D03:p0008:u0004, D03:p0008:u0005, D03:p0008:u0006, D03:p0008:u0007, D03:p0008:u0008, D03:p0008:u0009, D03:p0008:u0010, D03:p0008:u0011, D03:p0008:u0012, D03:p0008:u0013
**Общая страница с:** AI-04-01
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Example: Painting Robot
(simplified)
1. Goal
- All show surfaces of the part are covered in 1mm of paint
2. Problem Formulation
- A sequence of points about the part for the robot arm to move into in order to
ensure a dispersal about the entire part
3. Search
- Examine all pathways about the part, taking into account the movements on
each part of the arm
- A pathway is good as long as it covers the part with 1mm of paint
4. Execute
- The arm moves through the sequence of positions
````

## D19 — Week 3 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=21`
Строки (ID элементов): D19:p0021:u0001, D19:p0021:u0008, D19:p0021:u0009, D19:p0021:u0011, D19:p0021:u0012, D19:p0021:u0013, D19:p0021:u0014
**Непроверенные OCR/формулы:** 7 исключённых из основного текста кандидатов; см. JSON.

````text
Goal-based Agents
What the world
is like now
What it will be like
if I do action A
What action I
should do now
````

## D19 — Week 3 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=22`
Строки (ID элементов): D19:p0022:u0001, D19:p0022:u0002, D19:p0022:u0003, D19:p0022:u0004

````text
Goal-based Agents
- More flexible than previous agent types
- Goal replacement does not entail rewriting of all the rules
- May be hard to choose between multiple goals
````


---

# AI-02-08 — Агент на основе функции полезности

**Раздел РПД:** 2. Агенты
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Сравни два достижения цели с разной полезностью и обоснуй выбор агента.
**Пункты РПД:** RPD-11

**Связанные страницы:** 2; **символов извлечённого текста:** 335.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D19 — Week 3 Lecture.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=23`
Строки (ID элементов): D19:p0023:u0001, D19:p0023:u0013, D19:p0023:u0014, D19:p0023:u0015, D19:p0023:u0017, D19:p0023:u0018, D19:p0023:u0020, D19:p0023:u0021, D19:p0023:u0023, D19:p0023:u0024, D19:p0023:u0027
**Непроверенные OCR/формулы:** 15 исключённых из основного текста кандидатов; см. JSON.

````text
Utility-based Agents
What the world
How the world evolves
is like now
What it will be like
if I do action A
How happy I will be
in such a state
What action I
should do now
gent
````

## D19 — Week 3 Lecture.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=24`
Строки (ID элементов): D19:p0024:u0001, D19:p0024:u0002, D19:p0024:u0003, D19:p0024:u0004

````text
Utility-based Agents
- Allow to maximize the “happiness” of the agent
- Allows to find the tradeoff between the conflicting goals
- More difficult to implement
````


---

# AI-02-09 — Обучающийся агент и обратная связь

**Раздел РПД:** 2. Агенты
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Объясни, как критик, элемент обучения и исполнитель влияют друг на друга на примере.
**Пункты РПД:** RPD-11

**Связанные страницы:** 2; **символов извлечённого текста:** 641.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D19 — Week 3 Lecture.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=25`
Строки (ID элементов): D19:p0025:u0001, D19:p0025:u0002, D19:p0025:u0003, D19:p0025:u0004, D19:p0025:u0005, D19:p0025:u0006, D19:p0025:u0007, D19:p0025:u0008, D19:p0025:u0009, D19:p0025:u0010

````text
Learning Agents
- In 1950 Alan Turing proposed to build learning machines (agents) and then
to teach them
- Any type of agent (model-based, goal-based, utility-based, etc.) can be
built as a learning agent (or not)
- Performance element is what we previously considered as entire agent
- Leaning element is responsible for making improvements
- The learning element receives a feedback from the Critic
- Problem generator is responsible for suggesting actions that will lead to new
and informative experiences
````

## D19 — Week 3 Lecture.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/19_Week 3 Lecture/source.pdf#page=26`
Строки (ID элементов): D19:p0026:u0001, D19:p0026:u0005, D19:p0026:u0006, D19:p0026:u0008, D19:p0026:u0009, D19:p0026:u0010, D19:p0026:u0012, D19:p0026:u0013, D19:p0026:u0014, D19:p0026:u0015, D19:p0026:u0017, D19:p0026:u0018, D19:p0026:u0019, D19:p0026:u0020
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Learning Agents
Performance standard
4
Critic
feedback
changes
Performance
element
element
knowledge
goals
Problem
generator
\ Agent
````


---

# AI-03-01 — Назначение и архитектура экспертных систем

**Раздел РПД:** 3. Экспертные системы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Спроектируй структуру экспертной системы для диагностики и перечисли, что хранится в базе знаний.
**Пункты РПД:** RPD-12

**Связанные страницы:** 4; **символов извлечённого текста:** 1973.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D20 — Week 4 Lecture.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=3`
Строки (ID элементов): D20:p0003:u0001, D20:p0003:u0003

````text
Expert Systems
3
````

## D20 — Week 4 Lecture.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=4`
Строки (ID элементов): D20:p0004:u0001, D20:p0004:u0002, D20:p0004:u0003, D20:p0004:u0004, D20:p0004:u0005, D20:p0004:u0006, D20:p0004:u0007, D20:p0004:u0008

````text
Expert System
- Expert Systems are computer programs that utilize knowledge and
inference mechanisms to provide advice, solutions, or
recommendations in specialized domains
- They are designed to capture and emulate the expertise of human
specialists to solve complex problems and make informed decisions
- Were formally introduced around 1965 by the Stanford Heuristic
Programming Project led by Edward Feigenbaum
````

## D20 — Week 4 Lecture.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=13`
Строки (ID элементов): D20:p0013:u0001, D20:p0013:u0002, D20:p0013:u0003, D20:p0013:u0004, D20:p0013:u0005, D20:p0013:u0006, D20:p0013:u0007, D20:p0013:u0008, D20:p0013:u0009, D20:p0013:u0010, D20:p0013:u0011, D20:p0013:u0012, D20:p0013:u0013, D20:p0013:u0014, D20:p0013:u0015, D20:p0013:u0016, D20:p0013:u0017, D20:p0013:u0018, D20:p0013:u0019, D20:p0013:u0020, D20:p0013:u0021, D20:p0013:u0022, D20:p0013:u0023, D20:p0013:u0024, D20:p0013:u0025, D20:p0013:u0026, D20:p0013:u0027, D20:p0013:u0028, D20:p0013:u0029, D20:p0013:u0030, D20:p0013:u0031, D20:p0013:u0032, D20:p0013:u0033, D20:p0013:u0034, D20:p0013:u0035
**Общая страница с:** AI-03-02

````text
Areas of Application for Expert Systems
(Hayes-Roth 1983)
Category
Problem addressed
Examples
Interpretation Inferring situation descriptions from sensor data
Hearsay (speech recognition), PROSPECTOR
Prediction
Inferring likely consequences of given situations
Preterm Birth Risk Assessment
Diagnosis
Inferring system malfunctions from observables
CADUCEUS, MYCIN, PUFF, Mistral, Eydenet, Kaleidos
Design
Configuring objects under constraints
Dendral, Mortgage Loan Advisor, R1 (DEC VAX
Configuration), SID (DEC VAX 9000 CPU)
Planning
Designing actions
Mission Planning for Autonomous Underwater Vehicle
Monitoring
Comparing observations to plan vulnerabilities
REACTOR
Debugging
Providing incremental solutions for complex problems SAINT, MATHLAB, MACSYMA
Repair
Executing a plan to administer a prescribed remedy
Toxic Spill Crisis Management
Instruction
Diagnosing, assessing, and repairing student behavior SMH.PAL, Intelligent Clinical Training, STEAMER
Control
Interpreting, predicting, repairing, and monitoring
system behaviors
Real Time Process Control, Space Shuttle Mission
Control
````

## D20 — Week 4 Lecture.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=14`
Строки (ID элементов): D20:p0014:u0001, D20:p0014:u0002, D20:p0014:u0003, D20:p0014:u0004, D20:p0014:u0005, D20:p0014:u0006, D20:p0014:u0007, D20:p0014:u0008, D20:p0014:u0009, D20:p0014:u0010, D20:p0014:u0011
**Общая страница с:** AI-03-02

````text
Training an Expert System
- Interviews with experts
- Experts classify knowledge cases
- Provide a series of rules which they use to make the classifications
- Very costly - knowledge acquisition problem
- Experts by definition are rare
- Meaning expensive
- Why would they want to train the competitors?
- Machine Learning Techniques – especially Decision trees are used to define
a pathway to a solution
- Frontend development and user understanding
````


---

# AI-03-02 — Получение знаний от эксперта

**Раздел РПД:** 3. Экспертные системы
**Статус исходной разметки:** частично; расширение
**Диагностический вопрос (черновик):** Предложи способ извлечения и проверки правил от специалиста при создании экспертной системы.
**Пункты РПД:** —

**Связанные страницы:** 2; **символов извлечённого текста:** 1543.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D20 — Week 4 Lecture.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=13`
Строки (ID элементов): D20:p0013:u0001, D20:p0013:u0002, D20:p0013:u0003, D20:p0013:u0004, D20:p0013:u0005, D20:p0013:u0006, D20:p0013:u0007, D20:p0013:u0008, D20:p0013:u0009, D20:p0013:u0010, D20:p0013:u0011, D20:p0013:u0012, D20:p0013:u0013, D20:p0013:u0014, D20:p0013:u0015, D20:p0013:u0016, D20:p0013:u0017, D20:p0013:u0018, D20:p0013:u0019, D20:p0013:u0020, D20:p0013:u0021, D20:p0013:u0022, D20:p0013:u0023, D20:p0013:u0024, D20:p0013:u0025, D20:p0013:u0026, D20:p0013:u0027, D20:p0013:u0028, D20:p0013:u0029, D20:p0013:u0030, D20:p0013:u0031, D20:p0013:u0032, D20:p0013:u0033, D20:p0013:u0034, D20:p0013:u0035
**Общая страница с:** AI-03-01

````text
Areas of Application for Expert Systems
(Hayes-Roth 1983)
Category
Problem addressed
Examples
Interpretation Inferring situation descriptions from sensor data
Hearsay (speech recognition), PROSPECTOR
Prediction
Inferring likely consequences of given situations
Preterm Birth Risk Assessment
Diagnosis
Inferring system malfunctions from observables
CADUCEUS, MYCIN, PUFF, Mistral, Eydenet, Kaleidos
Design
Configuring objects under constraints
Dendral, Mortgage Loan Advisor, R1 (DEC VAX
Configuration), SID (DEC VAX 9000 CPU)
Planning
Designing actions
Mission Planning for Autonomous Underwater Vehicle
Monitoring
Comparing observations to plan vulnerabilities
REACTOR
Debugging
Providing incremental solutions for complex problems SAINT, MATHLAB, MACSYMA
Repair
Executing a plan to administer a prescribed remedy
Toxic Spill Crisis Management
Instruction
Diagnosing, assessing, and repairing student behavior SMH.PAL, Intelligent Clinical Training, STEAMER
Control
Interpreting, predicting, repairing, and monitoring
system behaviors
Real Time Process Control, Space Shuttle Mission
Control
````

## D20 — Week 4 Lecture.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=14`
Строки (ID элементов): D20:p0014:u0001, D20:p0014:u0002, D20:p0014:u0003, D20:p0014:u0004, D20:p0014:u0005, D20:p0014:u0006, D20:p0014:u0007, D20:p0014:u0008, D20:p0014:u0009, D20:p0014:u0010, D20:p0014:u0011
**Общая страница с:** AI-03-01

````text
Training an Expert System
- Interviews with experts
- Experts classify knowledge cases
- Provide a series of rules which they use to make the classifications
- Very costly - knowledge acquisition problem
- Experts by definition are rare
- Meaning expensive
- Why would they want to train the competitors?
- Machine Learning Techniques – especially Decision trees are used to define
a pathway to a solution
- Frontend development and user understanding
````


---

# AI-03-03 — ELIZA и системы сопоставления шаблонов

**Раздел РПД:** 3. Экспертные системы
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Построй диалог, показывающий различие между шаблонными ответами и содержательным выводом.
**Пункты РПД:** —

**Связанные страницы:** 3; **символов извлечённого текста:** 1427.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D20 — Week 4 Lecture.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=5`
Строки (ID элементов): D20:p0005:u0001, D20:p0005:u0002, D20:p0005:u0003, D20:p0005:u0004, D20:p0005:u0005, D20:p0005:u0006, D20:p0005:u0007

````text
ELIZA
- Program developed at MIT (1964-66) by Joseph Weizenbaum
- Idea was for it to act as a parity showing the Chinese Room
- Lead to a number of text adventure computer games
- GO LEFT
- “you go left and see a gnoll with an axe, what do you do?”
- Limited success at the Turing test
````

## D20 — Week 4 Lecture.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=6`
Строки (ID элементов): D20:p0006:u0001, D20:p0006:u0005, D20:p0006:u0009, D20:p0006:u0010, D20:p0006:u0011, D20:p0006:u0012, D20:p0006:u0013, D20:p0006:u0014, D20:p0006:u0015, D20:p0006:u0016, D20:p0006:u0017, D20:p0006:u0018, D20:p0006:u0019, D20:p0006:u0020, D20:p0006:u0021, D20:p0006:u0022, D20:p0006:u0023, D20:p0006:u0024, D20:p0006:u0025, D20:p0006:u0026, D20:p0006:u0027, D20:p0006:u0028, D20:p0006:u0029, D20:p0006:u0031
**Непроверенные OCR/формулы:** 7 исключённых из основного текста кандидатов; см. JSON.

````text
ELIZA in Action on DOCTOR Script
File Edit Options Buffers Tools Help
[X I am the psychotherapist.
Please, describe your problems.
2
SEach time
you are finished talking,
type RET twice.
I have a terrible headache.
Maybe you should consult a doctor of medicine,
I am a psychi?
Satrist.
I'll do that then.
Okay,
Can you elaborate on that?
What are you talking about? No I cannot elaborate.
See you la
Sater.
Why do you say that?
Now you're just talking nonsense!
What makes you believe now I am just talking nonsense?
You are not making any sense.
[7 Perhaps your plans have something to do with this.
*doctor*
````

## D20 — Week 4 Lecture.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=7`
Строки (ID элементов): D20:p0007:u0001, D20:p0007:u0002, D20:p0007:u0003, D20:p0007:u0004, D20:p0007:u0005, D20:p0007:u0006, D20:p0007:u0007, D20:p0007:u0008, D20:p0007:u0009, D20:p0007:u0010, D20:p0007:u0011, D20:p0007:u0012, D20:p0007:u0013

````text
How Does It Work?
- “I feel like this is an English sentence”
- First the string is disassembled based on some rules finding keywords
- <I> <feel> <like this is an English sentence>
- Next it is matched to a list of constructions
- <I> <feel> <like this is an English sentence> = <I> <FEEL> <X>
- This produced a construction rule
- <I> <FEEL> <X> ?:- <Why do you feel><X><?>
- This rule is applied and response is made
- Why do you feel like this is an English sentence?
- If no rule is found – delay
- Go on….
Tell me more about <X>
````


---

# AI-03-04 — Зима искусственного интеллекта

**Раздел РПД:** 3. Экспертные системы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Свяжи ожидания от экспертных систем с их ограничениями и объясни спад интереса к ИИ.
**Пункты РПД:** RPD-13

**Связанные страницы:** 2; **символов извлечённого текста:** 849.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D20 — Week 4 Lecture.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=11`
Строки (ID элементов): D20:p0011:u0001, D20:p0011:u0002, D20:p0011:u0003, D20:p0011:u0004, D20:p0011:u0005, D20:p0011:u0006, D20:p0011:u0007, D20:p0011:u0008, D20:p0011:u0009, D20:p0011:u0010, D20:p0011:u0011, D20:p0011:u0012, D20:p0011:u0013, D20:p0011:u0014, D20:p0011:u0015, D20:p0011:u0016, D20:p0011:u0017, D20:p0011:u0018, D20:p0011:u0019, D20:p0011:u0020, D20:p0011:u0021
**Общая страница с:** AI-03-05

````text
Imperative v. Logic Programming
Imperative
- Statements
- Code and Data
- Code by programmer
- Data as input from
programmer/user
- Actions from User (sometimes)
- Program build from libraries but
many of the units are special
purpose
Logic
- Rules
- Inference Engine/Knowledge Base
- Inference Engine built-in
- Knowledge base by
programmer/user
- Queries from User
- Rapid deployment and
prototyping as the language has
the inference engine by default
````

## D20 — Week 4 Lecture.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=12`
Строки (ID элементов): D20:p0012:u0001, D20:p0012:u0002, D20:p0012:u0003, D20:p0012:u0004, D20:p0012:u0005, D20:p0012:u0006, D20:p0012:u0007, D20:p0012:u0008, D20:p0012:u0009, D20:p0012:u0010, D20:p0012:u0011

````text
AI Winter
- Again these systems while being very popular in the 1980s suffered under
the AI Winter
- The idea of the these systems was that giving a computer all of the
knowledge will make it “smart” failed
- Too high expectations from AI
- Budgets for AI were significantly decreased
- The term AI became ‘undesired’
- Legal issues
- What if a doctor makes a misdiagnosis?
- Are we in AI Spring?
````


---

# AI-03-05 — Логическое и императивное программирование

**Раздел РПД:** 3. Экспертные системы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Сравни решение одной задачи правилами и пошаговым алгоритмом.
**Пункты РПД:** —

**Связанные страницы:** 6; **символов извлечённого текста:** 1851.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=8`
Строки (ID элементов): D08:p0008:u0003, D08:p0008:u0004, D08:p0008:u0005, D08:p0008:u0006, D08:p0008:u0008, D08:p0008:u0009
**Общая страница с:** AI-03-07
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
main(){
procedure1()
procedure2()
return
Logical Programming
Functional Programming
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=9`
Строки (ID элементов): D08:p0009:u0001, D08:p0009:u0004, D08:p0009:u0019, D08:p0009:u0020, D08:p0009:u0021, D08:p0009:u0022, D08:p0009:u0023, D08:p0009:u0024, D08:p0009:u0025, D08:p0009:u0026, D08:p0009:u0027, D08:p0009:u0028, D08:p0009:u0029, D08:p0009:u0030, D08:p0009:u0031, D08:p0009:u0032, D08:p0009:u0033
**Общая страница с:** AI-03-07
**Непроверенные OCR/формулы:** 16 исключённых из основного текста кандидатов; см. JSON.

````text
Using Prolog for Logic Programming
19 NOT Gate
Rule-Based Systems
Logic Circuits
Expert Systems
Prolog is great for creating rule-
Prolog can simulate the behavior
Prolog is widely used for creating
based systems that can be used
of digital logic gates and circuits,
expert systems that can provide
for problem-solving in various
which can be used for testing
automated advice and decision-
fields.
logic designs.
making.
````

## D20 — Week 4 Lecture.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=8`
Строки (ID элементов): D20:p0008:u0001, D20:p0008:u0002, D20:p0008:u0003, D20:p0008:u0004, D20:p0008:u0005, D20:p0008:u0006, D20:p0008:u0007

````text
Logic Programming
- Roots back to 1930s and Alonzo Church with Lambda Calculus
- Developed in 1950/60s
- Is a fundamentally differing paradigm than imperative languages (e.g. C,
C++, C#, Java, Python, etc.)
- Still Turing Complete
- Examples include LISP and PROLOG
````

## D20 — Week 4 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=9`
Строки (ID элементов): D20:p0009:u0001, D20:p0009:u0002, D20:p0009:u0003, D20:p0009:u0004, D20:p0009:u0005, D20:p0009:u0006, D20:p0009:u0007, D20:p0009:u0008, D20:p0009:u0009, D20:p0009:u0010, D20:p0009:u0011, D20:p0009:u0012, D20:p0009:u0013, D20:p0009:u0014, D20:p0009:u0015, D20:p0009:u0016

````text
Statements - Lambda Calculus
Syntax
Name
Description
a
Variable
A character or string representing a parameter
or mathematical/logical value
(λx.M)
Abstraction
Function definition (M is a lambda term). The
variable x becomes bound in the expression
(M N)
Application
Applying a function to an argument. M and N
are lambda terms
````

## D20 — Week 4 Lecture.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=10`
Строки (ID элементов): D20:p0010:u0001, D20:p0010:u0002, D20:p0010:u0003, D20:p0010:u0004, D20:p0010:u0005, D20:p0010:u0006, D20:p0010:u0007, D20:p0010:u0008, D20:p0010:u0009, D20:p0010:u0010, D20:p0010:u0011, D20:p0010:u0012, D20:p0010:u0013, D20:p0010:u0014

````text
Operations - Lambda Calculus
Operation
Name
Description
((λx.M) E) → (M[x:=E])
β-reduction
Substituting the bound variable by the
argument expression in the body of the
abstraction
(λx.M[x]) → (λy.M[y])
α-conversion
Renaming the bound (formal) variables
in the expression. Used to avoid name
collisions
````

## D20 — Week 4 Lecture.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=11`
Строки (ID элементов): D20:p0011:u0001, D20:p0011:u0002, D20:p0011:u0003, D20:p0011:u0004, D20:p0011:u0005, D20:p0011:u0006, D20:p0011:u0007, D20:p0011:u0008, D20:p0011:u0009, D20:p0011:u0010, D20:p0011:u0011, D20:p0011:u0012, D20:p0011:u0013, D20:p0011:u0014, D20:p0011:u0015, D20:p0011:u0016, D20:p0011:u0017, D20:p0011:u0018, D20:p0011:u0019, D20:p0011:u0020, D20:p0011:u0021
**Общая страница с:** AI-03-04

````text
Imperative v. Logic Programming
Imperative
- Statements
- Code and Data
- Code by programmer
- Data as input from
programmer/user
- Actions from User (sometimes)
- Program build from libraries but
many of the units are special
purpose
Logic
- Rules
- Inference Engine/Knowledge Base
- Inference Engine built-in
- Knowledge base by
programmer/user
- Queries from User
- Rapid deployment and
prototyping as the language has
the inference engine by default
````


---

# AI-03-06 — Факты и правила Prolog

**Раздел РПД:** 3. Экспертные системы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Запиши факты и правила для малой предметной области и объясни их семантику.
**Пункты РПД:** RPD-14

**Связанные страницы:** 16; **символов извлечённого текста:** 6092.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 2
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=2`
Строки (ID элементов): D08:p0002:u0001, D08:p0002:u0002, D08:p0002:u0003, D08:p0002:u0004, D08:p0002:u0005, D08:p0002:u0006, D08:p0002:u0007, D08:p0002:u0008, D08:p0002:u0009, D08:p0002:u0010, D08:p0002:u0011, D08:p0002:u0012, D08:p0002:u0013, D08:p0002:u0014, D08:p0002:u0015, D08:p0002:u0016, D08:p0002:u0017, D08:p0002:u0018, D08:p0002:u0019

````text
What is Prolog?
Theoretical
Declarative Language
Pattern Matching
Foundations
Prolog is a declarative
Prolog uses pattern
Prolog was developed based
language, which means you
matching to compare the
on formal logic and
describe the problem and let
input with the knowledge
mathematical theories of
the computer figure out how
base and find solutions to
computation.
to solve it.
problems.
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=3`
Строки (ID элементов): D08:p0003:u0001, D08:p0003:u0004, D08:p0003:u0007, D08:p0003:u0008, D08:p0003:u0009, D08:p0003:u0010, D08:p0003:u0011, D08:p0003:u0013, D08:p0003:u0014, D08:p0003:u0017, D08:p0003:u0018, D08:p0003:u0021, D08:p0003:u0022, D08:p0003:u0024, D08:p0003:u0025, D08:p0003:u0026, D08:p0003:u0027, D08:p0003:u0030, D08:p0003:u0031, D08:p0003:u0032, D08:p0003:u0033, D08:p0003:u0034, D08:p0003:u0035, D08:p0003:u0036, D08:p0003:u0037, D08:p0003:u0038, D08:p0003:u0039, D08:p0003:u0040, D08:p0003:u0041, D08:p0003:u0042, D08:p0003:u0043
**Непроверенные OCR/формулы:** 12 исключённых из основного текста кандидатов; см. JSON.

````text
Basic Concepts of Prolog
What is Logic Programming?
What is Prolog?
{rUe. —answer from prolog interpreter
« “The use of mathematical logic for computer
Prolog is a logical and a declarative programming
‘ign on
programming.” (Wikipedia)
language.
The name ital, Prolog, i shor for PROgramming in
* “A declarative, relational style of
programming based on first-order logic.”
‘numeric computation.
(Dictionary.com)
Prolog is the major example of a fourth generation
Y = jane ; — type ; to get next solution
‘programming language
Syntax and Structure
Logic Programming
Interpreters
Prolog programs are composed
Logic programming is based on
Prolog programs are run by an
of facts and rules that follow a
rules, which consist of a head
interpreter that matches queries
specific syntax and structure.
and a body that define
to the knowledge base and
relationships between objects.
produces results.
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=4`
Строки (ID элементов): D08:p0004:u0001, D08:p0004:u0002, D08:p0004:u0003, D08:p0004:u0004

````text
Three Constructs in Prolog
- Facts
- Rules
- Queries
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=5`
Строки (ID элементов): D08:p0005:u0001, D08:p0005:u0002, D08:p0005:u0003, D08:p0005:u0004, D08:p0005:u0005, D08:p0005:u0006, D08:p0005:u0007, D08:p0005:u0008, D08:p0005:u0009

````text
Working with Facts and Rules in Prolog
Facts
Rules
Facts are statements that are always true in the
Rules define relationships between objects and
knowledge base, which can be used to build
can be used to solve problems by querying
further relationships between objects.
them with specific input.
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=6`
Строки (ID элементов): D08:p0006:u0001, D08:p0006:u0002, D08:p0006:u0003, D08:p0006:u0004, D08:p0006:u0005, D08:p0006:u0006, D08:p0006:u0007

````text
KNOWLEDGE
BASE
Facts and Rules
together
comprises a
knowledge base
of the program.
````

## D10 — Week 04 Lab.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/10_Week 04 Lab/source.pdf#page=4`
Строки (ID элементов): D10:p0004:u0001, D10:p0004:u0002, D10:p0004:u0003, D10:p0004:u0004, D10:p0004:u0005, D10:p0004:u0006, D10:p0004:u0007, D10:p0004:u0008, D10:p0004:u0009, D10:p0004:u0010, D10:p0004:u0011, D10:p0004:u0012, D10:p0004:u0013, D10:p0004:u0014, D10:p0004:u0015

````text
Prolog
•
Prolog is a general-purpose logic programming language associated
with artificial intelligence and computational linguistics
•
Prolog stands for Programming in Logic
•
Prolog has its roots in first-order logic, a formal logic, and unlike many
other programming languages, Prolog is declarative: the program logic is
expressed in terms of relations, represented as facts and rules. A
computation is initiated by running a query over these relations
•
The language was first conceived by a group around Alain
Colmerauer in Marseille, France, in the early 1970s and the first Prolog
system was developed in 1972 by Colmerauer with Philippe Roussel
````

## D10 — Week 04 Lab.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/10_Week 04 Lab/source.pdf#page=5`
Строки (ID элементов): D10:p0005:u0001, D10:p0005:u0002, D10:p0005:u0003, D10:p0005:u0004, D10:p0005:u0005, D10:p0005:u0006, D10:p0005:u0007, D10:p0005:u0008, D10:p0005:u0009, D10:p0005:u0010, D10:p0005:u0011

````text
Prolog Syntax & Semantics (1)
•
Comma ( , ) represents AND
For example: tiger(X) :- cat(X), big(X).
[X is tiger if X is cat AND X is big]
•
Semicolon ( ; ) represents OR
For example: animal(X) :- cat(X); dog(X).
[X is animal if X is car OR X is dog]
•
Dot ( . ) represents the end of the sentence.
````

## D10 — Week 04 Lab.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/10_Week 04 Lab/source.pdf#page=6`
Строки (ID элементов): D10:p0006:u0002, D10:p0006:u0003, D10:p0006:u0004, D10:p0006:u0005, D10:p0006:u0006, D10:p0006:u0007, D10:p0006:u0008, D10:p0006:u0009, D10:p0006:u0010, D10:p0006:u0011, D10:p0006:u0012, D10:p0006:u0013, D10:p0006:u0014, D10:p0006:u0015

````text
Prolog Syntax & Semantics (2)
•
Head :- Body.
•
Clauses with empty bodies are called facts
cat(tom). [Tom is cat]
•
Clauses with bodies are called rules. Rules describe new rules based on
facts and/or other rules
animal(X) :- cat(X). [X is animal if X is cat]
•
Queries are needed to show outputs. It is also called a goal
?- cat(X).
Answer: X = tom
````

## D10 — Week 04 Lab.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/10_Week 04 Lab/source.pdf#page=7`
Строки (ID элементов): D10:p0007:u0001, D10:p0007:u0002, D10:p0007:u0003, D10:p0007:u0004, D10:p0007:u0005, D10:p0007:u0006, D10:p0007:u0007, D10:p0007:u0008

````text
Prolog Syntax & Semantics (3)
•
Rules can be more complex and contain AND (",") or OR (";") operators.
animal(X) :- cat(X); dog(X). [X is animal if X is cat OR X is dog]
animal(X) :- cat(X), alive(X). [X is animal if X is cat AND X is alive]
•
Rules can also contain NOT ("not") operator.
pet(X) :- cat(X), not(wild(X)). [X is pet if X is cat AND X is not wild]
````

## D10 — Week 04 Lab.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/10_Week 04 Lab/source.pdf#page=8`
Строки (ID элементов): D10:p0008:u0001, D10:p0008:u0002, D10:p0008:u0003, D10:p0008:u0004, D10:p0008:u0005, D10:p0008:u0006, D10:p0008:u0007, D10:p0008:u0008, D10:p0008:u0009, D10:p0008:u0010, D10:p0008:u0011, D10:p0008:u0012
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Общая страница с:** AI-03-07
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
SWI-Prolog
•
Go to https://swish.swi-prolog.org/example/prolog_tutorials.swinb
•
It will look as following
Here you can add
1) Facts
2) Rules
Here you can see
Your output
Here you can add
Your queries
````

## D20 — Week 4 Lecture.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=15`
Строки (ID элементов): D20:p0015:u0001, D20:p0015:u0002, D20:p0015:u0003, D20:p0015:u0004, D20:p0015:u0005, D20:p0015:u0006, D20:p0015:u0007, D20:p0015:u0008, D20:p0015:u0009, D20:p0015:u0010, D20:p0015:u0011

````text
Prolog
- Prolog is a general-purpose logic programming language associated
with artificial intelligence and computational linguistics
- Prolog stands for Programming in Logic
- Prolog has its roots in first-order logic, a formal logic, and unlike many
other programming languages, Prolog is declarative: the program logic is
expressed in terms of relations, represented as facts and rules. A
computation is initiated by running a query over these relations
- The language was first conceived by a group around Alain
Colmerauer in Marseille, France, in the early 1970s and the first Prolog
system was developed in 1972 by Colmerauer with Philippe Roussel
````

## D20 — Week 4 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=16`
Строки (ID элементов): D20:p0016:u0001, D20:p0016:u0002, D20:p0016:u0003, D20:p0016:u0004, D20:p0016:u0005, D20:p0016:u0006, D20:p0016:u0007
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Prolog Applications
Used for
Expert Systems
AI planning
Natural
language
processing etc.
````

## D20 — Week 4 Lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=17`
Строки (ID элементов): D20:p0017:u0001, D20:p0017:u0002, D20:p0017:u0003, D20:p0017:u0004, D20:p0017:u0005, D20:p0017:u0006, D20:p0017:u0007, D20:p0017:u0008

````text
Why to Study?
- Prolog was one of the first logic programming languages and remains the
most popular such language today, with several free and commercial
implementations available
- Currently, not widespread, and not the fastest in terms of execution
- Very easy to understand and apply
- Someday its concept can become useful for programming like it
happened to functional programming languages
````

## D20 — Week 4 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=18`
Строки (ID элементов): D20:p0018:u0001, D20:p0018:u0002, D20:p0018:u0003, D20:p0018:u0004, D20:p0018:u0005, D20:p0018:u0006, D20:p0018:u0007, D20:p0018:u0008, D20:p0018:u0009, D20:p0018:u0010, D20:p0018:u0011
**Общая страница с:** AI-03-07

````text
Prolog
- All inferences are done by backward chaining, with depth-first search. That
means that whenever there is a dead end in the attempt to prove a
sentence, Prolog backs up to the most recent step that has alternatives.
- The order of search through the conjuncts of an antecedent (left hand
side) is strictly left to right, and clauses in the knowledge base are applied
in first-to-last order.
- Prolog is based on first-order logic, but doesn’t fully support it
- False statements are not provided
- Order varies
- Letter size for atoms and variables vary
````

## D20 — Week 4 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=19`
Строки (ID элементов): D20:p0019:u0001, D20:p0019:u0002, D20:p0019:u0003, D20:p0019:u0004, D20:p0019:u0005, D20:p0019:u0006, D20:p0019:u0007, D20:p0019:u0008, D20:p0019:u0009, D20:p0019:u0010
**Общая страница с:** AI-03-07

````text
Prolog Semantics
- Head :- Body.
- Clauses with empty bodies are called facts
cat(tom).
- Clauses with bodies are called rules. Rules describe new rules based on
facts and/or other rules
cat(X) :- animal(X).
- Queries are needed to show outputs. They are also called goals
?- cat(X).
Answer: X = tom
````

## D20 — Week 4 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=20`
Строки (ID элементов): D20:p0020:u0001, D20:p0020:u0002, D20:p0020:u0003, D20:p0020:u0004, D20:p0020:u0005, D20:p0020:u0006, D20:p0020:u0007, D20:p0020:u0008, D20:p0020:u0009, D20:p0020:u0010, D20:p0020:u0011
**Общая страница с:** AI-03-07

````text
Rule Example
- Facts and Rules together comprises a knowledge base of the program.
Rules consists of facts with added conditions
- Example: father(Y,Z) :- man(Y), son(Z,Y).
- If the body of the rule is true then the head is true
- “:-” is read as “if”
- “,” is logical AND
- “;” is logical OR
- The statement is read as: Y is a father of Z if Y is a man and Z is a son of Y.
- Note that order and semantics of the arguments are specified by programmer
- By father(Y,Z) we can mean that Y is a father of Z OR Z is father of Y
````


---

# AI-03-07 — Запросы, сопоставление и логический вывод Prolog

**Раздел РПД:** 3. Экспертные системы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Предскажи результат нескольких запросов к базе знаний и объясни цепочку сопоставлений.
**Пункты РПД:** RPD-14

**Связанные страницы:** 12; **символов извлечённого текста:** 3276.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=7`
Строки (ID элементов): D08:p0007:u0001, D08:p0007:u0002

````text
Queries are used on the knowledge base.
Syntax: Queries end with a “full stop”.
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=8`
Строки (ID элементов): D08:p0008:u0003, D08:p0008:u0004, D08:p0008:u0005, D08:p0008:u0006, D08:p0008:u0008, D08:p0008:u0009
**Общая страница с:** AI-03-05
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
main(){
procedure1()
procedure2()
return
Logical Programming
Functional Programming
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=9`
Строки (ID элементов): D08:p0009:u0001, D08:p0009:u0004, D08:p0009:u0019, D08:p0009:u0020, D08:p0009:u0021, D08:p0009:u0022, D08:p0009:u0023, D08:p0009:u0024, D08:p0009:u0025, D08:p0009:u0026, D08:p0009:u0027, D08:p0009:u0028, D08:p0009:u0029, D08:p0009:u0030, D08:p0009:u0031, D08:p0009:u0032, D08:p0009:u0033
**Общая страница с:** AI-03-05
**Непроверенные OCR/формулы:** 16 исключённых из основного текста кандидатов; см. JSON.

````text
Using Prolog for Logic Programming
19 NOT Gate
Rule-Based Systems
Logic Circuits
Expert Systems
Prolog is great for creating rule-
Prolog can simulate the behavior
Prolog is widely used for creating
based systems that can be used
of digital logic gates and circuits,
expert systems that can provide
for problem-solving in various
which can be used for testing
automated advice and decision-
fields.
logic designs.
making.
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=10`
Строки (ID элементов): D08:p0010:u0001, D08:p0010:u0002, D08:p0010:u0003, D08:p0010:u0004, D08:p0010:u0005, D08:p0010:u0006, D08:p0010:u0007, D08:p0010:u0008, D08:p0010:u0009, D08:p0010:u0010

````text
Disadvantages of Prolog
- 
Prolog does not have good Input/Output features compared to other
languages like LISP.
- 
Prolog cannot handle statements where one of several things is true, but you
don't know which.
- 
Prolog can be less performant than other languages, particularly for tasks that
require a lot of computation.
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=11`
Строки (ID элементов): D08:p0011:u0001, D08:p0011:u0002, D08:p0011:u0003, D08:p0011:u0004, D08:p0011:u0005, D08:p0011:u0006

````text
SWI-Prolog
- SWI-Prolog runs
on Windows, Macintosh and L
inux platforms.
- Can be used online:
https://swish.swi-prolog.org/
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=12`
Строки (ID элементов): D08:p0012:u0001, D08:p0012:u0002
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
DEMO
- https://swish.swi-prolog.org/
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=13`
Строки (ID элементов): D08:p0013:u0001, D08:p0013:u0002, D08:p0013:u0003, D08:p0013:u0004, D08:p0013:u0005, D08:p0013:u0006, D08:p0013:u0007, D08:p0013:u0008, D08:p0013:u0009, D08:p0013:u0010

````text
Example
- 
Lili is happy if she dances.
- 
Tom is hungry if he is searching for food.
- 
Andrew and Ilnar are friends if both of them love to
play football.
- 
Ryan will go to play if school is closed, and he is free.
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=14`
Строки (ID элементов): D08:p0014:u0001, D08:p0014:u0002, D08:p0014:u0003, D08:p0014:u0004, D08:p0014:u0005, D08:p0014:u0006, D08:p0014:u0007, D08:p0014:u0008, D08:p0014:u0009, D08:p0014:u0010, D08:p0014:u0011, D08:p0014:u0012, D08:p0014:u0013, D08:p0014:u0014, D08:p0014:u0015

````text
Example
- 
Lili is happy if she dances.
- 
Tom is hungry if he is searching for food.
- 
Andrew and Ilnar are friends if both of them love to
play football.
- 
Ryan will go to play if school is closed, and he is free.
Solution:happy(lili) :- dances(lili).
hungry(tom) :- search_for_food(tom).
friends(Andrew, Ilnar) :- lovesFootball(jack),
lovesFootball(bili).
goToPlay(ryan) :- isClosed(school), free(ryan).
````

## D10 — Week 04 Lab.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/10_Week 04 Lab/source.pdf#page=8`
Строки (ID элементов): D10:p0008:u0001, D10:p0008:u0002, D10:p0008:u0003, D10:p0008:u0004, D10:p0008:u0005, D10:p0008:u0006, D10:p0008:u0007, D10:p0008:u0008, D10:p0008:u0009, D10:p0008:u0010, D10:p0008:u0011, D10:p0008:u0012
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Общая страница с:** AI-03-06
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
SWI-Prolog
•
Go to https://swish.swi-prolog.org/example/prolog_tutorials.swinb
•
It will look as following
Here you can add
1) Facts
2) Rules
Here you can see
Your output
Here you can add
Your queries
````

## D20 — Week 4 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=18`
Строки (ID элементов): D20:p0018:u0001, D20:p0018:u0002, D20:p0018:u0003, D20:p0018:u0004, D20:p0018:u0005, D20:p0018:u0006, D20:p0018:u0007, D20:p0018:u0008, D20:p0018:u0009, D20:p0018:u0010, D20:p0018:u0011
**Общая страница с:** AI-03-06

````text
Prolog
- All inferences are done by backward chaining, with depth-first search. That
means that whenever there is a dead end in the attempt to prove a
sentence, Prolog backs up to the most recent step that has alternatives.
- The order of search through the conjuncts of an antecedent (left hand
side) is strictly left to right, and clauses in the knowledge base are applied
in first-to-last order.
- Prolog is based on first-order logic, but doesn’t fully support it
- False statements are not provided
- Order varies
- Letter size for atoms and variables vary
````

## D20 — Week 4 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=19`
Строки (ID элементов): D20:p0019:u0001, D20:p0019:u0002, D20:p0019:u0003, D20:p0019:u0004, D20:p0019:u0005, D20:p0019:u0006, D20:p0019:u0007, D20:p0019:u0008, D20:p0019:u0009, D20:p0019:u0010
**Общая страница с:** AI-03-06

````text
Prolog Semantics
- Head :- Body.
- Clauses with empty bodies are called facts
cat(tom).
- Clauses with bodies are called rules. Rules describe new rules based on
facts and/or other rules
cat(X) :- animal(X).
- Queries are needed to show outputs. They are also called goals
?- cat(X).
Answer: X = tom
````

## D20 — Week 4 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=20`
Строки (ID элементов): D20:p0020:u0001, D20:p0020:u0002, D20:p0020:u0003, D20:p0020:u0004, D20:p0020:u0005, D20:p0020:u0006, D20:p0020:u0007, D20:p0020:u0008, D20:p0020:u0009, D20:p0020:u0010, D20:p0020:u0011
**Общая страница с:** AI-03-06

````text
Rule Example
- Facts and Rules together comprises a knowledge base of the program.
Rules consists of facts with added conditions
- Example: father(Y,Z) :- man(Y), son(Z,Y).
- If the body of the rule is true then the head is true
- “:-” is read as “if”
- “,” is logical AND
- “;” is logical OR
- The statement is read as: Y is a father of Z if Y is a man and Z is a son of Y.
- Note that order and semantics of the arguments are specified by programmer
- By father(Y,Z) we can mean that Y is a father of Z OR Z is father of Y
````


---

# AI-03-08 — Термы, переменные, структуры и списки Prolog

**Раздел РПД:** 3. Экспертные системы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Составь запрос с составным термом и списком и объясни связывание переменных.
**Пункты РПД:** —

**Связанные страницы:** 13; **символов извлечённого текста:** 4625.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=15`
Строки (ID элементов): D08:p0015:u0001, D08:p0015:u0005, D08:p0015:u0006, D08:p0015:u0008, D08:p0015:u0009, D08:p0015:u0011
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Data Objects in Prolog
Simple Objects
Structures
Constants
Variables
Atoms
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=16`
Строки (ID элементов): D08:p0016:u0001, D08:p0016:u0002, D08:p0016:u0003, D08:p0016:u0004, D08:p0016:u0005, D08:p0016:u0006, D08:p0016:u0007, D08:p0016:u0008, D08:p0016:u0009, D08:p0016:u0010, D08:p0016:u0011
**Общая страница с:** AI-03-09

````text
Arithmetic Expressions
The is built-in predicate is used in Prolog to force the evaluation of
arithmetic expressions. If you just write something like X = 2 + 4, the
result is to bind X to the unevaluated term 2 + 4, not to 6. Example:
?- X = 2 + 4.
X = 2+4
If instead you write X is 2 + 4, Prolog arranges for the second
argument, the arithmetic expression 2 + 4, to be evaluated (giving the
result 6) before binding the result to X.
?- X is 2 + 4.
X = 6
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=17`
Строки (ID элементов): D08:p0017:u0001, D08:p0017:u0003, D08:p0017:u0004, D08:p0017:u0007, D08:p0017:u0009, D08:p0017:u0010, D08:p0017:u0012, D08:p0017:u0013, D08:p0017:u0017, D08:p0017:u0018, D08:p0017:u0021, D08:p0017:u0022, D08:p0017:u0025, D08:p0017:u0026, D08:p0017:u0029, D08:p0017:u0030, D08:p0017:u0033, D08:p0017:u0034, D08:p0017:u0037, D08:p0017:u0038, D08:p0017:u0041, D08:p0017:u0045, D08:p0017:u0049, D08:p0017:u0053
**Общая страница с:** AI-03-09
**Непроверенные OCR/формулы:** 30 исключённых из основного текста кандидатов; см. JSON.

````text
Compa!
Evaluate:
succeeds if X and Y unify (match) in the Prolog sense
succeeds if X and Y do not unify; i.e. if not (x = ¥)
T1 == T2
succeeds if terms T1 and T2 are identical; e.g. names of variables have to be the same
T1 \== T2
succeeds if terms T1 and T2 are not identical
succeeds if values of expressions E1 and E2 are equal
Yes
succeeds if values of expressions E1 and E2 are not equal
Yes
succeeds if numeric value of expression El is < numeric value of E2
Yes
succeeds if numeric value of expression E1 is < numeric value of E2
Yes
succeeds if numeric value of expression El is > numeric value of E2
Yes
succeeds if numeric value of expression El is = numeric value of E2
Yes
succeeds if T1 is alphabetically <T2
succeeds if T1 is alphabetically < T2
succeeds if T1 is alphabetically > T2
succeeds if T1 is alphabetically => T2
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=18`
Строки (ID элементов): D08:p0018:u0001, D08:p0018:u0002, D08:p0018:u0003, D08:p0018:u0004, D08:p0018:u0005, D08:p0018:u0006, D08:p0018:u0007, D08:p0018:u0008, D08:p0018:u0009, D08:p0018:u0010, D08:p0018:u0011, D08:p0018:u0012, D08:p0018:u0013, D08:p0018:u0014, D08:p0018:u0015, D08:p0018:u0016, D08:p0018:u0017, D08:p0018:u0018, D08:p0018:u0019, D08:p0018:u0020, D08:p0018:u0021, D08:p0018:u0022, D08:p0018:u0023, D08:p0018:u0024, D08:p0018:u0025, D08:p0018:u0026, D08:p0018:u0027, D08:p0018:u0028, D08:p0018:u0029, D08:p0018:u0030, D08:p0018:u0031
**Общая страница с:** AI-03-09

````text
LISTS
- 
Lists:
➢
[]
➢
[1, 2, 3]
➢
[4, chan]
➢
[pen, apple]
➢
[[pen, pineapple], [apple, pen]]
- 
HEADS | TAILS
➢
[1, 2, 3] % 1 - head,  [2, 3] - tail
➢
[H | T] % "read: H bar T" %
➢
[H | T] matches with [1, 2, 3] as [1 | [2, 3]]
- 
[1, _, 3]
➢
% could be:
➢
% [1, 2, 3]
➢
% [1, x, 3]
➢
% [1, [......], 3]
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=19`
Строки (ID элементов): D08:p0019:u0001, D08:p0019:u0002, D08:p0019:u0003, D08:p0019:u0004, D08:p0019:u0005, D08:p0019:u0006, D08:p0019:u0007, D08:p0019:u0008, D08:p0019:u0009, D08:p0019:u0010
**Общая страница с:** AI-03-09

````text
Inbuilt predicates in Prolog
-
Identify if an element is part of a list:
-
member( a, [a, b, c, d]).
-
Test for integers in a range:
-   maplist(between(1, 3), [1, 2, 3]).
…
http://www.gprolog.org/manual/html_node/gprolog024.html
````

## D20 — Week 4 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=21`
Строки (ID элементов): D20:p0021:u0001, D20:p0021:u0002, D20:p0021:u0003, D20:p0021:u0004, D20:p0021:u0005, D20:p0021:u0006

````text
Data Types
- Prolog's single data type is the term. There are 4 term types:
- Atoms
- Numbers (integers and floats)
- Variables
- Compound terms
````

## D20 — Week 4 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=22`
Строки (ID элементов): D20:p0022:u0001, D20:p0022:u0002, D20:p0022:u0003, D20:p0022:u0004, D20:p0022:u0005, D20:p0022:u0006, D20:p0022:u0007, D20:p0022:u0008

````text
Atoms
- An atom is a general-purpose name with no inherent meaning
- Should begin with a lowercase letter or should be surrounded by single
quotes
- May contain uppercase letters, lowercase letters, digits (0-9),
characters (+-*/<>=:~)
- Examples:
- cat, ‘Dog’, ‘another cat’, my_pet, myPet
````

## D20 — Week 4 Lecture.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=23`
Строки (ID элементов): D20:p0023:u0001, D20:p0023:u0002, D20:p0023:u0003, D20:p0023:u0004, D20:p0023:u0005, D20:p0023:u0006, D20:p0023:u0007, D20:p0023:u0008, D20:p0023:u0009, D20:p0023:u0010, D20:p0023:u0011, D20:p0023:u0012, D20:p0023:u0013, D20:p0023:u0014, D20:p0023:u0015, D20:p0023:u0016, D20:p0023:u0017, D20:p0023:u0018, D20:p0023:u0019

````text
Variables
- 
Variables consists of letters, digits and underscores. Variables start with uppercase letter or
underscore
- 
Examples:
- X, _Y, Piano, Person_1, DOLL
- 
Free variable is the one, for which the value was not assigned, bound is the opposite
- ?- 5 = 4 // false, ‘=’ is used for unification trying to bound both sides
- ?- X = 5, X = 4 // false, can’t be done for the second time
- ?- X = 5 + 4 // it is not a mathematical expression!
- ?- X is 5 + 4 // X = 9
- ?- X = Y, X = 5, Z is Y + 4 // X = 5, Y = 5, Z = 9
- ?- 1 is mod(7/2) // 1 is the remainder when 7 is divided by 2
- 
Anonymous variable denoted by ‘_’ makes the output for that variable invisible
- ?- father(X,_). // should return all fathers X without showing names of children
- ?- father(X,Y). // should return all pairs of fathers X and children Y names
````

## D20 — Week 4 Lecture.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=24`
Строки (ID элементов): D20:p0024:u0001, D20:p0024:u0002, D20:p0024:u0003, D20:p0024:u0004, D20:p0024:u0005, D20:p0024:u0006, D20:p0024:u0007

````text
Comparing Integers
- X  <  Y     // x < y
- X  =<  Y   // x ≤ y
- X  =:=  Y  // x = y
- X  =\=  Y // x ⁄ = y
- X  >=  Y   // x ≥ y
- X  >  Y     // x > y
````

## D20 — Week 4 Lecture.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=25`
Строки (ID элементов): D20:p0025:u0001, D20:p0025:u0002, D20:p0025:u0003, D20:p0025:u0004, D20:p0025:u0005, D20:p0025:u0006, D20:p0025:u0007, D20:p0025:u0008, D20:p0025:u0009, D20:p0025:u0010

````text
Compound Terms
- A compound term is composed of an atom called a "functor" and a
number of "arguments", which are again terms
- Compound terms are ordinarily written as a functor followed by a comma-
separated list of argument terms, which is contained in parentheses
- The number of arguments is called the term's arity. An atom can be
regarded as a compound term with arity zero
- Examples:
- friend(max,peter).
- person_friends(zelda, [tom,jim]).
````

## D20 — Week 4 Lecture.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=26`
Строки (ID элементов): D20:p0026:u0001, D20:p0026:u0002, D20:p0026:u0003, D20:p0026:u0004, D20:p0026:u0005, D20:p0026:u0006, D20:p0026:u0007, D20:p0026:u0008, D20:p0026:u0009

````text
List
- A list is an ordered collection of terms. It is denoted by square brackets with
the terms separated by commas
- It is a compound term type
- Examples:
- [1,2,3]
- [1]
- []
- [red,green,blue].
````

## D20 — Week 4 Lecture.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=27`
Строки (ID элементов): D20:p0027:u0001, D20:p0027:u0002, D20:p0027:u0003, D20:p0027:u0004, D20:p0027:u0005, D20:p0027:u0006, D20:p0027:u0007, D20:p0027:u0008

````text
Strings
- String is a sequence of characters surrounded by double quotes
- It is equivalent to either a list of (numeric) character codes, a list of
characters (atoms of length 1), or an atom depending on the value of the
Prolog flag double quotes
- It is a compound term type
- Examples:
- "to be, or not to be"
````

## D20 — Week 4 Lecture.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=28`
Строки (ID элементов): D20:p0028:u0001, D20:p0028:u0002, D20:p0028:u0003, D20:p0028:u0004, D20:p0028:u0005, D20:p0028:u0006, D20:p0028:u0007, D20:p0028:u0008, D20:p0028:u0009, D20:p0028:u0010, D20:p0028:u0011

````text
Useful Operators
- Negation: not(term) or \+ term
- female(X) :- not(male(X)).
- legal(X) :- \+ illegal(X).
- Not equal: \=
- X\=Y
- Cut: !
- Takes only the first result
- ?- parent(Y,X), !. // Even if there is more than 1 child with parent, will return only
// the first found pair, e.g. X=tom, Y=max
- write('Hello world!’). // prints Hello world!
````


---

# AI-03-09 — Рекурсия и вычисления в Prolog

**Раздел РПД:** 3. Экспертные системы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Напиши рекурсивное правило для списка или факториала и разбери работу на примере.
**Пункты РПД:** RPD-14

**Связанные страницы:** 14; **символов извлечённого текста:** 3505.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=16`
Строки (ID элементов): D08:p0016:u0001, D08:p0016:u0002, D08:p0016:u0003, D08:p0016:u0004, D08:p0016:u0005, D08:p0016:u0006, D08:p0016:u0007, D08:p0016:u0008, D08:p0016:u0009, D08:p0016:u0010, D08:p0016:u0011
**Общая страница с:** AI-03-08

````text
Arithmetic Expressions
The is built-in predicate is used in Prolog to force the evaluation of
arithmetic expressions. If you just write something like X = 2 + 4, the
result is to bind X to the unevaluated term 2 + 4, not to 6. Example:
?- X = 2 + 4.
X = 2+4
If instead you write X is 2 + 4, Prolog arranges for the second
argument, the arithmetic expression 2 + 4, to be evaluated (giving the
result 6) before binding the result to X.
?- X is 2 + 4.
X = 6
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=17`
Строки (ID элементов): D08:p0017:u0001, D08:p0017:u0003, D08:p0017:u0004, D08:p0017:u0007, D08:p0017:u0009, D08:p0017:u0010, D08:p0017:u0012, D08:p0017:u0013, D08:p0017:u0017, D08:p0017:u0018, D08:p0017:u0021, D08:p0017:u0022, D08:p0017:u0025, D08:p0017:u0026, D08:p0017:u0029, D08:p0017:u0030, D08:p0017:u0033, D08:p0017:u0034, D08:p0017:u0037, D08:p0017:u0038, D08:p0017:u0041, D08:p0017:u0045, D08:p0017:u0049, D08:p0017:u0053
**Общая страница с:** AI-03-08
**Непроверенные OCR/формулы:** 30 исключённых из основного текста кандидатов; см. JSON.

````text
Compa!
Evaluate:
succeeds if X and Y unify (match) in the Prolog sense
succeeds if X and Y do not unify; i.e. if not (x = ¥)
T1 == T2
succeeds if terms T1 and T2 are identical; e.g. names of variables have to be the same
T1 \== T2
succeeds if terms T1 and T2 are not identical
succeeds if values of expressions E1 and E2 are equal
Yes
succeeds if values of expressions E1 and E2 are not equal
Yes
succeeds if numeric value of expression El is < numeric value of E2
Yes
succeeds if numeric value of expression E1 is < numeric value of E2
Yes
succeeds if numeric value of expression El is > numeric value of E2
Yes
succeeds if numeric value of expression El is = numeric value of E2
Yes
succeeds if T1 is alphabetically <T2
succeeds if T1 is alphabetically < T2
succeeds if T1 is alphabetically > T2
succeeds if T1 is alphabetically => T2
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=18`
Строки (ID элементов): D08:p0018:u0001, D08:p0018:u0002, D08:p0018:u0003, D08:p0018:u0004, D08:p0018:u0005, D08:p0018:u0006, D08:p0018:u0007, D08:p0018:u0008, D08:p0018:u0009, D08:p0018:u0010, D08:p0018:u0011, D08:p0018:u0012, D08:p0018:u0013, D08:p0018:u0014, D08:p0018:u0015, D08:p0018:u0016, D08:p0018:u0017, D08:p0018:u0018, D08:p0018:u0019, D08:p0018:u0020, D08:p0018:u0021, D08:p0018:u0022, D08:p0018:u0023, D08:p0018:u0024, D08:p0018:u0025, D08:p0018:u0026, D08:p0018:u0027, D08:p0018:u0028, D08:p0018:u0029, D08:p0018:u0030, D08:p0018:u0031
**Общая страница с:** AI-03-08

````text
LISTS
- 
Lists:
➢
[]
➢
[1, 2, 3]
➢
[4, chan]
➢
[pen, apple]
➢
[[pen, pineapple], [apple, pen]]
- 
HEADS | TAILS
➢
[1, 2, 3] % 1 - head,  [2, 3] - tail
➢
[H | T] % "read: H bar T" %
➢
[H | T] matches with [1, 2, 3] as [1 | [2, 3]]
- 
[1, _, 3]
➢
% could be:
➢
% [1, 2, 3]
➢
% [1, x, 3]
➢
% [1, [......], 3]
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=19`
Строки (ID элементов): D08:p0019:u0001, D08:p0019:u0002, D08:p0019:u0003, D08:p0019:u0004, D08:p0019:u0005, D08:p0019:u0006, D08:p0019:u0007, D08:p0019:u0008, D08:p0019:u0009, D08:p0019:u0010
**Общая страница с:** AI-03-08

````text
Inbuilt predicates in Prolog
-
Identify if an element is part of a list:
-
member( a, [a, b, c, d]).
-
Test for integers in a range:
-   maplist(between(1, 3), [1, 2, 3]).
…
http://www.gprolog.org/manual/html_node/gprolog024.html
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=20`
Строки (ID элементов): D08:p0020:u0001, D08:p0020:u0002

````text
Exercise I
Write a program that compares two numbers.
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=21`
Строки (ID элементов): D08:p0021:u0001, D08:p0021:u0002, D08:p0021:u0003, D08:p0021:u0004, D08:p0021:u0005, D08:p0021:u0006, D08:p0021:u0007, D08:p0021:u0008, D08:p0021:u0009

````text
Exercise I - Solution
Write a program that compares two numbers.
Solution 1.
find_max(X, Y, X) :- X >= Y.
find_max(X, Y, Y) :- X < Y.
Solution 2.
gte(X,Y) :- X > Y,write('X is greater').
gte(X,Y) :- X =:= Y,write('X and Y are same').
gte(X,Y) :- X < Y,write('X is smaller').
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=22`
Строки (ID элементов): D08:p0022:u0001, D08:p0022:u0002, D08:p0022:u0003, D08:p0022:u0004

````text
Exercise I - Extension
Extend the program to a program that recursively
compares each element in the list to find the
maximum value.
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=23`
Строки (ID элементов): D08:p0023:u0001, D08:p0023:u0002, D08:p0023:u0003, D08:p0023:u0004, D08:p0023:u0005, D08:p0023:u0006, D08:p0023:u0007, D08:p0023:u0008

````text
Exercise I - Extension Solution
Extend the program to a program that recursively
compares each element in the list to find the
maximum value.
max_list([X], X).
max_list([H|T], Max) :-
max_list(T, RestMax),
Max is max(H, RestMax).
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=24`
Строки (ID элементов): D08:p0024:u0001, D08:p0024:u0002

````text
Exercise II
Write a program that checks if two lists are equal.
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=25`
Строки (ID элементов): D08:p0025:u0001, D08:p0025:u0002, D08:p0025:u0003, D08:p0025:u0004, D08:p0025:u0005, D08:p0025:u0006

````text
Exercise III: Factorial Checker
- Write the program to check if the factorial of the first value is equal to
the second value
- Expected outputs:
○?- factorial(3,6). // true
○?- factorial(3,5). // false
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=26`
Строки (ID элементов): D08:p0026:u0001, D08:p0026:u0002, D08:p0026:u0003

````text
Exercise IV: Sum of elements
Define a program sum_list that takes a list of integers as its first argument and
returns the sum of all the integers in the list as its second argument.
````

## D08 — Tutorial 4. Prolog.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/08_Tutorial 4. Prolog/source.pdf#page=27`
Строки (ID элементов): D08:p0027:u0001, D08:p0027:u0002, D08:p0027:u0003, D08:p0027:u0004

````text
Exercise V: Palindrome
Define a program palindrome that takes a list as its argument
and returns true if the list is a palindrome (i.e., reads the same
forwards and backwards).
````

## D10 — Week 04 Lab.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/10_Week 04 Lab/source.pdf#page=12`
Строки (ID элементов): D10:p0012:u0001, D10:p0012:u0002, D10:p0012:u0003

````text
Exercise 3
•
Write the program to count from 1 to 10 using recursive call of rule
````

## D10 — Week 04 Lab.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/10_Week 04 Lab/source.pdf#page=13`
Строки (ID элементов): D10:p0013:u0001, D10:p0013:u0002, D10:p0013:u0003, D10:p0013:u0004, D10:p0013:u0005, D10:p0013:u0006, D10:p0013:u0007, D10:p0013:u0008, D10:p0013:u0009

````text
Exercise 4: Homework
•
As previous exercise, we want to get all people with same surname without
adding rules to your code, only facts are used.
Your name is nick if you are a boy.
Your name is jane if you are a girl.
•
Hint:
you can make a good query that your rules will be embedded in.
````


---

# AI-03-10 — Проектирование базы знаний семейных отношений

**Раздел РПД:** 3. Экспертные системы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Создай небольшую базу генеалогии, запроси две нетривиальные связи и проверь ответы.
**Пункты РПД:** —

**Связанные страницы:** 8; **символов извлечённого текста:** 2704.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D10 — Week 04 Lab.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/10_Week 04 Lab/source.pdf#page=9`
Строки (ID элементов): D10:p0009:u0001, D10:p0009:u0002, D10:p0009:u0003, D10:p0009:u0004, D10:p0009:u0005, D10:p0009:u0006, D10:p0009:u0007, D10:p0009:u0008, D10:p0009:u0009, D10:p0009:u0010, D10:p0009:u0011, D10:p0009:u0012, D10:p0009:u0013, D10:p0009:u0014, D10:p0009:u0015, D10:p0009:u0016, D10:p0009:u0017, D10:p0009:u0018, D10:p0009:u0019

````text
Exercise 1: Family Tree - Interactive
1.
Based on lecture example draw your own family tree.
2.
Write the program with facts and rules for sisters, brothers, mother, father, aunts,
uncles, grandfathers and grandmothers. It should be possible to check all these
relations.
•
Create facts with
male(nick).
•
Create rules for these people like
mother(X,Y) :- parent(X,Y), female(X).
where X is mother, Y is a child.
•
Check queries with
?- mother(jane,nick).
•
If it is correct, then the output should be true. Otherwise, false.
````

## D10 — Week 04 Lab.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/10_Week 04 Lab/source.pdf#page=10`
Строки (ID элементов): D10:p0010:u0001, D10:p0010:u0002, D10:p0010:u0003, D10:p0010:u0004, D10:p0010:u0005, D10:p0010:u0006, D10:p0010:u0007, D10:p0010:u0008

````text
Exercise 1: Family Tree
brad
jane
dan
alice
mary
kate
nick
````

## D10 — Week 04 Lab.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/10_Week 04 Lab/source.pdf#page=11`
Строки (ID элементов): D10:p0011:u0001, D10:p0011:u0002, D10:p0011:u0003, D10:p0011:u0004, D10:p0011:u0005, D10:p0011:u0006, D10:p0011:u0007, D10:p0011:u0008, D10:p0011:u0009, D10:p0011:u0010, D10:p0011:u0011

````text
Exercise 2: Ages
Modify previous exercise adding surname, age, height and weight to each
person.
•
Show all people with your surname
•
Show all people with your age
•
Show all people with your height
•
Show all people with your weight
````

## D20 — Week 4 Lecture.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=29`
Строки (ID элементов): D20:p0029:u0001, D20:p0029:u0002, D20:p0029:u0003, D20:p0029:u0004, D20:p0029:u0005, D20:p0029:u0006, D20:p0029:u0007, D20:p0029:u0008, D20:p0029:u0009, D20:p0029:u0010, D20:p0029:u0011, D20:p0029:u0012

````text
Example: Family Tree (1/5)
- Let’s consider family tree. First step is to build family tree including sisters,
brothers, mother, father, aunts, uncles, grandfathers and grandmothers. It
should be possible to check all these abovementioned relations
- Create facts with
male(nick).
- Create rules for these people like
mother(X,Y) :- parent(X,Y), female(X).
where X is mother, Y is a child.
- Check queries with
?- mother(jane,nick).
- If it is correct, then the output should be true. Otherwise, false
````

## D20 — Week 4 Lecture.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=30`
Строки (ID элементов): D20:p0030:u0001, D20:p0030:u0002, D20:p0030:u0003, D20:p0030:u0004, D20:p0030:u0005, D20:p0030:u0006, D20:p0030:u0007, D20:p0030:u0008

````text
Example: Family Tree (2/5)
brad
jane
dan
alice
mary
kate
nick
````

## D20 — Week 4 Lecture.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=31`
Строки (ID элементов): D20:p0031:u0001, D20:p0031:u0002, D20:p0031:u0003, D20:p0031:u0004, D20:p0031:u0005, D20:p0031:u0006, D20:p0031:u0007, D20:p0031:u0008, D20:p0031:u0009, D20:p0031:u0010, D20:p0031:u0011, D20:p0031:u0012, D20:p0031:u0013, D20:p0031:u0014, D20:p0031:u0015, D20:p0031:u0016, D20:p0031:u0017

````text
Example: Family Tree (3/5)
Facts:
male(nick).
male(dan).
male(brad).
female(jane).
female(alice).
female(kate).
female(mary).
parent(dan,nick).
parent(dan,kate).
parent(jane,dan).
parent(brad,dan).
parent(jane,alice).
parent(brad,alice).
parent(mary,nick).
parent(mary,kate).
````

## D20 — Week 4 Lecture.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=32`
Строки (ID элементов): D20:p0032:u0001, D20:p0032:u0002, D20:p0032:u0003, D20:p0032:u0004, D20:p0032:u0005, D20:p0032:u0006, D20:p0032:u0007, D20:p0032:u0008, D20:p0032:u0009, D20:p0032:u0010, D20:p0032:u0011

````text
Example: Family Tree (4/5)
Rules:
father(X,Y) :- parent(X,Y), male(X).
mother(X,Y) :- parent(X,Y), female(X).
grandfather(X,Y) :- father(X,Z), parent(Z,Y).
grandmother(X,Y) :- mother(X,Z), parent(Z,Y).
sibling(X,Y) :- father(F,X), father(F,Y), mother(M,X), mother(M,Y), X\=Y.
brother(X,Y) :- sibling(X,Y), male(X), X\=Y.
sister(X,Y) :- sibling(X,Y), female(X), X\=Y.
aunt(X,Y) :- parent(Z,Y), sister(X,Z).
uncle(X,Y) :- parent(Z,Y), brother(X,Z).
````

## D20 — Week 4 Lecture.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/20_Week 4 Lecture/source.pdf#page=33`
Строки (ID элементов): D20:p0033:u0001, D20:p0033:u0002, D20:p0033:u0003, D20:p0033:u0004, D20:p0033:u0005, D20:p0033:u0006, D20:p0033:u0007, D20:p0033:u0008, D20:p0033:u0009, D20:p0033:u0010, D20:p0033:u0011, D20:p0033:u0012, D20:p0033:u0013, D20:p0033:u0014, D20:p0033:u0015, D20:p0033:u0016, D20:p0033:u0017, D20:p0033:u0018, D20:p0033:u0019, D20:p0033:u0020, D20:p0033:u0021, D20:p0033:u0022, D20:p0033:u0023, D20:p0033:u0024, D20:p0033:u0027, D20:p0033:u0028, D20:p0033:u0029, D20:p0033:u0030, D20:p0033:u0031, D20:p0033:u0032, D20:p0033:u0033
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Example: Family Tree (5/5)
1. Check if Jane is mother of Nick
Goal: ?- mother(jane,nick).
Answer: false
2. Check if Dan is father of Nick
Goal: ?- father(dan,nick).
Answer: true
3. Whose parent is Jane?
Goal: ?- parent(jane,X).
Answer: X = dan;
X = alice
4. Whose parent is Jane (only the
first found child)?
Goal: ?- parent(jane,X), !.
Answer: X = dan
5. Find all pairs of aunts with
nephews and nieces
Goal: ?- aunt(X,Y).
Answer: X = alice, Y = nick;
X = alice, Y = kate
6. Find all aunts without showing
their nephews and nieces
Goal: ?- aunt(X,_).
Answer: X = alice
brad
jane
dan
alice
mary
kate
nick
````


---

# AI-04-01 — Формулировка задачи поиска и пространства состояний

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Определи состояния, действия, цель и стоимость для новой задачи и покажи один переход.
**Пункты РПД:** —

**Связанные страницы:** 7; **символов извлечённого текста:** 3179.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D03 — Lecture 5.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=4`
Строки (ID элементов): D03:p0004:u0001, D03:p0004:u0002, D03:p0004:u0003, D03:p0004:u0004, D03:p0004:u0005, D03:p0004:u0006, D03:p0004:u0007, D03:p0004:u0008, D03:p0004:u0009, D03:p0004:u0010, D03:p0004:u0011, D03:p0004:u0012, D03:p0004:u0013, D03:p0004:u0014, D03:p0004:u0015, D03:p0004:u0016, D03:p0004:u0042, D03:p0004:u0044
**Непроверенные OCR/формулы:** 13 исключённых из основного текста кандидатов; см. JSON.

````text
Your Car is Lost in a Carpark
- How would you find it?
- Walk at random
- No guarantee you will find it
- Could be lost forever
- Walk down each row
- Guarantee you will find it
- Might take a long time
- Walk to the place you think it was last, then expand your search
- Guarantee you will find it
- As long as your memory is good – on average it will be less than every row, worst case
just as good
- Walk to the place you think it was last, hit the alarm button, then expand search
- Guarantee you will find it
- Alarm can be heard from a long way away, and if you press it to no effect the car is
not local to you (radius of activation)
“Here ya go, I'm always losing mine
in big parking lots, too.”
````

## D03 — Lecture 5.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=5`
Строки (ID элементов): D03:p0005:u0001, D03:p0005:u0002, D03:p0005:u0003, D03:p0005:u0004, D03:p0005:u0005, D03:p0005:u0006, D03:p0005:u0007, D03:p0005:u0008, D03:p0005:u0009, D03:p0005:u0010, D03:p0005:u0011
**Общая страница с:** AI-04-02

````text
Search Space
- Many problems define a set of actions on an environment which can be
seen as a search space of states
- We are at one point in the environment with a destination, there is a list of action
states which will bring us to the destination
- Each search type is a method of navigation of the space
- We will rarely want to go to the same point in the search space
- Represents a cycle in the search, which is not useful in terms of state spaces
- Solution – most searches will avoid this by using tree structures
- Each node in the tree is a state within the search
- Search Trees, Game Trees
````

## D03 — Lecture 5.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=6`
Строки (ID элементов): D03:p0006:u0001, D03:p0006:u0002, D03:p0006:u0003, D03:p0006:u0004, D03:p0006:u0005, D03:p0006:u0006, D03:p0006:u0007, D03:p0006:u0008, D03:p0006:u0009
**Общая страница с:** AI-04-02

````text
Types of Searches
Uninformed Search
- Have no sense of the problem
domain
- Generally applicable in all cases
Informed Search
- Use a heuristic function
developed for the domain
- Applicable in their own domain
````

## D03 — Lecture 5.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=7`
Строки (ID элементов): D03:p0007:u0001, D03:p0007:u0002, D03:p0007:u0003, D03:p0007:u0004, D03:p0007:u0005, D03:p0007:u0006, D03:p0007:u0007, D03:p0007:u0008, D03:p0007:u0009, D03:p0007:u0010, D03:p0007:u0011
**Общая страница с:** AI-02-07

````text
Goal-based Agent
- Four Steps in the Agent:
1. Define Goals
- What are the states which are considered to be satisfying the goal?
2. Problem Formulation
- What actions are available to move towards the goal?
- What states are available to move towards the goal?
3. Search
- Determine the pathway of states in order to meet with the goal
4. Execute
- Move through the series of states
````

## D03 — Lecture 5.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=8`
Строки (ID элементов): D03:p0008:u0001, D03:p0008:u0002, D03:p0008:u0003, D03:p0008:u0004, D03:p0008:u0005, D03:p0008:u0006, D03:p0008:u0007, D03:p0008:u0008, D03:p0008:u0009, D03:p0008:u0010, D03:p0008:u0011, D03:p0008:u0012, D03:p0008:u0013
**Общая страница с:** AI-02-07
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Example: Painting Robot
(simplified)
1. Goal
- All show surfaces of the part are covered in 1mm of paint
2. Problem Formulation
- A sequence of points about the part for the robot arm to move into in order to
ensure a dispersal about the entire part
3. Search
- Examine all pathways about the part, taking into account the movements on
each part of the arm
- A pathway is good as long as it covers the part with 1mm of paint
4. Execute
- The arm moves through the sequence of positions
````

## D03 — Lecture 5.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=9`
Строки (ID элементов): D03:p0009:u0001, D03:p0009:u0002, D03:p0009:u0003, D03:p0009:u0004, D03:p0009:u0005, D03:p0009:u0006, D03:p0009:u0007, D03:p0009:u0008, D03:p0009:u0009, D03:p0009:u0010, D03:p0009:u0011, D03:p0009:u0016, D03:p0009:u0020, D03:p0009:u0023, D03:p0009:u0032
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
States Space of the Robot
- State space is defined as the location of all
moving elements on the robot
- Relative positioning on all joints from a home
position
- Might also include the rate of spray on the
nozzle – from 0 to full
- Transitions of states could be broken down
into a sequence of movements in the joints
on each rotational axis (hence a 6-axis robot)
- Move(Elbow, X degrees)
4th axis
6th axis
Sth axis
ist axis
````

## D03 — Lecture 5.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=10`
Строки (ID элементов): D03:p0010:u0001, D03:p0010:u0002, D03:p0010:u0003, D03:p0010:u0004, D03:p0010:u0005, D03:p0010:u0006, D03:p0010:u0007, D03:p0010:u0008, D03:p0010:u0009, D03:p0010:u0010, D03:p0010:u0011, D03:p0010:u0012, D03:p0010:u0013, D03:p0010:u0014
**Общая страница с:** AI-04-05
**Непроверенные OCR/формулы:** 17 исключённых из основного текста кандидатов; см. JSON.

````text
N Queens and Incremental Goals
- Place N queens onto an NxN chess board
such that no queen attacks any other
queen; a more complicated problem is a
Costas Array
- States
- Place a queen down
- Goal
- No queen attacks any other queen
- Hard sometimes to see a good pathway to
the goal
- Need a measure in order to see a good
pathway
- Minimize the number of queen attacks
````


---

# AI-04-02 — Информированный и неинформированный поиск

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Сравни два поиска для одной задачи и укажи, откуда в одном берётся дополнительная информация.
**Пункты РПД:** RPD-15, RPD-16

**Связанные страницы:** 3; **символов извлечённого текста:** 1197.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D03 — Lecture 5.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=5`
Строки (ID элементов): D03:p0005:u0001, D03:p0005:u0002, D03:p0005:u0003, D03:p0005:u0004, D03:p0005:u0005, D03:p0005:u0006, D03:p0005:u0007, D03:p0005:u0008, D03:p0005:u0009, D03:p0005:u0010, D03:p0005:u0011
**Общая страница с:** AI-04-01

````text
Search Space
- Many problems define a set of actions on an environment which can be
seen as a search space of states
- We are at one point in the environment with a destination, there is a list of action
states which will bring us to the destination
- Each search type is a method of navigation of the space
- We will rarely want to go to the same point in the search space
- Represents a cycle in the search, which is not useful in terms of state spaces
- Solution – most searches will avoid this by using tree structures
- Each node in the tree is a state within the search
- Search Trees, Game Trees
````

## D03 — Lecture 5.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=6`
Строки (ID элементов): D03:p0006:u0001, D03:p0006:u0002, D03:p0006:u0003, D03:p0006:u0004, D03:p0006:u0005, D03:p0006:u0006, D03:p0006:u0007, D03:p0006:u0008, D03:p0006:u0009
**Общая страница с:** AI-04-01

````text
Types of Searches
Uninformed Search
- Have no sense of the problem
domain
- Generally applicable in all cases
Informed Search
- Use a heuristic function
developed for the domain
- Applicable in their own domain
````

## D03 — Lecture 5.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=11`
Строки (ID элементов): D03:p0011:u0001, D03:p0011:u0002, D03:p0011:u0003, D03:p0011:u0004, D03:p0011:u0005, D03:p0011:u0006, D03:p0011:u0007, D03:p0011:u0008, D03:p0011:u0009, D03:p0011:u0010
**Общая страница с:** AI-04-03

````text
Tree Search
- Recursive definition of a tree search as
depth-first search (DFS)
- SearchTree(State, Move, Visited list)
- New State <- Apply Move
- If (New State == Goal) – return TRUE
- Else
- If neighbouring states are empty - return FALSE
- For each of the MOVE on neighbouring states not in Visited list
- If SearchTree(Neighbouring states, MOVE, Visited list + State) return TRUE;
````


---

# AI-04-03 — Поиск в глубину и представление дерева

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Проведи поиск в глубину на графе с циклом и покажи стек и множество посещённых.
**Пункты РПД:** RPD-15

**Связанные страницы:** 2; **символов извлечённого текста:** 1010.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D03 — Lecture 5.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=11`
Строки (ID элементов): D03:p0011:u0001, D03:p0011:u0002, D03:p0011:u0003, D03:p0011:u0004, D03:p0011:u0005, D03:p0011:u0006, D03:p0011:u0007, D03:p0011:u0008, D03:p0011:u0009, D03:p0011:u0010
**Общая страница с:** AI-04-02

````text
Tree Search
- Recursive definition of a tree search as
depth-first search (DFS)
- SearchTree(State, Move, Visited list)
- New State <- Apply Move
- If (New State == Goal) – return TRUE
- Else
- If neighbouring states are empty - return FALSE
- For each of the MOVE on neighbouring states not in Visited list
- If SearchTree(Neighbouring states, MOVE, Visited list + State) return TRUE;
````

## D03 — Lecture 5.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=12`
Строки (ID элементов): D03:p0012:u0001, D03:p0012:u0002, D03:p0012:u0003, D03:p0012:u0004, D03:p0012:u0005, D03:p0012:u0006, D03:p0012:u0007, D03:p0012:u0008, D03:p0012:u0009, D03:p0012:u0010, D03:p0012:u0011, D03:p0012:u0012
**Общая страница с:** AI-04-04

````text
Backtracking Searches
- Move towards the goal. If you reach a position which is going to be less
successful – stop and move back up the tree (backtrack, retrace your steps)
- Recursive definition of a DFS of a backtrack:
- SearchTreeBacktrack(State, Move, Visited list)
- New State <- Apply Move
- If (New State == Goal) – return TRUE
- If (New State causes an invalid path to goal/or costs too much) – return FALSE
- Else
- If neighbouring states are empty - return FALSE
- For each of the MOVE on neighbouring states not in Visited list
- If SearchTreeBacktrack(Neighbouring states, MOVE, Visited list + State) return TRUE;
````


---

# AI-04-04 — Поиск с возвратом и отсечение ветвей

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Реши маленькую задачу ограничений backtracking и поясни момент отката.
**Пункты РПД:** RPD-17

**Связанные страницы:** 8; **символов извлечённого текста:** 2331.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D02 — Lab 4 (without solution).pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=4`
Строки (ID элементов): D02:p0004:u0001, D02:p0004:u0002, D02:p0004:u0003, D02:p0004:u0004, D02:p0004:u0005, D02:p0004:u0006, D02:p0004:u0007, D02:p0004:u0008, D02:p0004:u0009, D02:p0004:u0010, D02:p0004:u0011, D02:p0004:u0012, D02:p0004:u0013, D02:p0004:u0014, D02:p0004:u0015, D02:p0004:u0016, D02:p0004:u0017

````text
Backtracking
- Simulate the entire game
- Assume rational/perfect play from the opponent
- Theoretically there is a perfect game play method if we search the entire game
- 
Solved Games
- 
Tic Tac Toe
- 
Checkers
- Two player heads-up limit poker – Recent discovery by researchers in
University of Alberta
- Unsolved
- 
Chess
- 
Go
````

## D02 — Lab 4 (without solution).pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=5`
Строки (ID элементов): D02:p0005:u0001, D02:p0005:u0002, D02:p0005:u0003, D02:p0005:u0004, D02:p0005:u0005, D02:p0005:u0006, D02:p0005:u0007, D02:p0005:u0008, D02:p0005:u0009, D02:p0005:u0010, D02:p0005:u0011
**Общая страница с:** AI-04-10

````text
Backtracking with Alpha Beta Cuts
- Heuristic search based on backtracking
- Used in situations where there is a value to the solution at each point to
allow for an evaluation
- Applied for Game Trees
- Alpha Cut
- 
Maximum lower bound (Max Plays - Black)
- Beta Cut
- 
Minimum upper bound (Min Play - Red)
````

## D02 — Lab 4 (without solution).pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=6`
Строки (ID элементов): D02:p0006:u0001, D02:p0006:u0002, D02:p0006:u0003, D02:p0006:u0004, D02:p0006:u0005, D02:p0006:u0006, D02:p0006:u0007, D02:p0006:u0008, D02:p0006:u0009, D02:p0006:u0010, D02:p0006:u0011, D02:p0006:u0012, D02:p0006:u0013, D02:p0006:u0014, D02:p0006:u0015, D02:p0006:u0016, D02:p0006:u0033
**Общая страница с:** AI-04-05
**Непроверенные OCR/формулы:** 17 исключённых из основного текста кандидатов; см. JSON.

````text
N Queens and Incremental Goals
- Place N queens onto an NxN chess board
such that no queen attacks any other queen;
a more complicated problem is a Costas Array
- States
- 
Place a queen down
- Goal
- 
No queen attacks any other queen
- 
Hard sometimes to see a good pathway to the goal
- Need a measure in order to see a good
pathway
- 
Minimize number of queens attacking
7
````

## D02 — Lab 4 (without solution).pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=7`
Строки (ID элементов): D02:p0007:u0001, D02:p0007:u0002, D02:p0007:u0003, D02:p0007:u0004, D02:p0007:u0005, D02:p0007:u0006, D02:p0007:u0007, D02:p0007:u0008, D02:p0007:u0009, D02:p0007:u0010, D02:p0007:u0011, D02:p0007:u0012, D02:p0007:u0013, D02:p0007:u0014, D02:p0007:u0015, D02:p0007:u0016, D02:p0007:u0017, D02:p0007:u0018, D02:p0007:u0019, D02:p0007:u0020, D02:p0007:u0021, D02:p0007:u0022, D02:p0007:u0023, D02:p0007:u0024, D02:p0007:u0025, D02:p0007:u0026, D02:p0007:u0027, D02:p0007:u0028, D02:p0007:u0029, D02:p0007:u0030, D02:p0007:u0031, D02:p0007:u0034, D02:p0007:u0035, D02:p0007:u0036, D02:p0007:u0037, D02:p0007:u0038, D02:p0007:u0039, D02:p0007:u0040, D02:p0007:u0041
**Общая страница с:** AI-04-05

````text
Solutions for N Queens Problem
N
Fundamental
All
1
1
1
2
0
0
3
0
0
4
1
2
5
2
10
6
1
4
7
6
40
8
12
92
…
…
…
- If solutions that differ only by the
symmetry operations of rotation
and reflection of the board are
counted as one and called
fundamental solutions
- Solutions exist for all natural
numbers N with the exception of
N = 2 and N = 3
````

## D02 — Lab 4 (without solution).pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=8`
Строки (ID элементов): D02:p0008:u0001, D02:p0008:u0002, D02:p0008:u0003, D02:p0008:u0004
**Общая страница с:** AI-04-05

````text
N Queens Problem
- By using backtracking algorithm preferably with heuristics solve
the N queens problem with N=4
- Which heuristics to apply?
````

## D03 — Lecture 5.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=12`
Строки (ID элементов): D03:p0012:u0001, D03:p0012:u0002, D03:p0012:u0003, D03:p0012:u0004, D03:p0012:u0005, D03:p0012:u0006, D03:p0012:u0007, D03:p0012:u0008, D03:p0012:u0009, D03:p0012:u0010, D03:p0012:u0011, D03:p0012:u0012
**Общая страница с:** AI-04-03

````text
Backtracking Searches
- Move towards the goal. If you reach a position which is going to be less
successful – stop and move back up the tree (backtrack, retrace your steps)
- Recursive definition of a DFS of a backtrack:
- SearchTreeBacktrack(State, Move, Visited list)
- New State <- Apply Move
- If (New State == Goal) – return TRUE
- If (New State causes an invalid path to goal/or costs too much) – return FALSE
- Else
- If neighbouring states are empty - return FALSE
- For each of the MOVE on neighbouring states not in Visited list
- If SearchTreeBacktrack(Neighbouring states, MOVE, Visited list + State) return TRUE;
````

## D03 — Lecture 5.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=13`
Строки (ID элементов): D03:p0013:u0001
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Sudoku
````

## D03 — Lecture 5.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=14`
Строки (ID элементов): D03:p0014:u0001, D03:p0014:u0002, D03:p0014:u0003, D03:p0014:u0004, D03:p0014:u0005, D03:p0014:u0006, D03:p0014:u0007, D03:p0014:u0008, D03:p0014:u0021, D03:p0014:u0022, D03:p0014:u0023, D03:p0014:u0025, D03:p0014:u0027, D03:p0014:u0029, D03:p0014:u0030, D03:p0014:u0031, D03:p0014:u0032, D03:p0014:u0034, D03:p0014:u0035
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
Backtrack on Sudoku
- Is valid?
- Check if we have not violated the rules
- 1-9 in each row
- 1-9 in each column
- 1-9 in each box
- Choice at each empty box 1-9
- Multiple Solutions?
8
6
3
4
1
7
2
6
6
419
5
````


---

# AI-04-05 — Расстановка N ферзей

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Реши 4-queens с пошаговыми проверками ограничений и отсечениями.
**Пункты РПД:** RPD-45

**Связанные страницы:** 6; **символов извлечённого текста:** 1764.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D02 — Lab 4 (without solution).pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=6`
Строки (ID элементов): D02:p0006:u0001, D02:p0006:u0002, D02:p0006:u0003, D02:p0006:u0004, D02:p0006:u0005, D02:p0006:u0006, D02:p0006:u0007, D02:p0006:u0008, D02:p0006:u0009, D02:p0006:u0010, D02:p0006:u0011, D02:p0006:u0012, D02:p0006:u0013, D02:p0006:u0014, D02:p0006:u0015, D02:p0006:u0016, D02:p0006:u0033
**Общая страница с:** AI-04-04
**Непроверенные OCR/формулы:** 17 исключённых из основного текста кандидатов; см. JSON.

````text
N Queens and Incremental Goals
- Place N queens onto an NxN chess board
such that no queen attacks any other queen;
a more complicated problem is a Costas Array
- States
- 
Place a queen down
- Goal
- 
No queen attacks any other queen
- 
Hard sometimes to see a good pathway to the goal
- Need a measure in order to see a good
pathway
- 
Minimize number of queens attacking
7
````

## D02 — Lab 4 (without solution).pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=7`
Строки (ID элементов): D02:p0007:u0001, D02:p0007:u0002, D02:p0007:u0003, D02:p0007:u0004, D02:p0007:u0005, D02:p0007:u0006, D02:p0007:u0007, D02:p0007:u0008, D02:p0007:u0009, D02:p0007:u0010, D02:p0007:u0011, D02:p0007:u0012, D02:p0007:u0013, D02:p0007:u0014, D02:p0007:u0015, D02:p0007:u0016, D02:p0007:u0017, D02:p0007:u0018, D02:p0007:u0019, D02:p0007:u0020, D02:p0007:u0021, D02:p0007:u0022, D02:p0007:u0023, D02:p0007:u0024, D02:p0007:u0025, D02:p0007:u0026, D02:p0007:u0027, D02:p0007:u0028, D02:p0007:u0029, D02:p0007:u0030, D02:p0007:u0031, D02:p0007:u0034, D02:p0007:u0035, D02:p0007:u0036, D02:p0007:u0037, D02:p0007:u0038, D02:p0007:u0039, D02:p0007:u0040, D02:p0007:u0041
**Общая страница с:** AI-04-04

````text
Solutions for N Queens Problem
N
Fundamental
All
1
1
1
2
0
0
3
0
0
4
1
2
5
2
10
6
1
4
7
6
40
8
12
92
…
…
…
- If solutions that differ only by the
symmetry operations of rotation
and reflection of the board are
counted as one and called
fundamental solutions
- Solutions exist for all natural
numbers N with the exception of
N = 2 and N = 3
````

## D02 — Lab 4 (without solution).pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=8`
Строки (ID элементов): D02:p0008:u0001, D02:p0008:u0002, D02:p0008:u0003, D02:p0008:u0004
**Общая страница с:** AI-04-04

````text
N Queens Problem
- By using backtracking algorithm preferably with heuristics solve
the N queens problem with N=4
- Which heuristics to apply?
````

## D02 — Lab 4 (without solution).pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=9`
Строки (ID элементов): D02:p0009:u0001, D02:p0009:u0002, D02:p0009:u0003, D02:p0009:u0004, D02:p0009:u0005, D02:p0009:u0006

````text
N Queens Problem
- By using backtracking algorithm preferably with heuristics solve
the N queens problem with N=4
- Which heuristics to apply?
- No more than 1 queen on rows, columns and on the diagonals
- If while consideration the column/row was left empty, backtrack
````

## D02 — Lab 4 (without solution).pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=10`
Строки (ID элементов): D02:p0010:u0001, D02:p0010:u0002, D02:p0010:u0003, D02:p0010:u0004, D02:p0010:u0005, D02:p0010:u0006
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
N Queens Problem
- By using backtracking algorithm preferably with heuristics solve
the N queens problem with N=4
- Which heuristics to apply?
- No more than 1 queen on rows, columns and on the diagonals
- If while consideration the column/row was left empty, backtrack
````

## D03 — Lecture 5.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=10`
Строки (ID элементов): D03:p0010:u0001, D03:p0010:u0002, D03:p0010:u0003, D03:p0010:u0004, D03:p0010:u0005, D03:p0010:u0006, D03:p0010:u0007, D03:p0010:u0008, D03:p0010:u0009, D03:p0010:u0010, D03:p0010:u0011, D03:p0010:u0012, D03:p0010:u0013, D03:p0010:u0014
**Общая страница с:** AI-04-01
**Непроверенные OCR/формулы:** 17 исключённых из основного текста кандидатов; см. JSON.

````text
N Queens and Incremental Goals
- Place N queens onto an NxN chess board
such that no queen attacks any other
queen; a more complicated problem is a
Costas Array
- States
- Place a queen down
- Goal
- No queen attacks any other queen
- Hard sometimes to see a good pathway to
the goal
- Need a measure in order to see a good
pathway
- Minimize the number of queen attacks
````


---

# AI-04-06 — Эвристическая функция

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Предложи две эвристики для 8-puzzle и объясни их преимущества и ограничения.
**Пункты РПД:** RPD-16

**Связанные страницы:** 12; **символов извлечённого текста:** 2843.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D03 — Lecture 5.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=15`
Строки (ID элементов): D03:p0015:u0001, D03:p0015:u0002, D03:p0015:u0003, D03:p0015:u0004, D03:p0015:u0005, D03:p0015:u0006, D03:p0015:u0007, D03:p0015:u0008, D03:p0015:u0009, D03:p0015:u0010

````text
Heuristic Search
- Word heuristic comes from the Greek for discovery
- Heuristics use an educated guess on where to move the search next –
rules-based movement about a search space
- Not necessarily deterministic – may have stochastic generation methods
- Trial and Error
- Experimental and Experiential
- Does not guarantee the most optimal solution
- Examples
- Greedy Approaches and Hill Climbers are heuristics
````

## D03 — Lecture 5.pdf, PDF-страница 43
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=43`
Строки (ID элементов): D03:p0043:u0001, D03:p0043:u0002, D03:p0043:u0003, D03:p0043:u0004, D03:p0043:u0005, D03:p0043:u0006, D03:p0043:u0007, D03:p0043:u0010, D03:p0043:u0011, D03:p0043:u0012, D03:p0043:u0013, D03:p0043:u0014, D03:p0043:u0015, D03:p0043:u0016, D03:p0043:u0017, D03:p0043:u0018, D03:p0043:u0019, D03:p0043:u0020, D03:p0043:u0021, D03:p0043:u0022, D03:p0043:u0023, D03:p0043:u0024, D03:p0043:u0025, D03:p0043:u0026, D03:p0043:u0027
**Общая страница с:** AI-04-12
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
8-puzzle Problem
- The 8-puzzle problem is a puzzle invented and popularized by Noyes Palmer
Chapman in the 1870s. It is played on a 3-by-3 grid with 8 square blocks
labeled 1 through 8 and a blank square
- Goal is to rearrange the blocks so that they are in order. It is permitted to
slide blocks horizontally or vertically into the blank square
- In general, there are 9!/2 = 181,400 reachable states
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Initial state
Goal state
````

## D03 — Lecture 5.pdf, PDF-страница 44
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=44`
Строки (ID элементов): D03:p0044:u0001, D03:p0044:u0002, D03:p0044:u0003, D03:p0044:u0006, D03:p0044:u0007, D03:p0044:u0008, D03:p0044:u0009, D03:p0044:u0010, D03:p0044:u0011, D03:p0044:u0012, D03:p0044:u0013, D03:p0044:u0014, D03:p0044:u0015, D03:p0044:u0016, D03:p0044:u0017, D03:p0044:u0018, D03:p0044:u0019, D03:p0044:u0020, D03:p0044:u0021, D03:p0044:u0022, D03:p0044:u0023
**Общая страница с:** AI-04-12

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
ℎ= 5
````

## D03 — Lecture 5.pdf, PDF-страница 45
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=45`
Строки (ID элементов): D03:p0045:u0001, D03:p0045:u0002, D03:p0045:u0003, D03:p0045:u0006, D03:p0045:u0007, D03:p0045:u0008, D03:p0045:u0009, D03:p0045:u0010, D03:p0045:u0011, D03:p0045:u0012, D03:p0045:u0013, D03:p0045:u0014, D03:p0045:u0015, D03:p0045:u0016, D03:p0045:u0017, D03:p0045:u0018, D03:p0045:u0019, D03:p0045:u0020, D03:p0045:u0021, D03:p0045:u0022, D03:p0045:u0023, D03:p0045:u0024, D03:p0045:u0025, D03:p0045:u0026, D03:p0045:u0027, D03:p0045:u0028, D03:p0045:u0029, D03:p0045:u0030, D03:p0045:u0031, D03:p0045:u0032, D03:p0045:u0033, D03:p0045:u0034, D03:p0045:u0035, D03:p0045:u0036, D03:p0045:u0037, D03:p0045:u0038, D03:p0045:u0039, D03:p0045:u0040, D03:p0045:u0041, D03:p0045:u0042, D03:p0045:u0043, D03:p0045:u0044, D03:p0045:u0045, D03:p0045:u0046, D03:p0045:u0047, D03:p0045:u0048, D03:p0045:u0049, D03:p0045:u0050
**Общая страница с:** AI-04-12
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
8
6
5
7
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
ℎ= 5
ℎ= 6
ℎ= 4
ℎ= 5
````

## D03 — Lecture 5.pdf, PDF-страница 46
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=46`
Строки (ID элементов): D03:p0046:u0001, D03:p0046:u0002, D03:p0046:u0003, D03:p0046:u0006, D03:p0046:u0007, D03:p0046:u0008, D03:p0046:u0009, D03:p0046:u0010, D03:p0046:u0011, D03:p0046:u0012, D03:p0046:u0013, D03:p0046:u0014, D03:p0046:u0015, D03:p0046:u0016, D03:p0046:u0017, D03:p0046:u0018, D03:p0046:u0019, D03:p0046:u0020, D03:p0046:u0021, D03:p0046:u0022, D03:p0046:u0023, D03:p0046:u0024, D03:p0046:u0025, D03:p0046:u0026, D03:p0046:u0027, D03:p0046:u0028, D03:p0046:u0029, D03:p0046:u0030, D03:p0046:u0031, D03:p0046:u0032
**Общая страница с:** AI-04-12

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
ℎ= 5
ℎ= 4
````

## D03 — Lecture 5.pdf, PDF-страница 47
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=47`
Строки (ID элементов): D03:p0047:u0001, D03:p0047:u0002, D03:p0047:u0003, D03:p0047:u0006, D03:p0047:u0007, D03:p0047:u0008, D03:p0047:u0009, D03:p0047:u0010, D03:p0047:u0011, D03:p0047:u0012, D03:p0047:u0013, D03:p0047:u0014, D03:p0047:u0015, D03:p0047:u0016, D03:p0047:u0017, D03:p0047:u0018, D03:p0047:u0019, D03:p0047:u0020, D03:p0047:u0021, D03:p0047:u0022, D03:p0047:u0023, D03:p0047:u0024, D03:p0047:u0025, D03:p0047:u0026, D03:p0047:u0027, D03:p0047:u0028, D03:p0047:u0029, D03:p0047:u0030, D03:p0047:u0031, D03:p0047:u0032, D03:p0047:u0033, D03:p0047:u0034, D03:p0047:u0035, D03:p0047:u0036, D03:p0047:u0037, D03:p0047:u0038, D03:p0047:u0039, D03:p0047:u0040, D03:p0047:u0041, D03:p0047:u0042, D03:p0047:u0043, D03:p0047:u0044, D03:p0047:u0045, D03:p0047:u0046, D03:p0047:u0047, D03:p0047:u0048, D03:p0047:u0049, D03:p0047:u0050
**Общая страница с:** AI-04-12

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
ℎ= 5
3
1
2
4
5
6
7
8
ℎ= 3
3
1
2
4
5
8
6
7
ℎ= 5
ℎ= 4
````

## D03 — Lecture 5.pdf, PDF-страница 48
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=48`
Строки (ID элементов): D03:p0048:u0001, D03:p0048:u0002, D03:p0048:u0003, D03:p0048:u0006, D03:p0048:u0007, D03:p0048:u0008, D03:p0048:u0009, D03:p0048:u0010, D03:p0048:u0011, D03:p0048:u0012, D03:p0048:u0013, D03:p0048:u0014, D03:p0048:u0015, D03:p0048:u0016, D03:p0048:u0017, D03:p0048:u0018, D03:p0048:u0019, D03:p0048:u0020, D03:p0048:u0021, D03:p0048:u0022, D03:p0048:u0023, D03:p0048:u0024, D03:p0048:u0025, D03:p0048:u0026, D03:p0048:u0027, D03:p0048:u0028, D03:p0048:u0029, D03:p0048:u0030, D03:p0048:u0031, D03:p0048:u0032, D03:p0048:u0033, D03:p0048:u0034, D03:p0048:u0035, D03:p0048:u0036, D03:p0048:u0037, D03:p0048:u0038, D03:p0048:u0039, D03:p0048:u0040, D03:p0048:u0041
**Общая страница с:** AI-04-12

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
3
1
2
4
5
6
7
8
ℎ= 5
ℎ= 4
ℎ= 3
````

## D03 — Lecture 5.pdf, PDF-страница 49
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=49`
Строки (ID элементов): D03:p0049:u0001, D03:p0049:u0002, D03:p0049:u0003, D03:p0049:u0006, D03:p0049:u0007, D03:p0049:u0008, D03:p0049:u0009, D03:p0049:u0010, D03:p0049:u0011, D03:p0049:u0012, D03:p0049:u0013, D03:p0049:u0014, D03:p0049:u0015, D03:p0049:u0016, D03:p0049:u0017, D03:p0049:u0018, D03:p0049:u0019, D03:p0049:u0020, D03:p0049:u0021, D03:p0049:u0022, D03:p0049:u0023, D03:p0049:u0024, D03:p0049:u0025, D03:p0049:u0026, D03:p0049:u0027, D03:p0049:u0028, D03:p0049:u0029, D03:p0049:u0030, D03:p0049:u0031, D03:p0049:u0032, D03:p0049:u0033, D03:p0049:u0034, D03:p0049:u0035, D03:p0049:u0036, D03:p0049:u0037, D03:p0049:u0038, D03:p0049:u0039, D03:p0049:u0040, D03:p0049:u0041, D03:p0049:u0042, D03:p0049:u0043, D03:p0049:u0044, D03:p0049:u0045, D03:p0049:u0046, D03:p0049:u0047, D03:p0049:u0048, D03:p0049:u0049, D03:p0049:u0050, D03:p0049:u0051, D03:p0049:u0052, D03:p0049:u0053, D03:p0049:u0054, D03:p0049:u0055, D03:p0049:u0056, D03:p0049:u0057, D03:p0049:u0058, D03:p0049:u0059, D03:p0049:u0060, D03:p0049:u0061, D03:p0049:u0062, D03:p0049:u0063, D03:p0049:u0064, D03:p0049:u0065, D03:p0049:u0066, D03:p0049:u0067, D03:p0049:u0068
**Общая страница с:** AI-04-12

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
3
1
2
4
5
6
7
8
3
1
2
4
5
6
7
8
ℎ= 5
ℎ= 4
ℎ= 2
ℎ= 3
ℎ= 4
3
1
2
4
5
8
6
7
3
1
4
5
2
6
7
8
ℎ= 4
````

## D03 — Lecture 5.pdf, PDF-страница 50
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=50`
Строки (ID элементов): D03:p0050:u0001, D03:p0050:u0002, D03:p0050:u0003, D03:p0050:u0006, D03:p0050:u0007, D03:p0050:u0008, D03:p0050:u0009, D03:p0050:u0010, D03:p0050:u0011, D03:p0050:u0012, D03:p0050:u0013, D03:p0050:u0014, D03:p0050:u0015, D03:p0050:u0016, D03:p0050:u0017, D03:p0050:u0018, D03:p0050:u0019, D03:p0050:u0020, D03:p0050:u0021, D03:p0050:u0022, D03:p0050:u0023, D03:p0050:u0024, D03:p0050:u0025, D03:p0050:u0026, D03:p0050:u0027, D03:p0050:u0028, D03:p0050:u0029, D03:p0050:u0030, D03:p0050:u0031, D03:p0050:u0032, D03:p0050:u0033, D03:p0050:u0034, D03:p0050:u0035, D03:p0050:u0036, D03:p0050:u0037, D03:p0050:u0038, D03:p0050:u0039, D03:p0050:u0040, D03:p0050:u0041, D03:p0050:u0042, D03:p0050:u0043, D03:p0050:u0044, D03:p0050:u0045, D03:p0050:u0046, D03:p0050:u0047, D03:p0050:u0048, D03:p0050:u0049, D03:p0050:u0050
**Общая страница с:** AI-04-12

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
3
1
2
4
5
6
7
8
3
1
2
4
5
6
7
8
ℎ= 5
ℎ= 4
ℎ= 2
ℎ= 3
````

## D03 — Lecture 5.pdf, PDF-страница 51
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=51`
Строки (ID элементов): D03:p0051:u0001, D03:p0051:u0002, D03:p0051:u0003, D03:p0051:u0006, D03:p0051:u0007, D03:p0051:u0008, D03:p0051:u0009, D03:p0051:u0010, D03:p0051:u0011, D03:p0051:u0012, D03:p0051:u0013, D03:p0051:u0014, D03:p0051:u0015, D03:p0051:u0016, D03:p0051:u0017, D03:p0051:u0018, D03:p0051:u0019, D03:p0051:u0020, D03:p0051:u0021, D03:p0051:u0022, D03:p0051:u0023, D03:p0051:u0024, D03:p0051:u0025, D03:p0051:u0026, D03:p0051:u0027, D03:p0051:u0028, D03:p0051:u0029, D03:p0051:u0030, D03:p0051:u0031, D03:p0051:u0032, D03:p0051:u0033, D03:p0051:u0034, D03:p0051:u0035, D03:p0051:u0036, D03:p0051:u0037, D03:p0051:u0038, D03:p0051:u0039, D03:p0051:u0040, D03:p0051:u0041, D03:p0051:u0042, D03:p0051:u0043, D03:p0051:u0044, D03:p0051:u0045, D03:p0051:u0046, D03:p0051:u0047, D03:p0051:u0048, D03:p0051:u0049, D03:p0051:u0050, D03:p0051:u0051, D03:p0051:u0052, D03:p0051:u0053, D03:p0051:u0054, D03:p0051:u0055, D03:p0051:u0056, D03:p0051:u0057, D03:p0051:u0058, D03:p0051:u0059, D03:p0051:u0060
**Общая страница с:** AI-04-12

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
3
1
2
4
5
6
7
8
ℎ= 1
3
1
2
4
5
6
7
8
3
1
2
4
5
6
7
8
ℎ= 5
ℎ= 4
ℎ= 2
ℎ= 3
…
````

## D03 — Lecture 5.pdf, PDF-страница 52
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=52`
Строки (ID элементов): D03:p0052:u0001, D03:p0052:u0002, D03:p0052:u0003, D03:p0052:u0006, D03:p0052:u0007, D03:p0052:u0008, D03:p0052:u0009, D03:p0052:u0010, D03:p0052:u0011, D03:p0052:u0012, D03:p0052:u0013, D03:p0052:u0014, D03:p0052:u0015, D03:p0052:u0016, D03:p0052:u0017, D03:p0052:u0018, D03:p0052:u0019, D03:p0052:u0020, D03:p0052:u0021, D03:p0052:u0022, D03:p0052:u0023, D03:p0052:u0024, D03:p0052:u0025, D03:p0052:u0026, D03:p0052:u0027, D03:p0052:u0028, D03:p0052:u0029, D03:p0052:u0030, D03:p0052:u0031, D03:p0052:u0032, D03:p0052:u0033, D03:p0052:u0034, D03:p0052:u0035, D03:p0052:u0036, D03:p0052:u0037, D03:p0052:u0038, D03:p0052:u0039, D03:p0052:u0040, D03:p0052:u0041, D03:p0052:u0042, D03:p0052:u0043, D03:p0052:u0044, D03:p0052:u0045, D03:p0052:u0046, D03:p0052:u0047, D03:p0052:u0048, D03:p0052:u0049, D03:p0052:u0050, D03:p0052:u0051, D03:p0052:u0052, D03:p0052:u0053, D03:p0052:u0054, D03:p0052:u0055, D03:p0052:u0056, D03:p0052:u0057, D03:p0052:u0058, D03:p0052:u0059, D03:p0052:u0060, D03:p0052:u0061, D03:p0052:u0062
**Общая страница с:** AI-04-12

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
ℎ= 5
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
ℎ= 4
ℎ= 0
3
1
2
4
5
6
7
8
ℎ= 1
3
1
2
4
5
6
7
8
ℎ= 2
3
1
2
4
5
6
7
8
ℎ= 3
…
…
````

## D03 — Lecture 5.pdf, PDF-страница 53
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=53`
Строки (ID элементов): D03:p0053:u0001, D03:p0053:u0002, D03:p0053:u0003, D03:p0053:u0004, D03:p0053:u0005, D03:p0053:u0008, D03:p0053:u0009, D03:p0053:u0010, D03:p0053:u0011, D03:p0053:u0012, D03:p0053:u0013, D03:p0053:u0014, D03:p0053:u0015, D03:p0053:u0016, D03:p0053:u0017, D03:p0053:u0018, D03:p0053:u0019, D03:p0053:u0020, D03:p0053:u0021, D03:p0053:u0022, D03:p0053:u0023, D03:p0053:u0024, D03:p0053:u0025
**Общая страница с:** AI-04-12, AI-04-13
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Alternative Heuristics?
- Instead of number of misplaced tiles we could use the sum of the
Manhattan distances of the tiles from their goal positions as heuristics
- ℎ→𝑚𝑖𝑛
- Test it by yourself
3
1
2
4
5
8
6
7
ℎ= 0 + 0 + 1 + 1 + 1 + 0 + 1 + 1 = 5
1
2
3
4
5
6
7
8
Goal state
````


---

# AI-04-07 — Допустимость эвристики

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Определи на конкретных оценках, допустима ли эвристика, и покажи контрпример.
**Пункты РПД:** —

**Связанные страницы:** 2; **символов извлечённого текста:** 1290.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D03 — Lecture 5.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=16`
Строки (ID элементов): D03:p0016:u0001, D03:p0016:u0002, D03:p0016:u0003, D03:p0016:u0004, D03:p0016:u0005, D03:p0016:u0006, D03:p0016:u0007

````text
Heuristics Admissibility
- In path-finding problems heuristics may be admissible or inadmissible
- Admissibility means that heuristics is not overestimating the solution
- Needs to be lower than or equal to the actual cost of reaching the goal
- An admissible heuristic is therefore optimistic
- Not each heuristic is obliged to be admissible. However, inadmissible
heuristic does not guarantee the optimal solution
````

## D22 — Week 6 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=16`
Строки (ID элементов): D22:p0016:u0001, D22:p0016:u0002, D22:p0016:u0003, D22:p0016:u0004, D22:p0016:u0005, D22:p0016:u0006, D22:p0016:u0007, D22:p0016:u0008, D22:p0016:u0009, D22:p0016:u0010, D22:p0016:u0011, D22:p0016:u0012, D22:p0016:u0013
**Общая страница с:** AI-04-08, AI-04-16
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Heuristics Admissibility and Consistency
- In path-finding problems heuristics may be admissible or inadmissible
- Admissibility means that heuristics is not overestimating the solution
- Needs to be lower than or equal to the actual cost of reaching the goal
- Not each heuristic is obliged to be admissible. However, inadmissible heuristic
does not guarantee the optimal solution
- In path-finding problems a heuristic is considered to be consistent (or
monotone) if the estimated cost from one node to the successor node, added
to the estimated cost from the successor node to the goal is less than or equal
to the estimated cost from the current node to the goal state
- 𝐸𝑓(𝑥! →𝑥!"#) + 𝐸𝑓(𝑥!"# →𝑥$%&') ≤𝐸𝑓(𝑥! →𝑥$%&') →consistent heuristics
- All consistent heuristics are admissible heuristics, however, all admissible
heuristics are not necessarily consistent heuristics
````


---

# AI-04-08 — Согласованность эвристики

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Проверь согласованность эвристики на нескольких рёбрах графа и объясни следствие.
**Пункты РПД:** —

**Связанные страницы:** 2; **символов извлечённого текста:** 1475.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D03 — Lecture 5.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=17`
Строки (ID элементов): D03:p0017:u0001, D03:p0017:u0002, D03:p0017:u0003, D03:p0017:u0004, D03:p0017:u0005, D03:p0017:u0006, D03:p0017:u0007, D03:p0017:u0008, D03:p0017:u0009, D03:p0017:u0010
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Heuristics Consistency
- In path-finding problems a heuristic is considered to be consistent if the
estimated cost from one node to the successor node, added to the
estimated cost from the successor node to the goal is less than or equal to
the estimated cost from the current node to the goal state
- ℎ𝑛≤𝑐𝑛, 𝑎, 𝑛! + ℎ(𝑛′)
- Consistent heuristics are called monotone because the estimated final cost
of a partial solution is monotonically non-decreasing along any path
- All consistent heuristics are admissible heuristics, however, all admissible
heuristics are not necessarily consistent heuristics
````

## D22 — Week 6 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=16`
Строки (ID элементов): D22:p0016:u0001, D22:p0016:u0002, D22:p0016:u0003, D22:p0016:u0004, D22:p0016:u0005, D22:p0016:u0006, D22:p0016:u0007, D22:p0016:u0008, D22:p0016:u0009, D22:p0016:u0010, D22:p0016:u0011, D22:p0016:u0012, D22:p0016:u0013
**Общая страница с:** AI-04-07, AI-04-16
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Heuristics Admissibility and Consistency
- In path-finding problems heuristics may be admissible or inadmissible
- Admissibility means that heuristics is not overestimating the solution
- Needs to be lower than or equal to the actual cost of reaching the goal
- Not each heuristic is obliged to be admissible. However, inadmissible heuristic
does not guarantee the optimal solution
- In path-finding problems a heuristic is considered to be consistent (or
monotone) if the estimated cost from one node to the successor node, added
to the estimated cost from the successor node to the goal is less than or equal
to the estimated cost from the current node to the goal state
- 𝐸𝑓(𝑥! →𝑥!"#) + 𝐸𝑓(𝑥!"# →𝑥$%&') ≤𝐸𝑓(𝑥! →𝑥$%&') →consistent heuristics
- All consistent heuristics are admissible heuristics, however, all admissible
heuristics are not necessarily consistent heuristics
````


---

# AI-04-09 — Минимакс и дерево игры

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Вычисли значения внутренних узлов дерева игры и выбери оптимальный первый ход.
**Пункты РПД:** RPD-44

**Связанные страницы:** 9; **символов извлечённого текста:** 1972.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D03 — Lecture 5.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=18`
Строки (ID элементов): D03:p0018:u0001, D03:p0018:u0002, D03:p0018:u0003, D03:p0018:u0004, D03:p0018:u0005, D03:p0018:u0006, D03:p0018:u0007, D03:p0018:u0008, D03:p0018:u0009, D03:p0018:u0010, D03:p0018:u0011

````text
Minimax
- Minimax is a kind of backtracking algorithm that is used in decision making
- Opponent’s goal is to reduce winnings (MINI-Move) and player’s goal is to
increase winnings (MAX-Move)
- Game with a scoring system or win/lose condition which can be evaluated
- GO
- Chess
- Game Tree
- Selection of plays in a turn-based game can be reduced to looking at a
pathway on a tree
- Used as part of the theoretical foundations of GAME THEORY
````

## D03 — Lecture 5.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=19`
Строки (ID элементов): D03:p0019:u0003, D03:p0019:u0004, D03:p0019:u0005, D03:p0019:u0006, D03:p0019:u0041, D03:p0019:u0042, D03:p0019:u0058, D03:p0019:u0059
**Непроверенные OCR/формулы:** 45 исключённых из основного текста кандидатов; см. JSON.

````text
Minimax Example
X’s turn (MAX)
0’s turn (MIN)
X’s turn (MAX)
O|x| x
O|x| x
O|xX| x
O|X| x
````

## D03 — Lecture 5.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=20`
Строки (ID элементов): D03:p0020:u0003, D03:p0020:u0004, D03:p0020:u0005, D03:p0020:u0006, D03:p0020:u0040, D03:p0020:u0041, D03:p0020:u0057, D03:p0020:u0058
**Непроверенные OCR/формулы:** 44 исключённых из основного текста кандидатов; см. JSON.

````text
Minimax Example
X’s turn (MAX)
0’s turn (MIN)
X’s turn (MAX)
O|x| x
O|x| x
O|xX| x
O|X| x
````

## D03 — Lecture 5.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=21`
Строки (ID элементов): D03:p0021:u0003, D03:p0021:u0004, D03:p0021:u0005, D03:p0021:u0006, D03:p0021:u0038, D03:p0021:u0039, D03:p0021:u0055, D03:p0021:u0056
**Непроверенные OCR/формулы:** 42 исключённых из основного текста кандидатов; см. JSON.

````text
Minimax Example
X’s turn (MAX)
0’s turn (MIN)
X’s turn (MAX)
O|x| x
O|x| x
O|xX| x
O|X| x
````

## D03 — Lecture 5.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=22`
Строки (ID элементов): D03:p0022:u0003, D03:p0022:u0004, D03:p0022:u0005, D03:p0022:u0006, D03:p0022:u0023, D03:p0022:u0026, D03:p0022:u0037, D03:p0022:u0059
**Непроверенные OCR/формулы:** 46 исключённых из основного текста кандидатов; см. JSON.

````text
Minimax Example
X’s turn (MAX)
0’s turn (MIN)
X’s turn (MAX)
0
olo|x
O|x| x
O|xX| x
````

## D03 — Lecture 5.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=23`
Строки (ID элементов): D03:p0023:u0001, D03:p0023:u0002, D03:p0023:u0003, D03:p0023:u0004, D03:p0023:u0005, D03:p0023:u0006, D03:p0023:u0007, D03:p0023:u0008, D03:p0023:u0009, D03:p0023:u0010, D03:p0023:u0011, D03:p0023:u0012, D03:p0023:u0013

````text
Backtracking
- Simulate the entire game
- Assume rational/perfect play from the opponent
- Theoretically, there is a perfect game play method if we search the entire
game
- Solved Games
- Tic-Tac-Toe
- Checkers
- Two player heads-up limit poker – Recent discovery by researchers in University of
Alberta
- Unsolved
- Chess
- Go
````

## D09 — Tutorial 5.pdf, PDF-страница 1
Источник в ZIP: `AI_course_cleaned/09_Tutorial 5/source.pdf#page=1`
Строки (ID элементов): D09:p0001:u0001, D09:p0001:u0002, D09:p0001:u0003, D09:p0001:u0004, D09:p0001:u0005, D09:p0001:u0006, D09:p0001:u0007, D09:p0001:u0008, D09:p0001:u0009, D09:p0001:u0010, D09:p0001:u0011, D09:p0001:u0012, D09:p0001:u0013, D09:p0001:u0014, D09:p0001:u0015, D09:p0001:u0016, D09:p0001:u0017, D09:p0001:u0018, D09:p0001:u0019, D09:p0001:u0020, D09:p0001:u0021

````text
Basics of Minimax Algorithm
1
Definition
The Minimax algorithm is a decision-making
algorithm that is used in two-player games, where the
goal is to ﬁnd the best possible move for the current
player while assuming that the other player will also
make optimal moves.
2
Working Principle
The algorithm works by creating a game tree that
represents all possible moves by both players. It then
analyzes the tree, minimizing the maximum possible
loss for the player, and maximizing the minimum
possible gain.
3
Pseudocode
We can implement the Minimax algorithm using
pseudocode. The algorithm recursively traverses the
game tree and assigns scores to each move,
ultimately returning the best possible move.
````

## D09 — Tutorial 5.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/09_Tutorial 5/source.pdf#page=6`
Строки (ID элементов): D09:p0006:u0001, D09:p0006:u0002
**Общая страница с:** AI-04-10
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Exercise
Give the values calculated by minimax for all states in the tree.
````

## D09 — Tutorial 5.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/09_Tutorial 5/source.pdf#page=7`
Строки (ID элементов): D09:p0007:u0001, D09:p0007:u0002, D09:p0007:u0012
**Общая страница с:** AI-04-10
**Непроверенные OCR/формулы:** 13 исключённых из основного текста кандидатов; см. JSON.

````text
Solution
Give the values calculated by minimax for all states in the tree.
2Y Y
````


---

# AI-04-10 — Альфа-бета-отсечение

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Выполни альфа-бета поиск на размеченном дереве и укажи точно отброшенные ветви.
**Пункты РПД:** RPD-44

**Связанные страницы:** 16; **символов извлечённого текста:** 3336.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D02 — Lab 4 (without solution).pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=5`
Строки (ID элементов): D02:p0005:u0001, D02:p0005:u0002, D02:p0005:u0003, D02:p0005:u0004, D02:p0005:u0005, D02:p0005:u0006, D02:p0005:u0007, D02:p0005:u0008, D02:p0005:u0009, D02:p0005:u0010, D02:p0005:u0011
**Общая страница с:** AI-04-04

````text
Backtracking with Alpha Beta Cuts
- Heuristic search based on backtracking
- Used in situations where there is a value to the solution at each point to
allow for an evaluation
- Applied for Game Trees
- Alpha Cut
- 
Maximum lower bound (Max Plays - Black)
- Beta Cut
- 
Minimum upper bound (Min Play - Red)
````

## D03 — Lecture 5.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=24`
Строки (ID элементов): D03:p0024:u0001, D03:p0024:u0002, D03:p0024:u0003, D03:p0024:u0004, D03:p0024:u0005, D03:p0024:u0006, D03:p0024:u0007, D03:p0024:u0008, D03:p0024:u0009

````text
Backtracking with Alpha-Beta Pruning
- Heuristic search based on backtracking
- Used in situations where there is a value to the solution at each point to
allow for an evaluation
- Applied for Game Trees
- Alpha Cut
- Maximum lower bound (Max Play - Black)
- Beta Cut
- Minimum upper bound (Min Play - Red)
````

## D03 — Lecture 5.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=25`
Строки (ID элементов): D03:p0025:u0001, D03:p0025:u0004, D03:p0025:u0005, D03:p0025:u0006, D03:p0025:u0007, D03:p0025:u0008, D03:p0025:u0009, D03:p0025:u0010
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
5
Cut Examples
MIN
MIN
MAX
−∞; +∞
−∞; 5
−∞; +∞
````

## D03 — Lecture 5.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=26`
Строки (ID элементов): D03:p0026:u0001, D03:p0026:u0004, D03:p0026:u0005, D03:p0026:u0006, D03:p0026:u0007, D03:p0026:u0008, D03:p0026:u0009, D03:p0026:u0010, D03:p0026:u0011, D03:p0026:u0012, D03:p0026:u0013, D03:p0026:u0014
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
5
Cut Examples
MIN
MIN
MAX
−∞; +∞
5; 5
5; +∞
11
5
−∞; 5
−∞; +∞
````

## D03 — Lecture 5.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=27`
Строки (ID элементов): D03:p0027:u0001, D03:p0027:u0004, D03:p0027:u0005, D03:p0027:u0006, D03:p0027:u0007, D03:p0027:u0008, D03:p0027:u0009, D03:p0027:u0010, D03:p0027:u0011, D03:p0027:u0012, D03:p0027:u0013, D03:p0027:u0014, D03:p0027:u0015, D03:p0027:u0016, D03:p0027:u0017, D03:p0027:u0018, D03:p0027:u0019
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
5
Cut Examples
MIN
MIN
MAX
−∞; +∞
5; 5
5; +∞
11
5
2
−∞; 2
?
≤2
5; 5
5
−∞; 5
````

## D03 — Lecture 5.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=28`
Строки (ID элементов): D03:p0028:u0001, D03:p0028:u0004, D03:p0028:u0005, D03:p0028:u0006, D03:p0028:u0007, D03:p0028:u0008, D03:p0028:u0009, D03:p0028:u0010, D03:p0028:u0011, D03:p0028:u0012, D03:p0028:u0013, D03:p0028:u0014, D03:p0028:u0015, D03:p0028:u0016, D03:p0028:u0017, D03:p0028:u0018, D03:p0028:u0019
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
5
Cut Examples
MIN
MIN
MAX
5; 5
11
5
2
−∞; 2
≤2
5; 5
5
−∞; 5
6
−∞; 6
−∞; +∞
````

## D03 — Lecture 5.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=29`
Строки (ID элементов): D03:p0029:u0001, D03:p0029:u0004, D03:p0029:u0005, D03:p0029:u0006, D03:p0029:u0007, D03:p0029:u0008, D03:p0029:u0009, D03:p0029:u0010, D03:p0029:u0011, D03:p0029:u0012, D03:p0029:u0013, D03:p0029:u0014, D03:p0029:u0015, D03:p0029:u0016, D03:p0029:u0017, D03:p0029:u0018, D03:p0029:u0019, D03:p0029:u0020, D03:p0029:u0021, D03:p0029:u0022, D03:p0029:u0023, D03:p0029:u0024, D03:p0029:u0025
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
5
Cut Examples
MIN
MIN
MAX
5; 5
11
5
2
−∞; 2
≤2
5; 5
5
−∞; 5
6
−∞; 6
−∞; +∞
7
6; 6
6
6; 6
6
5; 5 5
````

## D03 — Lecture 5.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=30`
Строки (ID элементов): D03:p0030:u0001, D03:p0030:u0002, D03:p0030:u0003, D03:p0030:u0004, D03:p0030:u0005, D03:p0030:u0006, D03:p0030:u0007, D03:p0030:u0008, D03:p0030:u0009, D03:p0030:u0010, D03:p0030:u0011, D03:p0030:u0012, D03:p0030:u0013

````text
Alpha-Beta Pruning Problems
- The effectiveness of alpha–beta pruning is highly dependent on the order
in which the states are examined
- Even with alpha–beta pruning and clever move ordering, minimax won’t
work for games like Chess and Go, because there are still too many states
to explore in the time available
- Too high branching factor
- The branching factor is the average number of child nodes or potential
moves/decisions at each node in a tree or graph, representing the "width" of the
search space
- Tic-Tac-Toe ~4
- Chess ~31-35
- Go ~250
````

## D09 — Tutorial 5.pdf, PDF-страница 2
Источник в ZIP: `AI_course_cleaned/09_Tutorial 5/source.pdf#page=2`
Строки (ID элементов): D09:p0002:u0001, D09:p0002:u0002, D09:p0002:u0003, D09:p0002:u0004, D09:p0002:u0005, D09:p0002:u0006, D09:p0002:u0007, D09:p0002:u0008, D09:p0002:u0009, D09:p0002:u0010, D09:p0002:u0011, D09:p0002:u0012, D09:p0002:u0013, D09:p0002:u0014, D09:p0002:u0015, D09:p0002:u0016, D09:p0002:u0017, D09:p0002:u0018, D09:p0002:u0019, D09:p0002:u0020, D09:p0002:u0021, D09:p0002:u0022, D09:p0002:u0023, D09:p0002:u0024, D09:p0002:u0025, D09:p0002:u0026, D09:p0002:u0027, D09:p0002:u0028, D09:p0002:u0029
**Непроверенные OCR/формулы:** 27 исключённых из основного текста кандидатов; см. JSON.

````text
Understanding Alpha-Beta Pruning
The Concept
Alpha-Beta pruning is a
technique used to improve the
eﬃciency of the Minimax
algorithm. It works by pruning
branches of the game tree that
don't need to be explored
further, thereby reducing the
total number of nodes that
need to be evaluated.
How it Works
The algorithm maintains two
values, alpha and beta, that are
used to keep track of the best
known score of the maximizing
and minimizing player,
respectively. It then prunes
branches that can't affect the
ﬁnal score and limits the
search space accordingly.
Performance
Boost
Alpha-Beta pruning can
signiﬁcantly reduce the number
of nodes evaluated, making the
algorithm much faster than the
regular Minimax algorithm for
large game trees.
````

## D09 — Tutorial 5.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/09_Tutorial 5/source.pdf#page=3`
Строки (ID элементов): D09:p0003:u0001, D09:p0003:u0002, D09:p0003:u0003, D09:p0003:u0004, D09:p0003:u0005, D09:p0003:u0006, D09:p0003:u0007, D09:p0003:u0008, D09:p0003:u0009, D09:p0003:u0010, D09:p0003:u0011, D09:p0003:u0012, D09:p0003:u0013, D09:p0003:u0014, D09:p0003:u0015, D09:p0003:u0016, D09:p0003:u0017, D09:p0003:u0018, D09:p0003:u0019

````text
Benefits and Limitations
Advantages
•
Can be applied to any two-player game
•
Eﬃcient in searching game trees
•
Maximizes the player’s beneﬁt while
minimizing the opponent’s gain
Disadvantages
•
Not suitable for games with imperfect
information or unknown state space
•
Requires a lot of memory to store and
traverse the game tree
•
Can be computationally expensive in
certain cases
````

## D09 — Tutorial 5.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/09_Tutorial 5/source.pdf#page=4`
Строки (ID элементов): D09:p0004:u0001, D09:p0004:u0002, D09:p0004:u0003, D09:p0004:u0004, D09:p0004:u0005, D09:p0004:u0006, D09:p0004:u0007, D09:p0004:u0008, D09:p0004:u0009, D09:p0004:u0010, D09:p0004:u0011, D09:p0004:u0012, D09:p0004:u0013, D09:p0004:u0014, D09:p0004:u0015, D09:p0004:u0016, D09:p0004:u0017, D09:p0004:u0018, D09:p0004:u0019

````text
Real-World Applications
Gaming
It is widely used in games,
from Chess and Go to
computer games like
Starcraft and World of
Warcraft.
Decision Making
These algorithms can be
used in decision-making
scenarios such as resource
allocation and project
planning.
Optimization
They can be used to
optimize complex systems
such as traﬃc ﬂow, energy
management, and ﬁnancial
portfolios.
````

## D09 — Tutorial 5.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/09_Tutorial 5/source.pdf#page=5`
Строки (ID элементов): нет

*На привязанной странице нет текста в категории educational; проверь изображение слайда.*

## D09 — Tutorial 5.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/09_Tutorial 5/source.pdf#page=6`
Строки (ID элементов): D09:p0006:u0001, D09:p0006:u0002
**Общая страница с:** AI-04-09
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Exercise
Give the values calculated by minimax for all states in the tree.
````

## D09 — Tutorial 5.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/09_Tutorial 5/source.pdf#page=7`
Строки (ID элементов): D09:p0007:u0001, D09:p0007:u0002, D09:p0007:u0012
**Общая страница с:** AI-04-09
**Непроверенные OCR/формулы:** 13 исключённых из основного текста кандидатов; см. JSON.

````text
Solution
Give the values calculated by minimax for all states in the tree.
2Y Y
````

## D09 — Tutorial 5.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/09_Tutorial 5/source.pdf#page=8`
Строки (ID элементов): D09:p0008:u0001, D09:p0008:u0002, D09:p0008:u0003
**Непроверенные OCR/формулы:** 7 исключённых из основного текста кандидатов; см. JSON.

````text
Extension
Indicate which branches of the tree will be pruned by alpha-beta
pruning.
````

## D09 — Tutorial 5.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/09_Tutorial 5/source.pdf#page=9`
Строки (ID элементов): D09:p0009:u0001, D09:p0009:u0002, D09:p0009:u0003
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
Solution
Indicate which branches of the tree will be pruned by alpha-beta
pruning.
````


---

# AI-04-11 — Жадный выбор и его локальная оптимальность

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Покажи задачу, где жадный выбор проигрывает глобальному оптимуму, и объясни причину.
**Пункты РПД:** —

**Связанные страницы:** 6; **символов извлечённого текста:** 1547.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D03 — Lecture 5.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=31`
Строки (ID элементов): D03:p0031:u0001, D03:p0031:u0002, D03:p0031:u0003, D03:p0031:u0004, D03:p0031:u0005, D03:p0031:u0006, D03:p0031:u0007, D03:p0031:u0011
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Greedy Approaches
- Generate and Test Methods primarily
- Current best solutions are held
- When I find something better – I get rid
of what I had
- Always wanting more
- Always takes the Locally Optimal choice
MR. GREEDY
````

## D03 — Lecture 5.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=32`
Строки (ID элементов): D03:p0032:u0001, D03:p0032:u0002, D03:p0032:u0003, D03:p0032:u0004, D03:p0032:u0005

````text
Greedy Algorithm Basics
- Start with a search space from which a candidate solution will be taken
from
- There is a number of decisions to be made in sequence to find a solution,
at each step make a choice which maximizes the outcome
````

## D03 — Lecture 5.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=33`
Строки (ID элементов): D03:p0033:u0001, D03:p0033:u0002, D03:p0033:u0003, D03:p0033:u0004, D03:p0033:u0005, D03:p0033:u0006
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Example – Game Tree
- Two players are making moves in a game, each move gives a certain
number of points to the player – goal is to make the most points
- In the first move our greedy player will take 7 points
3
7
````

## D03 — Lecture 5.pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=34`
Строки (ID элементов): D03:p0034:u0001, D03:p0034:u0002, D03:p0034:u0003, D03:p0034:u0004, D03:p0034:u0005, D03:p0034:u0006, D03:p0034:u0007, D03:p0034:u0008, D03:p0034:u0011
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
3
7
19
17
•
In the second move move
our greedy player will take 19
points, for a total of 26 points
Example – Game Tree
````

## D03 — Lecture 5.pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=35`
Строки (ID элементов): D03:p0035:u0001, D03:p0035:u0002, D03:p0035:u0003, D03:p0035:u0004, D03:p0035:u0005, D03:p0035:u0006, D03:p0035:u0007, D03:p0035:u0008, D03:p0035:u0009, D03:p0035:u0010, D03:p0035:u0011, D03:p0035:u0012, D03:p0035:u0013, D03:p0035:u0014, D03:p0035:u0015

````text
Was Greedy Good?
- Maybe – Depends on the Game
being played
- If the ? Position was less than
or equal to 23, then we
have maximized
the score
- If ? was greater,
then we have
failed
3
7
19
17
?
````

## D03 — Lecture 5.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=36`
Строки (ID элементов): D03:p0036:u0001, D03:p0036:u0002, D03:p0036:u0003, D03:p0036:u0004, D03:p0036:u0005, D03:p0036:u0006, D03:p0036:u0007, D03:p0036:u0008, D03:p0036:u0009, D03:p0036:u0010, D03:p0036:u0011, D03:p0036:u0012

````text
What Ensures That Greed Will Be
Rewarded?
- Sub-problem optimization
- Also called optimal substructures
- The optimal solution to the problem contains optimal sub-problems
- Greedy Choice Property
- We never need to consider the play until now and can move from this point only
making the current best decision. We never need to review the past moves in
order to make a better decision
- In our example, if we have played the optimal game until now, then this starting
point is also part of the optimal value on this move
- But the greediness sometimes does not work
````


---

# AI-04-12 — Поиск с восхождением к вершине

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Проведи hill climbing по соседним состояниям и объясни, где и почему он остановится.
**Пункты РПД:** RPD-18

**Связанные страницы:** 17; **символов извлечённого текста:** 3729.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D03 — Lecture 5.pdf, PDF-страница 37
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=37`
Строки (ID элементов): D03:p0037:u0001, D03:p0037:u0002, D03:p0037:u0003, D03:p0037:u0004, D03:p0037:u0005, D03:p0037:u0006, D03:p0037:u0007, D03:p0037:u0008, D03:p0037:u0009, D03:p0037:u0010, D03:p0037:u0011, D03:p0037:u0012, D03:p0037:u0018, D03:p0037:u0021, D03:p0037:u0026, D03:p0037:u0028, D03:p0037:u0031, D03:p0037:u0033, D03:p0037:u0035
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Hill Climbers
- Single Searching point
- Search locally for changes to the
actions
- Have a representation of a solution
string
- Have a test of the representation
about the space
- Each solution string maps to an
outcome
- An objective function
- A fitness on the problem
_— global maximum
shoulder
_ local maximum
“flat” local maximum
> state space
current
state
````

## D03 — Lecture 5.pdf, PDF-страница 38
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=38`
Строки (ID элементов): D03:p0038:u0001, D03:p0038:u0002, D03:p0038:u0003, D03:p0038:u0004, D03:p0038:u0005, D03:p0038:u0006, D03:p0038:u0007, D03:p0038:u0008, D03:p0038:u0009, D03:p0038:u0010

````text
Climbing Hill in Our Example
- Representation
- String of actions which we can take
- Objective
- Maximization of profit value based on the actions
- No string of actions is allowed to have an overlap
- Local Change
- Add and/or remove some number of items from the string
- Climbing the Hill
- Replace my position if the change is better
````

## D03 — Lecture 5.pdf, PDF-страница 39
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=39`
Строки (ID элементов): D03:p0039:u0001, D03:p0039:u0006, D03:p0039:u0007, D03:p0039:u0008, D03:p0039:u0009, D03:p0039:u0010, D03:p0039:u0011, D03:p0039:u0012, D03:p0039:u0013, D03:p0039:u0014
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Hill-Climbing Algorithm
inputs: problem, a problem
static: current, anode
next, anode
current — MAKE-NODE(INITIAL-STATE[problem])
loop do
next — a highest-valued successor of current
if VALUE[next] < VALUE[current] then return current
current — next
end
````

## D03 — Lecture 5.pdf, PDF-страница 40
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=40`
Строки (ID элементов): D03:p0040:u0001, D03:p0040:u0002, D03:p0040:u0003, D03:p0040:u0006, D03:p0040:u0007, D03:p0040:u0008, D03:p0040:u0009, D03:p0040:u0010

````text
Hill Climber for N Queens Problem
- ℎ– number of queen pairs attacking each other
- ℎ→𝑚𝑖𝑛
Q
Q
Q
Q
ℎ= 5
````

## D03 — Lecture 5.pdf, PDF-страница 41
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=41`
Строки (ID элементов): D03:p0041:u0001, D03:p0041:u0002, D03:p0041:u0003, D03:p0041:u0006, D03:p0041:u0007, D03:p0041:u0008, D03:p0041:u0009, D03:p0041:u0010, D03:p0041:u0011, D03:p0041:u0012, D03:p0041:u0013, D03:p0041:u0014, D03:p0041:u0015

````text
Hill Climber for N Queens Problem
- ℎ– number of queen pairs attacking each other
- ℎ→𝑚𝑖𝑛
Q
Q
Q
Q
ℎ= 5
Q
Q
Q
Q
ℎ= 2
````

## D03 — Lecture 5.pdf, PDF-страница 42
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=42`
Строки (ID элементов): D03:p0042:u0001, D03:p0042:u0002, D03:p0042:u0003, D03:p0042:u0006, D03:p0042:u0007, D03:p0042:u0008, D03:p0042:u0009, D03:p0042:u0010, D03:p0042:u0011, D03:p0042:u0012, D03:p0042:u0013, D03:p0042:u0014, D03:p0042:u0015, D03:p0042:u0016, D03:p0042:u0017, D03:p0042:u0018, D03:p0042:u0019, D03:p0042:u0020
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Hill Climber for N Queens Problem
- ℎ– number of queen pairs attacking each other
- ℎ→𝑚𝑖𝑛
Q
Q
Q
Q
Q
Q
Q
Q
ℎ= 5
Q
Q
Q
Q
ℎ= 2
ℎ= 0
````

## D03 — Lecture 5.pdf, PDF-страница 43
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=43`
Строки (ID элементов): D03:p0043:u0001, D03:p0043:u0002, D03:p0043:u0003, D03:p0043:u0004, D03:p0043:u0005, D03:p0043:u0006, D03:p0043:u0007, D03:p0043:u0010, D03:p0043:u0011, D03:p0043:u0012, D03:p0043:u0013, D03:p0043:u0014, D03:p0043:u0015, D03:p0043:u0016, D03:p0043:u0017, D03:p0043:u0018, D03:p0043:u0019, D03:p0043:u0020, D03:p0043:u0021, D03:p0043:u0022, D03:p0043:u0023, D03:p0043:u0024, D03:p0043:u0025, D03:p0043:u0026, D03:p0043:u0027
**Общая страница с:** AI-04-06
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
8-puzzle Problem
- The 8-puzzle problem is a puzzle invented and popularized by Noyes Palmer
Chapman in the 1870s. It is played on a 3-by-3 grid with 8 square blocks
labeled 1 through 8 and a blank square
- Goal is to rearrange the blocks so that they are in order. It is permitted to
slide blocks horizontally or vertically into the blank square
- In general, there are 9!/2 = 181,400 reachable states
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Initial state
Goal state
````

## D03 — Lecture 5.pdf, PDF-страница 44
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=44`
Строки (ID элементов): D03:p0044:u0001, D03:p0044:u0002, D03:p0044:u0003, D03:p0044:u0006, D03:p0044:u0007, D03:p0044:u0008, D03:p0044:u0009, D03:p0044:u0010, D03:p0044:u0011, D03:p0044:u0012, D03:p0044:u0013, D03:p0044:u0014, D03:p0044:u0015, D03:p0044:u0016, D03:p0044:u0017, D03:p0044:u0018, D03:p0044:u0019, D03:p0044:u0020, D03:p0044:u0021, D03:p0044:u0022, D03:p0044:u0023
**Общая страница с:** AI-04-06

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
ℎ= 5
````

## D03 — Lecture 5.pdf, PDF-страница 45
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=45`
Строки (ID элементов): D03:p0045:u0001, D03:p0045:u0002, D03:p0045:u0003, D03:p0045:u0006, D03:p0045:u0007, D03:p0045:u0008, D03:p0045:u0009, D03:p0045:u0010, D03:p0045:u0011, D03:p0045:u0012, D03:p0045:u0013, D03:p0045:u0014, D03:p0045:u0015, D03:p0045:u0016, D03:p0045:u0017, D03:p0045:u0018, D03:p0045:u0019, D03:p0045:u0020, D03:p0045:u0021, D03:p0045:u0022, D03:p0045:u0023, D03:p0045:u0024, D03:p0045:u0025, D03:p0045:u0026, D03:p0045:u0027, D03:p0045:u0028, D03:p0045:u0029, D03:p0045:u0030, D03:p0045:u0031, D03:p0045:u0032, D03:p0045:u0033, D03:p0045:u0034, D03:p0045:u0035, D03:p0045:u0036, D03:p0045:u0037, D03:p0045:u0038, D03:p0045:u0039, D03:p0045:u0040, D03:p0045:u0041, D03:p0045:u0042, D03:p0045:u0043, D03:p0045:u0044, D03:p0045:u0045, D03:p0045:u0046, D03:p0045:u0047, D03:p0045:u0048, D03:p0045:u0049, D03:p0045:u0050
**Общая страница с:** AI-04-06
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
8
6
5
7
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
ℎ= 5
ℎ= 6
ℎ= 4
ℎ= 5
````

## D03 — Lecture 5.pdf, PDF-страница 46
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=46`
Строки (ID элементов): D03:p0046:u0001, D03:p0046:u0002, D03:p0046:u0003, D03:p0046:u0006, D03:p0046:u0007, D03:p0046:u0008, D03:p0046:u0009, D03:p0046:u0010, D03:p0046:u0011, D03:p0046:u0012, D03:p0046:u0013, D03:p0046:u0014, D03:p0046:u0015, D03:p0046:u0016, D03:p0046:u0017, D03:p0046:u0018, D03:p0046:u0019, D03:p0046:u0020, D03:p0046:u0021, D03:p0046:u0022, D03:p0046:u0023, D03:p0046:u0024, D03:p0046:u0025, D03:p0046:u0026, D03:p0046:u0027, D03:p0046:u0028, D03:p0046:u0029, D03:p0046:u0030, D03:p0046:u0031, D03:p0046:u0032
**Общая страница с:** AI-04-06

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
ℎ= 5
ℎ= 4
````

## D03 — Lecture 5.pdf, PDF-страница 47
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=47`
Строки (ID элементов): D03:p0047:u0001, D03:p0047:u0002, D03:p0047:u0003, D03:p0047:u0006, D03:p0047:u0007, D03:p0047:u0008, D03:p0047:u0009, D03:p0047:u0010, D03:p0047:u0011, D03:p0047:u0012, D03:p0047:u0013, D03:p0047:u0014, D03:p0047:u0015, D03:p0047:u0016, D03:p0047:u0017, D03:p0047:u0018, D03:p0047:u0019, D03:p0047:u0020, D03:p0047:u0021, D03:p0047:u0022, D03:p0047:u0023, D03:p0047:u0024, D03:p0047:u0025, D03:p0047:u0026, D03:p0047:u0027, D03:p0047:u0028, D03:p0047:u0029, D03:p0047:u0030, D03:p0047:u0031, D03:p0047:u0032, D03:p0047:u0033, D03:p0047:u0034, D03:p0047:u0035, D03:p0047:u0036, D03:p0047:u0037, D03:p0047:u0038, D03:p0047:u0039, D03:p0047:u0040, D03:p0047:u0041, D03:p0047:u0042, D03:p0047:u0043, D03:p0047:u0044, D03:p0047:u0045, D03:p0047:u0046, D03:p0047:u0047, D03:p0047:u0048, D03:p0047:u0049, D03:p0047:u0050
**Общая страница с:** AI-04-06

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
ℎ= 5
3
1
2
4
5
6
7
8
ℎ= 3
3
1
2
4
5
8
6
7
ℎ= 5
ℎ= 4
````

## D03 — Lecture 5.pdf, PDF-страница 48
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=48`
Строки (ID элементов): D03:p0048:u0001, D03:p0048:u0002, D03:p0048:u0003, D03:p0048:u0006, D03:p0048:u0007, D03:p0048:u0008, D03:p0048:u0009, D03:p0048:u0010, D03:p0048:u0011, D03:p0048:u0012, D03:p0048:u0013, D03:p0048:u0014, D03:p0048:u0015, D03:p0048:u0016, D03:p0048:u0017, D03:p0048:u0018, D03:p0048:u0019, D03:p0048:u0020, D03:p0048:u0021, D03:p0048:u0022, D03:p0048:u0023, D03:p0048:u0024, D03:p0048:u0025, D03:p0048:u0026, D03:p0048:u0027, D03:p0048:u0028, D03:p0048:u0029, D03:p0048:u0030, D03:p0048:u0031, D03:p0048:u0032, D03:p0048:u0033, D03:p0048:u0034, D03:p0048:u0035, D03:p0048:u0036, D03:p0048:u0037, D03:p0048:u0038, D03:p0048:u0039, D03:p0048:u0040, D03:p0048:u0041
**Общая страница с:** AI-04-06

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
3
1
2
4
5
6
7
8
ℎ= 5
ℎ= 4
ℎ= 3
````

## D03 — Lecture 5.pdf, PDF-страница 49
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=49`
Строки (ID элементов): D03:p0049:u0001, D03:p0049:u0002, D03:p0049:u0003, D03:p0049:u0006, D03:p0049:u0007, D03:p0049:u0008, D03:p0049:u0009, D03:p0049:u0010, D03:p0049:u0011, D03:p0049:u0012, D03:p0049:u0013, D03:p0049:u0014, D03:p0049:u0015, D03:p0049:u0016, D03:p0049:u0017, D03:p0049:u0018, D03:p0049:u0019, D03:p0049:u0020, D03:p0049:u0021, D03:p0049:u0022, D03:p0049:u0023, D03:p0049:u0024, D03:p0049:u0025, D03:p0049:u0026, D03:p0049:u0027, D03:p0049:u0028, D03:p0049:u0029, D03:p0049:u0030, D03:p0049:u0031, D03:p0049:u0032, D03:p0049:u0033, D03:p0049:u0034, D03:p0049:u0035, D03:p0049:u0036, D03:p0049:u0037, D03:p0049:u0038, D03:p0049:u0039, D03:p0049:u0040, D03:p0049:u0041, D03:p0049:u0042, D03:p0049:u0043, D03:p0049:u0044, D03:p0049:u0045, D03:p0049:u0046, D03:p0049:u0047, D03:p0049:u0048, D03:p0049:u0049, D03:p0049:u0050, D03:p0049:u0051, D03:p0049:u0052, D03:p0049:u0053, D03:p0049:u0054, D03:p0049:u0055, D03:p0049:u0056, D03:p0049:u0057, D03:p0049:u0058, D03:p0049:u0059, D03:p0049:u0060, D03:p0049:u0061, D03:p0049:u0062, D03:p0049:u0063, D03:p0049:u0064, D03:p0049:u0065, D03:p0049:u0066, D03:p0049:u0067, D03:p0049:u0068
**Общая страница с:** AI-04-06

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
3
1
2
4
5
6
7
8
3
1
2
4
5
6
7
8
ℎ= 5
ℎ= 4
ℎ= 2
ℎ= 3
ℎ= 4
3
1
2
4
5
8
6
7
3
1
4
5
2
6
7
8
ℎ= 4
````

## D03 — Lecture 5.pdf, PDF-страница 50
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=50`
Строки (ID элементов): D03:p0050:u0001, D03:p0050:u0002, D03:p0050:u0003, D03:p0050:u0006, D03:p0050:u0007, D03:p0050:u0008, D03:p0050:u0009, D03:p0050:u0010, D03:p0050:u0011, D03:p0050:u0012, D03:p0050:u0013, D03:p0050:u0014, D03:p0050:u0015, D03:p0050:u0016, D03:p0050:u0017, D03:p0050:u0018, D03:p0050:u0019, D03:p0050:u0020, D03:p0050:u0021, D03:p0050:u0022, D03:p0050:u0023, D03:p0050:u0024, D03:p0050:u0025, D03:p0050:u0026, D03:p0050:u0027, D03:p0050:u0028, D03:p0050:u0029, D03:p0050:u0030, D03:p0050:u0031, D03:p0050:u0032, D03:p0050:u0033, D03:p0050:u0034, D03:p0050:u0035, D03:p0050:u0036, D03:p0050:u0037, D03:p0050:u0038, D03:p0050:u0039, D03:p0050:u0040, D03:p0050:u0041, D03:p0050:u0042, D03:p0050:u0043, D03:p0050:u0044, D03:p0050:u0045, D03:p0050:u0046, D03:p0050:u0047, D03:p0050:u0048, D03:p0050:u0049, D03:p0050:u0050
**Общая страница с:** AI-04-06

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
3
1
2
4
5
6
7
8
3
1
2
4
5
6
7
8
ℎ= 5
ℎ= 4
ℎ= 2
ℎ= 3
````

## D03 — Lecture 5.pdf, PDF-страница 51
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=51`
Строки (ID элементов): D03:p0051:u0001, D03:p0051:u0002, D03:p0051:u0003, D03:p0051:u0006, D03:p0051:u0007, D03:p0051:u0008, D03:p0051:u0009, D03:p0051:u0010, D03:p0051:u0011, D03:p0051:u0012, D03:p0051:u0013, D03:p0051:u0014, D03:p0051:u0015, D03:p0051:u0016, D03:p0051:u0017, D03:p0051:u0018, D03:p0051:u0019, D03:p0051:u0020, D03:p0051:u0021, D03:p0051:u0022, D03:p0051:u0023, D03:p0051:u0024, D03:p0051:u0025, D03:p0051:u0026, D03:p0051:u0027, D03:p0051:u0028, D03:p0051:u0029, D03:p0051:u0030, D03:p0051:u0031, D03:p0051:u0032, D03:p0051:u0033, D03:p0051:u0034, D03:p0051:u0035, D03:p0051:u0036, D03:p0051:u0037, D03:p0051:u0038, D03:p0051:u0039, D03:p0051:u0040, D03:p0051:u0041, D03:p0051:u0042, D03:p0051:u0043, D03:p0051:u0044, D03:p0051:u0045, D03:p0051:u0046, D03:p0051:u0047, D03:p0051:u0048, D03:p0051:u0049, D03:p0051:u0050, D03:p0051:u0051, D03:p0051:u0052, D03:p0051:u0053, D03:p0051:u0054, D03:p0051:u0055, D03:p0051:u0056, D03:p0051:u0057, D03:p0051:u0058, D03:p0051:u0059, D03:p0051:u0060
**Общая страница с:** AI-04-06

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
3
1
2
4
5
6
7
8
ℎ= 1
3
1
2
4
5
6
7
8
3
1
2
4
5
6
7
8
ℎ= 5
ℎ= 4
ℎ= 2
ℎ= 3
…
````

## D03 — Lecture 5.pdf, PDF-страница 52
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=52`
Строки (ID элементов): D03:p0052:u0001, D03:p0052:u0002, D03:p0052:u0003, D03:p0052:u0006, D03:p0052:u0007, D03:p0052:u0008, D03:p0052:u0009, D03:p0052:u0010, D03:p0052:u0011, D03:p0052:u0012, D03:p0052:u0013, D03:p0052:u0014, D03:p0052:u0015, D03:p0052:u0016, D03:p0052:u0017, D03:p0052:u0018, D03:p0052:u0019, D03:p0052:u0020, D03:p0052:u0021, D03:p0052:u0022, D03:p0052:u0023, D03:p0052:u0024, D03:p0052:u0025, D03:p0052:u0026, D03:p0052:u0027, D03:p0052:u0028, D03:p0052:u0029, D03:p0052:u0030, D03:p0052:u0031, D03:p0052:u0032, D03:p0052:u0033, D03:p0052:u0034, D03:p0052:u0035, D03:p0052:u0036, D03:p0052:u0037, D03:p0052:u0038, D03:p0052:u0039, D03:p0052:u0040, D03:p0052:u0041, D03:p0052:u0042, D03:p0052:u0043, D03:p0052:u0044, D03:p0052:u0045, D03:p0052:u0046, D03:p0052:u0047, D03:p0052:u0048, D03:p0052:u0049, D03:p0052:u0050, D03:p0052:u0051, D03:p0052:u0052, D03:p0052:u0053, D03:p0052:u0054, D03:p0052:u0055, D03:p0052:u0056, D03:p0052:u0057, D03:p0052:u0058, D03:p0052:u0059, D03:p0052:u0060, D03:p0052:u0061, D03:p0052:u0062
**Общая страница с:** AI-04-06

````text
Hill Climbers on 8-puzzle Problem
- ℎ– number of misplaced numbered tiles
- ℎ→𝑚𝑖𝑛
3
1
2
4
5
8
6
7
ℎ= 5
3
1
2
4
5
8
6
7
1
2
3
4
5
6
7
8
Goal state
ℎ= 4
ℎ= 0
3
1
2
4
5
6
7
8
ℎ= 1
3
1
2
4
5
6
7
8
ℎ= 2
3
1
2
4
5
6
7
8
ℎ= 3
…
…
````

## D03 — Lecture 5.pdf, PDF-страница 53
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=53`
Строки (ID элементов): D03:p0053:u0001, D03:p0053:u0002, D03:p0053:u0003, D03:p0053:u0004, D03:p0053:u0005, D03:p0053:u0008, D03:p0053:u0009, D03:p0053:u0010, D03:p0053:u0011, D03:p0053:u0012, D03:p0053:u0013, D03:p0053:u0014, D03:p0053:u0015, D03:p0053:u0016, D03:p0053:u0017, D03:p0053:u0018, D03:p0053:u0019, D03:p0053:u0020, D03:p0053:u0021, D03:p0053:u0022, D03:p0053:u0023, D03:p0053:u0024, D03:p0053:u0025
**Общая страница с:** AI-04-06, AI-04-13
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Alternative Heuristics?
- Instead of number of misplaced tiles we could use the sum of the
Manhattan distances of the tiles from their goal positions as heuristics
- ℎ→𝑚𝑖𝑛
- Test it by yourself
3
1
2
4
5
8
6
7
ℎ= 0 + 0 + 1 + 1 + 1 + 0 + 1 + 1 = 5
1
2
3
4
5
6
7
8
Goal state
````


---

# AI-04-13 — Локальные оптимумы, плато и перезапуски

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Диагностируй сбой локального поиска на ландшафте и выбери стратегию выхода.
**Пункты РПД:** —

**Связанные страницы:** 6; **символов извлечённого текста:** 1952.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D03 — Lecture 5.pdf, PDF-страница 53
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=53`
Строки (ID элементов): D03:p0053:u0001, D03:p0053:u0002, D03:p0053:u0003, D03:p0053:u0004, D03:p0053:u0005, D03:p0053:u0008, D03:p0053:u0009, D03:p0053:u0010, D03:p0053:u0011, D03:p0053:u0012, D03:p0053:u0013, D03:p0053:u0014, D03:p0053:u0015, D03:p0053:u0016, D03:p0053:u0017, D03:p0053:u0018, D03:p0053:u0019, D03:p0053:u0020, D03:p0053:u0021, D03:p0053:u0022, D03:p0053:u0023, D03:p0053:u0024, D03:p0053:u0025
**Общая страница с:** AI-04-06, AI-04-12
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Alternative Heuristics?
- Instead of number of misplaced tiles we could use the sum of the
Manhattan distances of the tiles from their goal positions as heuristics
- ℎ→𝑚𝑖𝑛
- Test it by yourself
3
1
2
4
5
8
6
7
ℎ= 0 + 0 + 1 + 1 + 1 + 0 + 1 + 1 = 5
1
2
3
4
5
6
7
8
Goal state
````

## D03 — Lecture 5.pdf, PDF-страница 54
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=54`
Строки (ID элементов): D03:p0054:u0001, D03:p0054:u0002, D03:p0054:u0003, D03:p0054:u0004, D03:p0054:u0005, D03:p0054:u0006, D03:p0054:u0007, D03:p0054:u0008, D03:p0054:u0009, D03:p0054:u0010, D03:p0054:u0011, D03:p0054:u0012, D03:p0054:u0013, D03:p0054:u0014
**Непроверенные OCR/формулы:** 7 исключённых из основного текста кандидатов; см. JSON.

````text
Issues and Work About
- Local Maxima
- Stuck in suboptimal places if our value is on a
localized hill
- Change the mutation
- Change the representation
- Random restart
- Plateaus
- A flat area of the state-space landscape. It can be a
flat local maximum, from which no uphill exit exists
- Ridges
- Because hill climbers only adjust one element in the
vector at a time, each step will move in an axis-
aligned direction
````

## D03 — Lecture 5.pdf, PDF-страница 55
Источник в ZIP: `AI_course_cleaned/03_Lecture 5/source.pdf#page=55`
Строки (ID элементов): D03:p0055:u0001, D03:p0055:u0002, D03:p0055:u0003, D03:p0055:u0004, D03:p0055:u0005, D03:p0055:u0006, D03:p0055:u0007, D03:p0055:u0008, D03:p0055:u0009

````text
Issues and Work About
- Multiple Optima
- Multiple Good Solutions
- Random Restart
- Large areas of equal solutions
- Change the mutation
- Random Restart
- Jumping over areas of the space
- Selected Mutation hops over the space
````

## D25 — Week 7 Lecture.pdf, PDF-страница 49
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=49`
Строки (ID элементов): D25:p0049:u0001, D25:p0049:u0003, D25:p0049:u0004, D25:p0049:u0006, D25:p0049:u0007, D25:p0049:u0009, D25:p0049:u0010, D25:p0049:u0012
**Общая страница с:** AI-04-22

````text
Local Maximums
A solution s in S is said to be a local maximum if its fitness is greater than or
equal to all of neighbors, i.e. f(s)>=f(w) V w in N(s)
If there is a relatively high number of such maximums then the space is
called rugged
If there is a low number of maximums then the space is declared to be
smooth
Note that this depends highly on how the neighbourhood is defined
````

## D25 — Week 7 Lecture.pdf, PDF-страница 50
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=50`
Строки (ID элементов): D25:p0050:u0001, D25:p0050:u0003, D25:p0050:u0004, D25:p0050:u0006, D25:p0050:u0008, D25:p0050:u0010
**Общая страница с:** AI-04-22

````text
Basins of Attraction
A basin of attraction is a set of points which are likely based on their
neighbours to move to the same local optimum
Local Optimums with small basins are considered isolated
Larger Basins imply a smoother landscape
If we have few local optimums the space is said to be more neutral
````

## D25 — Week 7 Lecture.pdf, PDF-страница 51
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=51`
Строки (ID элементов): D25:p0051:u0001, D25:p0051:u0003, D25:p0051:u0004, D25:p0051:u0006, D25:p0051:u0007, D25:p0051:u0009, D25:p0051:u0010
**Общая страница с:** AI-04-22

````text
Fitness Neutrality
If the fitness is relatively neutral then the search will randomly walk about
this area
If this is the case then our movements will for the most part will not progress
to a local optimum
If the space has many local optimum then it may be likely to be stuck, by
falling into a pit we cannot move out of based on our neighbor graph
````


---

# AI-04-14 — Имитация отжига

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Проведи несколько шагов simulated annealing и обоснуй принятие ухудшающего хода.
**Пункты РПД:** RPD-19

**Связанные страницы:** 9; **символов извлечённого текста:** 3691.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D22 — Week 6 Lecture.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=4`
Строки (ID элементов): D22:p0004:u0001, D22:p0004:u0002, D22:p0004:u0003, D22:p0004:u0004, D22:p0004:u0005
**Непроверенные OCR/формулы:** 14 исключённых из основного текста кандидатов; см. JSON.

````text
Simulated Annealing
- Inspired by metallurgy. Based on the properties of Metal working
- Metal is heated and cooled in order for it to be made workable
- Crystal lattice atoms are more active when temperature is higher
- Can be considered as a mixture of Hill Climber and Random Walk
````

## D22 — Week 6 Lecture.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=5`
Строки (ID элементов): D22:p0005:u0001, D22:p0005:u0002, D22:p0005:u0003, D22:p0005:u0004, D22:p0005:u0005, D22:p0005:u0006, D22:p0005:u0007, D22:p0005:u0008, D22:p0005:u0009, D22:p0005:u0010

````text
Simulation of This Process
- Set down a number of search points
- Points move dependent upon the temperature applied
- They move about the space based on a positive temperature which is
slowly reducing over time
- This allows for large movement at the beginning of the algorithm and reduces
into smaller and smaller movements as time goes on
- Two Types
- Temperature controls size of step
- Temperature controls the acceptance of a step
````

## D22 — Week 6 Lecture.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=6`
Строки (ID элементов): D22:p0006:u0001, D22:p0006:u0002, D22:p0006:u0003, D22:p0006:u0004, D22:p0006:u0005, D22:p0006:u0006, D22:p0006:u0007, D22:p0006:u0008, D22:p0006:u0009, D22:p0006:u0010, D22:p0006:u0011, D22:p0006:u0012

````text
Simulated Annealing
- Start at an initial temperature value (usually something hot) and create a
random initial solution
- Until temperature is cool, usually 0
- Make a change to the current solution (neighbour) based on the temperature
- Current location + Rand_Distribution(T), where T is temperature
- If new state 𝑥! is better than 𝑥" (𝑓𝑥" < 𝑓(𝑥!)), then move to 𝑥!
- Else, move to 𝑥! with probability 𝑃𝑥" →𝑥! = 𝑒($ %! &$ %" )/)
- Decrease the temperature T
- This can be done according to different formulas, but has to be gradual process
- Decreasing T reduces hops over
the search space
````

## D22 — Week 6 Lecture.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=7`
Строки (ID элементов): D22:p0007:u0001, D22:p0007:u0008
**Непроверенные OCR/формулы:** 10 исключённых из основного текста кандидатов; см. JSON.

````text
Temperature Controls the Step Size
arr
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=13`
Строки (ID элементов): D23:p0013:u0001, D23:p0013:u0002, D23:p0013:u0003
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
Simulated Annealing
Based on the properties of Metal working
Metal is heated and cooled in order for it to be made workable
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=14`
Строки (ID элементов): D23:p0014:u0001, D23:p0014:u0002, D23:p0014:u0003, D23:p0014:u0004, D23:p0014:u0005, D23:p0014:u0006, D23:p0014:u0007, D23:p0014:u0008, D23:p0014:u0009

````text
Simulated Annealing
Start at an initial temperature value (usually something hot) and create a
random initial solution
Until temperature is cool
Make a small change to the current solution (neighbour)
Decide if we move to this neighbour solution
Neighbour solution is better or
Rand_Distribution() < temp
Decrease the temperature
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=15`
Строки (ID элементов): D23:p0015:u0001, D23:p0015:u0002, D23:p0015:u0003, D23:p0015:u0004, D23:p0015:u0005, D23:p0015:u0006, D23:p0015:u0007, D23:p0015:u0008, D23:p0015:u0009, D23:p0015:u0010, D23:p0015:u0011, D23:p0015:u0012, D23:p0015:u0013, D23:p0015:u0014, D23:p0015:u0015, D23:p0015:u0016, D23:p0015:u0017, D23:p0015:u0018, D23:p0015:u0019

````text
Simulated Annealing
1.
Start with a random tour through the selected cities.
2.
Pick a new candidate tour at random from all neighbors of the existing tour. One way to pick a neighboring
tour “is to choose two cities on the tour randomly, and then reverse the portion of the tour that lies
between them.” This candidate tour might be better or worse compared to the existing tour, i.e. shorter or
longer.
3.
If the candidate tour is better than the existing tour, accept it as the new tour.
4.
If the candidate tour is worse than the existing tour, still maybe accept it, according to some probability. The
probability of accepting an inferior tour is a function of how much longer the candidate is compared to the
current tour, and the temperature of the annealing process. A higher temperature makes you more likely to
accept an inferior tour.
5.
Go back to step 2 and repeat many times, lowering the temperature a bit at each iteration, until you get to a
low temperature and arrive at your (hopefully global, possibly local) minimum. If you’re not sufficiently
satisfied with the result, try the process again, perhaps with a different temperature cooling schedule.
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=16`
Строки (ID элементов): D23:p0016:u0001, D23:p0016:u0002, D23:p0016:u0003, D23:p0016:u0004, D23:p0016:u0005, D23:p0016:u0006, D23:p0016:u0007, D23:p0016:u0008, D23:p0016:u0009, D23:p0016:u0010, D23:p0016:u0011, D23:p0016:u0012, D23:p0016:u0013

````text
Travelling Salesman Problem -
Simulated Annealing (Pseudocode)
SIMULATED- ANNEALING(source,destination, schedule, num_iterations) return a route
current ← random route from source to destination
for num_iterations do
T ←schedule()
neighbours ←current.NEIGHBOURS
next ← randomly choose one state from neighbours
ΔE ←next.COST - current.COST
if ΔE < 0 then current ←next
else current ←next only with probability of e-ΔE/T
route ←current
return route
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=17`
Строки (ID элементов): D23:p0017:u0001, D23:p0017:u0002, D23:p0017:u0003, D23:p0017:u0004, D23:p0017:u0005, D23:p0017:u0006, D23:p0017:u0007

````text
Travelling Salesman Problem -
Simulated Annealing (Python Code)
DEMO:
https://smartmobilityalgorithms.github.io/book/content/TrajectoryAlgorithm
s/SimulatedAnnealing.html
https://toddwschneider.com/posts/traveling-salesman-with-simulated-
annealing-r-and-shiny/
````


---

# AI-04-15 — Дилемма исследования и использования

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Предложи стратегию exploration-exploitation для агента и объясни, как она меняется со временем.
**Пункты РПД:** RPD-22

**Связанные страницы:** 14; **символов извлечённого текста:** 3237.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=3`
Строки (ID элементов): D21:p0003:u0001, D21:p0003:u0003, D21:p0003:u0004, D21:p0003:u0006, D21:p0003:u0007, D21:p0003:u0009, D21:p0003:u0011, D21:p0003:u0012, D21:p0003:u0013

````text
Exploring and Exploiting
Exploration – the want for a search method to find new areas of the search
space which have not been visited yet
Exploitation – the want for a search method to locally search about the
best known areas in the space in order to refine these current solutions
All search algorithms will have some mix of both properties
Note that if we only have a limited number of objective tests available,
then we have a zero-sum game – we can explore or we can search with a
test
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=4`
Строки (ID элементов): D21:p0004:u0001, D21:p0004:u0003, D21:p0004:u0004

````text
Exploration vs Exploitation
Before visiting a new city, we searched for the restaurants where we can
buy sushi.
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=5`
Строки (ID элементов): D21:p0005:u0001, D21:p0005:u0003, D21:p0005:u0004, D21:p0005:u0006

````text
Exploration
Before visiting a new city, we searched for the restaurants where we can
buy sushi.
It’s a new city, we have no information about it before.
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=6`
Строки (ID элементов): D21:p0006:u0001, D21:p0006:u0004, D21:p0006:u0007, D21:p0006:u0008
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Exploration vs Exploitation
Where is the worm?
Doe you
Explore or Exploit?
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=7`
Строки (ID элементов): D21:p0007:u0001, D21:p0007:u0003, D21:p0007:u0004, D21:p0007:u0005, D21:p0007:u0007, D21:p0007:u0008, D21:p0007:u0009, D21:p0007:u0010, D21:p0007:u0011

````text
Exploration vs Exploitation
In this game, our mouse can have an infinite amount of small cheese (+1
piece per day). But at the top of the maze, there is a gigantic sum of
cheese (+10000).
Now, let's delve into the motivation behind the possible mouse's actions:
What motivates the mouse to explore the maze further, and under what
conditions would it choose to do so? How does the desire for a better
solution or a change in satisfaction level influence its decision to explore or
exploit the available cheese sources?
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=8`
Строки (ID элементов): D21:p0008:u0001, D21:p0008:u0003, D21:p0008:u0004, D21:p0008:u0005, D21:p0008:u0007, D21:p0008:u0008, D21:p0008:u0010, D21:p0008:u0011, D21:p0008:u0012

````text
Exploration vs Exploitation
If we only focus on exploitation, our agent will never reach the gigantic sum
of cheese. Instead, it will only exploit the nearest source of rewards, even if
this source is small (exploitation).
But if our agent does a little bit of exploration, it can discover the big
reward (the pile of big cheese).
This is what we call the exploration/exploitation trade-off. We need to
balance how much we explore the environment and how much we exploit
what we know about the environment.
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=9`
Строки (ID элементов): D21:p0009:u0001
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Exploration
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=10`
Строки (ID элементов): D21:p0010:u0001
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Exploitation
````

## D22 — Week 6 Lecture.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=8`
Строки (ID элементов): D22:p0008:u0001, D22:p0008:u0002, D22:p0008:u0003, D22:p0008:u0004, D22:p0008:u0005, D22:p0008:u0006, D22:p0008:u0007, D22:p0008:u0008, D22:p0008:u0009

````text
Exploring and Exploiting
- Exploration – the want for a search method to find new areas of the search
space which have not been visited yet
- Exploitation – the want for a search method to locally search about the
best known areas in the space in order to refine these current solutions
- All search algorithms will have some mix of both properties
- Note that if we only have a limited number of objective tests available,
then we have a zero-sum game – we can explore or we can search with a
test
````

## D22 — Week 6 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=9`
Строки (ID элементов): D22:p0009:u0001, D22:p0009:u0002, D22:p0009:u0003

````text
Exploration or Exploitation?
- We create a simulated annealing which has a reheat if we are not seeing a
10% improvement in the solution
````

## D22 — Week 6 Lecture.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=10`
Строки (ID элементов): D22:p0010:u0001, D22:p0010:u0002, D22:p0010:u0003

````text
Exploration
- The reheat increases the step size
- The reheat increases the probability we accept worst solutions
````

## D22 — Week 6 Lecture.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=11`
Строки (ID элементов): D22:p0011:u0001, D22:p0011:u0002, D22:p0011:u0003

````text
Exploration or Exploitation?
- After the application of a search we look at the least significant digit and
test from 0-9 taking the best final solution
````

## D22 — Week 6 Lecture.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=12`
Строки (ID элементов): D22:p0012:u0001, D22:p0012:u0002, D22:p0012:u0003, D22:p0012:u0004

````text
Exploitation
- Looking at the least significant digit we are looking in a close locality to the
previous, making the assumption that close parameter settings generate
closer outputs
````

## D22 — Week 6 Lecture.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=13`
Строки (ID элементов): D22:p0013:u0001, D22:p0013:u0002, D22:p0013:u0003, D22:p0013:u0004, D22:p0013:u0005, D22:p0013:u0006

````text
Parallel
- Hill Climbers and Simulated Annealing are trivially parallel
- We can place one of these searching units onto a different ‘core’
processing unit without any issues
- Hill Climbers and Simulated Annealing use the idea of a solution
neighbourhood, so we can divide the space
````


---

# AI-04-16 — Функция оценки A* f=g+h

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Рассчитай f, g, h нескольких узлов и выбери следующий для раскрытия.
**Пункты РПД:** RPD-20

**Связанные страницы:** 13; **символов извлечённого текста:** 5288.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=11`
Строки (ID элементов): D21:p0011:u0001, D21:p0011:u0003, D21:p0011:u0004, D21:p0011:u0006, D21:p0011:u0008, D21:p0011:u0011, D21:p0011:u0012, D21:p0011:u0013, D21:p0011:u0014, D21:p0011:u0015, D21:p0011:u0016, D21:p0011:u0017, D21:p0011:u0018, D21:p0011:u0019
**Общая страница с:** AI-04-17

````text
Help the Prince to find Cinderella
The prince will be at some position and the surrounding boxes will have
some costs:
Diagonals cost = 14
Non-Diagonals cost = 10
14
10
14
10
Prince
10
14
10
14
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=12`
Строки (ID элементов): D21:p0012:u0001, D21:p0012:u0003, D21:p0012:u0005, D21:p0012:u0007, D21:p0012:u0009, D21:p0012:u0011, D21:p0012:u0014, D21:p0012:u0015, D21:p0012:u0016, D21:p0012:u0017, D21:p0012:u0018, D21:p0012:u0019, D21:p0012:u0020, D21:p0012:u0021, D21:p0012:u0022, D21:p0012:u0023
**Общая страница с:** AI-04-17
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
There will be three costs in each square (Total, G, H):
Cost of square from the Prince = G
Cost of square from Cinderella = H (straight line distance)
Total cost (F) = G + H
Our goal is to minimize the total cost
Cinderella
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(62, 10, 52)
Prince
(48, 10, 38)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=13`
Строки (ID элементов): D21:p0013:u0001, D21:p0013:u0003, D21:p0013:u0005, D21:p0013:u0006, D21:p0013:u0009, D21:p0013:u0010, D21:p0013:u0011, D21:p0013:u0012, D21:p0013:u0013, D21:p0013:u0014, D21:p0013:u0015, D21:p0013:u0016, D21:p0013:u0017, D21:p0013:u0018, D21:p0013:u0019, D21:p0013:u0020, D21:p0013:u0021, D21:p0013:u0022, D21:p0013:u0023
**Общая страница с:** AI-04-17
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
Prince will move to the square with least costs.
After moving to next square, new costs will be calculated, and Prince will
move to the one with least cost.
Cinderella
(62, 28, 34)
(48, 24, 24)
(42, 28, 14)
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=14`
Строки (ID элементов): D21:p0014:u0001, D21:p0014:u0003, D21:p0014:u0005, D21:p0014:u0006, D21:p0014:u0009, D21:p0014:u0010, D21:p0014:u0011, D21:p0014:u0012, D21:p0014:u0013, D21:p0014:u0014, D21:p0014:u0015, D21:p0014:u0016, D21:p0014:u0017, D21:p0014:u0018, D21:p0014:u0019, D21:p0014:u0020, D21:p0014:u0021, D21:p0014:u0022, D21:p0014:u0023
**Общая страница с:** AI-04-17
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
Prince will move to the square with least costs.
After moving to next square, new costs will be calculated, and Prince will
move to the one with least cost.
Cinderella
(62, 28, 34)
(48, 24, 24)
(42, 28, 14)
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=15`
Строки (ID элементов): D21:p0015:u0001, D21:p0015:u0003, D21:p0015:u0005, D21:p0015:u0006, D21:p0015:u0009, D21:p0015:u0010, D21:p0015:u0011, D21:p0015:u0012, D21:p0015:u0013, D21:p0015:u0014, D21:p0015:u0015, D21:p0015:u0016, D21:p0015:u0017, D21:p0015:u0018, D21:p0015:u0019, D21:p0015:u0020, D21:p0015:u0021, D21:p0015:u0022, D21:p0015:u0023, D21:p0015:u0024, D21:p0015:u0025, D21:p0015:u0026, D21:p0015:u0027
**Общая страница с:** AI-04-17

````text
Help the Prince to find Cinderella
Prince will move to the square with least costs.
After moving to next square, new costs will be calculated, and Prince will
move to the one with least cost.
(62, 42, 20)
(48, 38, 10)
(42, 42, 0)
(62, 28, 34)
(48, 24, 24)
(42, 28, 14)
(48, 38, 10)
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(62, 42, 20)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=16`
Строки (ID элементов): D21:p0016:u0001, D21:p0016:u0003, D21:p0016:u0004, D21:p0016:u0006, D21:p0016:u0008, D21:p0016:u0009, D21:p0016:u0012, D21:p0016:u0013, D21:p0016:u0014, D21:p0016:u0015, D21:p0016:u0016, D21:p0016:u0017, D21:p0016:u0018, D21:p0016:u0019, D21:p0016:u0020, D21:p0016:u0021
**Общая страница с:** AI-04-17
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
If there is some obstacle, the prince will change it’s direction based on the
scores which are explored:
i.e. it will move to the square with least costs.
If there are several with same least cost, then it will go to the one with least cost
from Cinderella.
Cinderella
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(62, 10, 52)
Prince
(48, 10, 38)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=17`
Строки (ID элементов): D21:p0017:u0001, D21:p0017:u0003, D21:p0017:u0006, D21:p0017:u0007, D21:p0017:u0008, D21:p0017:u0009, D21:p0017:u0010, D21:p0017:u0011, D21:p0017:u0012, D21:p0017:u0013, D21:p0017:u0014, D21:p0017:u0015, D21:p0017:u0016, D21:p0017:u0017
**Общая страница с:** AI-04-17
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
We will move to the square with least cost, i.e. (42,14,28)
Cinderella
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=18`
Строки (ID элементов): D21:p0018:u0001, D21:p0018:u0003, D21:p0018:u0004, D21:p0018:u0005, D21:p0018:u0006, D21:p0018:u0009, D21:p0018:u0010, D21:p0018:u0011, D21:p0018:u0012, D21:p0018:u0013, D21:p0018:u0014, D21:p0018:u0015, D21:p0018:u0016, D21:p0018:u0017, D21:p0018:u0018, D21:p0018:u0019, D21:p0018:u0020, D21:p0018:u0021, D21:p0018:u0022, D21:p0018:u0023
**Общая страница с:** AI-04-17
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
We will move to the square with least total cost and in this case we have
three of such squares, so we will move to the square with least total cost
and least cost of heuristics (cost from Cinderella), i.e. (48,24,24), and
calculate new scores
Cinderella
(48, 38, 10)
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(54, 34, 20)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(68, 38, 30)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=19`
Строки (ID элементов): D21:p0019:u0001, D21:p0019:u0003, D21:p0019:u0004, D21:p0019:u0007, D21:p0019:u0008, D21:p0019:u0009, D21:p0019:u0010, D21:p0019:u0011, D21:p0019:u0012, D21:p0019:u0013, D21:p0019:u0014, D21:p0019:u0015, D21:p0019:u0016, D21:p0019:u0017, D21:p0019:u0018, D21:p0019:u0019, D21:p0019:u0020, D21:p0019:u0021, D21:p0019:u0022, D21:p0019:u0023, D21:p0019:u0024, D21:p0019:u0025
**Общая страница с:** AI-04-17
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
Now we can see that the lowest total cost is 48 for three squares, so we’ll
choose based on heuristics, which is (48, 38, 10).
(62, 52, 10)
Cinderella
(62, 52, 10)
(48, 38, 10)
(62, 48, 14)
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(54, 34, 20)
(76, 52, 24)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(68, 38, 30)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=20`
Строки (ID элементов): D21:p0020:u0001, D21:p0020:u0003, D21:p0020:u0006, D21:p0020:u0007, D21:p0020:u0008, D21:p0020:u0009, D21:p0020:u0010, D21:p0020:u0011, D21:p0020:u0012, D21:p0020:u0013, D21:p0020:u0014, D21:p0020:u0015, D21:p0020:u0016, D21:p0020:u0017, D21:p0020:u0018, D21:p0020:u0019, D21:p0020:u0020, D21:p0020:u0021, D21:p0020:u0022, D21:p0020:u0023, D21:p0020:u0024
**Общая страница с:** AI-04-17
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
This is our shortest path by following A* Algorithm with total cost of 48.
(62, 52, 10)
(48, 48, 0)
(62, 52, 10)
(48, 38, 10)
(62, 48, 14)
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(54, 34, 20)
(76, 52, 24)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(68, 38, 30)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D22 — Week 6 Lecture.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=14`
Строки (ID элементов): D22:p0014:u0001, D22:p0014:u0002, D22:p0014:u0003, D22:p0014:u0004, D22:p0014:u0005, D22:p0014:u0006, D22:p0014:u0007, D22:p0014:u0008, D22:p0014:u0009, D22:p0014:u0010, D22:p0014:u0011, D22:p0014:u0012, D22:p0014:u0013

````text
A* Search
- Fast well-established algorithm for game AI
- Pathways
- Movement of NPC (non-player character)
- RTS (real-time strategy) movement
- Usually one member of a flock
- Works in areas where we do not know the connectivity
- Makes it very suitable for PCG – because we do not need nodes defined by the
generator – but can still understand the measurements
- Can take into account multiple different connection topologies and styles of
movement
- Large number of iterative improvements and problem domain specific
implementations with heuristics
````

## D22 — Week 6 Lecture.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=15`
Строки (ID элементов): D22:p0015:u0001, D22:p0015:u0002, D22:p0015:u0003, D22:p0015:u0004, D22:p0015:u0005

````text
A* Formula
- f(n) = g(n) + h(n)
- g(n) is the real path from the initial position to the current node
- h(n) is the estimated path from the current node to the goal position
- To make Heuristics optimal, it has to be admissible and consistent
````

## D22 — Week 6 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=16`
Строки (ID элементов): D22:p0016:u0001, D22:p0016:u0002, D22:p0016:u0003, D22:p0016:u0004, D22:p0016:u0005, D22:p0016:u0006, D22:p0016:u0007, D22:p0016:u0008, D22:p0016:u0009, D22:p0016:u0010, D22:p0016:u0011, D22:p0016:u0012, D22:p0016:u0013
**Общая страница с:** AI-04-07, AI-04-08
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Heuristics Admissibility and Consistency
- In path-finding problems heuristics may be admissible or inadmissible
- Admissibility means that heuristics is not overestimating the solution
- Needs to be lower than or equal to the actual cost of reaching the goal
- Not each heuristic is obliged to be admissible. However, inadmissible heuristic
does not guarantee the optimal solution
- In path-finding problems a heuristic is considered to be consistent (or
monotone) if the estimated cost from one node to the successor node, added
to the estimated cost from the successor node to the goal is less than or equal
to the estimated cost from the current node to the goal state
- 𝐸𝑓(𝑥! →𝑥!"#) + 𝐸𝑓(𝑥!"# →𝑥$%&') ≤𝐸𝑓(𝑥! →𝑥$%&') →consistent heuristics
- All consistent heuristics are admissible heuristics, however, all admissible
heuristics are not necessarily consistent heuristics
````


---

# AI-04-17 — Алгоритм A* и списки OPEN/CLOSED

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Пошагово выполни A* на небольшой карте с препятствиями и восстанови оптимальный путь.
**Пункты РПД:** RPD-20

**Связанные страницы:** 49; **символов извлечённого текста:** 18083.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=11`
Строки (ID элементов): D21:p0011:u0001, D21:p0011:u0003, D21:p0011:u0004, D21:p0011:u0006, D21:p0011:u0008, D21:p0011:u0011, D21:p0011:u0012, D21:p0011:u0013, D21:p0011:u0014, D21:p0011:u0015, D21:p0011:u0016, D21:p0011:u0017, D21:p0011:u0018, D21:p0011:u0019
**Общая страница с:** AI-04-16

````text
Help the Prince to find Cinderella
The prince will be at some position and the surrounding boxes will have
some costs:
Diagonals cost = 14
Non-Diagonals cost = 10
14
10
14
10
Prince
10
14
10
14
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=12`
Строки (ID элементов): D21:p0012:u0001, D21:p0012:u0003, D21:p0012:u0005, D21:p0012:u0007, D21:p0012:u0009, D21:p0012:u0011, D21:p0012:u0014, D21:p0012:u0015, D21:p0012:u0016, D21:p0012:u0017, D21:p0012:u0018, D21:p0012:u0019, D21:p0012:u0020, D21:p0012:u0021, D21:p0012:u0022, D21:p0012:u0023
**Общая страница с:** AI-04-16
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
There will be three costs in each square (Total, G, H):
Cost of square from the Prince = G
Cost of square from Cinderella = H (straight line distance)
Total cost (F) = G + H
Our goal is to minimize the total cost
Cinderella
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(62, 10, 52)
Prince
(48, 10, 38)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=13`
Строки (ID элементов): D21:p0013:u0001, D21:p0013:u0003, D21:p0013:u0005, D21:p0013:u0006, D21:p0013:u0009, D21:p0013:u0010, D21:p0013:u0011, D21:p0013:u0012, D21:p0013:u0013, D21:p0013:u0014, D21:p0013:u0015, D21:p0013:u0016, D21:p0013:u0017, D21:p0013:u0018, D21:p0013:u0019, D21:p0013:u0020, D21:p0013:u0021, D21:p0013:u0022, D21:p0013:u0023
**Общая страница с:** AI-04-16
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
Prince will move to the square with least costs.
After moving to next square, new costs will be calculated, and Prince will
move to the one with least cost.
Cinderella
(62, 28, 34)
(48, 24, 24)
(42, 28, 14)
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=14`
Строки (ID элементов): D21:p0014:u0001, D21:p0014:u0003, D21:p0014:u0005, D21:p0014:u0006, D21:p0014:u0009, D21:p0014:u0010, D21:p0014:u0011, D21:p0014:u0012, D21:p0014:u0013, D21:p0014:u0014, D21:p0014:u0015, D21:p0014:u0016, D21:p0014:u0017, D21:p0014:u0018, D21:p0014:u0019, D21:p0014:u0020, D21:p0014:u0021, D21:p0014:u0022, D21:p0014:u0023
**Общая страница с:** AI-04-16
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
Prince will move to the square with least costs.
After moving to next square, new costs will be calculated, and Prince will
move to the one with least cost.
Cinderella
(62, 28, 34)
(48, 24, 24)
(42, 28, 14)
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=15`
Строки (ID элементов): D21:p0015:u0001, D21:p0015:u0003, D21:p0015:u0005, D21:p0015:u0006, D21:p0015:u0009, D21:p0015:u0010, D21:p0015:u0011, D21:p0015:u0012, D21:p0015:u0013, D21:p0015:u0014, D21:p0015:u0015, D21:p0015:u0016, D21:p0015:u0017, D21:p0015:u0018, D21:p0015:u0019, D21:p0015:u0020, D21:p0015:u0021, D21:p0015:u0022, D21:p0015:u0023, D21:p0015:u0024, D21:p0015:u0025, D21:p0015:u0026, D21:p0015:u0027
**Общая страница с:** AI-04-16

````text
Help the Prince to find Cinderella
Prince will move to the square with least costs.
After moving to next square, new costs will be calculated, and Prince will
move to the one with least cost.
(62, 42, 20)
(48, 38, 10)
(42, 42, 0)
(62, 28, 34)
(48, 24, 24)
(42, 28, 14)
(48, 38, 10)
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(62, 42, 20)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=16`
Строки (ID элементов): D21:p0016:u0001, D21:p0016:u0003, D21:p0016:u0004, D21:p0016:u0006, D21:p0016:u0008, D21:p0016:u0009, D21:p0016:u0012, D21:p0016:u0013, D21:p0016:u0014, D21:p0016:u0015, D21:p0016:u0016, D21:p0016:u0017, D21:p0016:u0018, D21:p0016:u0019, D21:p0016:u0020, D21:p0016:u0021
**Общая страница с:** AI-04-16
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
If there is some obstacle, the prince will change it’s direction based on the
scores which are explored:
i.e. it will move to the square with least costs.
If there are several with same least cost, then it will go to the one with least cost
from Cinderella.
Cinderella
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(62, 10, 52)
Prince
(48, 10, 38)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=17`
Строки (ID элементов): D21:p0017:u0001, D21:p0017:u0003, D21:p0017:u0006, D21:p0017:u0007, D21:p0017:u0008, D21:p0017:u0009, D21:p0017:u0010, D21:p0017:u0011, D21:p0017:u0012, D21:p0017:u0013, D21:p0017:u0014, D21:p0017:u0015, D21:p0017:u0016, D21:p0017:u0017
**Общая страница с:** AI-04-16
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
We will move to the square with least cost, i.e. (42,14,28)
Cinderella
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=18`
Строки (ID элементов): D21:p0018:u0001, D21:p0018:u0003, D21:p0018:u0004, D21:p0018:u0005, D21:p0018:u0006, D21:p0018:u0009, D21:p0018:u0010, D21:p0018:u0011, D21:p0018:u0012, D21:p0018:u0013, D21:p0018:u0014, D21:p0018:u0015, D21:p0018:u0016, D21:p0018:u0017, D21:p0018:u0018, D21:p0018:u0019, D21:p0018:u0020, D21:p0018:u0021, D21:p0018:u0022, D21:p0018:u0023
**Общая страница с:** AI-04-16
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
We will move to the square with least total cost and in this case we have
three of such squares, so we will move to the square with least total cost
and least cost of heuristics (cost from Cinderella), i.e. (48,24,24), and
calculate new scores
Cinderella
(48, 38, 10)
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(54, 34, 20)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(68, 38, 30)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=19`
Строки (ID элементов): D21:p0019:u0001, D21:p0019:u0003, D21:p0019:u0004, D21:p0019:u0007, D21:p0019:u0008, D21:p0019:u0009, D21:p0019:u0010, D21:p0019:u0011, D21:p0019:u0012, D21:p0019:u0013, D21:p0019:u0014, D21:p0019:u0015, D21:p0019:u0016, D21:p0019:u0017, D21:p0019:u0018, D21:p0019:u0019, D21:p0019:u0020, D21:p0019:u0021, D21:p0019:u0022, D21:p0019:u0023, D21:p0019:u0024, D21:p0019:u0025
**Общая страница с:** AI-04-16
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
Now we can see that the lowest total cost is 48 for three squares, so we’ll
choose based on heuristics, which is (48, 38, 10).
(62, 52, 10)
Cinderella
(62, 52, 10)
(48, 38, 10)
(62, 48, 14)
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(54, 34, 20)
(76, 52, 24)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(68, 38, 30)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=20`
Строки (ID элементов): D21:p0020:u0001, D21:p0020:u0003, D21:p0020:u0006, D21:p0020:u0007, D21:p0020:u0008, D21:p0020:u0009, D21:p0020:u0010, D21:p0020:u0011, D21:p0020:u0012, D21:p0020:u0013, D21:p0020:u0014, D21:p0020:u0015, D21:p0020:u0016, D21:p0020:u0017, D21:p0020:u0018, D21:p0020:u0019, D21:p0020:u0020, D21:p0020:u0021, D21:p0020:u0022, D21:p0020:u0023, D21:p0020:u0024
**Общая страница с:** AI-04-16
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Help the Prince to find Cinderella
This is our shortest path by following A* Algorithm with total cost of 48.
(62, 52, 10)
(48, 48, 0)
(62, 52, 10)
(48, 38, 10)
(62, 48, 14)
(62, 14, 48)
(48, 10, 38)
(42, 14, 28)
(48, 24, 24)
(54, 34, 20)
(76, 52, 24)
(62, 10, 52)
Prince
(48, 10, 38)
(62, 28, 34)
(68, 38, 30)
(70, 14, 56)
(62, 10, 52)
(62, 14, 48)
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=21`
Строки (ID элементов): D21:p0021:u0001
**Общая страница с:** AI-04-18

````text
Moore Neighbourhood Algorithm Range 1
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=22`
Строки (ID элементов): D21:p0022:u0001, D21:p0022:u0003, D21:p0022:u0004, D21:p0022:u0005, D21:p0022:u0007, D21:p0022:u0008, D21:p0022:u0010, D21:p0022:u0011
**Общая страница с:** AI-04-18

````text
Moore Neighbourhood Algorithm
Using Moore Neighbourhood algorithm, the agent (the prince in our
example) can check all 8 cells of his immediate neighbourhood
(exploring the environment around him).
If any of these cells contain an obstacle such as the stepmom or stepsisters,
the prince will be aware of them.
Based on this perception, the prince can decide how to move in order to
avoid coming into a cell containing an obstacle.
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=23`
Строки (ID элементов): D21:p0023:u0001
**Общая страница с:** AI-04-18
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Von Neumann vs Moore Range 1
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=24`
Строки (ID элементов): D21:p0024:u0001, D21:p0024:u0004, D21:p0024:u0005
**Общая страница с:** AI-04-18
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Moore Neighbourhood Ranges
Moore neighbourhoods for ranges r = 0, 1, 2, and 3 are illustrated above. The number of
cells in the Moore neighbourhood of range r is (2r+1)^2, the square of odd number
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=25`
Строки (ID элементов): D21:p0025:u0001, D21:p0025:u0004, D21:p0025:u0005
**Общая страница с:** AI-04-18
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Von Neumann Neighbourhood Ranges
Von Neumann neighbourhoods for ranges r = 0, 1, 2, and 3 are illustrated above. The number of
cells in the von Neumann neighbourhood of range r is 2r(r+1)+1
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=26`
Строки (ID элементов): D21:p0026:u0001, D21:p0026:u0004, D21:p0026:u0005, D21:p0026:u0006, D21:p0026:u0009, D21:p0026:u0010, D21:p0026:u0011, D21:p0026:u0012, D21:p0026:u0013, D21:p0026:u0014, D21:p0026:u0015, D21:p0026:u0016, D21:p0026:u0017, D21:p0026:u0018, D21:p0026:u0019, D21:p0026:u0020, D21:p0026:u0021, D21:p0026:u0022, D21:p0026:u0023, D21:p0026:u0024, D21:p0026:u0025, D21:p0026:u0026, D21:p0026:u0027, D21:p0026:u0028, D21:p0026:u0029, D21:p0026:u0030, D21:p0026:u0031

````text
Task 1: Help Prince
find out the shortest path for Prince to
meet Cinderella. Follow the A* algorithm and write down the costs at each
visited square. Stepmom, Stepsisters are obstacles for the Prince.
9
8
Cinderella
7
6
Stepsis1
Stepsis2
Stepsis3
5
4
Stepmom
3
2
Prince
1
1
2
3
4
5
6
7
8
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=27`
Строки (ID элементов): D21:p0027:u0001, D21:p0027:u0003, D21:p0027:u0004, D21:p0027:u0005, D21:p0027:u0008, D21:p0027:u0009, D21:p0027:u0010, D21:p0027:u0011, D21:p0027:u0012, D21:p0027:u0013, D21:p0027:u0014, D21:p0027:u0015, D21:p0027:u0016, D21:p0027:u0017, D21:p0027:u0018, D21:p0027:u0019, D21:p0027:u0020, D21:p0027:u0021, D21:p0027:u0022, D21:p0027:u0023, D21:p0027:u0024, D21:p0027:u0025, D21:p0027:u0026

````text
Task 2: Help Prince
Repeat the same game with obstacles. Prince is able to perceive obstacles
via Moore neighbourhood. The obstacles are hidden, ask the instructor for
obstacle after making a move.
9
8
Cinderella
7
6
5
4
3
2
Prince
1
1
2
3
4
5
6
7
8
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=28`
Строки (ID элементов): D21:p0028:u0001, D21:p0028:u0003, D21:p0028:u0004

````text
Homework
Implement A* algorithm for considered world with obstacles using
C/C++/C#/Java/Python.
````

## D22 — Week 6 Lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=17`
Строки (ID элементов): D22:p0017:u0001, D22:p0017:u0002, D22:p0017:u0003, D22:p0017:u0004, D22:p0017:u0005, D22:p0017:u0006, D22:p0017:u0007, D22:p0017:u0008, D22:p0017:u0009, D22:p0017:u0010, D22:p0017:u0011, D22:p0017:u0012, D22:p0017:u0013, D22:p0017:u0016, D22:p0017:u0017, D22:p0017:u0018, D22:p0017:u0019, D22:p0017:u0020, D22:p0017:u0021, D22:p0017:u0022

````text
A* Algorithm
A node contains a location, a cost, and a parent
Initialize sets CLOSED and BLOCKED to be null
Initialize a priority queue based on cost of a node
called OPEN to be the starting location, set cost = 0
While OPEN is non-empty do
Current <- Pop OPEN.top
For all neighbouring locations X
If not in (BLOCKED or CLOSED)
If not in OPEN
X.cost = current.cost + costFromCurrentToX
X.parent = current
Push X to OPEN
Else if X is in OPEN
If current.cost + costFromCurrentToX < OPEN.X.cost
// we found a better path
OPEN.X.cost = current.cost + costFromCurrentToX
OPEN.X.parent = current
END FOR ALL X
Push Current to CLOSED
````

## D22 — Week 6 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=18`
Строки (ID элементов): D22:p0018:u0001, D22:p0018:u0002, D22:p0018:u0003, D22:p0018:u0004, D22:p0018:u0005, D22:p0018:u0006, D22:p0018:u0007, D22:p0018:u0008, D22:p0018:u0009, D22:p0018:u0010, D22:p0018:u0011, D22:p0018:u0012

````text
A* for PATH FINDING
- REPORT_PATH (START, FINISH)
- STACK PATH initialized to NULL
- RUN A* (START)
- Find FINISH in CLOSED
- Current <- FINISH
- While Current not START
- PUSH Current to PATH
- Current <- Current.parent
- PRINT START
- While STACK not NULL
- PRINT POP PATH
````

## D22 — Week 6 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=19`
Строки (ID элементов): D22:p0019:u0001, D22:p0019:u0004, D22:p0019:u0005, D22:p0019:u0006, D22:p0019:u0007, D22:p0019:u0008, D22:p0019:u0009, D22:p0019:u0010, D22:p0019:u0011, D22:p0019:u0012

````text
Rover World
0
1
2
3
4
0                 1                  2                 3                4
Rover
Obstacle
Goal
````

## D22 — Week 6 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=20`
Строки (ID элементов): D22:p0020:u0001, D22:p0020:u0004, D22:p0020:u0005, D22:p0020:u0006, D22:p0020:u0007, D22:p0020:u0008, D22:p0020:u0009
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
World with Obstacles
0
1
2
3
4
0                 1                  2                 3                4
````

## D22 — Week 6 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=21`
Строки (ID элементов): D22:p0021:u0001, D22:p0021:u0004, D22:p0021:u0005, D22:p0021:u0006, D22:p0021:u0007, D22:p0021:u0008, D22:p0021:u0009
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
World with Obstacles and Goal
0
1
2
3
4
0                 1                  2                 3                4
````

## D22 — Week 6 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=22`
Строки (ID элементов): D22:p0022:u0001, D22:p0022:u0004, D22:p0022:u0005, D22:p0022:u0006, D22:p0022:u0007, D22:p0022:u0008, D22:p0022:u0009
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
World with Obstacles, Goal and Starting Position
0
1
2
3
4
0                 1                  2                 3                4
````

## D22 — Week 6 Lecture.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=23`
Строки (ID элементов): D22:p0023:u0001, D22:p0023:u0004, D22:p0023:u0005, D22:p0023:u0006, D22:p0023:u0007, D22:p0023:u0008, D22:p0023:u0009, D22:p0023:u0010, D22:p0023:u0011, D22:p0023:u0012, D22:p0023:u0013, D22:p0023:u0014, D22:p0023:u0015, D22:p0023:u0016, D22:p0023:u0017, D22:p0023:u0018, D22:p0023:u0019, D22:p0023:u0020, D22:p0023:u0021, D22:p0023:u0022, D22:p0023:u0023, D22:p0023:u0024, D22:p0023:u0025, D22:p0023:u0026, D22:p0023:u0027, D22:p0023:u0028, D22:p0023:u0029
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
World with Obstacles, Goal and Starting Position
0
1
2
3
4
0                 1                  2                 3                4
•
To find the path to the
customer Rover requires
A* algorithm to be applied
•
Assume that the Rover
can move horizontally
(10p), vertically (10p) and
diagonally (14p)
•
For heuristics we use a
Euclidean distance without
mantissa from the current
cell till the goal
•
For each cell x costs g(x),
h(x) and f(x) = g(x) + h(x)
have to be assigned
g(x) h(x)
f(x)
````

## D22 — Week 6 Lecture.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=24`
Строки (ID элементов): D22:p0024:u0001, D22:p0024:u0002, D22:p0024:u0003, D22:p0024:u0004, D22:p0024:u0005, D22:p0024:u0006, D22:p0024:u0015, D22:p0024:u0019, D22:p0024:u0020, D22:p0024:u0023, D22:p0024:u0024, D22:p0024:u0025
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Types of Heuristics
- Correct choice of heuristics defines the optimality of A*
- If diagonal moves are allowed and the cost is the same as to vertical and
horizontal moves than Chebyshev Distance is preferable, it is also called a
Straight Line Distance
- If only 4 directions, than Manhattan Distance is more logical
Euclidean Distance
4
4
1
4
4
````

## D22 — Week 6 Lecture.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=25`
Строки (ID элементов): D22:p0025:u0001, D22:p0025:u0004, D22:p0025:u0005, D22:p0025:u0006, D22:p0025:u0007, D22:p0025:u0008, D22:p0025:u0009, D22:p0025:u0010, D22:p0025:u0011, D22:p0025:u0012, D22:p0025:u0013, D22:p0025:u0014, D22:p0025:u0015
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Add Initial Point to Open List and Assign Cost
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
NULL
OPEN:
(0,0) – 0
g(x) h(x)
f(x)
````

## D22 — Week 6 Lecture.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=26`
Строки (ID элементов): D22:p0026:u0001, D22:p0026:u0002, D22:p0026:u0003, D22:p0026:u0004, D22:p0026:u0005, D22:p0026:u0006, D22:p0026:u0009, D22:p0026:u0010, D22:p0026:u0011, D22:p0026:u0012, D22:p0026:u0013, D22:p0026:u0014, D22:p0026:u0015, D22:p0026:u0016, D22:p0026:u0017, D22:p0026:u0018, D22:p0026:u0019, D22:p0026:u0020, D22:p0026:u0021, D22:p0026:u0022, D22:p0026:u0023
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
10 42
52
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0 – NEW
OPEN:
(1,0) – 52 – NEW
(0,1) – 58 – NEW
(1,1) – COLLISION
For simplicity we can assign
infinitely big value to each
obstacle cell
````

## D22 — Week 6 Lecture.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=27`
Строки (ID элементов): D22:p0027:u0001, D22:p0027:u0002, D22:p0027:u0003, D22:p0027:u0004, D22:p0027:u0005, D22:p0027:u0006, D22:p0027:u0007, D22:p0027:u0008, D22:p0027:u0009, D22:p0027:u0010, D22:p0027:u0013, D22:p0027:u0014, D22:p0027:u0015, D22:p0027:u0016, D22:p0027:u0017, D22:p0027:u0018, D22:p0027:u0019, D22:p0027:u0020, D22:p0027:u0021, D22:p0027:u0022, D22:p0027:u0023, D22:p0027:u0024, D22:p0027:u0025, D22:p0027:u0026
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
10 42
52
20 38
58
24 28
52
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52 – NEW
OPEN:
(0,1) – 58
(1,1) – ∞
(2,0) – 58 – NEW
(2,1) – 52 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=28`
Строки (ID элементов): D22:p0028:u0001, D22:p0028:u0002, D22:p0028:u0003, D22:p0028:u0004, D22:p0028:u0005, D22:p0028:u0006, D22:p0028:u0007, D22:p0028:u0008, D22:p0028:u0009, D22:p0028:u0010, D22:p0028:u0011, D22:p0028:u0012, D22:p0028:u0013, D22:p0028:u0014, D22:p0028:u0015, D22:p0028:u0016, D22:p0028:u0019, D22:p0028:u0020, D22:p0028:u0021, D22:p0028:u0022, D22:p0028:u0023, D22:p0028:u0024, D22:p0028:u0025, D22:p0028:u0026, D22:p0028:u0027, D22:p0028:u0028, D22:p0028:u0029, D22:p0028:u0030, D22:p0028:u0031, D22:p0028:u0032, D22:p0028:u0033, D22:p0028:u0034, D22:p0028:u0035, D22:p0028:u0036, D22:p0028:u0037
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
10 42
52
38 34
72
20 38
58
24 28
52
34 24
58
38 34
72
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52 – NEW
OPEN:
(0,1) – 58
(1,1) – ∞
(2,0) – 58
(3,1) – ∞– NEW
(3,2) – ∞– NEW
(3,0) – 72 – NEW
(2,2) – 58 – NEW
(1,2) – 72 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=29`
Строки (ID элементов): D22:p0029:u0001, D22:p0029:u0002, D22:p0029:u0003, D22:p0029:u0004, D22:p0029:u0005, D22:p0029:u0006, D22:p0029:u0007, D22:p0029:u0008, D22:p0029:u0009, D22:p0029:u0010, D22:p0029:u0011, D22:p0029:u0012, D22:p0029:u0013, D22:p0029:u0014, D22:p0029:u0015, D22:p0029:u0016, D22:p0029:u0019, D22:p0029:u0020, D22:p0029:u0021, D22:p0029:u0022, D22:p0029:u0023, D22:p0029:u0024, D22:p0029:u0025, D22:p0029:u0026, D22:p0029:u0027, D22:p0029:u0028, D22:p0029:u0029, D22:p0029:u0030, D22:p0029:u0031, D22:p0029:u0032, D22:p0029:u0033, D22:p0029:u0034, D22:p0029:u0035, D22:p0029:u0036, D22:p0029:u0037
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
10 42
52
38 34
72
20 38
58
24 28
52
34 24
58
38 34
72
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52 – NEW
OPEN:
(0,1) – 58
(1,1) – ∞
(2,0) – 58
(3,1) – ∞– NEW
(3,2) – ∞– NEW
(3,0) – 72 – NEW
(2,2) – 58 – NEW
(1,2) – 72 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=30`
Строки (ID элементов): D22:p0030:u0001, D22:p0030:u0002, D22:p0030:u0003, D22:p0030:u0004, D22:p0030:u0005, D22:p0030:u0006, D22:p0030:u0007, D22:p0030:u0008, D22:p0030:u0009, D22:p0030:u0010, D22:p0030:u0011, D22:p0030:u0012, D22:p0030:u0013, D22:p0030:u0014, D22:p0030:u0015, D22:p0030:u0016, D22:p0030:u0017, D22:p0030:u0018, D22:p0030:u0019, D22:p0030:u0020, D22:p0030:u0023, D22:p0030:u0024, D22:p0030:u0025, D22:p0030:u0026, D22:p0030:u0027, D22:p0030:u0028, D22:p0030:u0029, D22:p0030:u0030, D22:p0030:u0031, D22:p0030:u0032, D22:p0030:u0033, D22:p0030:u0034, D22:p0030:u0035, D22:p0030:u0036, D22:p0030:u0037, D22:p0030:u0038, D22:p0030:u0039, D22:p0030:u0040, D22:p0030:u0041, D22:p0030:u0042, D22:p0030:u0043
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
10 42
52
38 34
72
48 30
78
20 38
58
24 28
52
34 24
58
44 20
64
38 34
72
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58 – NEW
OPEN:
(0,1) – 58
(1,1) – ∞
(2,0) – 58
(3,1) – ∞
(3,2) – ∞
(3,0) – 72
(1,2) – 72
(2,3) – 64 – NEW
(1,3) – 78 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=31`
Строки (ID элементов): D22:p0031:u0001, D22:p0031:u0002, D22:p0031:u0003, D22:p0031:u0004, D22:p0031:u0005, D22:p0031:u0006, D22:p0031:u0007, D22:p0031:u0008, D22:p0031:u0009, D22:p0031:u0010, D22:p0031:u0011, D22:p0031:u0012, D22:p0031:u0013, D22:p0031:u0014, D22:p0031:u0015, D22:p0031:u0016, D22:p0031:u0017, D22:p0031:u0018, D22:p0031:u0019, D22:p0031:u0020, D22:p0031:u0023, D22:p0031:u0024, D22:p0031:u0025, D22:p0031:u0026, D22:p0031:u0027, D22:p0031:u0028, D22:p0031:u0029, D22:p0031:u0030, D22:p0031:u0031, D22:p0031:u0032, D22:p0031:u0033, D22:p0031:u0034, D22:p0031:u0035, D22:p0031:u0036, D22:p0031:u0037, D22:p0031:u0038, D22:p0031:u0039, D22:p0031:u0040, D22:p0031:u0041, D22:p0031:u0042, D22:p0031:u0043
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
10 42
52
38 34
72
48 30
78
20 38
58
24 28
52
34 24
58
44 20
64
38 34
72
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58 – NEW
OPEN:
(0,1) – 58
(1,1) – ∞
(2,0) – 58
(3,1) – ∞
(3,2) – ∞
(3,0) – 72
(1,2) – 72
(2,3) – 64 – NEW
(1,3) – 78 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=32`
Строки (ID элементов): D22:p0032:u0001, D22:p0032:u0002, D22:p0032:u0003, D22:p0032:u0004, D22:p0032:u0005, D22:p0032:u0006, D22:p0032:u0007, D22:p0032:u0008, D22:p0032:u0009, D22:p0032:u0010, D22:p0032:u0011, D22:p0032:u0012, D22:p0032:u0013, D22:p0032:u0014, D22:p0032:u0015, D22:p0032:u0016, D22:p0032:u0017, D22:p0032:u0018, D22:p0032:u0019, D22:p0032:u0020, D22:p0032:u0023, D22:p0032:u0024, D22:p0032:u0025, D22:p0032:u0026, D22:p0032:u0027, D22:p0032:u0028, D22:p0032:u0029, D22:p0032:u0030, D22:p0032:u0031, D22:p0032:u0032, D22:p0032:u0033, D22:p0032:u0034, D22:p0032:u0035, D22:p0032:u0036, D22:p0032:u0037, D22:p0032:u0038, D22:p0032:u0039, D22:p0032:u0040, D22:p0032:u0041, D22:p0032:u0042, D22:p0032:u0043
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
10 42
52
38 34
72
48 30
78
20 38
58
24 28
52
34 24
58
44 20
64
30 34
64
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58 - NEW
OPEN:
(0,1) – 58
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(3,0) – 64 – UPD
(1,2) – 72
(2,3) – 64
(1,3) – 78
````

## D22 — Week 6 Lecture.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=33`
Строки (ID элементов): D22:p0033:u0001, D22:p0033:u0002, D22:p0033:u0003, D22:p0033:u0004, D22:p0033:u0005, D22:p0033:u0006, D22:p0033:u0007, D22:p0033:u0008, D22:p0033:u0009, D22:p0033:u0010, D22:p0033:u0011, D22:p0033:u0012, D22:p0033:u0013, D22:p0033:u0014, D22:p0033:u0015, D22:p0033:u0016, D22:p0033:u0017, D22:p0033:u0018, D22:p0033:u0019, D22:p0033:u0020, D22:p0033:u0021, D22:p0033:u0022, D22:p0033:u0025, D22:p0033:u0026, D22:p0033:u0027, D22:p0033:u0028, D22:p0033:u0029, D22:p0033:u0030, D22:p0033:u0031, D22:p0033:u0032, D22:p0033:u0033, D22:p0033:u0034, D22:p0033:u0035, D22:p0033:u0036, D22:p0033:u0037, D22:p0033:u0038, D22:p0033:u0039, D22:p0033:u0040, D22:p0033:u0041, D22:p0033:u0042, D22:p0033:u0043, D22:p0033:u0044, D22:p0033:u0045, D22:p0033:u0046
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
10 42
52
24 34
58
48 30
78
20 38
58
24 28
52
34 24
58
44 20
64
30 34
64
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58 – NEW
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(3,0) – 64
(1,2) – 58 – UPD
(2,3) – 64
(1,3) – 78
(0,2) – 64 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=34`
Строки (ID элементов): D22:p0034:u0001, D22:p0034:u0002, D22:p0034:u0003, D22:p0034:u0004, D22:p0034:u0005, D22:p0034:u0006, D22:p0034:u0007, D22:p0034:u0008, D22:p0034:u0009, D22:p0034:u0010, D22:p0034:u0011, D22:p0034:u0012, D22:p0034:u0013, D22:p0034:u0014, D22:p0034:u0015, D22:p0034:u0016, D22:p0034:u0017, D22:p0034:u0018, D22:p0034:u0019, D22:p0034:u0020, D22:p0034:u0021, D22:p0034:u0022, D22:p0034:u0023, D22:p0034:u0024, D22:p0034:u0027, D22:p0034:u0028, D22:p0034:u0029, D22:p0034:u0030, D22:p0034:u0031, D22:p0034:u0032, D22:p0034:u0033, D22:p0034:u0034, D22:p0034:u0035, D22:p0034:u0036, D22:p0034:u0037, D22:p0034:u0038, D22:p0034:u0039, D22:p0034:u0040, D22:p0034:u0041, D22:p0034:u0042, D22:p0034:u0043, D22:p0034:u0044, D22:p0034:u0045, D22:p0034:u0046, D22:p0034:u0047, D22:p0034:u0048, D22:p0034:u0049
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
38 40
78
10 42
52
24 34
58
34 30
64
20 38
58
24 28
52
34 24
58
38 20
58
30 34
64
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58 – NEW
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(3,0) – 64
(2,3) – 58 – UPD
(1,3) – 64 – UPD
(0,2) – 64
(0,3) – 78 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=35`
Строки (ID элементов): D22:p0035:u0001, D22:p0035:u0002, D22:p0035:u0003, D22:p0035:u0004, D22:p0035:u0005, D22:p0035:u0006, D22:p0035:u0007, D22:p0035:u0008, D22:p0035:u0009, D22:p0035:u0010, D22:p0035:u0011, D22:p0035:u0012, D22:p0035:u0013, D22:p0035:u0014, D22:p0035:u0015, D22:p0035:u0016, D22:p0035:u0017, D22:p0035:u0018, D22:p0035:u0019, D22:p0035:u0020, D22:p0035:u0021, D22:p0035:u0022, D22:p0035:u0023, D22:p0035:u0024, D22:p0035:u0025, D22:p0035:u0026, D22:p0035:u0027, D22:p0035:u0028, D22:p0035:u0029, D22:p0035:u0030, D22:p0035:u0033, D22:p0035:u0034, D22:p0035:u0035, D22:p0035:u0036, D22:p0035:u0037, D22:p0035:u0038, D22:p0035:u0039, D22:p0035:u0040, D22:p0035:u0041, D22:p0035:u0042, D22:p0035:u0043, D22:p0035:u0044, D22:p0035:u0045, D22:p0035:u0046, D22:p0035:u0047, D22:p0035:u0048, D22:p0035:u0049, D22:p0035:u0050, D22:p0035:u0051, D22:p0035:u0052, D22:p0035:u0053, D22:p0035:u0054, D22:p0035:u0055, D22:p0035:u0056, D22:p0035:u0057, D22:p0035:u0058
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
38 40
78
10 42
52
24 34
58
34 30
64
52 34
86
20 38
58
24 28
52
34 24
58
38 20
58
48 24
72
30 34
64
52 14
66
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(3,0) – 64
(1,3) – 64
(0,2) – 64
(0,3) – 78
(1,4) – 86 – NEW
(2,3) – 58 – NEW
(2,4) – 72 – NEW
(3,4) – 66 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=36`
Строки (ID элементов): D22:p0036:u0001, D22:p0036:u0002, D22:p0036:u0003, D22:p0036:u0004, D22:p0036:u0005, D22:p0036:u0006, D22:p0036:u0007, D22:p0036:u0008, D22:p0036:u0009, D22:p0036:u0010, D22:p0036:u0011, D22:p0036:u0012, D22:p0036:u0013, D22:p0036:u0014, D22:p0036:u0015, D22:p0036:u0016, D22:p0036:u0017, D22:p0036:u0018, D22:p0036:u0019, D22:p0036:u0020, D22:p0036:u0021, D22:p0036:u0022, D22:p0036:u0023, D22:p0036:u0024, D22:p0036:u0025, D22:p0036:u0026, D22:p0036:u0027, D22:p0036:u0028, D22:p0036:u0029, D22:p0036:u0030, D22:p0036:u0033, D22:p0036:u0034, D22:p0036:u0035, D22:p0036:u0036, D22:p0036:u0037, D22:p0036:u0038, D22:p0036:u0039, D22:p0036:u0040, D22:p0036:u0041, D22:p0036:u0042, D22:p0036:u0043, D22:p0036:u0044, D22:p0036:u0045, D22:p0036:u0046, D22:p0036:u0047, D22:p0036:u0048, D22:p0036:u0049, D22:p0036:u0050, D22:p0036:u0051, D22:p0036:u0052, D22:p0036:u0053, D22:p0036:u0054, D22:p0036:u0055, D22:p0036:u0056, D22:p0036:u0057, D22:p0036:u0058
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
38 40
78
10 42
52
24 34
58
34 30
64
52 34
86
20 38
58
24 28
52
34 24
58
38 20
58
48 24
72
30 34
64
52 14
66
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(3,0) – 64
(1,3) – 64
(0,2) – 64
(0,3) – 78
(1,4) – 86 – NEW
(2,3) – 58 – NEW
(2,4) – 72 – NEW
(3,4) – 66 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 37
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=37`
Строки (ID элементов): D22:p0037:u0001, D22:p0037:u0002, D22:p0037:u0003, D22:p0037:u0004, D22:p0037:u0005, D22:p0037:u0006, D22:p0037:u0007, D22:p0037:u0008, D22:p0037:u0009, D22:p0037:u0010, D22:p0037:u0011, D22:p0037:u0012, D22:p0037:u0013, D22:p0037:u0014, D22:p0037:u0015, D22:p0037:u0016, D22:p0037:u0017, D22:p0037:u0018, D22:p0037:u0019, D22:p0037:u0020, D22:p0037:u0021, D22:p0037:u0022, D22:p0037:u0023, D22:p0037:u0024, D22:p0037:u0025, D22:p0037:u0026, D22:p0037:u0027, D22:p0037:u0028, D22:p0037:u0029, D22:p0037:u0030, D22:p0037:u0031, D22:p0037:u0032, D22:p0037:u0035, D22:p0037:u0036, D22:p0037:u0037, D22:p0037:u0038, D22:p0037:u0039, D22:p0037:u0040, D22:p0037:u0041, D22:p0037:u0042, D22:p0037:u0043, D22:p0037:u0044, D22:p0037:u0045, D22:p0037:u0046, D22:p0037:u0047, D22:p0037:u0048, D22:p0037:u0049, D22:p0037:u0050, D22:p0037:u0051, D22:p0037:u0052, D22:p0037:u0053, D22:p0037:u0054, D22:p0037:u0055, D22:p0037:u0056, D22:p0037:u0057, D22:p0037:u0058, D22:p0037:u0059, D22:p0037:u0060, D22:p0037:u0061
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
38 40
78
48 44
92
10 42
52
24 34
58
34 30
64
44 34
78
20 38
58
24 28
52
34 24
58
38 20
58
48 24
72
30 34
64
52 14
66
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(3,0) – 64
(0,2) – 64
(0,3) – 78
(1,4) – 78 – UPD
(2,4) – 72
(2,3) – 58
(1,3) – 64 – NEW
(3,4) – 66
(0,4) – 92 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 38
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=38`
Строки (ID элементов): D22:p0038:u0001, D22:p0038:u0002, D22:p0038:u0003, D22:p0038:u0004, D22:p0038:u0005, D22:p0038:u0006, D22:p0038:u0007, D22:p0038:u0008, D22:p0038:u0009, D22:p0038:u0010, D22:p0038:u0011, D22:p0038:u0012, D22:p0038:u0013, D22:p0038:u0014, D22:p0038:u0015, D22:p0038:u0016, D22:p0038:u0017, D22:p0038:u0018, D22:p0038:u0019, D22:p0038:u0020, D22:p0038:u0021, D22:p0038:u0022, D22:p0038:u0023, D22:p0038:u0024, D22:p0038:u0025, D22:p0038:u0026, D22:p0038:u0027, D22:p0038:u0028, D22:p0038:u0029, D22:p0038:u0030, D22:p0038:u0031, D22:p0038:u0032, D22:p0038:u0035, D22:p0038:u0036, D22:p0038:u0037, D22:p0038:u0038, D22:p0038:u0039, D22:p0038:u0040, D22:p0038:u0041, D22:p0038:u0042, D22:p0038:u0043, D22:p0038:u0044, D22:p0038:u0045, D22:p0038:u0046, D22:p0038:u0047, D22:p0038:u0048, D22:p0038:u0049, D22:p0038:u0050, D22:p0038:u0051, D22:p0038:u0052, D22:p0038:u0053, D22:p0038:u0054, D22:p0038:u0055, D22:p0038:u0056, D22:p0038:u0057, D22:p0038:u0058, D22:p0038:u0059, D22:p0038:u0060, D22:p0038:u0061
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
38 40
78
48 44
92
10 42
52
24 34
58
34 30
64
44 34
78
20 38
58
24 28
52
34 24
58
38 20
58
48 24
72
30 34
64
52 14
66
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(3,0) – 64
(0,2) – 64
(0,3) – 78
(1,4) – 78 – UPD
(2,4) – 72
(2,3) – 58
(1,3) – 64 – NEW
(3,4) – 66
(0,4) – 92 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 39
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=39`
Строки (ID элементов): D22:p0039:u0001, D22:p0039:u0002, D22:p0039:u0003, D22:p0039:u0004, D22:p0039:u0005, D22:p0039:u0006, D22:p0039:u0007, D22:p0039:u0008, D22:p0039:u0009, D22:p0039:u0010, D22:p0039:u0011, D22:p0039:u0012, D22:p0039:u0013, D22:p0039:u0014, D22:p0039:u0015, D22:p0039:u0016, D22:p0039:u0017, D22:p0039:u0018, D22:p0039:u0019, D22:p0039:u0020, D22:p0039:u0021, D22:p0039:u0022, D22:p0039:u0023, D22:p0039:u0024, D22:p0039:u0025, D22:p0039:u0026, D22:p0039:u0027, D22:p0039:u0028, D22:p0039:u0029, D22:p0039:u0030, D22:p0039:u0031, D22:p0039:u0032, D22:p0039:u0033, D22:p0039:u0034, D22:p0039:u0035, D22:p0039:u0036, D22:p0039:u0039, D22:p0039:u0040, D22:p0039:u0041, D22:p0039:u0042, D22:p0039:u0043, D22:p0039:u0044, D22:p0039:u0045, D22:p0039:u0046, D22:p0039:u0047, D22:p0039:u0048, D22:p0039:u0049, D22:p0039:u0050, D22:p0039:u0051, D22:p0039:u0052, D22:p0039:u0053, D22:p0039:u0054, D22:p0039:u0055, D22:p0039:u0056, D22:p0039:u0057, D22:p0039:u0058, D22:p0039:u0059, D22:p0039:u0060, D22:p0039:u0061, D22:p0039:u0062, D22:p0039:u0063, D22:p0039:u0064, D22:p0039:u0065, D22:p0039:u0066, D22:p0039:u0067
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
38 40
78
48 44
92
10 42
52
24 34
58
34 30
64
44 34
78
20 38
58
24 28
52
34 24
58
38 20
58
48 24
72
30 34
64
52 14
66
40 30
70
44 20
64
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(0,2) – 64
(0,3) – 78
(1,4) – 78
(2,4) – 72
(3,4) – 66
(2,3) – 58
(1,3) – 64
(3,0) – 64 – NEW
(0,4) – 92
(4,0) – 70 – NEW
(4,1) – 64 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 40
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=40`
Строки (ID элементов): D22:p0040:u0001, D22:p0040:u0002, D22:p0040:u0003, D22:p0040:u0004, D22:p0040:u0005, D22:p0040:u0006, D22:p0040:u0007, D22:p0040:u0008, D22:p0040:u0009, D22:p0040:u0010, D22:p0040:u0011, D22:p0040:u0012, D22:p0040:u0013, D22:p0040:u0014, D22:p0040:u0015, D22:p0040:u0016, D22:p0040:u0017, D22:p0040:u0018, D22:p0040:u0019, D22:p0040:u0020, D22:p0040:u0021, D22:p0040:u0022, D22:p0040:u0023, D22:p0040:u0024, D22:p0040:u0025, D22:p0040:u0026, D22:p0040:u0027, D22:p0040:u0028, D22:p0040:u0029, D22:p0040:u0030, D22:p0040:u0031, D22:p0040:u0032, D22:p0040:u0033, D22:p0040:u0034, D22:p0040:u0035, D22:p0040:u0036, D22:p0040:u0039, D22:p0040:u0040, D22:p0040:u0041, D22:p0040:u0042, D22:p0040:u0043, D22:p0040:u0044, D22:p0040:u0045, D22:p0040:u0046, D22:p0040:u0047, D22:p0040:u0048, D22:p0040:u0049, D22:p0040:u0050, D22:p0040:u0051, D22:p0040:u0052, D22:p0040:u0053, D22:p0040:u0054, D22:p0040:u0055, D22:p0040:u0056, D22:p0040:u0057, D22:p0040:u0058, D22:p0040:u0059, D22:p0040:u0060, D22:p0040:u0061, D22:p0040:u0062, D22:p0040:u0063, D22:p0040:u0064, D22:p0040:u0065, D22:p0040:u0066, D22:p0040:u0067
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
38 40
78
48 44
92
10 42
52
24 34
58
34 30
64
44 34
78
20 38
58
24 28
52
34 24
58
38 20
58
48 24
72
30 34
64
52 14
66
40 30
70
44 20
64
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(0,2) – 64
(0,3) – 78
(1,4) – 78
(2,4) – 72
(3,4) – 66
(2,3) – 58
(1,3) – 64
(3,0) – 64 – NEW
(0,4) – 92
(4,0) – 70 – NEW
(4,1) – 64 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 41
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=41`
Строки (ID элементов): D22:p0041:u0001, D22:p0041:u0002, D22:p0041:u0003, D22:p0041:u0004, D22:p0041:u0005, D22:p0041:u0006, D22:p0041:u0007, D22:p0041:u0008, D22:p0041:u0009, D22:p0041:u0010, D22:p0041:u0011, D22:p0041:u0012, D22:p0041:u0013, D22:p0041:u0014, D22:p0041:u0015, D22:p0041:u0016, D22:p0041:u0017, D22:p0041:u0018, D22:p0041:u0019, D22:p0041:u0020, D22:p0041:u0021, D22:p0041:u0022, D22:p0041:u0023, D22:p0041:u0024, D22:p0041:u0025, D22:p0041:u0026, D22:p0041:u0027, D22:p0041:u0028, D22:p0041:u0029, D22:p0041:u0030, D22:p0041:u0031, D22:p0041:u0032, D22:p0041:u0033, D22:p0041:u0034, D22:p0041:u0035, D22:p0041:u0036, D22:p0041:u0037, D22:p0041:u0038, D22:p0041:u0041, D22:p0041:u0042, D22:p0041:u0043, D22:p0041:u0044, D22:p0041:u0045, D22:p0041:u0046, D22:p0041:u0047, D22:p0041:u0048, D22:p0041:u0049, D22:p0041:u0050, D22:p0041:u0051, D22:p0041:u0052, D22:p0041:u0053, D22:p0041:u0054, D22:p0041:u0055, D22:p0041:u0056, D22:p0041:u0057, D22:p0041:u0058, D22:p0041:u0059, D22:p0041:u0060, D22:p0041:u0061, D22:p0041:u0062, D22:p0041:u0063, D22:p0041:u0064, D22:p0041:u0065, D22:p0041:u0066, D22:p0041:u0067, D22:p0041:u0068, D22:p0041:u0069, D22:p0041:u0070
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
38 40
78
48 44
92
10 42
52
24 34
58
34 30
64
44 34
78
20 38
58
24 28
52
34 24
58
38 20
58
48 24
72
30 34
64
52 14
66
40 30
70
44 20
64
54 10
64
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(0,2) – 64
(0,3) – 78
(1,4) – 78
(2,4) – 72
(3,4) – 66
(2,3) – 58
(1,3) – 64
(3,0) – 64
(4,1) – 64 – NEW
(0,4) – 92
(4,0) – 70
(4,2) – 64 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 42
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=42`
Строки (ID элементов): D22:p0042:u0001, D22:p0042:u0002, D22:p0042:u0003, D22:p0042:u0004, D22:p0042:u0005, D22:p0042:u0006, D22:p0042:u0007, D22:p0042:u0008, D22:p0042:u0009, D22:p0042:u0010, D22:p0042:u0011, D22:p0042:u0012, D22:p0042:u0013, D22:p0042:u0014, D22:p0042:u0015, D22:p0042:u0016, D22:p0042:u0017, D22:p0042:u0018, D22:p0042:u0019, D22:p0042:u0020, D22:p0042:u0021, D22:p0042:u0022, D22:p0042:u0023, D22:p0042:u0024, D22:p0042:u0025, D22:p0042:u0026, D22:p0042:u0027, D22:p0042:u0028, D22:p0042:u0029, D22:p0042:u0030, D22:p0042:u0031, D22:p0042:u0032, D22:p0042:u0033, D22:p0042:u0034, D22:p0042:u0035, D22:p0042:u0036, D22:p0042:u0037, D22:p0042:u0038, D22:p0042:u0041, D22:p0042:u0042, D22:p0042:u0043, D22:p0042:u0044, D22:p0042:u0045, D22:p0042:u0046, D22:p0042:u0047, D22:p0042:u0048, D22:p0042:u0049, D22:p0042:u0050, D22:p0042:u0051, D22:p0042:u0052, D22:p0042:u0053, D22:p0042:u0054, D22:p0042:u0055, D22:p0042:u0056, D22:p0042:u0057, D22:p0042:u0058, D22:p0042:u0059, D22:p0042:u0060, D22:p0042:u0061, D22:p0042:u0062, D22:p0042:u0063, D22:p0042:u0064, D22:p0042:u0065, D22:p0042:u0066, D22:p0042:u0067, D22:p0042:u0068, D22:p0042:u0069, D22:p0042:u0070
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
38 40
78
48 44
92
10 42
52
24 34
58
34 30
64
44 34
78
20 38
58
24 28
52
34 24
58
38 20
58
48 24
72
30 34
64
52 14
66
40 30
70
44 20
64
54 10
64
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(0,2) – 64
(0,3) – 78
(1,4) – 78
(2,4) – 72
(3,4) – 66
(2,3) – 58
(1,3) – 64
(3,0) – 64
(4,1) – 64 – NEW
(0,4) – 92
(4,0) – 70
(4,2) – 64 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 43
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=43`
Строки (ID элементов): D22:p0043:u0001, D22:p0043:u0002, D22:p0043:u0003, D22:p0043:u0004, D22:p0043:u0005, D22:p0043:u0006, D22:p0043:u0007, D22:p0043:u0008, D22:p0043:u0009, D22:p0043:u0010, D22:p0043:u0011, D22:p0043:u0012, D22:p0043:u0013, D22:p0043:u0014, D22:p0043:u0015, D22:p0043:u0016, D22:p0043:u0017, D22:p0043:u0018, D22:p0043:u0019, D22:p0043:u0020, D22:p0043:u0021, D22:p0043:u0022, D22:p0043:u0023, D22:p0043:u0024, D22:p0043:u0025, D22:p0043:u0026, D22:p0043:u0027, D22:p0043:u0028, D22:p0043:u0029, D22:p0043:u0030, D22:p0043:u0031, D22:p0043:u0032, D22:p0043:u0033, D22:p0043:u0034, D22:p0043:u0035, D22:p0043:u0036, D22:p0043:u0037, D22:p0043:u0038, D22:p0043:u0039, D22:p0043:u0040, D22:p0043:u0043, D22:p0043:u0044, D22:p0043:u0045, D22:p0043:u0046, D22:p0043:u0047, D22:p0043:u0048, D22:p0043:u0049, D22:p0043:u0050, D22:p0043:u0051, D22:p0043:u0052, D22:p0043:u0053, D22:p0043:u0054, D22:p0043:u0055, D22:p0043:u0056, D22:p0043:u0057, D22:p0043:u0058, D22:p0043:u0059, D22:p0043:u0060, D22:p0043:u0061, D22:p0043:u0062, D22:p0043:u0063, D22:p0043:u0064, D22:p0043:u0065, D22:p0043:u0066, D22:p0043:u0067, D22:p0043:u0068, D22:p0043:u0069, D22:p0043:u0070, D22:p0043:u0071, D22:p0043:u0072, D22:p0043:u0073
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
38 40
78
48 44
92
10 42
52
24 34
58
34 30
64
44 34
78
20 38
58
24 28
52
34 24
58
38 20
58
48 24
72
30 34
64
52 14
66
40 30
70
44 20
64
54 10
64
64 0
64
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(0,2) – 64
(0,3) – 78
(1,4) – 78
(2,4) – 72
(3,4) – 66
(2,3) – 58
(1,3) – 64
(3,0) – 64
(4,1) – 64
(4,2) – 64 – NEW
(0,4) – 92
(4,0) – 70
(4,3) – 64 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 44
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=44`
Строки (ID элементов): D22:p0044:u0001, D22:p0044:u0002, D22:p0044:u0003, D22:p0044:u0004, D22:p0044:u0005, D22:p0044:u0006, D22:p0044:u0007, D22:p0044:u0008, D22:p0044:u0009, D22:p0044:u0010, D22:p0044:u0011, D22:p0044:u0012, D22:p0044:u0013, D22:p0044:u0014, D22:p0044:u0015, D22:p0044:u0016, D22:p0044:u0017, D22:p0044:u0018, D22:p0044:u0019, D22:p0044:u0020, D22:p0044:u0021, D22:p0044:u0022, D22:p0044:u0023, D22:p0044:u0024, D22:p0044:u0025, D22:p0044:u0026, D22:p0044:u0027, D22:p0044:u0028, D22:p0044:u0029, D22:p0044:u0030, D22:p0044:u0031, D22:p0044:u0032, D22:p0044:u0033, D22:p0044:u0034, D22:p0044:u0035, D22:p0044:u0036, D22:p0044:u0037, D22:p0044:u0038, D22:p0044:u0039, D22:p0044:u0040, D22:p0044:u0043, D22:p0044:u0044, D22:p0044:u0045, D22:p0044:u0046, D22:p0044:u0047, D22:p0044:u0048, D22:p0044:u0049, D22:p0044:u0050, D22:p0044:u0051, D22:p0044:u0052, D22:p0044:u0053, D22:p0044:u0054, D22:p0044:u0055, D22:p0044:u0056, D22:p0044:u0057, D22:p0044:u0058, D22:p0044:u0059, D22:p0044:u0060, D22:p0044:u0061, D22:p0044:u0062, D22:p0044:u0063, D22:p0044:u0064, D22:p0044:u0065, D22:p0044:u0066, D22:p0044:u0067, D22:p0044:u0068, D22:p0044:u0069, D22:p0044:u0070, D22:p0044:u0071, D22:p0044:u0072, D22:p0044:u0073
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
38 40
78
48 44
92
10 42
52
24 34
58
34 30
64
44 34
78
20 38
58
24 28
52
34 24
58
38 20
58
48 24
72
30 34
64
52 14
66
40 30
70
44 20
64
54 10
64
64 0
64
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(0,2) – 64
(0,3) – 78
(1,4) – 78
(2,4) – 72
(3,4) – 66
(2,3) – 58
(1,3) – 64
(3,0) – 64
(4,1) – 64
(4,2) – 64 – NEW
(0,4) – 92
(4,0) – 70
(4,3) – 64 – NEW
````

## D22 — Week 6 Lecture.pdf, PDF-страница 45
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=45`
Строки (ID элементов): D22:p0045:u0001, D22:p0045:u0002, D22:p0045:u0003, D22:p0045:u0004, D22:p0045:u0005, D22:p0045:u0006, D22:p0045:u0007, D22:p0045:u0008, D22:p0045:u0009, D22:p0045:u0010, D22:p0045:u0011, D22:p0045:u0012, D22:p0045:u0013, D22:p0045:u0014, D22:p0045:u0015, D22:p0045:u0016, D22:p0045:u0017, D22:p0045:u0018, D22:p0045:u0019, D22:p0045:u0020, D22:p0045:u0021, D22:p0045:u0022, D22:p0045:u0023, D22:p0045:u0024, D22:p0045:u0025, D22:p0045:u0026, D22:p0045:u0027, D22:p0045:u0028, D22:p0045:u0029, D22:p0045:u0030, D22:p0045:u0031, D22:p0045:u0032, D22:p0045:u0033, D22:p0045:u0034, D22:p0045:u0035, D22:p0045:u0036, D22:p0045:u0037, D22:p0045:u0038, D22:p0045:u0039, D22:p0045:u0040, D22:p0045:u0043, D22:p0045:u0044, D22:p0045:u0045, D22:p0045:u0046, D22:p0045:u0047, D22:p0045:u0048, D22:p0045:u0049, D22:p0045:u0050, D22:p0045:u0051, D22:p0045:u0052, D22:p0045:u0053, D22:p0045:u0054, D22:p0045:u0055, D22:p0045:u0056, D22:p0045:u0057, D22:p0045:u0058, D22:p0045:u0059, D22:p0045:u0060, D22:p0045:u0061, D22:p0045:u0062, D22:p0045:u0063, D22:p0045:u0064, D22:p0045:u0065, D22:p0045:u0066, D22:p0045:u0067, D22:p0045:u0068, D22:p0045:u0069, D22:p0045:u0070, D22:p0045:u0071, D22:p0045:u0072, D22:p0045:u0073
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Move Lowest Cost to Closed with Smaller Heuristics and
Search Neighbours
10 48
58
20 44
64
38 40
78
48 44
92
10 42
52
24 34
58
34 30
64
44 34
78
20 38
58
24 28
52
34 24
58
38 20
58
48 24
72
30 34
64
52 14
66
40 30
70
44 20
64
54 10
64
64 0
64
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(0,2) – 64
(0,3) – 78
(1,4) – 78
(2,4) – 72
(3,4) – 66
(2,3) – 58
(1,3) – 64
(3,0) – 64
(4,1) – 64
(4,2) – 64
(4,3) – 64 – AIM
(0,4) – 92
(4,0) – 70
````

## D22 — Week 6 Lecture.pdf, PDF-страница 46
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=46`
Строки (ID элементов): D22:p0046:u0001, D22:p0046:u0002, D22:p0046:u0003, D22:p0046:u0004, D22:p0046:u0005, D22:p0046:u0006, D22:p0046:u0007, D22:p0046:u0008, D22:p0046:u0009, D22:p0046:u0010, D22:p0046:u0011, D22:p0046:u0012, D22:p0046:u0013, D22:p0046:u0014, D22:p0046:u0015, D22:p0046:u0016, D22:p0046:u0017, D22:p0046:u0018, D22:p0046:u0019, D22:p0046:u0020, D22:p0046:u0021, D22:p0046:u0022, D22:p0046:u0023, D22:p0046:u0024, D22:p0046:u0025, D22:p0046:u0026, D22:p0046:u0027, D22:p0046:u0028, D22:p0046:u0029, D22:p0046:u0030, D22:p0046:u0031, D22:p0046:u0032, D22:p0046:u0033, D22:p0046:u0034, D22:p0046:u0035, D22:p0046:u0036, D22:p0046:u0037, D22:p0046:u0038, D22:p0046:u0039, D22:p0046:u0042, D22:p0046:u0043, D22:p0046:u0044, D22:p0046:u0045, D22:p0046:u0046, D22:p0046:u0047, D22:p0046:u0048, D22:p0046:u0049, D22:p0046:u0050, D22:p0046:u0051, D22:p0046:u0052, D22:p0046:u0053, D22:p0046:u0054, D22:p0046:u0055, D22:p0046:u0056, D22:p0046:u0057, D22:p0046:u0058, D22:p0046:u0059, D22:p0046:u0060, D22:p0046:u0061, D22:p0046:u0062, D22:p0046:u0063, D22:p0046:u0064, D22:p0046:u0065, D22:p0046:u0066, D22:p0046:u0067, D22:p0046:u0068, D22:p0046:u0069, D22:p0046:u0070, D22:p0046:u0071, D22:p0046:u0072
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Goal is Found
10 48
58
20 44
64
38 40
78
48 44
92
10 42
52
24 34
58
34 30
64
44 34
78
20 38
58
24 28
52
34 24
58
38 20
58
48 24
72
30 34
64
52 14
66
40 30
70
44 20
64
54 10
64
64 0
64
0
1
2
3
4
0                 1                  2                 3                4
CLOSED:
(0,0) – 0
(1,0) – 52
(2,1) – 52
(2,2) – 58
(2,0) – 58
(0,1) – 58
(1,2) – 58
OPEN:
(1,1) – ∞
(3,1) – ∞
(3,2) – ∞
(0,2) – 64
(0,3) – 78
(1,4) – 78
(2,4) – 72
(3,4) – 66
(2,3) – 58
(1,3) – 64
(3,0) – 64
(4,1) – 64
(4,2) – 64
(4,3) – 64 – AIM
(0,4) – 92
(4,0) – 70
````

## D22 — Week 6 Lecture.pdf, PDF-страница 47
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=47`
Строки (ID элементов): D22:p0047:u0001, D22:p0047:u0002, D22:p0047:u0003, D22:p0047:u0004, D22:p0047:u0005, D22:p0047:u0006, D22:p0047:u0007, D22:p0047:u0008, D22:p0047:u0009, D22:p0047:u0010, D22:p0047:u0011, D22:p0047:u0012

````text
Improvements of A*
- Dealing with other units
- Treat stopped units as unpassable
- Treat moving units nearby as unpassable
- More complexity – prediction of their movement for avoidance – query their
path
- Cost of movement
- Taken into account in the cost function
- Non-grid setting
- Open World
- Enforce a grid or graph
- Develop pathways explicitly for longer movements
````


---

# AI-04-18 — Модель соседства на сетке для поиска пути

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Сравни допустимые ходы и эвристики для окрестностей Мура и фон Неймана.
**Пункты РПД:** —

**Связанные страницы:** 5; **символов извлечённого текста:** 880.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=21`
Строки (ID элементов): D21:p0021:u0001
**Общая страница с:** AI-04-17

````text
Moore Neighbourhood Algorithm Range 1
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=22`
Строки (ID элементов): D21:p0022:u0001, D21:p0022:u0003, D21:p0022:u0004, D21:p0022:u0005, D21:p0022:u0007, D21:p0022:u0008, D21:p0022:u0010, D21:p0022:u0011
**Общая страница с:** AI-04-17

````text
Moore Neighbourhood Algorithm
Using Moore Neighbourhood algorithm, the agent (the prince in our
example) can check all 8 cells of his immediate neighbourhood
(exploring the environment around him).
If any of these cells contain an obstacle such as the stepmom or stepsisters,
the prince will be aware of them.
Based on this perception, the prince can decide how to move in order to
avoid coming into a cell containing an obstacle.
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=23`
Строки (ID элементов): D21:p0023:u0001
**Общая страница с:** AI-04-17
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Von Neumann vs Moore Range 1
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=24`
Строки (ID элементов): D21:p0024:u0001, D21:p0024:u0004, D21:p0024:u0005
**Общая страница с:** AI-04-17
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Moore Neighbourhood Ranges
Moore neighbourhoods for ranges r = 0, 1, 2, and 3 are illustrated above. The number of
cells in the Moore neighbourhood of range r is (2r+1)^2, the square of odd number
````

## D21 — Week 6 Lab 5 (without solution).pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/21_Week 6 Lab 5 (without solution)/source.pdf#page=25`
Строки (ID элементов): D21:p0025:u0001, D21:p0025:u0004, D21:p0025:u0005
**Общая страница с:** AI-04-17
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Von Neumann Neighbourhood Ranges
Von Neumann neighbourhoods for ranges r = 0, 1, 2, and 3 are illustrated above. The number of
cells in the von Neumann neighbourhood of range r is 2r(r+1)+1
````


---

# AI-04-19 — Табу-поиск и запрещённые ходы

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Пройди несколько итераций tabu search и объясни роль tabu list.
**Пункты РПД:** RPD-21

**Связанные страницы:** 18; **символов извлечённого текста:** 5915.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D22 — Week 6 Lecture.pdf, PDF-страница 48
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=48`
Строки (ID элементов): D22:p0048:u0001, D22:p0048:u0002, D22:p0048:u0003, D22:p0048:u0004, D22:p0048:u0005, D22:p0048:u0006, D22:p0048:u0007, D22:p0048:u0008, D22:p0048:u0009

````text
Tabu Search
- Created by Fred Glover in 1986
- Idea coming from a social tabu – never return to where I once was
- Heuristic – where I have been is not where I want to go
- Search is conducted by single point changes in the candidate solution with
a list of previous places that the search was at, a Tabu List
- The tabus are feature sets of the parameters
- Searches locally, then places the locality on the tabu areas of the search –
forcing it to move away
````

## D22 — Week 6 Lecture.pdf, PDF-страница 49
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=49`
Строки (ID элементов): D22:p0049:u0001, D22:p0049:u0002, D22:p0049:u0003, D22:p0049:u0004, D22:p0049:u0005, D22:p0049:u0006, D22:p0049:u0007, D22:p0049:u0008, D22:p0049:u0009, D22:p0049:u0010
**Общая страница с:** AI-04-20

````text
Tabu Tenure and Aspiration Criterion
- Tabu tenure is the number of iterations, during which tabu is considered
- A memory for the last actions not be reverted back for some iterations
- Chosen by programmer
- Aspiration criterion allows for potential solutions with tabu and better than
best found to skip the tabu
- This sets tabu tenure to max value, does not matter how small or big it was before
- Can consider only significant difference to break the tabu
- Stopping criterion for algorithm is usually the attempt limit or a score
threshold
````

## D22 — Week 6 Lecture.pdf, PDF-страница 50
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=50`
Строки (ID элементов): D22:p0050:u0001, D22:p0050:u0002, D22:p0050:u0003, D22:p0050:u0004, D22:p0050:u0005, D22:p0050:u0006, D22:p0050:u0007, D22:p0050:u0008
**Общая страница с:** AI-04-20

````text
Tabu Advantages and Disadvantages
- Advantages:
- Accepts non-improving solutions to escape from local optimum
- Can be applied to both discrete and continuous solution spaces
- Disadvantages:
- Too many parameters to be determined
- Number of iterations may be very large
- Global optimum is not guaranteed to be found
````

## D22 — Week 6 Lecture.pdf, PDF-страница 51
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=51`
Строки (ID элементов): D22:p0051:u0001, D22:p0051:u0002, D22:p0051:u0003, D22:p0051:u0004, D22:p0051:u0005, D22:p0051:u0006, D22:p0051:u0007, D22:p0051:u0008, D22:p0051:u0009, D22:p0051:u0010, D22:p0051:u0011, D22:p0051:u0012, D22:p0051:u0013, D22:p0051:u0014, D22:p0051:u0015, D22:p0051:u0016, D22:p0051:u0017
**Общая страница с:** AI-04-20

````text
Tabu Loop
- 
Set a current position, set best to this position, set a tabu list to null
- 
While not at a stopping condition
- Create a candidate list from neighbours
- Check if the candidates are on the tabu list. If they are, remove them, if aspiration criterion is
not satisfied
- Find the best candidate
- Move to this as current position
- Test the best candidate against the best
- If it is the new best – replace
- Create a tabu by looking at the differences in the features between this new best and the previous
best
- Produce a tabu restriction based on this difference
- Add this tabu to the tabu list
- Check tabu list length and remove old tabus based on tabu tenure
````

## D22 — Week 6 Lecture.pdf, PDF-страница 52
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=52`
Строки (ID элементов): D22:p0052:u0001, D22:p0052:u0002, D22:p0052:u0003, D22:p0052:u0004, D22:p0052:u0005, D22:p0052:u0006, D22:p0052:u0007, D22:p0052:u0008, D22:p0052:u0009, D22:p0052:u0010, D22:p0052:u0011
**Общая страница с:** AI-04-20

````text
Example - Tabu
- String of 5 parameters – containing numbers 0-9
- Tabu List is *,*,3,*,*
- New Tabus are created by adding one point where the best strings
matched
- Best is 0,3,3,2,1 scoring 14 (the way of scoring is omitted for simplicity)
- Local neighbourhood is +/-1 from each parameter
- Generate the new list and get members’ scores. For example, top 3:
- 0,2,3,2,0 - 17
- 0,3,4,2,1 - 18
- 0,4,4,2,0 – 20 (best in the new list)
````

## D22 — Week 6 Lecture.pdf, PDF-страница 53
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=53`
Строки (ID элементов): D22:p0053:u0001, D22:p0053:u0002, D22:p0053:u0003
**Общая страница с:** AI-04-20

````text
Compare and Add Tabu
- 0,3,3,2,1 – previous best (score 14)
- 0,4,4,2,0 – new best (score 20)
````

## D22 — Week 6 Lecture.pdf, PDF-страница 54
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=54`
Строки (ID элементов): D22:p0054:u0001, D22:p0054:u0002, D22:p0054:u0003, D22:p0054:u0004, D22:p0054:u0005, D22:p0054:u0006
**Общая страница с:** AI-04-20

````text
Compare and Add Tabu
- 0,3,3,2,1 – previous best (score 14)
- 0,4,4,2,0 – new best (score 20)
- 0,*,*,2,*
- Add the tabu of 0,*,*,*,* or *,*,*,2,*
- New Tabu list of *,*,3,*,* and (0,*,*,*,* or *,*,*,2,*)
````

## D22 — Week 6 Lecture.pdf, PDF-страница 55
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=55`
Строки (ID элементов): D22:p0055:u0001, D22:p0055:u0002, D22:p0055:u0003, D22:p0055:u0004, D22:p0055:u0005, D22:p0055:u0006, D22:p0055:u0007, D22:p0055:u0008, D22:p0055:u0009, D22:p0055:u0010
**Общая страница с:** AI-04-20

````text
Issues with Too Many Tabus
- Small sets of tabus might make it impossible to move
- In our example, with 3 tabus all happening about the same value, it would
lock movement completely (lock upper and lower move, then move
between and make that tabu)
- Rationalize the Tabus – Costly
- Only allow a small enough number of Tabus – where is this necessary value?
Is it too low? How often will it happen?
- Aspiration criteria – Accept Tabu moves if they SIGNIFICANTLY increase
fitness
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 2
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=2`
Строки (ID элементов): D23:p0002:u0001, D23:p0002:u0003, D23:p0002:u0004, D23:p0002:u0005, D23:p0002:u0012, D23:p0002:u0013, D23:p0002:u0024, D23:p0002:u0026, D23:p0002:u0035, D23:p0002:u0036, D23:p0002:u0039, D23:p0002:u0042, D23:p0002:u0050, D23:p0002:u0051, D23:p0002:u0054, D23:p0002:u0055, D23:p0002:u0056, D23:p0002:u0057, D23:p0002:u0058, D23:p0002:u0059
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Непроверенные OCR/формулы:** 34 исключённых из основного текста кандидатов; см. JSON.

````text
Traveling Salesman Problem (TSP)
"Given a list of cities and the distances between each pair of cities, what is the
shortest possible route that visits each city exactly once and returns to the origin
city?"
Winnipeg
North
Oregon
Wyoming
Connecti
lew Je
Delaware
Disthict of
1
California
Gulf of
Florida
Mexico
49 872
Mexico
Havanilap data ©2014 Google, INEGI
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=3`
Строки (ID элементов): D23:p0003:u0001, D23:p0003:u0004, D23:p0003:u0005, D23:p0003:u0013, D23:p0003:u0014, D23:p0003:u0015, D23:p0003:u0016, D23:p0003:u0018, D23:p0003:u0019, D23:p0003:u0020, D23:p0003:u0021, D23:p0003:u0023, D23:p0003:u0024, D23:p0003:u0025, D23:p0003:u0026, D23:p0003:u0028, D23:p0003:u0029, D23:p0003:u0030, D23:p0003:u0031, D23:p0003:u0033, D23:p0003:u0034, D23:p0003:u0035, D23:p0003:u0036
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Непроверенные OCR/формулы:** 10 исключённых из основного текста кандидатов; см. JSON.

````text
Traveling Salesman Problem (2)
The solution can be written as C2->C5->C1->C4->C3->C2. An itinerary that begins
and ends at the same city and visits each city once is called a tour.
132
217
164
158
132
290
201
79
217
290
113
303
164
201
113
196
158
79
303
196
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=4`
Строки (ID элементов): D23:p0004:u0001, D23:p0004:u0005, D23:p0004:u0006, D23:p0004:u0008
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
TSP – Graph Representation
10
18
18
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=5`
Строки (ID элементов): D23:p0005:u0001, D23:p0005:u0004, D23:p0005:u0005, D23:p0005:u0006, D23:p0005:u0008, D23:p0005:u0009, D23:p0005:u0010, D23:p0005:u0011, D23:p0005:u0012, D23:p0005:u0013, D23:p0005:u0014, D23:p0005:u0015, D23:p0005:u0016, D23:p0005:u0017, D23:p0005:u0019, D23:p0005:u0020, D23:p0005:u0021, D23:p0005:u0022, D23:p0005:u0025, D23:p0005:u0026, D23:p0005:u0028, D23:p0005:u0029, D23:p0005:u0030, D23:p0005:u0031, D23:p0005:u0032, D23:p0005:u0033
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Tabu Search
Begin with A Starting Current Solution
Obtain the solution from initialization or from
an intermediate or long-term memory component
Create a Candidate List of Moves
(If applied, each move would generate
a new solution from the current solution)
* Choose th
st Admis:
Candidate +
(Admissibility is based on the tabu restrictions and
aspiration criteria.) Designate the solution obtained
‘as the new current solution. Record it as the new
Best Solution if it improves on the previous best.
‘Stopping Criterion
Stop if a specified number of iterations
has elapsed in total or since the last
Best Solution was found
‘Terminate Globally or Transfer
+ Update Admissibility
A transfer initiates an intensification
or diversification phase embodied in
Update Tabu Restrictions
‘an intermediate or long-term
‘and Aspiration Criteria
memory component.
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=6`
Строки (ID элементов): D23:p0006:u0001, D23:p0006:u0002, D23:p0006:u0004, D23:p0006:u0005, D23:p0006:u0006, D23:p0006:u0007, D23:p0006:u0008, D23:p0006:u0009, D23:p0006:u0010, D23:p0006:u0011, D23:p0006:u0012, D23:p0006:u0013, D23:p0006:u0014, D23:p0006:u0015, D23:p0006:u0016, D23:p0006:u0017, D23:p0006:u0018, D23:p0006:u0019

````text
TSP – Tabu Search
Suppose the initial solution to our problem is the shown as:
2
5
1
4
3
2
The ordering specifies that city 2 is placed in the first position, followed by city 5,
etc. Tabu search methods operate to identify the neighbourhood that can be reached
from any current solution. Identifying moves that lead from one solution to the next.
In our problem, a swap exchanges the position of two cities.
2
4
1
5
3
2
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=7`
Строки (ID элементов): D23:p0007:u0001, D23:p0007:u0004, D23:p0007:u0006, D23:p0007:u0009, D23:p0007:u0010, D23:p0007:u0011, D23:p0007:u0012, D23:p0007:u0018
**Непроверенные OCR/формулы:** 9 исключённых из основного текста кандидатов; см. JSON.

````text
Resolution for the TSP using Tabu Search
Current
Top 5
indida
4
5
6
Insulation
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=8`
Строки (ID элементов): D23:p0008:u0001, D23:p0008:u0011, D23:p0008:u0012, D23:p0008:u0013, D23:p0008:u0014, D23:p0008:u0015, D23:p0008:u0016
**Непроверенные OCR/формулы:** 11 исключённых из основного текста кандидатов; см. JSON.

````text
Resolution for the TSP using Tabu Search (2)
Value
2
3
4
5
6
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=9`
Строки (ID элементов): D23:p0009:u0001, D23:p0009:u0004, D23:p0009:u0005, D23:p0009:u0006, D23:p0009:u0008, D23:p0009:u0009, D23:p0009:u0010, D23:p0009:u0011, D23:p0009:u0012, D23:p0009:u0013, D23:p0009:u0014, D23:p0009:u0015, D23:p0009:u0020, D23:p0009:u0021
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Resolution for the TSP using Tabu Search (3)
Current
Tabu
Top 5
Structure
Candidates
4
5
6
7
Swap
Value
Insulation
Value = 18
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=10`
Строки (ID элементов): D23:p0010:u0001, D23:p0010:u0003, D23:p0010:u0006, D23:p0010:u0016, D23:p0010:u0028, D23:p0010:u0029, D23:p0010:u0035, D23:p0010:u0037, D23:p0010:u0040, D23:p0010:u0043, D23:p0010:u0045, D23:p0010:u0046, D23:p0010:u0047
**Непроверенные OCR/формулы:** 34 исключённых из основного текста кандидатов; см. JSON.

````text
SOLUTION
‘Tabu Search Method for Solving the Travel salesman Problem
apply the (Greedy procedure)
‘moves that swap between any two cities, each move would generate anew solution from
Aspiration
Yer
Yes
“Take the next solution
‘Cheek the
number of
Update Tabu List{0 0100.0),
iterations
Figure(2) The flowchart of Tabu search with TSP
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=18`
Строки (ID элементов): D23:p0018:u0001, D23:p0018:u0002, D23:p0018:u0003, D23:p0018:u0004

````text
Tabu search vs.
semi-deterministic approach
While tabu search uses a semi-deterministic approach to escape local optima,
simulated annealing uses a complete stochastic approach
````


---

# AI-04-20 — Длительность запрета и критерий aspiration

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Приведи случай, когда следует снять табу, и вычисли срок хранения запрета.
**Пункты РПД:** —

**Связанные страницы:** 9; **символов извлечённого текста:** 3500.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D22 — Week 6 Lecture.pdf, PDF-страница 49
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=49`
Строки (ID элементов): D22:p0049:u0001, D22:p0049:u0002, D22:p0049:u0003, D22:p0049:u0004, D22:p0049:u0005, D22:p0049:u0006, D22:p0049:u0007, D22:p0049:u0008, D22:p0049:u0009, D22:p0049:u0010
**Общая страница с:** AI-04-19

````text
Tabu Tenure and Aspiration Criterion
- Tabu tenure is the number of iterations, during which tabu is considered
- A memory for the last actions not be reverted back for some iterations
- Chosen by programmer
- Aspiration criterion allows for potential solutions with tabu and better than
best found to skip the tabu
- This sets tabu tenure to max value, does not matter how small or big it was before
- Can consider only significant difference to break the tabu
- Stopping criterion for algorithm is usually the attempt limit or a score
threshold
````

## D22 — Week 6 Lecture.pdf, PDF-страница 50
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=50`
Строки (ID элементов): D22:p0050:u0001, D22:p0050:u0002, D22:p0050:u0003, D22:p0050:u0004, D22:p0050:u0005, D22:p0050:u0006, D22:p0050:u0007, D22:p0050:u0008
**Общая страница с:** AI-04-19

````text
Tabu Advantages and Disadvantages
- Advantages:
- Accepts non-improving solutions to escape from local optimum
- Can be applied to both discrete and continuous solution spaces
- Disadvantages:
- Too many parameters to be determined
- Number of iterations may be very large
- Global optimum is not guaranteed to be found
````

## D22 — Week 6 Lecture.pdf, PDF-страница 51
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=51`
Строки (ID элементов): D22:p0051:u0001, D22:p0051:u0002, D22:p0051:u0003, D22:p0051:u0004, D22:p0051:u0005, D22:p0051:u0006, D22:p0051:u0007, D22:p0051:u0008, D22:p0051:u0009, D22:p0051:u0010, D22:p0051:u0011, D22:p0051:u0012, D22:p0051:u0013, D22:p0051:u0014, D22:p0051:u0015, D22:p0051:u0016, D22:p0051:u0017
**Общая страница с:** AI-04-19

````text
Tabu Loop
- 
Set a current position, set best to this position, set a tabu list to null
- 
While not at a stopping condition
- Create a candidate list from neighbours
- Check if the candidates are on the tabu list. If they are, remove them, if aspiration criterion is
not satisfied
- Find the best candidate
- Move to this as current position
- Test the best candidate against the best
- If it is the new best – replace
- Create a tabu by looking at the differences in the features between this new best and the previous
best
- Produce a tabu restriction based on this difference
- Add this tabu to the tabu list
- Check tabu list length and remove old tabus based on tabu tenure
````

## D22 — Week 6 Lecture.pdf, PDF-страница 52
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=52`
Строки (ID элементов): D22:p0052:u0001, D22:p0052:u0002, D22:p0052:u0003, D22:p0052:u0004, D22:p0052:u0005, D22:p0052:u0006, D22:p0052:u0007, D22:p0052:u0008, D22:p0052:u0009, D22:p0052:u0010, D22:p0052:u0011
**Общая страница с:** AI-04-19

````text
Example - Tabu
- String of 5 parameters – containing numbers 0-9
- Tabu List is *,*,3,*,*
- New Tabus are created by adding one point where the best strings
matched
- Best is 0,3,3,2,1 scoring 14 (the way of scoring is omitted for simplicity)
- Local neighbourhood is +/-1 from each parameter
- Generate the new list and get members’ scores. For example, top 3:
- 0,2,3,2,0 - 17
- 0,3,4,2,1 - 18
- 0,4,4,2,0 – 20 (best in the new list)
````

## D22 — Week 6 Lecture.pdf, PDF-страница 53
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=53`
Строки (ID элементов): D22:p0053:u0001, D22:p0053:u0002, D22:p0053:u0003
**Общая страница с:** AI-04-19

````text
Compare and Add Tabu
- 0,3,3,2,1 – previous best (score 14)
- 0,4,4,2,0 – new best (score 20)
````

## D22 — Week 6 Lecture.pdf, PDF-страница 54
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=54`
Строки (ID элементов): D22:p0054:u0001, D22:p0054:u0002, D22:p0054:u0003, D22:p0054:u0004, D22:p0054:u0005, D22:p0054:u0006
**Общая страница с:** AI-04-19

````text
Compare and Add Tabu
- 0,3,3,2,1 – previous best (score 14)
- 0,4,4,2,0 – new best (score 20)
- 0,*,*,2,*
- Add the tabu of 0,*,*,*,* or *,*,*,2,*
- New Tabu list of *,*,3,*,* and (0,*,*,*,* or *,*,*,2,*)
````

## D22 — Week 6 Lecture.pdf, PDF-страница 55
Источник в ZIP: `AI_course_cleaned/22_Week 6 Lecture/source.pdf#page=55`
Строки (ID элементов): D22:p0055:u0001, D22:p0055:u0002, D22:p0055:u0003, D22:p0055:u0004, D22:p0055:u0005, D22:p0055:u0006, D22:p0055:u0007, D22:p0055:u0008, D22:p0055:u0009, D22:p0055:u0010
**Общая страница с:** AI-04-19

````text
Issues with Too Many Tabus
- Small sets of tabus might make it impossible to move
- In our example, with 3 tabus all happening about the same value, it would
lock movement completely (lock upper and lower move, then move
between and make that tabu)
- Rationalize the Tabus – Costly
- Only allow a small enough number of Tabus – where is this necessary value?
Is it too low? How often will it happen?
- Aspiration criteria – Accept Tabu moves if they SIGNIFICANTLY increase
fitness
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=11`
Строки (ID элементов): D23:p0011:u0001, D23:p0011:u0002, D23:p0011:u0003, D23:p0011:u0004, D23:p0011:u0005, D23:p0011:u0006, D23:p0011:u0007, D23:p0011:u0008, D23:p0011:u0009, D23:p0011:u0010, D23:p0011:u0011, D23:p0011:u0012

````text
Tabu Search Characteristics
Aspiration Criterion
In order to override the tabu list when there is a good tabu move, aspiration
criterion is used, the tabu move is accepted if it produces better solution than
the best obtained so far.
Termination criterion
The most commonly used stopping criteria in tabu search are:
1- Terminate the search after number of iterations.
2- After some number of iterations without an improvement in the
objective function value.
3- When the objective reaches a pre-specified threshold value. In this
research the first criteria is used for stopping criteria.
````

## D23 — Week 6 Tutorial_Covered.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/23_Week 6 Tutorial_Covered/source.pdf#page=12`
Строки (ID элементов): D23:p0012:u0001, D23:p0012:u0002, D23:p0012:u0003, D23:p0012:u0004, D23:p0012:u0005

````text
Travelling Salesman Problem –
Tabu Search (Python Code)
DEMO:
https://smartmobilityalgorithms.github.io/book/content/TrajectoryAlgorithm
s/TabuSearch.html
````


---

# AI-04-21 — Мир Wumpus как задача поиска

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Опиши состояния, наблюдения и разрешённые ходы Wumpus-агента для безопасного маршрута.
**Пункты РПД:** —

**Связанные страницы:** 21; **символов извлечённого текста:** 9869.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D02 — Lab 4 (without solution).pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=11`
Строки (ID элементов): D02:p0011:u0001, D02:p0011:u0002, D02:p0011:u0003, D02:p0011:u0004, D02:p0011:u0005, D02:p0011:u0006, D02:p0011:u0007, D02:p0011:u0008, D02:p0011:u0009, D02:p0011:u0010, D02:p0011:u0011, D02:p0011:u0012, D02:p0011:u0013, D02:p0011:u0014, D02:p0011:u0015, D02:p0011:u0016, D02:p0011:u0017, D02:p0011:u0018, D02:p0011:u0019, D02:p0011:u0020, D02:p0011:u0021, D02:p0011:u0022, D02:p0011:u0023, D02:p0011:u0024, D02:p0011:u0025, D02:p0011:u0026, D02:p0011:u0027, D02:p0011:u0045, D02:p0011:u0046, D02:p0011:u0059
**Непроверенные OCR/формулы:** 11 исключённых из основного текста кандидатов; см. JSON.

````text
The Wumpus World
Wumpus was an early computer
game, based on an agent who
explores a cave consisting of rooms
connected by passageways. Lurking
somewhere
in
the
cave
is
the
wumpus, a beast that eats anyone
who enters its room. To make matters
worse,
some
rooms
contain
bottomless pits that will trap anyone
who
wanders
into
these
rooms
(except for the wumpus, who is too
big to fall in). The only mitigating
feature of living in this environment
is the occasional heap of gold
Artifi
I Intelligence
4
````

## D02 — Lab 4 (without solution).pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=12`
Строки (ID элементов): D02:p0012:u0001, D02:p0012:u0002, D02:p0012:u0003, D02:p0012:u0004, D02:p0012:u0005, D02:p0012:u0006, D02:p0012:u0007, D02:p0012:u0008, D02:p0012:u0009, D02:p0012:u0017, D02:p0012:u0022, D02:p0012:u0036, D02:p0012:u0037, D02:p0012:u0040, D02:p0012:u0041, D02:p0012:u0042
**Непроверенные OCR/формулы:** 12 исключённых из основного текста кандидатов; см. JSON.

````text
The Wumpus World Rules (1)
Like the vacuum world, the wumpus
world is a grid of squares surrounded by
walls, where each square can contain
agents and objects. The agent always
starts in the lower left corner, a square
that we will label [1,1]. The agent's task
is to find the gold if it is possible, return
to [1,1] and climb out of the cave
stench S
Stench >
PIT
START
2
3
4
````

## D02 — Lab 4 (without solution).pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=13`
Строки (ID элементов): D02:p0013:u0001, D02:p0013:u0002, D02:p0013:u0003, D02:p0013:u0004, D02:p0013:u0005, D02:p0013:u0006, D02:p0013:u0007, D02:p0013:u0008, D02:p0013:u0009, D02:p0013:u0010, D02:p0013:u0011, D02:p0013:u0012

````text
The Wumpus World Rules (2)
- In the square containing the wumpus and in the directly (not diagonally)
adjacent squares the agent will perceive a stench
- In the squares directly adjacent to a pit, the agent will perceive a breeze
- In the square where the gold is, the agent will perceive a glitter
- When an agent walks into a wall, it will perceive a bump
- When the wumpus is killed, it gives out a woeful scream that can be
perceived anywhere in the cave
- The precepts will be given to the agent in the form of a list of five
symbols; for example, if there is a stench, a breeze, and a glitter but no
bump and no scream, the agent will receive the percept [Stench, Breeze,
Glitter, None, None]. The agent cannot perceive its own location
````

## D02 — Lab 4 (without solution).pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=14`
Строки (ID элементов): D02:p0014:u0001, D02:p0014:u0002, D02:p0014:u0003, D02:p0014:u0004, D02:p0014:u0005, D02:p0014:u0006, D02:p0014:u0007, D02:p0014:u0008, D02:p0014:u0009, D02:p0014:u0010, D02:p0014:u0011, D02:p0014:u0012, D02:p0014:u0013, D02:p0014:u0014

````text
The Wumpus World Rules (3)
- Just as in the vacuum world, there are actions to go forward, turn right by 90°,
and turn left by 90°. In addition, the action Grab can be used to pick up an object
that is in the same square as the agent. The action Shoot can be used to fire an
arrow in a straight line in the direction the agent is facing. The arrow continues
until it either hits and kills the wumpus or hits the wall. The agent only has one
arrow, so only the first Shoot action has any effect. Finally, the action Climb is
used to leave the cave; it is effective only when the agent is in the start square
- The agent dies a miserable death if it enters a square containing a pit or a live
wumpus. It is safe (but smelly) to enter a square with a dead Wumpus
- The agent's goal is to find the gold and bring it back to the start as quickly as
possible, without getting killed. To be precise, 1000 points are awarded for
climbing out of the cave while carrying the gold, but there is a 1-point penalty for
each action taken, and a 10,000-point penalty for getting killed
````

## D02 — Lab 4 (without solution).pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/02_Lab 4 (without solution)/source.pdf#page=15`
Строки (ID элементов): D02:p0015:u0001, D02:p0015:u0002, D02:p0015:u0003, D02:p0015:u0004, D02:p0015:u0006, D02:p0015:u0008, D02:p0015:u0009, D02:p0015:u0010, D02:p0015:u0011, D02:p0015:u0012, D02:p0015:u0013, D02:p0015:u0014, D02:p0015:u0015, D02:p0015:u0016, D02:p0015:u0017, D02:p0015:u0018, D02:p0015:u0019, D02:p0015:u0020, D02:p0015:u0021, D02:p0015:u0022, D02:p0015:u0023, D02:p0015:u0024

````text
Let’s Play
- We will try to simulate
backtracking search with
some modifications
people and choose a captain
- Talk for 5 min inside the team
about the applied heuristics
7
6
5
4
3
2
1
start
1
2
3
4
5
6
7
````

## D07 — Tutorial 3.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=31`
Строки (ID элементов): D07:p0031:u0001, D07:p0031:u0002, D07:p0031:u0003, D07:p0031:u0004, D07:p0031:u0005, D07:p0031:u0006, D07:p0031:u0007, D07:p0031:u0008, D07:p0031:u0009

````text
Logical agents
Three (non-exclusive) agent architectures:
–Reflex agents
• Have rules that classify situations, specifying how to react to
each possible situation
–Model-based agents
• Construct an internal model of their world
–Goal-based agents
• Form goals and try to achieve them
````

## D07 — Tutorial 3.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=32`
Строки (ID элементов): D07:p0032:u0001, D07:p0032:u0003, D07:p0032:u0006, D07:p0032:u0009, D07:p0032:u0015, D07:p0032:u0019, D07:p0032:u0021, D07:p0032:u0022, D07:p0032:u0023, D07:p0032:u0024, D07:p0032:u0025
**Непроверенные OCR/формулы:** 13 исключённых из основного текста кандидатов; см. JSON.

````text
Wumpus World
Stench
PIT
PIT
Stench
PIT
START
1
2
3
4
````

## D07 — Tutorial 3.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=33`
Строки (ID элементов): D07:p0033:u0001, D07:p0033:u0002, D07:p0033:u0003, D07:p0033:u0004, D07:p0033:u0005, D07:p0033:u0006, D07:p0033:u0007, D07:p0033:u0008, D07:p0033:u0009, D07:p0033:u0010, D07:p0033:u0011, D07:p0033:u0012, D07:p0033:u0013, D07:p0033:u0014

````text
A simple reflex agent
• Rules to map percepts into observations:
∀b,g,u,c,t Percept([Stench, b, g, u, c], t) → Stench(t)
∀s,g,u,c,t Percept([s, Breeze, g, u, c], t) → Breeze(t)
∀s,b,u,c,t Percept([s, b, Glitter, u, c], t) → AtGold(t)
• Rules to select an action given observations:
∀t AtGold(t) → Action(Grab, t);
• Some difficulties:
– Consider Climb. There is no percept that indicates the agent should
climb out – position and holding gold are not part of the percept
sequence
– Loops – the percept will be repeated when you return to a square,
which should cause the same response (unless we maintain some
internal model of the world)
````

## D07 — Tutorial 3.pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=34`
Строки (ID элементов): D07:p0034:u0001, D07:p0034:u0002, D07:p0034:u0003, D07:p0034:u0004, D07:p0034:u0005, D07:p0034:u0006, D07:p0034:u0007, D07:p0034:u0008, D07:p0034:u0009, D07:p0034:u0010, D07:p0034:u0011, D07:p0034:u0012, D07:p0034:u0013, D07:p0034:u0014

````text
The “Hunt the Wumpus” agent
• Some atomic propositions:
S12 = There is a stench in cell (1,2)
B34 = There is a breeze in cell (3,4)
W22 = The Wumpus is in cell (2,2)
V11 = We have visited cell (1,1)
OK11 = Cell (1,1) is safe.
etc
• Some rules:
(R1) ¬S11 → ¬W11 ∧¬ W12 ∧¬ W21
(R2) ¬ S21 → ¬W11 ∧¬ W21 ∧¬ W22 ∧¬ W31
(R3) ¬ S12 → ¬W11 ∧¬ W12 ∧¬ W22 ∧¬ W13
(R4)    S12 → W13 ∨W12 ∨W22 ∨W11
etc
````

## D07 — Tutorial 3.pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=35`
Строки (ID элементов): D07:p0035:u0001, D07:p0035:u0002, D07:p0035:u0003, D07:p0035:u0004, D07:p0035:u0006, D07:p0035:u0007, D07:p0035:u0008, D07:p0035:u0010, D07:p0035:u0012, D07:p0035:u0015, D07:p0035:u0017, D07:p0035:u0018, D07:p0035:u0021, D07:p0035:u0022, D07:p0035:u0027, D07:p0035:u0029, D07:p0035:u0031, D07:p0035:u0033, D07:p0035:u0034, D07:p0035:u0035, D07:p0035:u0039, D07:p0035:u0040, D07:p0035:u0041
**Непроверенные OCR/формулы:** 17 исключённых из основного текста кандидатов; см. JSON.

````text
After the third move
• We can prove that the
Wumpus is in (1,3) using
the four rules given.
14
24
34
= Agent
= Breeze
= Glitter, Gold
OK = Safe square
3
33
43
= Stench
= Visited
= Wumpus
22
32
42
21
34
44
````

## D07 — Tutorial 3.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=36`
Строки (ID элементов): D07:p0036:u0001, D07:p0036:u0002, D07:p0036:u0003, D07:p0036:u0004, D07:p0036:u0005, D07:p0036:u0006, D07:p0036:u0007, D07:p0036:u0008, D07:p0036:u0009, D07:p0036:u0010, D07:p0036:u0011, D07:p0036:u0012, D07:p0036:u0013, D07:p0036:u0014, D07:p0036:u0015

````text
Proving W13
• Apply MP with ¬S11  and  R1:
¬ W11 ∧¬ W12 ∧¬ W21
• Apply And-Elimination to this, yielding 3 sentences:
¬ W11, ¬ W12, ¬ W21
• Apply MP to ~S21 and  R2, then apply And-elimination:
¬ W22, ¬ W21, ¬ W31
• Apply MP to S12 and  R4 to obtain:
W13 ∨W12 ∨W22 ∨W11
• Apply Unit resolution on  (W13 ∨W12 ∨W22 ∨W11) and ¬W11:
W13 ∨W12 ∨W22
• Apply Unit Resolution with (W13 ∨W12 ∨W22) and ¬W22:
W13 ∨W12
• Apply UR with (W13 ∨W12) and ¬W12:
W13
````

## D07 — Tutorial 3.pdf, PDF-страница 37
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=37`
Строки (ID элементов): D07:p0037:u0001, D07:p0037:u0002, D07:p0037:u0003, D07:p0037:u0004, D07:p0037:u0005, D07:p0037:u0006, D07:p0037:u0007, D07:p0037:u0008

````text
Problems with the
propositional Wumpus hunter
• Lack of variables prevents stating more general rules
– We need a set of similar rules for each cell
• Change of the KB over time is difficult to represent
– Standard technique is to index facts with the time when
they’re true
– This means we have a separate KB for every time point
````

## D07 — Tutorial 3.pdf, PDF-страница 38
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=38`
Строки (ID элементов): D07:p0038:u0001, D07:p0038:u0002, D07:p0038:u0003, D07:p0038:u0004, D07:p0038:u0005, D07:p0038:u0006, D07:p0038:u0007, D07:p0038:u0008, D07:p0038:u0009, D07:p0038:u0010, D07:p0038:u0011, D07:p0038:u0012
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Representing change
• Representing change in the world in logic can be
tricky.
• One way is just to change the KB
– Add and delete sentences from the KB to reflect changes
– How do we remember the past, or reason about changes?
• Situation calculus is another way
• A situation is a snapshot of the world at some
instant in time
• When the agent performs an action A
in situation S1, the result is a new
situation S2.
````

## D07 — Tutorial 3.pdf, PDF-страница 39
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=39`
Строки (ID элементов): D07:p0039:u0001
**Непроверенные OCR/формулы:** 13 исключённых из основного текста кандидатов; см. JSON.

````text
Situations
````

## D07 — Tutorial 3.pdf, PDF-страница 40
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=40`
Строки (ID элементов): D07:p0040:u0001, D07:p0040:u0002, D07:p0040:u0003, D07:p0040:u0004, D07:p0040:u0005, D07:p0040:u0006, D07:p0040:u0007, D07:p0040:u0008, D07:p0040:u0009, D07:p0040:u0010, D07:p0040:u0011, D07:p0040:u0012, D07:p0040:u0013

````text
Situation calculus
• A situation is a snapshot of the world at an interval of time during which
nothing changes
• Every true or false statement is made with respect to a particular situation.
– Add situation variables to every predicate.
– at(Agent,1,1) becomes at(Agent,1,1,s0): at(Agent,1,1) is true in
situation (i.e., state) s0.
– Alternatively, add a special 2nd-order predicate, holds(f,s), that means
“f is true in situation s.” E.g., holds(at(Agent,1,1),s0)
• Add a new function, result(a,s), that maps a situation s into a new
situation as a result of performing action a. For example, result(forward, s)
is a function that returns the successor state (situation) to s
• Example: The action agent-walks-to-location-y
````

## D07 — Tutorial 3.pdf, PDF-страница 41
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=41`
Строки (ID элементов): D07:p0041:u0001, D07:p0041:u0002, D07:p0041:u0003, D07:p0041:u0004, D07:p0041:u0005, D07:p0041:u0006, D07:p0041:u0007, D07:p0041:u0008, D07:p0041:u0009, D07:p0041:u0010, D07:p0041:u0011, D07:p0041:u0012, D07:p0041:u0013

````text
Qualification problem
• Qualification problem:
– How can you possibly characterize every single effect of an action, or
every single exception that might occur?
– When I put my bread into the toaster, and push the button, it will
become toasted after two minutes, unless…
• The toaster is broken, or…
• The power is out, or…
• I blow a fuse, or…
• A neutron bomb explodes nearby and fries all electrical
components, or…
• A meteor strikes the earth, and the world we know it ceases to
exist, or…
````

## D07 — Tutorial 3.pdf, PDF-страница 42
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=42`
Строки (ID элементов): D07:p0042:u0001, D07:p0042:u0002, D07:p0042:u0003, D07:p0042:u0004, D07:p0042:u0005, D07:p0042:u0006, D07:p0042:u0007, D07:p0042:u0008, D07:p0042:u0009, D07:p0042:u0010, D07:p0042:u0011, D07:p0042:u0012, D07:p0042:u0013, D07:p0042:u0014, D07:p0042:u0015, D07:p0042:u0016, D07:p0042:u0017, D07:p0042:u0018, D07:p0042:u0019, D07:p0042:u0020, D07:p0042:u0021, D07:p0042:u0022

````text
Ramification problem
• Similarly, it’s just about impossible to characterize every side effect of every
action, at every possible level of detail:
– When I put my bread into the toaster, and push the button, the bread will become
toasted after two minutes, and…
•
The crumbs that fall off the bread onto the bottom of the toaster over tray will also become
toasted, and…
•
Some of the aforementioned crumbs will become burnt, and…
•
The outside molecules of the bread will become “toasted,” and…
•
The inside molecules of the bread will remain more “breadlike,” and…
•
The toasting process will release a small amount of humidity into the air because of
evaporation, and…
•
The heating elements will become a tiny fraction more likely to burn out the next time I
use the toaster, and…
•
The electricity meter in the house will move up slightly, and…
````

## D07 — Tutorial 3.pdf, PDF-страница 43
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=43`
Строки (ID элементов): D07:p0043:u0001, D07:p0043:u0002, D07:p0043:u0003, D07:p0043:u0004, D07:p0043:u0005, D07:p0043:u0006, D07:p0043:u0007, D07:p0043:u0008, D07:p0043:u0009, D07:p0043:u0010, D07:p0043:u0011, D07:p0043:u0012

````text
Knowledge engineering!
• Modeling the “right” conditions and the “right” effects at the “right” level
of abstraction is very difficult
• Knowledge engineering (creating and maintaining knowledge bases for
intelligent reasoning) is an entire field of investigation
• Many researchers hope that automated knowledge acquisition and
machine learning tools can fill the gap:
– Our intelligent systems should be able to learn about the conditions
and effects, just like we do!
– Our intelligent systems should be able to learn when to pay attention
to, or reason about, certain aspects of processes, depending on the
context!
````

## D07 — Tutorial 3.pdf, PDF-страница 44
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=44`
Строки (ID элементов): D07:p0044:u0001, D07:p0044:u0002, D07:p0044:u0003, D07:p0044:u0004, D07:p0044:u0005, D07:p0044:u0006, D07:p0044:u0007, D07:p0044:u0008, D07:p0044:u0009, D07:p0044:u0010, D07:p0044:u0011

````text
Preferences among actions
• A problem with Wumpus world knowledge base that we have built so far
is that it is difficult to decide which action is best among a number of
possibilities.
• For example, to decide between a forward and a grab, axioms
describing when it is OK to move to a square would have to mention
glitter.
• This is not modular!
• We can solve this problem by separating facts about actions from
facts about goals. This way our agent can be reprogrammed just by
asking it to achieve different goals.
````

## D07 — Tutorial 3.pdf, PDF-страница 45
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=45`
Строки (ID элементов): D07:p0045:u0001, D07:p0045:u0002, D07:p0045:u0003, D07:p0045:u0004, D07:p0045:u0005, D07:p0045:u0006, D07:p0045:u0007, D07:p0045:u0008, D07:p0045:u0009, D07:p0045:u0010

````text
Preferences among actions
• The first step is to describe the desirability of actions independent of
each other.
• In doing this we will use a simple scale: actions can be Great, Good,
Medium, Risky, or Deadly.
• Obviously, the agent should always do the best action it can find:
(∀a,s) Great(a,s) → Action(a,s)
(∀a,s) Good(a,s) ∧¬(∃b) Great(b,s)  → Action(a,s)
(∀a,s) Medium(a,s) ∧(¬(∃b) Great(b,s) ∨Good(b,s)) → Action(a,s)
...
````

## D07 — Tutorial 3.pdf, PDF-страница 46
Источник в ZIP: `AI_course_cleaned/07_Tutorial 3/source.pdf#page=46`
Строки (ID элементов): D07:p0046:u0001, D07:p0046:u0002, D07:p0046:u0003, D07:p0046:u0004, D07:p0046:u0005, D07:p0046:u0006, D07:p0046:u0007, D07:p0046:u0008, D07:p0046:u0009, D07:p0046:u0010, D07:p0046:u0011, D07:p0046:u0012, D07:p0046:u0013

````text
Preferences among actions
• We use this action quality scale in the following way.
• Until it finds the gold, the basic strategy for our agent is:
– Great actions include picking up the gold when found and
climbing out of the cave with the gold.
– Good actions include moving to a square that’s OK and hasn't
been visited yet.
– Medium actions include moving to a square that is OK and
has already been visited.
– Risky actions include moving to a square that is not known to
be deadly or OK.
– Deadly actions are moving into a square that is known to have
a pit or a Wumpus.
````


---

# AI-04-22 — Ландшафт приспособленности и бассейны притяжения

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Построй ландшафт малого поиска, определи локальные максимумы и бассейны притяжения.
**Пункты РПД:** —

**Связанные страницы:** 13; **символов извлечённого текста:** 3137.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D25 — Week 7 Lecture.pdf, PDF-страница 39
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=39`
Строки (ID элементов): D25:p0039:u0001, D25:p0039:u0002, D25:p0039:u0003, D25:p0039:u0004, D25:p0039:u0006

````text
Going up the Mountain… Search
as a Landscape
Life is a mountain of solvable problems, and I enjoy that.
James Dyson
39
````

## D25 — Week 7 Lecture.pdf, PDF-страница 40
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=40`
Строки (ID элементов): D25:p0040:u0001, D25:p0040:u0003, D25:p0040:u0004, D25:p0040:u0006, D25:p0040:u0007, D25:p0040:u0008, D25:p0040:u0010, D25:p0040:u0016
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Search Space
We have already heard the term
Search Space
The tuple collection of parameter
inputs and outputs for those
parameters
Can we see this as some other shape?
Fitness
````

## D25 — Week 7 Lecture.pdf, PDF-страница 41
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=41`
Строки (ID элементов): D25:p0041:u0001, D25:p0041:u0003, D25:p0041:u0004, D25:p0041:u0005, D25:p0041:u0006, D25:p0041:u0007
**Общая страница с:** AI-07-02

````text
Fitness Landscapes
Evolutionary biologist Sewall Wright came up with the idea of fitness
landscapes back in 1932. His maps displayed reproductive success, or
fitness of individual organisms as a function of genotype (an organism's
genetic constitution) or phenotype (or organism's observable physical
characteristics)
````

## D25 — Week 7 Lecture.pdf, PDF-страница 42
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=42`
Строки (ID элементов): D25:p0042:u0018, D25:p0042:u0019, D25:p0042:u0020
**Общая страница с:** AI-07-02
**Непроверенные OCR/формулы:** 15 исключённых из основного текста кандидатов; см. JSON.

````text
Figure 2—Diagrammatic representation of the field of gene combinations in two dimen-
sions instead of many thousands. Dotted lines represent contours with respect to adap-
tiveness.
````

## D25 — Week 7 Lecture.pdf, PDF-страница 43
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=43`
Строки (ID элементов): D25:p0043:u0001, D25:p0043:u0003, D25:p0043:u0005, D25:p0043:u0007, D25:p0043:u0009, D25:p0043:u0011, D25:p0043:u0013, D25:p0043:u0015, D25:p0043:u0017
**Общая страница с:** AI-07-02

````text
Quantify the Problem
Is our problem smooth or rough?
How smooth or rough?
Can we quantify this?
Do we have gaps?
Areas were our parameters
Can we visualize this?
Visuals are helpful to our understanding
Demonstrate problems to others
````

## D25 — Week 7 Lecture.pdf, PDF-страница 44
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=44`
Строки (ID элементов): D25:p0044:u0001, D25:p0044:u0007, D25:p0044:u0008, D25:p0044:u0009, D25:p0044:u0010, D25:p0044:u0011
**Общая страница с:** AI-07-02

````text
Fitness Landscape
fitness landscape is a Tuple L = (S,f,N) where S is the search space of
feasible solutions, f:S > R is a fitness function, and N(s) is the set of
neighbouring points for a member of S such that they can be reached by a
single application of the search operation
® This defines a 3-dimensional space which can be projected as a mountain
````

## D25 — Week 7 Lecture.pdf, PDF-страница 45
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=45`
Строки (ID элементов): D25:p0045:u0001, D25:p0045:u0005, D25:p0045:u0007, D25:p0045:u0008, D25:p0045:u0010
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Visualization by R. Olson and Ostman
Static fitness landscape
Mutation rate, y = 0.05 per trait
Population
© Randy Olson and Bjorn Ostm:
````

## D25 — Week 7 Lecture.pdf, PDF-страница 46
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=46`
Строки (ID элементов): D25:p0046:u0003, D25:p0046:u0005, D25:p0046:u0006, D25:p0046:u0007, D25:p0046:u0008

````text
Visualization by R. Olson and Ostman
Dynamic fitness landscape
Mutation rate, y = 0.5 per trait
Population size, N = 2,304
© Randy Olson and Bjorn @stman
````

## D25 — Week 7 Lecture.pdf, PDF-страница 47
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=47`
Строки (ID элементов): D25:p0047:u0003, D25:p0047:u0005, D25:p0047:u0006, D25:p0047:u0007, D25:p0047:u0008

````text
Visualization by R. Olson and Ostman
Dynamic fitness landscape changes 3x faster
Mutation rate, w= 0.5 per trait
Population sze, N = 2,304
© Randy Olson and Bjorn Ostman
````

## D25 — Week 7 Lecture.pdf, PDF-страница 48
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=48`
Строки (ID элементов): D25:p0048:u0003, D25:p0048:u0005, D25:p0048:u0006, D25:p0048:u0007, D25:p0048:u0008, D25:p0048:u0009, D25:p0048:u0010

````text
Visualization by R. Olson and Ostman
Density-dependent fitness landscape
The population can split into subpopulations (species)
when fitness depends on the density of the organisms
Population sze, N = 2,304
Mutation rate, y = 0.05 per trait
© Randy Olson and Bjorn Ostman
````

## D25 — Week 7 Lecture.pdf, PDF-страница 49
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=49`
Строки (ID элементов): D25:p0049:u0001, D25:p0049:u0003, D25:p0049:u0004, D25:p0049:u0006, D25:p0049:u0007, D25:p0049:u0009, D25:p0049:u0010, D25:p0049:u0012
**Общая страница с:** AI-04-13

````text
Local Maximums
A solution s in S is said to be a local maximum if its fitness is greater than or
equal to all of neighbors, i.e. f(s)>=f(w) V w in N(s)
If there is a relatively high number of such maximums then the space is
called rugged
If there is a low number of maximums then the space is declared to be
smooth
Note that this depends highly on how the neighbourhood is defined
````

## D25 — Week 7 Lecture.pdf, PDF-страница 50
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=50`
Строки (ID элементов): D25:p0050:u0001, D25:p0050:u0003, D25:p0050:u0004, D25:p0050:u0006, D25:p0050:u0008, D25:p0050:u0010
**Общая страница с:** AI-04-13

````text
Basins of Attraction
A basin of attraction is a set of points which are likely based on their
neighbours to move to the same local optimum
Local Optimums with small basins are considered isolated
Larger Basins imply a smoother landscape
If we have few local optimums the space is said to be more neutral
````

## D25 — Week 7 Lecture.pdf, PDF-страница 51
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=51`
Строки (ID элементов): D25:p0051:u0001, D25:p0051:u0003, D25:p0051:u0004, D25:p0051:u0006, D25:p0051:u0007, D25:p0051:u0009, D25:p0051:u0010
**Общая страница с:** AI-04-13

````text
Fitness Neutrality
If the fitness is relatively neutral then the search will randomly walk about
this area
If this is the case then our movements will for the most part will not progress
to a local optimum
If the space has many local optimum then it may be likely to be stuck, by
falling into a pit we cannot move out of based on our neighbor graph
````


---

# AI-04-23 — Измерение сложности ландшафта случайными блужданиями

**Раздел РПД:** 4. Обучение через поиск
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Объясни, как информационное содержание по случайным блужданиям характеризует ландшафт.
**Пункты РПД:** —

**Связанные страницы:** 4; **символов извлечённого текста:** 1209.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D25 — Week 7 Lecture.pdf, PDF-страница 52
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=52`
Строки (ID элементов): D25:p0052:u0001, D25:p0052:u0003, D25:p0052:u0004, D25:p0052:u0006, D25:p0052:u0007, D25:p0052:u0009, D25:p0052:u0010

````text
Quantifying the Space
Take a random walk about the space – we are not interested in the
optimization but knowing how the space looks to the operators
Take the connections mixed with the fitness values, who is a neighbor of
who
Use this measure to get an idea of how the space looks – surveying the
space
````

## D25 — Week 7 Lecture.pdf, PDF-страница 53
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=53`
Строки (ID элементов): D25:p0053:u0001, D25:p0053:u0003, D25:p0053:u0004, D25:p0053:u0006, D25:p0053:u0007, D25:p0053:u0009, D25:p0053:u0010

````text
Information Content
Uses principles from Information theory to give a measure of the ruggedness
of the space
Transform the space or area in a space into a single quantifiable value
based on the Entropy
Idea is to make random walks over the space, score them based on the
gradient, then check the amount of variation in these changes
````

## D25 — Week 7 Lecture.pdf, PDF-страница 54
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=54`
Строки (ID элементов): D25:p0054:u0001, D25:p0054:u0003, D25:p0054:u0005, D25:p0054:u0007, D25:p0054:u0009, D25:p0054:u0011, D25:p0054:u0013, D25:p0054:u0015, D25:p0054:u0016, D25:p0054:u0018

````text
Three Modalities
We move from higher to lower fitness beyond a tolerance
Score as a -1
We keep the same fitness within a tolerance
Score as a 0
We move from a lower to higher fitness beyond a tolerance
Score as a 1
A smooth space will have a very little change in these values
(0,0,1,1,1,1,1,1,0)
A rugged space will have a ‘randomness’ in the values (0,1,-1,-1,0,1,1,0)
````

## D25 — Week 7 Lecture.pdf, PDF-страница 55
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=55`
Строки (ID элементов): D25:p0055:u0001, D25:p0055:u0006, D25:p0055:u0007, D25:p0055:u0008, D25:p0055:u0011, D25:p0055:u0013
**Непроверенные OCR/формулы:** 7 исключённых из основного текста кандидатов; см. JSON.

````text
Information Content
Take a number of random walks from p to gq, compute the entropy
For a random walk from p to q
Pr[pq] — the proportions found of each of the fitness movements on the walks
Log base 6
10
````


---

# AI-05-01 — Метод Монте-Карло и случайные проигрывания

**Раздел РПД:** 5. Поиск по дереву Монте-Карло
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Оцени два игровых действия серией случайных проигрываний и интерпретируй оценки.
**Пункты РПД:** RPD-23

**Связанные страницы:** 10; **символов извлечённого текста:** 2627.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D25 — Week 7 Lecture.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=4`
Строки (ID элементов): D25:p0004:u0001, D25:p0004:u0003, D25:p0004:u0004, D25:p0004:u0005, D25:p0004:u0007, D25:p0004:u0008, D25:p0004:u0009
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Monte Carlo Tree Search
In computer science, Monte Carlo tree search (MCTS) is a heuristic search
algorithm for some kinds of decision processes, most notably those
employed in playing games
A leading example of Monte Carlo tree search is recent computer
Go programs, but it also has been used in other board games, as well as
real-time video games and non-deterministic games such as poker
````

## D25 — Week 7 Lecture.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=5`
Строки (ID элементов): D25:p0005:u0001, D25:p0005:u0003, D25:p0005:u0004, D25:p0005:u0006, D25:p0005:u0007, D25:p0005:u0008

````text
MCTS History
In 2006, Rémi Coulom described the Monte Carlo method to game-tree
search and coined the name Monte Carlo Tree Search
The Monte Carlo method, which uses random sampling for deterministic
problems which are difficult or impossible to solve using other approaches,
dates back to the 1940s
````

## D25 — Week 7 Lecture.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=6`
Строки (ID элементов): D25:p0006:u0001, D25:p0006:u0003, D25:p0006:u0004, D25:p0006:u0006, D25:p0006:u0007, D25:p0006:u0008, D25:p0006:u0010, D25:p0006:u0011, D25:p0006:u0012

````text
Idea
The focus of MCTS is on the analysis of the most promising moves,
expanding the search tree based on random sampling of the search space
The application of MCTS in games is based on many playouts (rollouts). In
each playout, the game is played out to the very end by selecting moves
at random
The final game result of each playout is then used to weight the nodes in
the game tree so that better nodes are more likely to be chosen in future
playouts
````

## D25 — Week 7 Lecture.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=7`
Строки (ID элементов): D25:p0007:u0001, D25:p0007:u0002
**Общая страница с:** AI-05-02
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
What makes MCTS different from past
decision making algorithms like Minimax?
````

## D25 — Week 7 Lecture.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=8`
Строки (ID элементов): D25:p0008:u0001, D25:p0008:u0003, D25:p0008:u0004, D25:p0008:u0005, D25:p0008:u0007, D25:p0008:u0008, D25:p0008:u0010, D25:p0008:u0052
**Общая страница с:** AI-05-02
**Непроверенные OCR/формулы:** 31 исключённых из основного текста кандидатов; см. JSON.

````text
Minimax and Game Trees
A Game tree is a directed
graph whose nodes are
positions in a game
What if game tree is too
complex?
Higher branching factor
(Winner - x)
````

## D25 — Week 7 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=9`
Строки (ID элементов): D25:p0009:u0001, D25:p0009:u0003, D25:p0009:u0005
**Общая страница с:** AI-05-02
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Go
Go game tree complexity 10360 VS chess 10123
For ~20 years after Deep Blue (chess AI) no AI could master Go
````

## D25 — Week 7 Lecture.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=10`
Строки (ID элементов): D25:p0010:u0001, D25:p0010:u0006, D25:p0010:u0007
**Общая страница с:** AI-05-02
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
2016 Alpha Go and the MCTS
‘6: Google DeepMind
Challenge Match
````

## D25 — Week 7 Lecture.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=11`
Строки (ID элементов): D25:p0011:u0001, D25:p0011:u0003, D25:p0011:u0005
**Общая страница с:** AI-05-02

````text
Monte Carlo Tree Search
How could it plan ahead when there are so many potential moves in Go?
BRUTE FORCE minimax method from chess no longer applicable here
````

## D25 — Week 7 Lecture.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=12`
Строки (ID элементов): D25:p0012:u0001, D25:p0012:u0003, D25:p0012:u0004, D25:p0012:u0006, D25:p0012:u0007, D25:p0012:u0009
**Общая страница с:** AI-05-02

````text
Statistics Tree
MCTS builds a statistics tree (detailing value of nodes) that partially maps
onto the entire game tree
Statistics tree guides the AI to look only/mostly at the most interesting nodes
in the game tree
Value of nodes determined by simulation
````

## D25 — Week 7 Lecture.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=13`
Строки (ID элементов): D25:p0013:u0001, D25:p0013:u0003, D25:p0013:u0005, D25:p0013:u0006, D25:p0013:u0007, D25:p0013:u0009, D25:p0013:u0010, D25:p0013:u0012, D25:p0013:u0014, D25:p0013:u0015, D25:p0013:u0016, D25:p0013:u0017, D25:p0013:u0018, D25:p0013:u0019, D25:p0013:u0020, D25:p0013:u0021, D25:p0013:u0022, D25:p0013:u0023
**Общая страница с:** AI-05-03

````text
MCTS Steps
Pure Monte Carlo Search
The most basic way to use playouts is to apply the same number of playouts after each
legal move of the current player, then choosing the move which led to the most
victories
The efficiency of this method often increases with time as more playouts are assigned to
the moves that have frequently resulted in the player's victory (in previous playouts)
May work sometimes, but for the most of the games selection policy is required
Full Monte Carlo Tree Search employs this principle recursively on many depths of
the game tree. Each round of MCTS consists of four steps:
1.
Selection
2.
Expansion
3.
Simulation
4.
Backpropagation
````


---

# AI-05-02 — Мотивация частичного построения дерева MCTS

**Раздел РПД:** 5. Поиск по дереву Монте-Карло
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Объясни, почему полный minimax становится непрактичным для Go, а MCTS исследует часть дерева.
**Пункты РПД:** —

**Связанные страницы:** 7; **символов извлечённого текста:** 1322.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D24 — Week 7 Lab_noSol.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/24_Week 7 Lab_noSol/source.pdf#page=3`
Строки (ID элементов): D24:p0003:u0001, D24:p0003:u0002, D24:p0003:u0003, D24:p0003:u0004, D24:p0003:u0005, D24:p0003:u0006, D24:p0003:u0007, D24:p0003:u0008, D24:p0003:u0009, D24:p0003:u0010, D24:p0003:u0011
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.

````text
MCTS (Background)
- In games like Chess, Starcraft II, and many more, a
heuristic method called Monte Carlo Tree Search is
employed to choose the best course of action given
the current environmental conditions.
- Monte Carlo Tree Search (MCTS) doesn't require an
evaluation function for states; it learns from general
gameplay patterns. It's used in games with
sequences of moves, where each depth represents
a new move. Initially designed for two-player games,
it's also applied to one-player games.
````

## D25 — Week 7 Lecture.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=7`
Строки (ID элементов): D25:p0007:u0001, D25:p0007:u0002
**Общая страница с:** AI-05-01
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
What makes MCTS different from past
decision making algorithms like Minimax?
````

## D25 — Week 7 Lecture.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=8`
Строки (ID элементов): D25:p0008:u0001, D25:p0008:u0003, D25:p0008:u0004, D25:p0008:u0005, D25:p0008:u0007, D25:p0008:u0008, D25:p0008:u0010, D25:p0008:u0052
**Общая страница с:** AI-05-01
**Непроверенные OCR/формулы:** 31 исключённых из основного текста кандидатов; см. JSON.

````text
Minimax and Game Trees
A Game tree is a directed
graph whose nodes are
positions in a game
What if game tree is too
complex?
Higher branching factor
(Winner - x)
````

## D25 — Week 7 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=9`
Строки (ID элементов): D25:p0009:u0001, D25:p0009:u0003, D25:p0009:u0005
**Общая страница с:** AI-05-01
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Go
Go game tree complexity 10360 VS chess 10123
For ~20 years after Deep Blue (chess AI) no AI could master Go
````

## D25 — Week 7 Lecture.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=10`
Строки (ID элементов): D25:p0010:u0001, D25:p0010:u0006, D25:p0010:u0007
**Общая страница с:** AI-05-01
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
2016 Alpha Go and the MCTS
‘6: Google DeepMind
Challenge Match
````

## D25 — Week 7 Lecture.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=11`
Строки (ID элементов): D25:p0011:u0001, D25:p0011:u0003, D25:p0011:u0005
**Общая страница с:** AI-05-01

````text
Monte Carlo Tree Search
How could it plan ahead when there are so many potential moves in Go?
BRUTE FORCE minimax method from chess no longer applicable here
````

## D25 — Week 7 Lecture.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=12`
Строки (ID элементов): D25:p0012:u0001, D25:p0012:u0003, D25:p0012:u0004, D25:p0012:u0006, D25:p0012:u0007, D25:p0012:u0009
**Общая страница с:** AI-05-01

````text
Statistics Tree
MCTS builds a statistics tree (detailing value of nodes) that partially maps
onto the entire game tree
Statistics tree guides the AI to look only/mostly at the most interesting nodes
in the game tree
Value of nodes determined by simulation
````


---

# AI-05-03 — Четыре этапа MCTS

**Раздел РПД:** 5. Поиск по дереву Монте-Карло
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Проведи один цикл selection, expansion, simulation, backpropagation на маленьком дереве.
**Пункты РПД:** RPD-24

**Связанные страницы:** 14; **символов извлечённого текста:** 2070.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D24 — Week 7 Lab_noSol.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/24_Week 7 Lab_noSol/source.pdf#page=5`
Строки (ID элементов): D24:p0005:u0001, D24:p0005:u0005, D24:p0005:u0006, D24:p0005:u0007, D24:p0005:u0008, D24:p0005:u0010
**Общая страница с:** AI-05-06
**Непроверенные OCR/формулы:** 16 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Algorithm
SELECTION
EXPANSION
ROLLOUT
BACKPROPAGATION
0
````

## D25 — Week 7 Lecture.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=13`
Строки (ID элементов): D25:p0013:u0001, D25:p0013:u0003, D25:p0013:u0005, D25:p0013:u0006, D25:p0013:u0007, D25:p0013:u0009, D25:p0013:u0010, D25:p0013:u0012, D25:p0013:u0014, D25:p0013:u0015, D25:p0013:u0016, D25:p0013:u0017, D25:p0013:u0018, D25:p0013:u0019, D25:p0013:u0020, D25:p0013:u0021, D25:p0013:u0022, D25:p0013:u0023
**Общая страница с:** AI-05-01

````text
MCTS Steps
Pure Monte Carlo Search
The most basic way to use playouts is to apply the same number of playouts after each
legal move of the current player, then choosing the move which led to the most
victories
The efficiency of this method often increases with time as more playouts are assigned to
the moves that have frequently resulted in the player's victory (in previous playouts)
May work sometimes, but for the most of the games selection policy is required
Full Monte Carlo Tree Search employs this principle recursively on many depths of
the game tree. Each round of MCTS consists of four steps:
1.
Selection
2.
Expansion
3.
Simulation
4.
Backpropagation
````

## D25 — Week 7 Lecture.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=14`
Строки (ID элементов): D25:p0014:u0001, D25:p0014:u0002, D25:p0014:u0003, D25:p0014:u0005, D25:p0014:u0006, D25:p0014:u0007, D25:p0014:u0008, D25:p0014:u0009, D25:p0014:u0011, D25:p0014:u0012, D25:p0014:u0013, D25:p0014:u0014, D25:p0014:u0016, D25:p0014:u0018, D25:p0014:u0019, D25:p0014:u0020, D25:p0014:u0022

````text
Steps
1.
Selection
Start from root R and select successive child nodes down to a leaf node L. The section
below says more about a way of choosing child nodes that lets the game tree expand
towards most promising moves, which is the essence of MCTS
2.
Expansion
Unless L ends the game with a win/loss for either player, either create one or more child
nodes or choose from them node C
3.
Simulation
Play a random playout from node C.
This step is sometimes also called playout or rollout
4.
Backpropagation
Use the result of the playout to update information in the nodes on the path from C to R
````

## D25 — Week 7 Lecture.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=15`
Строки (ID элементов): D25:p0015:u0001
**Непроверенные OCR/формулы:** 7 исключённых из основного текста кандидатов; см. JSON.

````text
Hypothetical Game Tree
````

## D25 — Week 7 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=16`
Строки (ID элементов): D25:p0016:u0001, D25:p0016:u0003
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
MCTS begins its stats tree
````

## D25 — Week 7 Lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=17`
Строки (ID элементов): D25:p0017:u0001, D25:p0017:u0003, D25:p0017:u0004, D25:p0017:u0010, D25:p0017:u0013, D25:p0017:u0015, D25:p0017:u0016
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
Add a new node to the stats tree, representing a position in the game tree
that the AI will investigate (how good the move is) next
Starting point
EXPANSION
Potential
moves
````

## D25 — Week 7 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=18`
Строки (ID элементов): D25:p0018:u0001, D25:p0018:u0005, D25:p0018:u0007, D25:p0018:u0008, D25:p0018:u0010, D25:p0018:u0011, D25:p0018:u0012, D25:p0018:u0013, D25:p0018:u0014, D25:p0018:u0015
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
Starting point
SIMULATION
Potential
moves
Starting from the position
represented by the left child
node, make random moves
repeatedly until the game is
won, or lost
````

## D25 — Week 7 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=19`
Строки (ID элементов): D25:p0019:u0001, D25:p0019:u0005, D25:p0019:u0006, D25:p0019:u0007, D25:p0019:u0009, D25:p0019:u0010, D25:p0019:u0011, D25:p0019:u0012, D25:p0019:u0013, D25:p0019:u0014
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
Starting point
UPDATE
Potential
moves
Depending on win or
loss, update left child
node in stats tree with
relevant stats (One win
out of one simulation!)
````

## D25 — Week 7 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=20`
Строки (ID элементов): D25:p0020:u0001
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
````

## D25 — Week 7 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=21`
Строки (ID элементов): D25:p0021:u0001, D25:p0021:u0005, D25:p0021:u0008
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
‘Starting point
SIMULATION
````

## D25 — Week 7 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=22`
Строки (ID элементов): D25:p0022:u0001, D25:p0022:u0005, D25:p0022:u0011
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
Starting point
UPDATE
````

## D25 — Week 7 Lecture.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=23`
Строки (ID элементов): D25:p0023:u0001, D25:p0023:u0002, D25:p0023:u0009
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Selection, Expansion, Simulation,
Backpropagation
ntial
````

## D25 — Week 7 Lecture.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=24`
Строки (ID элементов): D25:p0024:u0001
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
````

## D25 — Week 7 Lecture.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=25`
Строки (ID элементов): D25:p0025:u0001
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
````


---

# AI-05-04 — Статистика посещений и наград MCTS

**Раздел РПД:** 5. Поиск по дереву Монте-Карло
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Обнови статистику узлов после двух роллаутов и выбери предпочтительное действие.
**Пункты РПД:** —

**Связанные страницы:** 17; **символов извлечённого текста:** 2269.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D25 — Week 7 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=16`
Строки (ID элементов): D25:p0016:u0001, D25:p0016:u0003
**Общая страница с:** AI-05-03
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
MCTS begins its stats tree
````

## D25 — Week 7 Lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=17`
Строки (ID элементов): D25:p0017:u0001, D25:p0017:u0003, D25:p0017:u0004, D25:p0017:u0010, D25:p0017:u0013, D25:p0017:u0015, D25:p0017:u0016
**Общая страница с:** AI-05-03
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
Add a new node to the stats tree, representing a position in the game tree
that the AI will investigate (how good the move is) next
Starting point
EXPANSION
Potential
moves
````

## D25 — Week 7 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=18`
Строки (ID элементов): D25:p0018:u0001, D25:p0018:u0005, D25:p0018:u0007, D25:p0018:u0008, D25:p0018:u0010, D25:p0018:u0011, D25:p0018:u0012, D25:p0018:u0013, D25:p0018:u0014, D25:p0018:u0015
**Общая страница с:** AI-05-03
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
Starting point
SIMULATION
Potential
moves
Starting from the position
represented by the left child
node, make random moves
repeatedly until the game is
won, or lost
````

## D25 — Week 7 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=19`
Строки (ID элементов): D25:p0019:u0001, D25:p0019:u0005, D25:p0019:u0006, D25:p0019:u0007, D25:p0019:u0009, D25:p0019:u0010, D25:p0019:u0011, D25:p0019:u0012, D25:p0019:u0013, D25:p0019:u0014
**Общая страница с:** AI-05-03
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
Starting point
UPDATE
Potential
moves
Depending on win or
loss, update left child
node in stats tree with
relevant stats (One win
out of one simulation!)
````

## D25 — Week 7 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=20`
Строки (ID элементов): D25:p0020:u0001
**Общая страница с:** AI-05-03
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
````

## D25 — Week 7 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=21`
Строки (ID элементов): D25:p0021:u0001, D25:p0021:u0005, D25:p0021:u0008
**Общая страница с:** AI-05-03
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
‘Starting point
SIMULATION
````

## D25 — Week 7 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=22`
Строки (ID элементов): D25:p0022:u0001, D25:p0022:u0005, D25:p0022:u0011
**Общая страница с:** AI-05-03
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
Starting point
UPDATE
````

## D25 — Week 7 Lecture.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=23`
Строки (ID элементов): D25:p0023:u0001, D25:p0023:u0002, D25:p0023:u0009
**Общая страница с:** AI-05-03
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Selection, Expansion, Simulation,
Backpropagation
ntial
````

## D25 — Week 7 Lecture.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=24`
Строки (ID элементов): D25:p0024:u0001
**Общая страница с:** AI-05-03
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
````

## D25 — Week 7 Lecture.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=25`
Строки (ID элементов): D25:p0025:u0001
**Общая страница с:** AI-05-03
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
````

## D25 — Week 7 Lecture.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=26`
Строки (ID элементов): D25:p0026:u0001, D25:p0026:u0003, D25:p0026:u0004, D25:p0026:u0005, D25:p0026:u0007, D25:p0026:u0015, D25:p0026:u0020, D25:p0026:u0021, D25:p0026:u0022
**Общая страница с:** AI-05-05
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
Left node seems to be a better move, but chances are, these numbers
(produced by a single random simulation) are probably not a good
indicator of how good any of the moves are
More simulations will make them more accurate!
Starting point
UPDATE
Potential
moves
````

## D25 — Week 7 Lecture.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=27`
Строки (ID элементов): D25:p0027:u0001, D25:p0027:u0003, D25:p0027:u0004, D25:p0027:u0006, D25:p0027:u0007, D25:p0027:u0015, D25:p0027:u0016, D25:p0027:u0017, D25:p0027:u0018
**Общая страница с:** AI-05-05

````text
MCTS Example
All child nodes have now been visited at least once. Now AI can select
which child node to be investigated further
Remember the higher the value, the better the move is (for producing a
win)
‘Starting point
SELECTION
Potential
moves
````

## D25 — Week 7 Lecture.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=28`
Строки (ID элементов): D25:p0028:u0001, D25:p0028:u0003, D25:p0028:u0005, D25:p0028:u0007, D25:p0028:u0014, D25:p0028:u0016, D25:p0028:u0017
**Общая страница с:** AI-05-05
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
Selection is based on 2 things:
How good are the statistics?
How much has child node been “ignored”
Starting point
Potential
moves
````

## D25 — Week 7 Lecture.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=29`
Строки (ID элементов): D25:p0029:u0001
**Общая страница с:** AI-05-05
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
````

## D25 — Week 7 Lecture.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=30`
Строки (ID элементов): D25:p0030:u0001, D25:p0030:u0003, D25:p0030:u0004, D25:p0030:u0005, D25:p0030:u0012, D25:p0030:u0015, D25:p0030:u0016, D25:p0030:u0017
**Общая страница с:** AI-05-05
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
These simulations can go on for as long as you want. The more simulation
there are, the bigger the stats tree, and the more accurate the node
values are
Starting point
SELECTION
Potential
moves
````

## D25 — Week 7 Lecture.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=31`
Строки (ID элементов): D25:p0031:u0001, D25:p0031:u0005, D25:p0031:u0009, D25:p0031:u0010, D25:p0031:u0011, D25:p0031:u0012, D25:p0031:u0013
**Общая страница с:** AI-05-05
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Another MCTS Example
Two players are involved in this game
(a) Selection
and simulation
(b) Expansion
(c) Backpropagation
black wins
````

## D25 — Week 7 Lecture.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=32`
Строки (ID элементов): D25:p0032:u0001, D25:p0032:u0003, D25:p0032:u0005, D25:p0032:u0007, D25:p0032:u0008, D25:p0032:u0009, D25:p0032:u0011, D25:p0032:u0013, D25:p0032:u0014
**Общая страница с:** AI-05-05, AI-05-07

````text
What is the Solution?
Usually, the node with the highest denominator should be the solution
In other words, the node with the biggest number of simulations
You might think that it would be better to return the node with the highest
average utility, but the idea is that a node with 65/100 (0.65) wins is better than
one with 2/3 (~0.66) wins, because the latter has a lot of uncertainty
2/3 (~0.66) can easily turn into 2/4 (0.5) with one more rollout
The number of simulations should be big enough for statistical
independence
````


---

# AI-05-05 — Баланс исследования и использования в UCT

**Раздел РПД:** 5. Поиск по дереву Монте-Карло
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** По заданным посещениям и наградам сравни UCT двух детей и объясни оба слагаемых.
**Пункты РПД:** RPD-24, RPD-46

**Связанные страницы:** 9; **символов извлечённого текста:** 2435.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D25 — Week 7 Lecture.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=26`
Строки (ID элементов): D25:p0026:u0001, D25:p0026:u0003, D25:p0026:u0004, D25:p0026:u0005, D25:p0026:u0007, D25:p0026:u0015, D25:p0026:u0020, D25:p0026:u0021, D25:p0026:u0022
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
Left node seems to be a better move, but chances are, these numbers
(produced by a single random simulation) are probably not a good
indicator of how good any of the moves are
More simulations will make them more accurate!
Starting point
UPDATE
Potential
moves
````

## D25 — Week 7 Lecture.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=27`
Строки (ID элементов): D25:p0027:u0001, D25:p0027:u0003, D25:p0027:u0004, D25:p0027:u0006, D25:p0027:u0007, D25:p0027:u0015, D25:p0027:u0016, D25:p0027:u0017, D25:p0027:u0018
**Общая страница с:** AI-05-04

````text
MCTS Example
All child nodes have now been visited at least once. Now AI can select
which child node to be investigated further
Remember the higher the value, the better the move is (for producing a
win)
‘Starting point
SELECTION
Potential
moves
````

## D25 — Week 7 Lecture.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=28`
Строки (ID элементов): D25:p0028:u0001, D25:p0028:u0003, D25:p0028:u0005, D25:p0028:u0007, D25:p0028:u0014, D25:p0028:u0016, D25:p0028:u0017
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
Selection is based on 2 things:
How good are the statistics?
How much has child node been “ignored”
Starting point
Potential
moves
````

## D25 — Week 7 Lecture.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=29`
Строки (ID элементов): D25:p0029:u0001
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
````

## D25 — Week 7 Lecture.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=30`
Строки (ID элементов): D25:p0030:u0001, D25:p0030:u0003, D25:p0030:u0004, D25:p0030:u0005, D25:p0030:u0012, D25:p0030:u0015, D25:p0030:u0016, D25:p0030:u0017
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Example
These simulations can go on for as long as you want. The more simulation
there are, the bigger the stats tree, and the more accurate the node
values are
Starting point
SELECTION
Potential
moves
````

## D25 — Week 7 Lecture.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=31`
Строки (ID элементов): D25:p0031:u0001, D25:p0031:u0005, D25:p0031:u0009, D25:p0031:u0010, D25:p0031:u0011, D25:p0031:u0012, D25:p0031:u0013
**Общая страница с:** AI-05-04
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Another MCTS Example
Two players are involved in this game
(a) Selection
and simulation
(b) Expansion
(c) Backpropagation
black wins
````

## D25 — Week 7 Lecture.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=32`
Строки (ID элементов): D25:p0032:u0001, D25:p0032:u0003, D25:p0032:u0005, D25:p0032:u0007, D25:p0032:u0008, D25:p0032:u0009, D25:p0032:u0011, D25:p0032:u0013, D25:p0032:u0014
**Общая страница с:** AI-05-04, AI-05-07

````text
What is the Solution?
Usually, the node with the highest denominator should be the solution
In other words, the node with the biggest number of simulations
You might think that it would be better to return the node with the highest
average utility, but the idea is that a node with 65/100 (0.65) wins is better than
one with 2/3 (~0.66) wins, because the latter has a lot of uncertainty
2/3 (~0.66) can easily turn into 2/4 (0.5) with one more rollout
The number of simulations should be big enough for statistical
independence
````

## D25 — Week 7 Lecture.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=33`
Строки (ID элементов): D25:p0033:u0001, D25:p0033:u0006, D25:p0033:u0007, D25:p0033:u0008, D25:p0033:u0009, D25:p0033:u0010, D25:p0033:u0014, D25:p0033:u0016, D25:p0033:u0017, D25:p0033:u0019
**Общая страница с:** AI-05-07
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Exploration vs Exploitation
The main difficulty in selecting child nodes is maintaining some balance
between the exploitation of deep variants after moves with high average
win rate and the exploration of moves with few simulations
It is recommended to select nodes with the highest value of the next
formula called UCT (Upper Confidence Bound 1 applied to trees)
Exploitation is the first term: 2
In Ni
Exploration is the second term:
c is a constant that balances exploitation and exploration
````

## D25 — Week 7 Lecture.pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=34`
Строки (ID элементов): D25:p0034:u0001, D25:p0034:u0008, D25:p0034:u0012, D25:p0034:u0013, D25:p0034:u0014, D25:p0034:u0015, D25:p0034:u0016, D25:p0034:u0017, D25:p0034:u0018, D25:p0034:u0019
**Общая страница с:** AI-05-07
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Exploration vs Exploitation
InN,
w; stands for the number of wins for the node considered after the i-th
move
n; stands for the number of simulations for the node considered after the i-th
move
Nj; stands for the total number of simulations after the i-th move run by the
parent node of the one considered
cis the exploration parameter — theoretically equal to V2; in practice
usually chosen empirically
````


---

# AI-05-06 — Практическая реализация MCTS для Connect Four

**Раздел РПД:** 5. Поиск по дереву Монте-Карло
**Статус исходной разметки:** частично; расширение
**Диагностический вопрос (черновик):** Разметь недостающие шаги алгоритма в реализации Connect Four и проверь корректность обновлений.
**Пункты РПД:** —

**Связанные страницы:** 3; **символов извлечённого текста:** 440.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D24 — Week 7 Lab_noSol.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/24_Week 7 Lab_noSol/source.pdf#page=4`
Строки (ID элементов): D24:p0004:u0001, D24:p0004:u0002, D24:p0004:u0003, D24:p0004:u0004, D24:p0004:u0005, D24:p0004:u0006, D24:p0004:u0007, D24:p0004:u0008
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Connect 4?
Connect 4 is a 6x7 board game where players drop their
colored pieces to form a sequence of 4 horizontally,
vertically, or diagonally. The first player to achieve this
wins. The pieces should be dropped only from the bottom
to up (not at random row).
YouTube
Play Game
````

## D24 — Week 7 Lab_noSol.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/24_Week 7 Lab_noSol/source.pdf#page=5`
Строки (ID элементов): D24:p0005:u0001, D24:p0005:u0005, D24:p0005:u0006, D24:p0005:u0007, D24:p0005:u0008, D24:p0005:u0010
**Общая страница с:** AI-05-03
**Непроверенные OCR/формулы:** 16 исключённых из основного текста кандидатов; см. JSON.

````text
MCTS Algorithm
SELECTION
EXPANSION
ROLLOUT
BACKPROPAGATION
0
````

## D24 — Week 7 Lab_noSol.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/24_Week 7 Lab_noSol/source.pdf#page=6`
Строки (ID элементов): D24:p0006:u0001, D24:p0006:u0002, D24:p0006:u0003, D24:p0006:u0004

````text
Code
Follow the link below, copy the colab notebook, and
complete the missing lines of code.
MCTS lab
````


---

# AI-05-07 — Выбор финального хода и параллелизация MCTS

**Раздел РПД:** 5. Поиск по дереву Монте-Карло
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Обоснуй выбор хода по статистике и объясни один способ параллельного rollout.
**Пункты РПД:** —

**Связанные страницы:** 5; **символов извлечённого текста:** 2245.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D25 — Week 7 Lecture.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=32`
Строки (ID элементов): D25:p0032:u0001, D25:p0032:u0003, D25:p0032:u0005, D25:p0032:u0007, D25:p0032:u0008, D25:p0032:u0009, D25:p0032:u0011, D25:p0032:u0013, D25:p0032:u0014
**Общая страница с:** AI-05-04, AI-05-05

````text
What is the Solution?
Usually, the node with the highest denominator should be the solution
In other words, the node with the biggest number of simulations
You might think that it would be better to return the node with the highest
average utility, but the idea is that a node with 65/100 (0.65) wins is better than
one with 2/3 (~0.66) wins, because the latter has a lot of uncertainty
2/3 (~0.66) can easily turn into 2/4 (0.5) with one more rollout
The number of simulations should be big enough for statistical
independence
````

## D25 — Week 7 Lecture.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=33`
Строки (ID элементов): D25:p0033:u0001, D25:p0033:u0006, D25:p0033:u0007, D25:p0033:u0008, D25:p0033:u0009, D25:p0033:u0010, D25:p0033:u0014, D25:p0033:u0016, D25:p0033:u0017, D25:p0033:u0019
**Общая страница с:** AI-05-05
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Exploration vs Exploitation
The main difficulty in selecting child nodes is maintaining some balance
between the exploitation of deep variants after moves with high average
win rate and the exploration of moves with few simulations
It is recommended to select nodes with the highest value of the next
formula called UCT (Upper Confidence Bound 1 applied to trees)
Exploitation is the first term: 2
In Ni
Exploration is the second term:
c is a constant that balances exploitation and exploration
````

## D25 — Week 7 Lecture.pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=34`
Строки (ID элементов): D25:p0034:u0001, D25:p0034:u0008, D25:p0034:u0012, D25:p0034:u0013, D25:p0034:u0014, D25:p0034:u0015, D25:p0034:u0016, D25:p0034:u0017, D25:p0034:u0018, D25:p0034:u0019
**Общая страница с:** AI-05-05
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Exploration vs Exploitation
InN,
w; stands for the number of wins for the node considered after the i-th
move
n; stands for the number of simulations for the node considered after the i-th
move
Nj; stands for the total number of simulations after the i-th move run by the
parent node of the one considered
cis the exploration parameter — theoretically equal to V2; in practice
usually chosen empirically
````

## D25 — Week 7 Lecture.pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=35`
Строки (ID элементов): D25:p0035:u0001, D25:p0035:u0003, D25:p0035:u0005, D25:p0035:u0007, D25:p0035:u0008, D25:p0035:u0010, D25:p0035:u0012, D25:p0035:u0014, D25:p0035:u0015

````text
Advantages and Disadvantages
Advantages
No evaluation function that makes the algorithm ultimate for different tasks
Achieves better results than classical algorithms in games with a high branching
factor
Shortens the search time for large tasks
Disadvantages
In certain positions, there may be moves that look superficially strong, but that
actually lead to a loss via a subtle line of play
````

## D25 — Week 7 Lecture.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=36`
Строки (ID элементов): D25:p0036:u0001, D25:p0036:u0003, D25:p0036:u0005, D25:p0036:u0007, D25:p0036:u0009, D25:p0036:u0010, D25:p0036:u0012, D25:p0036:u0014, D25:p0036:u0015, D25:p0036:u0016

````text
Parallelization
Leaf parallelization
Parallel execution of many playouts from one leaf of the game tree
Root parallelization
Building independent game trees in parallel and making the move based on the
root-level branches of all these trees
Tree parallelization
Parallel building of the same game tree, protecting data from simultaneous
writes either with one, global mutex, with more mutexes, or with non-blocking
synchronization
````


---

# AI-06-01 — Планирование как поиск последовательности действий

**Раздел РПД:** 6. Язык определения проблемной области планирования (PDDL)
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Сформулируй planning-задачу с началом, целью и последовательностью действий.
**Пункты РПД:** —

**Связанные страницы:** 11; **символов извлечённого текста:** 2689.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 2
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=2`
Строки (ID элементов): D04:p0002:u0001, D04:p0002:u0002, D04:p0002:u0003, D04:p0002:u0004, D04:p0002:u0005, D04:p0002:u0006, D04:p0002:u0007
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
Motivations
• What is the Planning Domain Definition Language
(PDDL)?
2
? ?
?
?
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=3`
Строки (ID элементов): D04:p0003:u0001, D04:p0003:u0002, D04:p0003:u0003, D04:p0003:u0004, D04:p0003:u0005, D04:p0003:u0006
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Непроверенные OCR/формулы:** 14 исключённых из основного текста кандидатов; см. JSON.

````text
Motivations
3
• Formulated the problem:
- First Order Logic (FOL)
• PROLOG
Fig. From [Beetz-2020]
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=4`
Строки (ID элементов): D04:p0004:u0001, D04:p0004:u0002, D04:p0004:u0003, D04:p0004:u0004, D04:p0004:u0005, D04:p0004:u0006, D04:p0004:u0007, D04:p0004:u0008, D04:p0004:u0009, D04:p0004:u0010, D04:p0004:u0011

````text
Motivations
4
Fig. From [Beetz-2020]
• Schema for a Knowledge-
enabled agent:
• Action plan:
- Action sequencer: solves the
planning problem
• Execution of the plan:
- If the goal can be satisfied
actions are executed
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=5`
Строки (ID элементов): D04:p0005:u0001, D04:p0005:u0002, D04:p0005:u0003, D04:p0005:u0004

````text
• PDDL:
A framework for formulating and solving planning problem.
Motivations
5
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=6`
Строки (ID элементов): D04:p0006:u0001, D04:p0006:u0002, D04:p0006:u0003, D04:p0006:u0004, D04:p0006:u0005, D04:p0006:u0006, D04:p0006:u0007

````text
Intuitive definition:
Planning is the thinking before acting
More precise definition:
Planning is the process of choosing and scheduling actions that lead
towards a goal, based on a high-level description of the world
What is planning?
6
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=7`
Строки (ID элементов): D04:p0007:u0001, D04:p0007:u0002, D04:p0007:u0003, D04:p0007:u0004, D04:p0007:u0005, D04:p0007:u0006, D04:p0007:u0007, D04:p0007:u0008, D04:p0007:u0009, D04:p0007:u0010, D04:p0007:u0011, D04:p0007:u0012, D04:p0007:u0013, D04:p0007:u0014, D04:p0007:u0015, D04:p0007:u0016, D04:p0007:u0017

````text
Two families of planning approaches
7
• Applicable across very different
domains
• Many different flavours
- Offline/online
- Discrete/continuous
- Deterministic/non-deterministic
- Fully/partially observable
- Sequential/temporal
Domain independent planning
• Methods and representations are
specific to a problem:
- Path and motion planning
- Manipulation planning
- …
Domain specific planning
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=8`
Строки (ID элементов): D04:p0008:u0001, D04:p0008:u0002, D04:p0008:u0003, D04:p0008:u0004, D04:p0008:u0005, D04:p0008:u0006, D04:p0008:u0007, D04:p0008:u0008, D04:p0008:u0009
**Общая страница с:** AI-06-02

````text
Planning Domain Definition Language
8
We need to formally describe:
• The environment in which we operate: the initial state, and the goal
• The actions that our robot can do, and how these affect the
environment
Initial state
Action library
Goal
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=9`
Строки (ID элементов): D04:p0009:u0001, D04:p0009:u0002, D04:p0009:u0003, D04:p0009:u0004, D04:p0009:u0005, D04:p0009:u0006, D04:p0009:u0007, D04:p0009:u0008, D04:p0009:u0009, D04:p0009:u0010, D04:p0009:u0011, D04:p0009:u0012, D04:p0009:u0013, D04:p0009:u0014, D04:p0009:u0015, D04:p0009:u0016, D04:p0009:u0017, D04:p0009:u0018, D04:p0009:u0019, D04:p0009:u0020
**Общая страница с:** AI-06-02

````text
PDDL - The classical planning problem
9
The classical (simplest) PDDL planning problem is described by a tuple:
where:
•
is a set of boolean propositions (facts)
•
is a set of deterministic actions (with preconditions and effects)
•
is the initial state
•
is the goal state
The set of states  in  is the power set of ,
< F, A, I, G >
F
A
I ∈S
G
S
F S = 2F
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=10`
Строки (ID элементов): D04:p0010:u0001, D04:p0010:u0002, D04:p0010:u0003, D04:p0010:u0004, D04:p0010:u0005, D04:p0010:u0006, D04:p0010:u0007, D04:p0010:u0008, D04:p0010:u0009
**Общая страница с:** AI-06-02

````text
PDDL - The classical planning problem
10
The classical PDDL assumes:
• Deterministic and instantaneous actions
• Boolean propositions to describe the world
• The world only changes according to the actions we apply (no external
events)
• The system is fully observable (i.e.  is known)
I
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=11`
Строки (ID элементов): D04:p0011:u0001, D04:p0011:u0002, D04:p0011:u0003, D04:p0011:u0004, D04:p0011:u0005, D04:p0011:u0006, D04:p0011:u0007, D04:p0011:u0008, D04:p0011:u0009, D04:p0011:u0010
**Общая страница с:** AI-06-02

````text
PDDL - The classical planning problem
11
Classical PDDL might seem limiting:
• Assumptions might appear unrealistic for real use-cases
Why is it so popular then?
• It provides idealised settings to develop automated planners
• In many cases it is enough - simplified robotics task in controlled
environments
Extensions:
• PDDL2.1, Probabilistic PDDL (PPDDL), RDDL, and many more…
````

## D26 — Week 9 Lab.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=3`
Строки (ID элементов): D26:p0003:u0001, D26:p0003:u0002, D26:p0003:u0003, D26:p0003:u0004, D26:p0003:u0005, D26:p0003:u0006, D26:p0003:u0007, D26:p0003:u0008, D26:p0003:u0009, D26:p0003:u0010
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Общая страница с:** AI-06-02

````text
Introduction
- 
As planning has evolved, so has the language used to describe
it
- 
Planning Domain Definition Language (PDDL) is a family of
languages which allow us to define a planning problem
- 
PDDL one of the few languages designed for the purpose of
creating a standard for Artificial Intelligence (AI) planning
````


---

# AI-06-02 — Структура domain и problem в PDDL

**Раздел РПД:** 6. Язык определения проблемной области планирования (PDDL)
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Раздели описание учебной задачи на domain.pddl и problem.pddl и объясни разделение.
**Пункты РПД:** RPD-25

**Связанные страницы:** 15; **символов извлечённого текста:** 4868.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=8`
Строки (ID элементов): D04:p0008:u0001, D04:p0008:u0002, D04:p0008:u0003, D04:p0008:u0004, D04:p0008:u0005, D04:p0008:u0006, D04:p0008:u0007, D04:p0008:u0008, D04:p0008:u0009
**Общая страница с:** AI-06-01

````text
Planning Domain Definition Language
8
We need to formally describe:
• The environment in which we operate: the initial state, and the goal
• The actions that our robot can do, and how these affect the
environment
Initial state
Action library
Goal
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=9`
Строки (ID элементов): D04:p0009:u0001, D04:p0009:u0002, D04:p0009:u0003, D04:p0009:u0004, D04:p0009:u0005, D04:p0009:u0006, D04:p0009:u0007, D04:p0009:u0008, D04:p0009:u0009, D04:p0009:u0010, D04:p0009:u0011, D04:p0009:u0012, D04:p0009:u0013, D04:p0009:u0014, D04:p0009:u0015, D04:p0009:u0016, D04:p0009:u0017, D04:p0009:u0018, D04:p0009:u0019, D04:p0009:u0020
**Общая страница с:** AI-06-01

````text
PDDL - The classical planning problem
9
The classical (simplest) PDDL planning problem is described by a tuple:
where:
•
is a set of boolean propositions (facts)
•
is a set of deterministic actions (with preconditions and effects)
•
is the initial state
•
is the goal state
The set of states  in  is the power set of ,
< F, A, I, G >
F
A
I ∈S
G
S
F S = 2F
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=10`
Строки (ID элементов): D04:p0010:u0001, D04:p0010:u0002, D04:p0010:u0003, D04:p0010:u0004, D04:p0010:u0005, D04:p0010:u0006, D04:p0010:u0007, D04:p0010:u0008, D04:p0010:u0009
**Общая страница с:** AI-06-01

````text
PDDL - The classical planning problem
10
The classical PDDL assumes:
• Deterministic and instantaneous actions
• Boolean propositions to describe the world
• The world only changes according to the actions we apply (no external
events)
• The system is fully observable (i.e.  is known)
I
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=11`
Строки (ID элементов): D04:p0011:u0001, D04:p0011:u0002, D04:p0011:u0003, D04:p0011:u0004, D04:p0011:u0005, D04:p0011:u0006, D04:p0011:u0007, D04:p0011:u0008, D04:p0011:u0009, D04:p0011:u0010
**Общая страница с:** AI-06-01

````text
PDDL - The classical planning problem
11
Classical PDDL might seem limiting:
• Assumptions might appear unrealistic for real use-cases
Why is it so popular then?
• It provides idealised settings to develop automated planners
• In many cases it is enough - simplified robotics task in controlled
environments
Extensions:
• PDDL2.1, Probabilistic PDDL (PPDDL), RDDL, and many more…
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=12`
Строки (ID элементов): D04:p0012:u0001, D04:p0012:u0002, D04:p0012:u0003, D04:p0012:u0004, D04:p0012:u0005, D04:p0012:u0006, D04:p0012:u0007, D04:p0012:u0008, D04:p0012:u0009, D04:p0012:u0010, D04:p0012:u0011, D04:p0012:u0012, D04:p0012:u0013, D04:p0012:u0014, D04:p0012:u0015

````text
PDDL - Structure
12
Planning tasks in classical PDDL relies on two separate files:
Domain file
domain.pddl
Problem file
problem.pddl
• Predicates: properties of the world
• Operators: the way in which the state can change
• First order logic (FOL): derive  and
F
A
• Objects: the things in the world
• Initial state
• Goal
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=13`
Строки (ID элементов): D04:p0013:u0001, D04:p0013:u0002, D04:p0013:u0003, D04:p0013:u0004, D04:p0013:u0005, D04:p0013:u0006, D04:p0013:u0007, D04:p0013:u0008
**Общая страница с:** AI-06-06

````text
PDDL - Solvers
13
How to find a plan to achieve a goal?
• Solvers take as input a domain.pddl and problem.pddl, and generate a
plan
• The planning problem can be seen as network of states, where actions
represent transitions.
• It is a search problem: MCTS, A*…
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=14`
Строки (ID элементов): D04:p0014:u0001

````text
Syntax and tools
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=15`
Строки (ID элементов): D04:p0015:u0001, D04:p0015:u0002, D04:p0015:u0003, D04:p0015:u0004, D04:p0015:u0005, D04:p0015:u0006, D04:p0015:u0007, D04:p0015:u0008, D04:p0015:u0009, D04:p0015:u0010, D04:p0015:u0011, D04:p0015:u0012, D04:p0015:u0013, D04:p0015:u0014, D04:p0015:u0015, D04:p0015:u0016, D04:p0015:u0017, D04:p0015:u0018, D04:p0015:u0019, D04:p0015:u0020, D04:p0015:u0021, D04:p0015:u0022, D04:p0015:u0023
**Общая страница с:** AI-06-03

````text
PDDL - Syntax
15
Domain file
domain.pddl
(define (domain <domain-name>)
(:requirements
<requirements-list>)
(:types
<types-list>)
(:predicates
<predicate-list>)
(:action
<action-details>)
)
• <domain-name> is the name of the
world
• :requirements - which features of
PDDL are being used
• :types - optional, type of objects
• :predicates - list of model’s state,
true or false facts
• :action - list of possible state
transitions
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=16`
Строки (ID элементов): D04:p0016:u0001, D04:p0016:u0002, D04:p0016:u0003, D04:p0016:u0004, D04:p0016:u0005, D04:p0016:u0006, D04:p0016:u0007, D04:p0016:u0008, D04:p0016:u0009, D04:p0016:u0010, D04:p0016:u0011, D04:p0016:u0012, D04:p0016:u0013, D04:p0016:u0014, D04:p0016:u0015, D04:p0016:u0016, D04:p0016:u0017, D04:p0016:u0018, D04:p0016:u0019, D04:p0016:u0020, D04:p0016:u0021, D04:p0016:u0022
**Общая страница с:** AI-06-03, AI-06-05

````text
PDDL - Syntax
16
(define (problem <title>)
(:domain <domain-name>)
(:objects
<object-list>)
(:init
<predicates>)
(:goal
<predicates>)
)
Problem file
problem.pddl
• <title> is the name you give to the
problem
• <domain-name> refers to the relative
domain.pddl
• :objects - things in the world you
want to manipulate
• :init - the initial state of your
objects
• :goal - final state(s) to be achieved
````

## D26 — Week 9 Lab.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=3`
Строки (ID элементов): D26:p0003:u0001, D26:p0003:u0002, D26:p0003:u0003, D26:p0003:u0004, D26:p0003:u0005, D26:p0003:u0006, D26:p0003:u0007, D26:p0003:u0008, D26:p0003:u0009, D26:p0003:u0010
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Общая страница с:** AI-06-01

````text
Introduction
- 
As planning has evolved, so has the language used to describe
it
- 
Planning Domain Definition Language (PDDL) is a family of
languages which allow us to define a planning problem
- 
PDDL one of the few languages designed for the purpose of
creating a standard for Artificial Intelligence (AI) planning
````

## D26 — Week 9 Lab.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=4`
Строки (ID элементов): D26:p0004:u0001, D26:p0004:u0002, D26:p0004:u0003, D26:p0004:u0004, D26:p0004:u0005, D26:p0004:u0006, D26:p0004:u0007, D26:p0004:u0008, D26:p0004:u0009, D26:p0004:u0010, D26:p0004:u0011, D26:p0004:u0025, D26:p0004:u0026, D26:p0004:u0027
**Общая страница с:** AI-06-03
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Components of PDDL
- 
A world in PDDL is described by set of states each containing a
list of facts and/or objects
- 
A world begins with an initial state
- 
A world governed by a set of rules and constraints that limit
which actions can be taken in each state
- 
Each action generally represents a transition to a different state
GOAL
TART
OBSTACLE
````

## D26 — Week 9 Lab.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=5`
Строки (ID элементов): D26:p0005:u0001, D26:p0005:u0002, D26:p0005:u0003, D26:p0005:u0004, D26:p0005:u0005, D26:p0005:u0006, D26:p0005:u0007, D26:p0005:u0008, D26:p0005:u0009, D26:p0005:u0010, D26:p0005:u0011, D26:p0005:u0012, D26:p0005:u0013, D26:p0005:u0014, D26:p0005:u0015, D26:p0005:u0016, D26:p0005:u0017
**Общая страница с:** AI-06-03

````text
Components of PDDL
- 
There are certain things we need to keep track of in the “world”:
○
Objects: Things in the world that interest us
○
Predicates: Facts that we are interested in (e.g. properties of
objects), which can be true or false
○
Actions/Operators: Ways of changing the state of the world, i.e.
things that happen that change the facts
○
An initial state: The state of the world that we start in, i.e.
things that are true at the start
○
Goal specification: The state of the world we want to end at,
i.e. things that we want to be true at the end
````

## D26 — Week 9 Lab.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=6`
Строки (ID элементов): D26:p0006:u0001, D26:p0006:u0002, D26:p0006:u0003, D26:p0006:u0004, D26:p0006:u0005, D26:p0006:u0006, D26:p0006:u0007, D26:p0006:u0008, D26:p0006:u0009, D26:p0006:u0010, D26:p0006:u0011, D26:p0006:u0012, D26:p0006:u0013, D26:p0006:u0014, D26:p0006:u0015, D26:p0006:u0016, D26:p0006:u0017, D26:p0006:u0018, D26:p0006:u0019, D26:p0006:u0020, D26:p0006:u0021, D26:p0006:u0022, D26:p0006:u0023, D26:p0006:u0024, D26:p0006:u0025, D26:p0006:u0026
**Общая страница с:** AI-06-03

````text
PDDL Syntax
- 
First thing you need to know, PDDL files usually have the extension
.pddl
- 
There are two PDDL files you need to learn the syntax of:
○
The Domain File (domain.pddl)
■
establishes the context of the world
■
determines what sorts of details the states can include
(predicates)
■
what can we do to move between states in the world
(actions).
○
The Problem File (problem.pddl)
■
represents an instance of the world we established in the
domain
■
determines what is true at the start of the plan (initial state)
■
what we want to be true at the end of the plan (goal
state).
````

## D26 — Week 9 Lab.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=7`
Строки (ID элементов): D26:p0007:u0001, D26:p0007:u0002, D26:p0007:u0003, D26:p0007:u0004, D26:p0007:u0005, D26:p0007:u0006, D26:p0007:u0007, D26:p0007:u0008, D26:p0007:u0009, D26:p0007:u0010, D26:p0007:u0011, D26:p0007:u0012, D26:p0007:u0013, D26:p0007:u0014, D26:p0007:u0015
**Общая страница с:** AI-06-03
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
PDDL Syntax
- 
The Domain File structure (domain.pddl)
(define (domain <domain name>)
(:predicates
<predicate-list>
)
; optional block
(:types
<types-list>
)
(:action
<action-details>
)
)
````

## D26 — Week 9 Lab.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=8`
Строки (ID элементов): D26:p0008:u0001, D26:p0008:u0002, D26:p0008:u0003, D26:p0008:u0004, D26:p0008:u0005, D26:p0008:u0006, D26:p0008:u0007, D26:p0008:u0008, D26:p0008:u0009, D26:p0008:u0010, D26:p0008:u0011, D26:p0008:u0012, D26:p0008:u0013, D26:p0008:u0014, D26:p0008:u0015
**Общая страница с:** AI-06-03, AI-06-05
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
PDDL Syntax
- 
The Problem File structure (problem.pddl)
(define (problem <title>)
(:domain <domain-name>)
(:objects
<object-list>
)
(:init
<predicates>
)
(:goal
<predicates>
)
)
````


---

# AI-06-03 — Предикаты, объекты и типы в PDDL

**Раздел РПД:** 6. Язык определения проблемной области планирования (PDDL)
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Задай объекты и предикаты предметной области и проверь правильность типизации.
**Пункты РПД:** —

**Связанные страницы:** 9; **символов извлечённого текста:** 3603.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=15`
Строки (ID элементов): D04:p0015:u0001, D04:p0015:u0002, D04:p0015:u0003, D04:p0015:u0004, D04:p0015:u0005, D04:p0015:u0006, D04:p0015:u0007, D04:p0015:u0008, D04:p0015:u0009, D04:p0015:u0010, D04:p0015:u0011, D04:p0015:u0012, D04:p0015:u0013, D04:p0015:u0014, D04:p0015:u0015, D04:p0015:u0016, D04:p0015:u0017, D04:p0015:u0018, D04:p0015:u0019, D04:p0015:u0020, D04:p0015:u0021, D04:p0015:u0022, D04:p0015:u0023
**Общая страница с:** AI-06-02

````text
PDDL - Syntax
15
Domain file
domain.pddl
(define (domain <domain-name>)
(:requirements
<requirements-list>)
(:types
<types-list>)
(:predicates
<predicate-list>)
(:action
<action-details>)
)
• <domain-name> is the name of the
world
• :requirements - which features of
PDDL are being used
• :types - optional, type of objects
• :predicates - list of model’s state,
true or false facts
• :action - list of possible state
transitions
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=16`
Строки (ID элементов): D04:p0016:u0001, D04:p0016:u0002, D04:p0016:u0003, D04:p0016:u0004, D04:p0016:u0005, D04:p0016:u0006, D04:p0016:u0007, D04:p0016:u0008, D04:p0016:u0009, D04:p0016:u0010, D04:p0016:u0011, D04:p0016:u0012, D04:p0016:u0013, D04:p0016:u0014, D04:p0016:u0015, D04:p0016:u0016, D04:p0016:u0017, D04:p0016:u0018, D04:p0016:u0019, D04:p0016:u0020, D04:p0016:u0021, D04:p0016:u0022
**Общая страница с:** AI-06-02, AI-06-05

````text
PDDL - Syntax
16
(define (problem <title>)
(:domain <domain-name>)
(:objects
<object-list>)
(:init
<predicates>)
(:goal
<predicates>)
)
Problem file
problem.pddl
• <title> is the name you give to the
problem
• <domain-name> refers to the relative
domain.pddl
• :objects - things in the world you
want to manipulate
• :init - the initial state of your
objects
• :goal - final state(s) to be achieved
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=17`
Строки (ID элементов): D04:p0017:u0001, D04:p0017:u0002, D04:p0017:u0003, D04:p0017:u0004, D04:p0017:u0005, D04:p0017:u0006, D04:p0017:u0007, D04:p0017:u0008, D04:p0017:u0009, D04:p0017:u0010, D04:p0017:u0011, D04:p0017:u0012, D04:p0017:u0013, D04:p0017:u0014, D04:p0017:u0015, D04:p0017:u0016, D04:p0017:u0017, D04:p0017:u0018, D04:p0017:u0019, D04:p0017:u0020, D04:p0017:u0021, D04:p0017:u0022, D04:p0017:u0023, D04:p0017:u0024, D04:p0017:u0025, D04:p0017:u0026, D04:p0017:u0027, D04:p0017:u0028, D04:p0017:u0029, D04:p0017:u0030, D04:p0017:u0031, D04:p0017:u0032
**Общая страница с:** AI-06-04, AI-06-05
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Classic PDDL - Example
17
• An action has:
-
: parameters
-
: simple conditions
-
: add effects
-
: delete effects
• The order of expressions is prefix
- (operator <arguments>):
(and <conjunct1> … <conjunctN>)
par(a) ⊆F
pre(a) ⊆F
add(a) ⊆F
del(a) ⊆F
(define (domain simple_switches)
(:requirements :typing)
(:types switch)
(:predicates (off ?s - switch)
(on ?s - switch))
(:action switch_on
:parameters (?s - switch)
:precondition (off ?s)
:effect (and (not (off ?s))
(on ?s))))
domain.pddl
OFF
OFF
ON
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=18`
Строки (ID элементов): D04:p0018:u0001, D04:p0018:u0002, D04:p0018:u0003, D04:p0018:u0004, D04:p0018:u0005, D04:p0018:u0006, D04:p0018:u0007, D04:p0018:u0008, D04:p0018:u0009, D04:p0018:u0010, D04:p0018:u0011, D04:p0018:u0012, D04:p0018:u0013, D04:p0018:u0014, D04:p0018:u0015, D04:p0018:u0016, D04:p0018:u0017, D04:p0018:u0018, D04:p0018:u0019, D04:p0018:u0020
**Общая страница с:** AI-06-04, AI-06-05
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
18
Classic PDDL - Example
• The domain in which we operate is
simple_switches
• There are 3 objects of type switch
• Two out of three switches are OFF
• The goal is  to have all the switches
ON
• Different problems, same domain!!!
(define (problem switches_problem)
(:domain simple_switches)
(:objects s1 s2 s3 - switch)
(:init (off s1) (off s2) (on s3))
(:goal (and (on s1)
(on s2)
(on s3))) )
problem.pddl
OFF
OFF
ON
````

## D26 — Week 9 Lab.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=4`
Строки (ID элементов): D26:p0004:u0001, D26:p0004:u0002, D26:p0004:u0003, D26:p0004:u0004, D26:p0004:u0005, D26:p0004:u0006, D26:p0004:u0007, D26:p0004:u0008, D26:p0004:u0009, D26:p0004:u0010, D26:p0004:u0011, D26:p0004:u0025, D26:p0004:u0026, D26:p0004:u0027
**Общая страница с:** AI-06-02
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Components of PDDL
- 
A world in PDDL is described by set of states each containing a
list of facts and/or objects
- 
A world begins with an initial state
- 
A world governed by a set of rules and constraints that limit
which actions can be taken in each state
- 
Each action generally represents a transition to a different state
GOAL
TART
OBSTACLE
````

## D26 — Week 9 Lab.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=5`
Строки (ID элементов): D26:p0005:u0001, D26:p0005:u0002, D26:p0005:u0003, D26:p0005:u0004, D26:p0005:u0005, D26:p0005:u0006, D26:p0005:u0007, D26:p0005:u0008, D26:p0005:u0009, D26:p0005:u0010, D26:p0005:u0011, D26:p0005:u0012, D26:p0005:u0013, D26:p0005:u0014, D26:p0005:u0015, D26:p0005:u0016, D26:p0005:u0017
**Общая страница с:** AI-06-02

````text
Components of PDDL
- 
There are certain things we need to keep track of in the “world”:
○
Objects: Things in the world that interest us
○
Predicates: Facts that we are interested in (e.g. properties of
objects), which can be true or false
○
Actions/Operators: Ways of changing the state of the world, i.e.
things that happen that change the facts
○
An initial state: The state of the world that we start in, i.e.
things that are true at the start
○
Goal specification: The state of the world we want to end at,
i.e. things that we want to be true at the end
````

## D26 — Week 9 Lab.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=6`
Строки (ID элементов): D26:p0006:u0001, D26:p0006:u0002, D26:p0006:u0003, D26:p0006:u0004, D26:p0006:u0005, D26:p0006:u0006, D26:p0006:u0007, D26:p0006:u0008, D26:p0006:u0009, D26:p0006:u0010, D26:p0006:u0011, D26:p0006:u0012, D26:p0006:u0013, D26:p0006:u0014, D26:p0006:u0015, D26:p0006:u0016, D26:p0006:u0017, D26:p0006:u0018, D26:p0006:u0019, D26:p0006:u0020, D26:p0006:u0021, D26:p0006:u0022, D26:p0006:u0023, D26:p0006:u0024, D26:p0006:u0025, D26:p0006:u0026
**Общая страница с:** AI-06-02

````text
PDDL Syntax
- 
First thing you need to know, PDDL files usually have the extension
.pddl
- 
There are two PDDL files you need to learn the syntax of:
○
The Domain File (domain.pddl)
■
establishes the context of the world
■
determines what sorts of details the states can include
(predicates)
■
what can we do to move between states in the world
(actions).
○
The Problem File (problem.pddl)
■
represents an instance of the world we established in the
domain
■
determines what is true at the start of the plan (initial state)
■
what we want to be true at the end of the plan (goal
state).
````

## D26 — Week 9 Lab.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=7`
Строки (ID элементов): D26:p0007:u0001, D26:p0007:u0002, D26:p0007:u0003, D26:p0007:u0004, D26:p0007:u0005, D26:p0007:u0006, D26:p0007:u0007, D26:p0007:u0008, D26:p0007:u0009, D26:p0007:u0010, D26:p0007:u0011, D26:p0007:u0012, D26:p0007:u0013, D26:p0007:u0014, D26:p0007:u0015
**Общая страница с:** AI-06-02
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
PDDL Syntax
- 
The Domain File structure (domain.pddl)
(define (domain <domain name>)
(:predicates
<predicate-list>
)
; optional block
(:types
<types-list>
)
(:action
<action-details>
)
)
````

## D26 — Week 9 Lab.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=8`
Строки (ID элементов): D26:p0008:u0001, D26:p0008:u0002, D26:p0008:u0003, D26:p0008:u0004, D26:p0008:u0005, D26:p0008:u0006, D26:p0008:u0007, D26:p0008:u0008, D26:p0008:u0009, D26:p0008:u0010, D26:p0008:u0011, D26:p0008:u0012, D26:p0008:u0013, D26:p0008:u0014, D26:p0008:u0015
**Общая страница с:** AI-06-02, AI-06-05
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
PDDL Syntax
- 
The Problem File structure (problem.pddl)
(define (problem <title>)
(:domain <domain-name>)
(:objects
<object-list>
)
(:init
<predicates>
)
(:goal
<predicates>
)
)
````


---

# AI-06-04 — Предусловия, действия и эффекты PDDL

**Раздел РПД:** 6. Язык определения проблемной области планирования (PDDL)
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Определи действие с предусловием, add и delete effects и вычисли новое состояние.
**Пункты РПД:** RPD-25

**Связанные страницы:** 6; **символов извлечённого текста:** 2098.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=17`
Строки (ID элементов): D04:p0017:u0001, D04:p0017:u0002, D04:p0017:u0003, D04:p0017:u0004, D04:p0017:u0005, D04:p0017:u0006, D04:p0017:u0007, D04:p0017:u0008, D04:p0017:u0009, D04:p0017:u0010, D04:p0017:u0011, D04:p0017:u0012, D04:p0017:u0013, D04:p0017:u0014, D04:p0017:u0015, D04:p0017:u0016, D04:p0017:u0017, D04:p0017:u0018, D04:p0017:u0019, D04:p0017:u0020, D04:p0017:u0021, D04:p0017:u0022, D04:p0017:u0023, D04:p0017:u0024, D04:p0017:u0025, D04:p0017:u0026, D04:p0017:u0027, D04:p0017:u0028, D04:p0017:u0029, D04:p0017:u0030, D04:p0017:u0031, D04:p0017:u0032
**Общая страница с:** AI-06-03, AI-06-05
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Classic PDDL - Example
17
• An action has:
-
: parameters
-
: simple conditions
-
: add effects
-
: delete effects
• The order of expressions is prefix
- (operator <arguments>):
(and <conjunct1> … <conjunctN>)
par(a) ⊆F
pre(a) ⊆F
add(a) ⊆F
del(a) ⊆F
(define (domain simple_switches)
(:requirements :typing)
(:types switch)
(:predicates (off ?s - switch)
(on ?s - switch))
(:action switch_on
:parameters (?s - switch)
:precondition (off ?s)
:effect (and (not (off ?s))
(on ?s))))
domain.pddl
OFF
OFF
ON
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=18`
Строки (ID элементов): D04:p0018:u0001, D04:p0018:u0002, D04:p0018:u0003, D04:p0018:u0004, D04:p0018:u0005, D04:p0018:u0006, D04:p0018:u0007, D04:p0018:u0008, D04:p0018:u0009, D04:p0018:u0010, D04:p0018:u0011, D04:p0018:u0012, D04:p0018:u0013, D04:p0018:u0014, D04:p0018:u0015, D04:p0018:u0016, D04:p0018:u0017, D04:p0018:u0018, D04:p0018:u0019, D04:p0018:u0020
**Общая страница с:** AI-06-03, AI-06-05
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
18
Classic PDDL - Example
• The domain in which we operate is
simple_switches
• There are 3 objects of type switch
• Two out of three switches are OFF
• The goal is  to have all the switches
ON
• Different problems, same domain!!!
(define (problem switches_problem)
(:domain simple_switches)
(:objects s1 s2 s3 - switch)
(:init (off s1) (off s2) (on s3))
(:goal (and (on s1)
(on s2)
(on s3))) )
problem.pddl
OFF
OFF
ON
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=19`
Строки (ID элементов): D04:p0019:u0001, D04:p0019:u0002, D04:p0019:u0003, D04:p0019:u0004, D04:p0019:u0005, D04:p0019:u0006, D04:p0019:u0007, D04:p0019:u0008, D04:p0019:u0009, D04:p0019:u0010, D04:p0019:u0011, D04:p0019:u0012, D04:p0019:u0013, D04:p0019:u0014
**Общая страница с:** AI-06-05, AI-06-06
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Classic PDDL - Example
19
A plan for a classical planning problem is a sequence of actions that are
applicable from the initial state and lead to a a state that satisfies the goal
(switch_on s1)
(switch_on s2)
PLAN:
(:goal (and (on s1)
(on s2)
(on s3))
)
OFF
OFF
ON
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=20`
Строки (ID элементов): D04:p0020:u0001, D04:p0020:u0002, D04:p0020:u0003, D04:p0020:u0004, D04:p0020:u0005, D04:p0020:u0012, D04:p0020:u0013, D04:p0020:u0015, D04:p0020:u0018, D04:p0020:u0019, D04:p0020:u0020, D04:p0020:u0021, D04:p0020:u0022, D04:p0020:u0023, D04:p0020:u0024, D04:p0020:u0025, D04:p0020:u0026, D04:p0020:u0027, D04:p0020:u0028, D04:p0020:u0029
**Общая страница с:** AI-06-05, AI-06-06
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Classic PDDL - Example
20
A plan for a classical planning problem is a sequence of actions that are
applicable from the initial state and lead to a a state that satisfies the goal
Online PDDL Editor: to write and solve PDDL planning problems:
Ik File ~
® Session v
4 Solve ¥F Plugins
domain.pddl
C:requirements :typing)
C:types switch)
problem.pddl
C:predicates (off ?s - switch)
Con ?s - switch))
C:action switch_on
:parameters (?s - switch)
:precondition Coff ?s)
:effect Cand (not Coff ?s))
10
Con ?s)))
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=21`
Строки (ID элементов): D04:p0021:u0001, D04:p0021:u0002, D04:p0021:u0003, D04:p0021:u0004, D04:p0021:u0005, D04:p0021:u0006, D04:p0021:u0007, D04:p0021:u0008
**Общая страница с:** AI-06-06

````text
Did you create the switch_off action?
21
(:action switch_off
:parameters (?s - switch)
:precondition (on ?s)
:effect (and (not (on ?s))
(off ?s))))
http://editor.planning.domains/#edit_session=wQgyhJKiR0wyquH
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=22`
Строки (ID элементов): D04:p0022:u0001, D04:p0022:u0002, D04:p0022:u0003, D04:p0022:u0004, D04:p0022:u0005, D04:p0022:u0006, D04:p0022:u0007, D04:p0022:u0008, D04:p0022:u0009, D04:p0022:u0010, D04:p0022:u0011, D04:p0022:u0012, D04:p0022:u0013
**Общая страница с:** AI-06-06

````text
Add and delete effects
22
switch1 off: FALSE
switch1 on: FALSE
switch1 off: TRUE
switch1 on: FALSE
switch1 off: FALSE
switch1 on: TRUE
switch1 off: TRUE
switch1 on: TRUE
switch_on
switch_off
Valid set
````


---

# AI-06-05 — Начальное состояние и целевое условие

**Раздел РПД:** 6. Язык определения проблемной области планирования (PDDL)
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Запиши PDDL-проблему с исходными фактами и проверяемой целью.
**Пункты РПД:** RPD-25

**Связанные страницы:** 7; **символов извлечённого текста:** 2496.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=16`
Строки (ID элементов): D04:p0016:u0001, D04:p0016:u0002, D04:p0016:u0003, D04:p0016:u0004, D04:p0016:u0005, D04:p0016:u0006, D04:p0016:u0007, D04:p0016:u0008, D04:p0016:u0009, D04:p0016:u0010, D04:p0016:u0011, D04:p0016:u0012, D04:p0016:u0013, D04:p0016:u0014, D04:p0016:u0015, D04:p0016:u0016, D04:p0016:u0017, D04:p0016:u0018, D04:p0016:u0019, D04:p0016:u0020, D04:p0016:u0021, D04:p0016:u0022
**Общая страница с:** AI-06-02, AI-06-03

````text
PDDL - Syntax
16
(define (problem <title>)
(:domain <domain-name>)
(:objects
<object-list>)
(:init
<predicates>)
(:goal
<predicates>)
)
Problem file
problem.pddl
• <title> is the name you give to the
problem
• <domain-name> refers to the relative
domain.pddl
• :objects - things in the world you
want to manipulate
• :init - the initial state of your
objects
• :goal - final state(s) to be achieved
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=17`
Строки (ID элементов): D04:p0017:u0001, D04:p0017:u0002, D04:p0017:u0003, D04:p0017:u0004, D04:p0017:u0005, D04:p0017:u0006, D04:p0017:u0007, D04:p0017:u0008, D04:p0017:u0009, D04:p0017:u0010, D04:p0017:u0011, D04:p0017:u0012, D04:p0017:u0013, D04:p0017:u0014, D04:p0017:u0015, D04:p0017:u0016, D04:p0017:u0017, D04:p0017:u0018, D04:p0017:u0019, D04:p0017:u0020, D04:p0017:u0021, D04:p0017:u0022, D04:p0017:u0023, D04:p0017:u0024, D04:p0017:u0025, D04:p0017:u0026, D04:p0017:u0027, D04:p0017:u0028, D04:p0017:u0029, D04:p0017:u0030, D04:p0017:u0031, D04:p0017:u0032
**Общая страница с:** AI-06-03, AI-06-04
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Classic PDDL - Example
17
• An action has:
-
: parameters
-
: simple conditions
-
: add effects
-
: delete effects
• The order of expressions is prefix
- (operator <arguments>):
(and <conjunct1> … <conjunctN>)
par(a) ⊆F
pre(a) ⊆F
add(a) ⊆F
del(a) ⊆F
(define (domain simple_switches)
(:requirements :typing)
(:types switch)
(:predicates (off ?s - switch)
(on ?s - switch))
(:action switch_on
:parameters (?s - switch)
:precondition (off ?s)
:effect (and (not (off ?s))
(on ?s))))
domain.pddl
OFF
OFF
ON
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=18`
Строки (ID элементов): D04:p0018:u0001, D04:p0018:u0002, D04:p0018:u0003, D04:p0018:u0004, D04:p0018:u0005, D04:p0018:u0006, D04:p0018:u0007, D04:p0018:u0008, D04:p0018:u0009, D04:p0018:u0010, D04:p0018:u0011, D04:p0018:u0012, D04:p0018:u0013, D04:p0018:u0014, D04:p0018:u0015, D04:p0018:u0016, D04:p0018:u0017, D04:p0018:u0018, D04:p0018:u0019, D04:p0018:u0020
**Общая страница с:** AI-06-03, AI-06-04
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
18
Classic PDDL - Example
• The domain in which we operate is
simple_switches
• There are 3 objects of type switch
• Two out of three switches are OFF
• The goal is  to have all the switches
ON
• Different problems, same domain!!!
(define (problem switches_problem)
(:domain simple_switches)
(:objects s1 s2 s3 - switch)
(:init (off s1) (off s2) (on s3))
(:goal (and (on s1)
(on s2)
(on s3))) )
problem.pddl
OFF
OFF
ON
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=19`
Строки (ID элементов): D04:p0019:u0001, D04:p0019:u0002, D04:p0019:u0003, D04:p0019:u0004, D04:p0019:u0005, D04:p0019:u0006, D04:p0019:u0007, D04:p0019:u0008, D04:p0019:u0009, D04:p0019:u0010, D04:p0019:u0011, D04:p0019:u0012, D04:p0019:u0013, D04:p0019:u0014
**Общая страница с:** AI-06-04, AI-06-06
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Classic PDDL - Example
19
A plan for a classical planning problem is a sequence of actions that are
applicable from the initial state and lead to a a state that satisfies the goal
(switch_on s1)
(switch_on s2)
PLAN:
(:goal (and (on s1)
(on s2)
(on s3))
)
OFF
OFF
ON
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=20`
Строки (ID элементов): D04:p0020:u0001, D04:p0020:u0002, D04:p0020:u0003, D04:p0020:u0004, D04:p0020:u0005, D04:p0020:u0012, D04:p0020:u0013, D04:p0020:u0015, D04:p0020:u0018, D04:p0020:u0019, D04:p0020:u0020, D04:p0020:u0021, D04:p0020:u0022, D04:p0020:u0023, D04:p0020:u0024, D04:p0020:u0025, D04:p0020:u0026, D04:p0020:u0027, D04:p0020:u0028, D04:p0020:u0029
**Общая страница с:** AI-06-04, AI-06-06
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Classic PDDL - Example
20
A plan for a classical planning problem is a sequence of actions that are
applicable from the initial state and lead to a a state that satisfies the goal
Online PDDL Editor: to write and solve PDDL planning problems:
Ik File ~
® Session v
4 Solve ¥F Plugins
domain.pddl
C:requirements :typing)
C:types switch)
problem.pddl
C:predicates (off ?s - switch)
Con ?s - switch))
C:action switch_on
:parameters (?s - switch)
:precondition Coff ?s)
:effect Cand (not Coff ?s))
10
Con ?s)))
````

## D26 — Week 9 Lab.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=8`
Строки (ID элементов): D26:p0008:u0001, D26:p0008:u0002, D26:p0008:u0003, D26:p0008:u0004, D26:p0008:u0005, D26:p0008:u0006, D26:p0008:u0007, D26:p0008:u0008, D26:p0008:u0009, D26:p0008:u0010, D26:p0008:u0011, D26:p0008:u0012, D26:p0008:u0013, D26:p0008:u0014, D26:p0008:u0015
**Общая страница с:** AI-06-02, AI-06-03
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
PDDL Syntax
- 
The Problem File structure (problem.pddl)
(define (problem <title>)
(:domain <domain-name>)
(:objects
<object-list>
)
(:init
<predicates>
)
(:goal
<predicates>
)
)
````

## D26 — Week 9 Lab.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=9`
Строки (ID элементов): D26:p0009:u0001, D26:p0009:u0002, D26:p0009:u0003, D26:p0009:u0004, D26:p0009:u0005, D26:p0009:u0006, D26:p0009:u0007, D26:p0009:u0008, D26:p0009:u0009, D26:p0009:u0010, D26:p0009:u0011, D26:p0009:u0012, D26:p0009:u0013, D26:p0009:u0014, D26:p0009:u0015, D26:p0009:u0016, D26:p0009:u0017, D26:p0009:u0018, D26:p0009:u0019, D26:p0009:u0020, D26:p0009:u0021
**Общая страница с:** AI-06-09
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Example (WUMPUS WORLD)
Environment
- 
sq 1-1 is agent
- 
sq 1-2 is pit
- 
sq 1-3 is gold
- 
sq 2-3 contain Wumpus
Actions
- 
Move from sq to adj sq
- 
Kill Wumpus with arrow
- 
Take Gold
Goal
- 
Get gold & Return back
to start pos
````


---

# AI-06-06 — Получение и проверка плана PDDL-планировщиком

**Раздел РПД:** 6. Язык определения проблемной области планирования (PDDL)
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** На примере последовательности действий установи достижение цели и укажи ошибку плана.
**Пункты РПД:** —

**Связанные страницы:** 5; **символов извлечённого текста:** 1440.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=13`
Строки (ID элементов): D04:p0013:u0001, D04:p0013:u0002, D04:p0013:u0003, D04:p0013:u0004, D04:p0013:u0005, D04:p0013:u0006, D04:p0013:u0007, D04:p0013:u0008
**Общая страница с:** AI-06-02

````text
PDDL - Solvers
13
How to find a plan to achieve a goal?
• Solvers take as input a domain.pddl and problem.pddl, and generate a
plan
• The planning problem can be seen as network of states, where actions
represent transitions.
• It is a search problem: MCTS, A*…
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=19`
Строки (ID элементов): D04:p0019:u0001, D04:p0019:u0002, D04:p0019:u0003, D04:p0019:u0004, D04:p0019:u0005, D04:p0019:u0006, D04:p0019:u0007, D04:p0019:u0008, D04:p0019:u0009, D04:p0019:u0010, D04:p0019:u0011, D04:p0019:u0012, D04:p0019:u0013, D04:p0019:u0014
**Общая страница с:** AI-06-04, AI-06-05
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Classic PDDL - Example
19
A plan for a classical planning problem is a sequence of actions that are
applicable from the initial state and lead to a a state that satisfies the goal
(switch_on s1)
(switch_on s2)
PLAN:
(:goal (and (on s1)
(on s2)
(on s3))
)
OFF
OFF
ON
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=20`
Строки (ID элементов): D04:p0020:u0001, D04:p0020:u0002, D04:p0020:u0003, D04:p0020:u0004, D04:p0020:u0005, D04:p0020:u0012, D04:p0020:u0013, D04:p0020:u0015, D04:p0020:u0018, D04:p0020:u0019, D04:p0020:u0020, D04:p0020:u0021, D04:p0020:u0022, D04:p0020:u0023, D04:p0020:u0024, D04:p0020:u0025, D04:p0020:u0026, D04:p0020:u0027, D04:p0020:u0028, D04:p0020:u0029
**Общая страница с:** AI-06-04, AI-06-05
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Classic PDDL - Example
20
A plan for a classical planning problem is a sequence of actions that are
applicable from the initial state and lead to a a state that satisfies the goal
Online PDDL Editor: to write and solve PDDL planning problems:
Ik File ~
® Session v
4 Solve ¥F Plugins
domain.pddl
C:requirements :typing)
C:types switch)
problem.pddl
C:predicates (off ?s - switch)
Con ?s - switch))
C:action switch_on
:parameters (?s - switch)
:precondition Coff ?s)
:effect Cand (not Coff ?s))
10
Con ?s)))
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=21`
Строки (ID элементов): D04:p0021:u0001, D04:p0021:u0002, D04:p0021:u0003, D04:p0021:u0004, D04:p0021:u0005, D04:p0021:u0006, D04:p0021:u0007, D04:p0021:u0008
**Общая страница с:** AI-06-04

````text
Did you create the switch_off action?
21
(:action switch_off
:parameters (?s - switch)
:precondition (on ?s)
:effect (and (not (on ?s))
(off ?s))))
http://editor.planning.domains/#edit_session=wQgyhJKiR0wyquH
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=22`
Строки (ID элементов): D04:p0022:u0001, D04:p0022:u0002, D04:p0022:u0003, D04:p0022:u0004, D04:p0022:u0005, D04:p0022:u0006, D04:p0022:u0007, D04:p0022:u0008, D04:p0022:u0009, D04:p0022:u0010, D04:p0022:u0011, D04:p0022:u0012, D04:p0022:u0013
**Общая страница с:** AI-06-04

````text
Add and delete effects
22
switch1 off: FALSE
switch1 on: FALSE
switch1 off: TRUE
switch1 on: FALSE
switch1 off: FALSE
switch1 on: TRUE
switch1 off: TRUE
switch1 on: TRUE
switch_on
switch_off
Valid set
````


---

# AI-06-07 — Временное планирование в PDDL 2.1

**Раздел РПД:** 6. Язык определения проблемной области планирования (PDDL)
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Опиши длительное действие с временными ограничениями и объясни отличие от классического PDDL.
**Пункты РПД:** RPD-47

**Связанные страницы:** 7; **символов извлечённого текста:** 3462.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=23`
Строки (ID элементов): D04:p0023:u0001, D04:p0023:u0002, D04:p0023:u0003, D04:p0023:u0004, D04:p0023:u0005, D04:p0023:u0006, D04:p0023:u0007, D04:p0023:u0008, D04:p0023:u0009, D04:p0023:u0010, D04:p0023:u0011, D04:p0023:u0012
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
Temporal Planning - PDDL 2.1
23
• Up until now we considered classical planning with instantaneous actions
• For things to happen at the same time we need to model duration and
concurrency of actions and events
• Complex inter-dependancies which determine what is
physically possible
• Example:
For a mobile manipulator navigating a store it
might be possible to scan the environment
while moving, but it might be impossible to
attempt to pick something if not still
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=24`
Строки (ID элементов): D04:p0024:u0001, D04:p0024:u0002, D04:p0024:u0003, D04:p0024:u0004, D04:p0024:u0005, D04:p0024:u0006, D04:p0024:u0007, D04:p0024:u0008, D04:p0024:u0009, D04:p0024:u0010, D04:p0024:u0011, D04:p0024:u0012, D04:p0024:u0013, D04:p0024:u0014, D04:p0024:u0015, D04:p0024:u0016, D04:p0024:u0017, D04:p0024:u0018, D04:p0024:u0019, D04:p0024:u0020, D04:p0024:u0021

````text
PDDL 2.1 - Tuple
24
• PDDL 2.1 extends PDDL to more realistic scenarios where actions have
durations and adds numeric variables and optimisation
• The temporal planning problem is a tuple:
• where:
-
is a set of boolean propositions
-
is a set of real numeric expressions
-
is a set of deterministic actions which can be durative
-
is the initial state and
is the goal
< F, V, A, I, G >
F
V
A
I
G
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=25`
Строки (ID элементов): D04:p0025:u0001, D04:p0025:u0002, D04:p0025:u0003, D04:p0025:u0004, D04:p0025:u0005, D04:p0025:u0006, D04:p0025:u0007, D04:p0025:u0008, D04:p0025:u0009, D04:p0025:u0010, D04:p0025:u0011, D04:p0025:u0012, D04:p0025:u0013, D04:p0025:u0014, D04:p0025:u0015, D04:p0025:u0016

````text
PDDL 2.1 - State and solution
25
• The state is now a tuple
:
-
- Logical state
- Numerical state
(real numbers + undefined if not specified)
• Solution to a temporal plan:
• No longer a simple sequence of actions
• Timed schedule of
S = (t, sl, sn)
t ∈ℝ
sl ∈F
sn : V →ℝ⊥
(ti, ai)
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=26`
Строки (ID элементов): D04:p0026:u0001, D04:p0026:u0002, D04:p0026:u0003, D04:p0026:u0004, D04:p0026:u0005, D04:p0026:u0006, D04:p0026:u0007, D04:p0026:u0008, D04:p0026:u0009, D04:p0026:u0010
**Непроверенные OCR/формулы:** 7 исключённых из основного текста кандидатов; см. JSON.

````text
Durative actions
26
• A durative action consists now of:
- Action name
- Parameters
- Duration
- Conditions:
- Effects:
at start, over all, at end
at start, at end
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=27`
Строки (ID элементов): D04:p0027:u0001, D04:p0027:u0002, D04:p0027:u0003, D04:p0027:u0004, D04:p0027:u0005, D04:p0027:u0006, D04:p0027:u0007, D04:p0027:u0008, D04:p0027:u0009, D04:p0027:u0010, D04:p0027:u0011, D04:p0027:u0012, D04:p0027:u0013, D04:p0027:u0014, D04:p0027:u0015, D04:p0027:u0016, D04:p0027:u0017, D04:p0027:u0018, D04:p0027:u0019, D04:p0027:u0020, D04:p0027:u0021, D04:p0027:u0022

````text
PDDL 2.1 - Syntax
27
• What is different from classical
PDDL?
• :durative-action
• :duration - expressed as
comparison
• :condition - not preconditions
anymore
• :effects - they happen either at
start or at end
( < , > , = , > = , < = )
(:durative-action zoom_meeting
:parameters (?s - student
?t - teacher)
:duration (<= ?duration 120)
:condition (and
(at start (awake ?s))
(over all (awake ?t)))
:effect (and
(at end (not (awake ?s)))))
Durative Action
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=28`
Строки (ID элементов): D04:p0028:u0001, D04:p0028:u0002, D04:p0028:u0003, D04:p0028:u0004, D04:p0028:u0010, D04:p0028:u0011, D04:p0028:u0013, D04:p0028:u0014, D04:p0028:u0015, D04:p0028:u0016, D04:p0028:u0017, D04:p0028:u0018, D04:p0028:u0019, D04:p0028:u0020, D04:p0028:u0021, D04:p0028:u0022, D04:p0028:u0023, D04:p0028:u0024, D04:p0028:u0025, D04:p0028:u0026, D04:p0028:u0027, D04:p0028:u0028, D04:p0028:u0029, D04:p0028:u0030, D04:p0028:u0031, D04:p0028:u0032, D04:p0028:u0033, D04:p0028:u0034, D04:p0028:u0035, D04:p0028:u0036, D04:p0028:u0037, D04:p0028:u0038, D04:p0028:u0039, D04:p0028:u0040, D04:p0028:u0041
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
PDDL 2.1 - Online editor
28
PDDL Editor supports temporal planning with the right plugins:
http://editor.planning.domains/#read_session=EWjbgnhuUd
Plugin URL
http://editor.planning.domains/plugins/temporal-light.js
Close
Plugins
Plugin
Description
Author
Status
Misc PDDL
Adds a number of utilities to the editor for generating
Christian Muise and Nir
Generators
PDDL.
Lipovetzky
Timeline Viewe:
Steve Levine
Visualize the timeline of a plan from a temporal
planner's output
Temporal Setup
Sets up the editor for temporal planning.
Christian Muise and Steve Levine
Solver
Christian Muise
Calls a classical solver and displays the resulting plan.
Hanbin Li
Drag and Drop
Allow users to drag and drop files on the main window.
Save Tabs
Plugin to save the state of the PDDL files when saving
Christian Muise
the plugin setup.
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=29`
Строки (ID элементов): D04:p0029:u0001, D04:p0029:u0002, D04:p0029:u0003, D04:p0029:u0004, D04:p0029:u0005, D04:p0029:u0006, D04:p0029:u0007, D04:p0029:u0008, D04:p0029:u0009, D04:p0029:u0010, D04:p0029:u0011, D04:p0029:u0012

````text
Imagine you are in charge of the stage lighting instruments to illuminate important live performance at
international concerts. Your task for a particular venue in Moscow is to make sure that all 5 available stage
lights are ON whenever the artist enters the stage. A colleague of yours provided you with the following
PDDL files to solve the problem for a generic venue with 5 lights:
Unfortunately, the electrical system in Moscow was not installed properly and you cannot independently
switch ON and OFF single lights as you please. In particular, a light can be switched ON if and only if there
is already another adjacent light ON. Your task is to modify the given domain.pddl and problem.pddl
templates and generate a plan to turn ON all the lights respecting the constraints. The initial state is the
following:
• Initial state: {off, on, off, off, on}
Exercise (30 min)
29
````


---

# AI-06-08 — PDDL и исполнение планов в робототехнике через ROSPlan

**Раздел РПД:** 6. Язык определения проблемной области планирования (PDDL)
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Объясни, как задача из PDDL превращается в исполнение и обратную связь у робота.
**Пункты РПД:** —

**Связанные страницы:** 9; **символов извлечённого текста:** 3433.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=30`
Строки (ID элементов): D04:p0030:u0001, D04:p0030:u0002

````text
ROSPlan
A ROS module to integrate planning into robotics for plan execution.
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=31`
Строки (ID элементов): D04:p0031:u0001, D04:p0031:u0002, D04:p0031:u0003, D04:p0031:u0004, D04:p0031:u0005, D04:p0031:u0006, D04:p0031:u0007, D04:p0031:u0008, D04:p0031:u0009, D04:p0031:u0010, D04:p0031:u0011, D04:p0031:u0012, D04:p0031:u0013, D04:p0031:u0014, D04:p0031:u0021
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
Planning in Robotics
Planning can be pretty abstract
• How can a plan be used to perform a task in the
real world?
31
So far
Missing
• Platform
• Problem and Domain
• Generate a solution
• Update and maintain
the world model
• Process and dispatch
the plan
Gur
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=32`
Строки (ID элементов): D04:p0032:u0001, D04:p0032:u0002, D04:p0032:u0003, D04:p0032:u0004, D04:p0032:u0005, D04:p0032:u0006, D04:p0032:u0007, D04:p0032:u0008, D04:p0032:u0009, D04:p0032:u0010

````text
Planning in Robotics
Using task planning in robotics might be tedious
• A lot of different things need to be integrated:
- State estimation - build and update a symbolic representation of the
world
- Domain and problem definition for the task
- Generate the plan
- Execute the plan according to runtime data
ROSPlan facilitates this integration
32
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=33`
Строки (ID элементов): D04:p0033:u0001, D04:p0033:u0002, D04:p0033:u0003, D04:p0033:u0004, D04:p0033:u0005, D04:p0033:u0006, D04:p0033:u0007, D04:p0033:u0008, D04:p0033:u0009, D04:p0033:u0010, D04:p0033:u0011, D04:p0033:u0012, D04:p0033:u0013, D04:p0033:u0014, D04:p0033:u0015, D04:p0033:u0016, D04:p0033:u0017, D04:p0033:u0018, D04:p0033:u0019, D04:p0033:u0020

````text
ROSPlan - Overview
ROSPlan integrates standard tools:
• Planning with PDDL 2.1
• ROS (Robot Operating System)
ROSPlan takes care of:
• Build the initial state from the PDDL
problem
• Generate and validate the plan
• Dispatch the plan
ROSPlan is domain/platform generic
33
Executor
Environment
State
Estimation
ROSPlan
PS
KB
PS: planning system
KB: knowledge base
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=34`
Строки (ID элементов): D04:p0034:u0001, D04:p0034:u0002, D04:p0034:u0003, D04:p0034:u0004, D04:p0034:u0005, D04:p0034:u0006, D04:p0034:u0007, D04:p0034:u0008, D04:p0034:u0009, D04:p0034:u0011, D04:p0034:u0013, D04:p0034:u0014, D04:p0034:u0015, D04:p0034:u0016, D04:p0034:u0019, D04:p0034:u0020, D04:p0034:u0022, D04:p0034:u0024, D04:p0034:u0025, D04:p0034:u0027, D04:p0034:u0028, D04:p0034:u0032
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
34
• The Knowledge Base
• The Problem Interface
• The Planner Interface
• The Parsing Interface
• The Plan Dispatch
https://kcl-planning.github.io/ROSPlan/documentation/
Resources:
ROSPlan - Components
domain/*
state/*
problem instance
domain_path
problem_path
planner output
domain/*
state/*
query_state
plan
query_state
action feedback
action dispatch
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=35`
Строки (ID элементов): D04:p0035:u0001, D04:p0035:u0002, D04:p0035:u0003, D04:p0035:u0004, D04:p0035:u0005, D04:p0035:u0006, D04:p0035:u0007, D04:p0035:u0008, D04:p0035:u0009, D04:p0035:u0012, D04:p0035:u0014, D04:p0035:u0016, D04:p0035:u0021, D04:p0035:u0023, D04:p0035:u0024, D04:p0035:u0027, D04:p0035:u0028, D04:p0035:u0029, D04:p0035:u0032, D04:p0035:u0034, D04:p0035:u0035, D04:p0035:u0037, D04:p0035:u0039, D04:p0035:u0040, D04:p0035:u0042, D04:p0035:u0043, D04:p0035:u0045, D04:p0035:u0046
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
The Knowledge Base:
• Loads a PDDL domain and
problem from .pddl files
• Stores the state as a PDDL
instance
• Is updated by ROS messages
• Can be queried
35
ROSPlan - Knowledge Base
domain_path
problem_path
parameters
domain/name
state/instances
query_state
domain/types
state/propositions
update
state/functions
clear
update and query services
domain/functions
state/timed_knowledge
domain/operators
state/goals
domain/operator_details
state/metric
Fetch domain and current state services
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=36`
Строки (ID элементов): D04:p0036:u0001, D04:p0036:u0002, D04:p0036:u0003, D04:p0036:u0004, D04:p0036:u0005, D04:p0036:u0006, D04:p0036:u0007, D04:p0036:u0008
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
36
ROSPlan - Example
Domain file
domain.pddl
Problem file
problem.pddl
Pick some object from
somewhere
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 37
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=37`
Строки (ID элементов): D04:p0037:u0001, D04:p0037:u0003, D04:p0037:u0004, D04:p0037:u0005, D04:p0037:u0006, D04:p0037:u0007, D04:p0037:u0008, D04:p0037:u0009, D04:p0037:u0011, D04:p0037:u0012, D04:p0037:u0015, D04:p0037:u0021, D04:p0037:u0026, D04:p0037:u0031, D04:p0037:u0035, D04:p0037:u0037, D04:p0037:u0040, D04:p0037:u0042, D04:p0037:u0043, D04:p0037:u0044, D04:p0037:u0049, D04:p0037:u0051, D04:p0037:u0052, D04:p0037:u0053, D04:p0037:u0055, D04:p0037:u0056, D04:p0037:u0057, D04:p0037:u0059, D04:p0037:u0061, D04:p0037:u0062, D04:p0037:u0063, D04:p0037:u0065, D04:p0037:u0066, D04:p0037:u0067, D04:p0037:u0068, D04:p0037:u0069, D04:p0037:u0070, D04:p0037:u0073, D04:p0037:u0075, D04:p0037:u0077, D04:p0037:u0078, D04:p0037:u0079, D04:p0037:u0080, D04:p0037:u0081, D04:p0037:u0083, D04:p0037:u0084, D04:p0037:u0085, D04:p0037:u0086, D04:p0037:u0087
**Непроверенные OCR/формулы:** 37 исключённых из основного текста кандидатов; см. JSON.

````text
37
corrado@corrado-work: ~/simulations/krr_course/tiago_ws/src...
File
Edit
Camera
View
Window
Help
olution
found in 0.030963 seconds
[ INFO] [1614878035.486142202, 7.726000000]
impleSetup: Path simplification took 0.155687
seconds and changed from 4 to 2 states
[ INFO] [1614878035.489142568, 7.728000000]: P
lanning adapters have added states at index po
sitions:
[INFO] [1614878046.112027, 17.259000]: Arm tuc
ked.
[tuck_arm-21] process has finished cleanly
log file: /home/corrado/.ros/log/f775e4aa-7d0c
se/tiago_ws/src/rosplan_planning_system/test/p
ddl/turtlebot/problem.pddl > /home/corrado/sim
ulations/krr_course/tiago_ws/src/rosplan_plann
ing_system/test/pddl/turtlebot/plan.pddl
[ INFO] [1614878121.236455918, 83.382000000]:
KCL:
(/rosplan_planner_interface)
1) Planning complete
[ INFO] [1614878121.236571134, 83.382000000]:
KCL:
(/rosplan_planner_interface)
1) Plan was solved.
[ INFO] [1614878121.236821758, 83.382000000]:
KCL:
(/rosplan_parsing_interface)
Planner outp
ut received.
:~/simulations/krr_course/tiago_ws/src/r
/retail_store_planning
_course/tiago_ws/src/retail_store_lightweight_
sim/retail_store_planning$ ./rosplan_executor.
bash
Generating a Problem
Planning
Reset Time
II >I steps: 1+ Real Time Factor:
Sim Time:
Real Time:
Iterations:
````

## D04 — PDDL (Lecture +Tutorial).pdf, PDF-страница 38
Источник в ZIP: `AI_course_cleaned/04_PDDL (Lecture +Tutorial)/source.pdf#page=38`
Строки (ID элементов): D04:p0038:u0001, D04:p0038:u0002, D04:p0038:u0003, D04:p0038:u0004

````text
DEMO
38
Solution for Robotic gripper manipulating boxes: http://editor.planning.domains/#edit_session=6GXQPcJRtBZVWJN
Visualisation: https://blocks-dot-ai-planning.appspot.com/
````


---

# AI-06-09 — Модель Wumpus в PDDL

**Раздел РПД:** 6. Язык определения проблемной области планирования (PDDL)
**Статус исходной разметки:** частично; ядро
**Диагностический вопрос (черновик):** Составь фрагменты domain и problem для мира Wumpus и проверь достижимость цели.
**Пункты РПД:** RPD-47

**Связанные страницы:** 2; **символов извлечённого текста:** 281.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D26 — Week 9 Lab.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=9`
Строки (ID элементов): D26:p0009:u0001, D26:p0009:u0002, D26:p0009:u0003, D26:p0009:u0004, D26:p0009:u0005, D26:p0009:u0006, D26:p0009:u0007, D26:p0009:u0008, D26:p0009:u0009, D26:p0009:u0010, D26:p0009:u0011, D26:p0009:u0012, D26:p0009:u0013, D26:p0009:u0014, D26:p0009:u0015, D26:p0009:u0016, D26:p0009:u0017, D26:p0009:u0018, D26:p0009:u0019, D26:p0009:u0020, D26:p0009:u0021
**Общая страница с:** AI-06-05
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Example (WUMPUS WORLD)
Environment
- 
sq 1-1 is agent
- 
sq 1-2 is pit
- 
sq 1-3 is gold
- 
sq 2-3 contain Wumpus
Actions
- 
Move from sq to adj sq
- 
Kill Wumpus with arrow
- 
Take Gold
Goal
- 
Get gold & Return back
to start pos
````

## D26 — Week 9 Lab.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/26_Week 9 Lab/source.pdf#page=10`
Строки (ID элементов): D26:p0010:u0001, D26:p0010:u0002, D26:p0010:u0003
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
Environment Setup
- 
We will use PDDL Online Editor
````


---

# AI-07-01 — Эволюционный цикл популяции решений

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Разбери одну итерацию EA: представление, fitness, selection, variation и replacement.
**Пункты РПД:** RPD-26

**Связанные страницы:** 6; **символов извлечённого текста:** 2924.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D11 — Week 10 Lecture.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=5`
Строки (ID элементов): D11:p0005:u0001, D11:p0005:u0002, D11:p0005:u0003, D11:p0005:u0004, D11:p0005:u0005, D11:p0005:u0006, D11:p0005:u0007, D11:p0005:u0008, D11:p0005:u0009, D11:p0005:u0010, D11:p0005:u0011, D11:p0005:u0012, D11:p0005:u0013, D11:p0005:u0014, D11:p0005:u0015, D11:p0005:u0016, D11:p0005:u0017

````text
Evolutionary Algorithms
- 
Use the concepts of the Neo-Darwinian Synthesis or Lamarckian Evolution
- Natural Selection
- Inheritable Traits
- Fitness Biased Reproduction
- Fitness evaluates individuals
- Generational/Time Series
- 
Four major overarching techniques discovered about 1980
- Genetic Algorithms - Holland
- Genetic Programming - Koza
- Evolutionary Programming - Fogel
- Evolutionary Strategies – Rechenberg/Schwefel
- 
Large arguments about priority of technique leads to a compromise on the title of
Evolutionary Algorithms – schisms still fighting for dominance
````

## D11 — Week 10 Lecture.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=6`
Строки (ID элементов): D11:p0006:u0001, D11:p0006:u0002, D11:p0006:u0003, D11:p0006:u0004, D11:p0006:u0005, D11:p0006:u0006, D11:p0006:u0007, D11:p0006:u0008, D11:p0006:u0009, D11:p0006:u0010, D11:p0006:u0011, D11:p0006:u0012, D11:p0006:u0013

````text
EA System
- Create a randomized population made up of chromosomes, data
structures which encode a potential solution
- Until <Done>, based on a stopping criteria
- Find an objective/fitness score for each member of the population
- Select members to act upon using some variation operators
- Apply operations on the members
- Crossover
- Mutations
- Replace some members of the population with these children from the variation
operators
- Keep some members from the previous population in the new population, i.e.
elitism/inheritance
````

## D11 — Week 10 Lecture.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=7`
Строки (ID элементов): D11:p0007:u0001, D11:p0007:u0002, D11:p0007:u0003, D11:p0007:u0004, D11:p0007:u0005, D11:p0007:u0006, D11:p0007:u0007, D11:p0007:u0008, D11:p0007:u0009
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Selection
- Cartoon of the ideas of Natural Selection by Charles Darwin
- Provides a fitness-biased method of keeping good structures
- Note: BIASED not based
- We can still accept ‘worst’ choices
- Structures which have a higher
fitness on the objective score are
more likely to continue on in the
population
````

## D11 — Week 10 Lecture.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=8`
Строки (ID элементов): D11:p0008:u0001, D11:p0008:u0002, D11:p0008:u0003, D11:p0008:u0004, D11:p0008:u0005, D11:p0008:u0006, D11:p0008:u0007, D11:p0008:u0008, D11:p0008:u0009, D11:p0008:u0010, D11:p0008:u0011, D11:p0008:u0012
**Общая страница с:** AI-07-02
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Survival of the Fittest
- Major misconceptions in the application of this phrase
- Darwin didn’t coin it – nor was it used until the 5th edition of “The Origin of
Species” (1869)
- Used by Herbert Spencer in Principles of Biology in 1864
- "This survival of the fittest, which I have here sought
to express in mechanical terms, is that which
Mr. Darwin has called 'natural selection', or
the preservation of favoured races in the struggle
for life.“
- Darwin’s use was based on the fitness of a creature to
survive in a local environment
````

## D11 — Week 10 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=9`
Строки (ID элементов): D11:p0009:u0001, D11:p0009:u0002, D11:p0009:u0003, D11:p0009:u0004, D11:p0009:u0005, D11:p0009:u0006, D11:p0009:u0007, D11:p0009:u0008, D11:p0009:u0009, D11:p0009:u0010, D11:p0009:u0011, D11:p0009:u0012, D11:p0009:u0013, D11:p0009:u0016, D11:p0009:u0017, D11:p0009:u0018
**Общая страница с:** AI-07-02
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Biological Fitness
- The phrase seems to imply that there is an innate idea of what is
FIT/UNFIT
- Post Hoc Ergo Propter Hoc Fallacy or Post Hoc Fallacy
- The creature survived as it was fit
- The creature is fit because it has survived
- Biological Fitness is defined as the number of offspring which
reach sexual maturity and are able to pass along their genes
- Male praying mantis killed by female praying mantis may be
biologically fit, if many eggs were produced. Even,
- Evolutionary Algorithms fall under this misconception – we apply
fitness as a post hoc
- So, biological fitness is usually differing from EA fitness
What is the secret
of your long and
happy marriage?
````

## D11 — Week 10 Lecture.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=15`
Строки (ID элементов): D11:p0015:u0001, D11:p0015:u0002, D11:p0015:u0003, D11:p0015:u0004, D11:p0015:u0005, D11:p0015:u0006, D11:p0015:u0007, D11:p0015:u0008, D11:p0015:u0009, D11:p0015:u0010
**Общая страница с:** AI-07-05

````text
Genetic Algorithms (GA)
- Representation
- Data Structure (commonly a discrete string)
- Selection
- Fitness Proportional or Tournament
- Crossover
- Yes. Data Structure Dependent
- Mutation
- Yes. Data Structure Dependent, commonly a small change to a percentage of
symbols in the string
````


---

# AI-07-02 — Фитнес-функция и отбор

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Предложи функцию приспособленности и сравни последствия двух разных шкал оценки.
**Пункты РПД:** —

**Связанные страницы:** 7; **символов извлечённого текста:** 2460.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D11 — Week 10 Lecture.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=8`
Строки (ID элементов): D11:p0008:u0001, D11:p0008:u0002, D11:p0008:u0003, D11:p0008:u0004, D11:p0008:u0005, D11:p0008:u0006, D11:p0008:u0007, D11:p0008:u0008, D11:p0008:u0009, D11:p0008:u0010, D11:p0008:u0011, D11:p0008:u0012
**Общая страница с:** AI-07-01
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Survival of the Fittest
- Major misconceptions in the application of this phrase
- Darwin didn’t coin it – nor was it used until the 5th edition of “The Origin of
Species” (1869)
- Used by Herbert Spencer in Principles of Biology in 1864
- "This survival of the fittest, which I have here sought
to express in mechanical terms, is that which
Mr. Darwin has called 'natural selection', or
the preservation of favoured races in the struggle
for life.“
- Darwin’s use was based on the fitness of a creature to
survive in a local environment
````

## D11 — Week 10 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=9`
Строки (ID элементов): D11:p0009:u0001, D11:p0009:u0002, D11:p0009:u0003, D11:p0009:u0004, D11:p0009:u0005, D11:p0009:u0006, D11:p0009:u0007, D11:p0009:u0008, D11:p0009:u0009, D11:p0009:u0010, D11:p0009:u0011, D11:p0009:u0012, D11:p0009:u0013, D11:p0009:u0016, D11:p0009:u0017, D11:p0009:u0018
**Общая страница с:** AI-07-01
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Biological Fitness
- The phrase seems to imply that there is an innate idea of what is
FIT/UNFIT
- Post Hoc Ergo Propter Hoc Fallacy or Post Hoc Fallacy
- The creature survived as it was fit
- The creature is fit because it has survived
- Biological Fitness is defined as the number of offspring which
reach sexual maturity and are able to pass along their genes
- Male praying mantis killed by female praying mantis may be
biologically fit, if many eggs were produced. Even,
- Evolutionary Algorithms fall under this misconception – we apply
fitness as a post hoc
- So, biological fitness is usually differing from EA fitness
What is the secret
of your long and
happy marriage?
````

## D11 — Week 10 Lecture.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=10`
Строки (ID элементов): D11:p0010:u0001, D11:p0010:u0002, D11:p0010:u0003, D11:p0010:u0004, D11:p0010:u0005, D11:p0010:u0006
**Общая страница с:** AI-07-03

````text
Selection
- The selection of parents for further breeding can be in different ways:
- Roulette selection
- Rank selection
- Single tournament
- Double tournament
````

## D25 — Week 7 Lecture.pdf, PDF-страница 41
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=41`
Строки (ID элементов): D25:p0041:u0001, D25:p0041:u0003, D25:p0041:u0004, D25:p0041:u0005, D25:p0041:u0006, D25:p0041:u0007
**Общая страница с:** AI-04-22

````text
Fitness Landscapes
Evolutionary biologist Sewall Wright came up with the idea of fitness
landscapes back in 1932. His maps displayed reproductive success, or
fitness of individual organisms as a function of genotype (an organism's
genetic constitution) or phenotype (or organism's observable physical
characteristics)
````

## D25 — Week 7 Lecture.pdf, PDF-страница 42
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=42`
Строки (ID элементов): D25:p0042:u0018, D25:p0042:u0019, D25:p0042:u0020
**Общая страница с:** AI-04-22
**Непроверенные OCR/формулы:** 15 исключённых из основного текста кандидатов; см. JSON.

````text
Figure 2—Diagrammatic representation of the field of gene combinations in two dimen-
sions instead of many thousands. Dotted lines represent contours with respect to adap-
tiveness.
````

## D25 — Week 7 Lecture.pdf, PDF-страница 43
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=43`
Строки (ID элементов): D25:p0043:u0001, D25:p0043:u0003, D25:p0043:u0005, D25:p0043:u0007, D25:p0043:u0009, D25:p0043:u0011, D25:p0043:u0013, D25:p0043:u0015, D25:p0043:u0017
**Общая страница с:** AI-04-22

````text
Quantify the Problem
Is our problem smooth or rough?
How smooth or rough?
Can we quantify this?
Do we have gaps?
Areas were our parameters
Can we visualize this?
Visuals are helpful to our understanding
Demonstrate problems to others
````

## D25 — Week 7 Lecture.pdf, PDF-страница 44
Источник в ZIP: `AI_course_cleaned/25_Week 7 Lecture/source.pdf#page=44`
Строки (ID элементов): D25:p0044:u0001, D25:p0044:u0007, D25:p0044:u0008, D25:p0044:u0009, D25:p0044:u0010, D25:p0044:u0011
**Общая страница с:** AI-04-22

````text
Fitness Landscape
fitness landscape is a Tuple L = (S,f,N) where S is the search space of
feasible solutions, f:S > R is a fitness function, and N(s) is the set of
neighbouring points for a member of S such that they can be reached by a
single application of the search operation
® This defines a 3-dimensional space which can be projected as a mountain
````


---

# AI-07-03 — Пропорциональный отбор roulette wheel

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Вычисли вероятности отбора и смоделируй выбор двух родителей.
**Пункты РПД:** —

**Связанные страницы:** 2; **символов извлечённого текста:** 521.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D11 — Week 10 Lecture.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=10`
Строки (ID элементов): D11:p0010:u0001, D11:p0010:u0002, D11:p0010:u0003, D11:p0010:u0004, D11:p0010:u0005, D11:p0010:u0006
**Общая страница с:** AI-07-02

````text
Selection
- The selection of parents for further breeding can be in different ways:
- Roulette selection
- Rank selection
- Single tournament
- Double tournament
````

## D11 — Week 10 Lecture.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=11`
Строки (ID элементов): D11:p0011:u0001, D11:p0011:u0002, D11:p0011:u0003, D11:p0011:u0004, D11:p0011:u0005, D11:p0011:u0006, D11:p0011:u0007, D11:p0011:u0008, D11:p0011:u0009, D11:p0011:u0010, D11:p0011:u0011, D11:p0011:u0028, D11:p0011:u0032, D11:p0011:u0035, D11:p0011:u0036, D11:p0011:u0038, D11:p0011:u0039, D11:p0011:u0041
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
Fitness Proportional (Roulette Wheel
Selection)
- Each member is given
a section of the wheel
in relation to their
fitness score
- Member fitness/
Sum of all member fitness
- Wheel is spun for a
number of times
- Winners Breed Together
point
Fittest individual
the roulette wheel
has largest share of
Weakest individual
has smallest share of
the roulette wheel
````


---

# AI-07-04 — Ранговый и турнирный отбор

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Сравни rank selection и tournament на заданной популяции и обоснуй выбор.
**Пункты РПД:** —

**Связанные страницы:** 3; **символов извлечённого текста:** 1520.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D11 — Week 10 Lecture.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=12`
Строки (ID элементов): D11:p0012:u0001, D11:p0012:u0002, D11:p0012:u0003, D11:p0012:u0004, D11:p0012:u0005, D11:p0012:u0006, D11:p0012:u0007, D11:p0012:u0008, D11:p0012:u0009, D11:p0012:u0010, D11:p0012:u0011, D11:p0012:u0012, D11:p0012:u0013, D11:p0012:u0024

````text
Rank Selection
- Rank selection works in a fashion similar to
roulette wheel selection except that the
creatures are ordered by fitness (ascending
order) and then selected by their rank instead
of their fitness
- If creature 𝑖has rank 𝑓!, then the probability of
being picked is
"!
#, where 𝐹is the sum of the
ranks of the entire population
- The least fit creature is given a rank of 1 so as
to give it the smallest chance of being picked.
Pointer
````

## D11 — Week 10 Lecture.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=13`
Строки (ID элементов): D11:p0013:u0001, D11:p0013:u0002, D11:p0013:u0003, D11:p0013:u0004, D11:p0013:u0005, D11:p0013:u0006, D11:p0013:u0015, D11:p0013:u0016, D11:p0013:u0018, D11:p0013:u0020, D11:p0013:u0021, D11:p0013:u0023, D11:p0013:u0024, D11:p0013:u0026, D11:p0013:u0027, D11:p0013:u0029, D11:p0013:u0030, D11:p0013:u0032, D11:p0013:u0033, D11:p0013:u0035, D11:p0013:u0036
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
Roulette vs Rank Selection
- An advantage of rank-based selection can be seen in the fact that it also
gives worse individuals a higher chance to reproduce and thus to improve
- If there is a strong fitness gradient, then roulette wheel selection gives a
stronger fitness bias than rank selection and, hence, tends to take the
population to a nearly uniform type faster
Creature # | Fitness
Rank | P(chosen) | P(chosen)
Rank
0.099
0.048
0.169
0.238
0.333
0.286
0.113
0.095
0.164
0.190
0.122
0.143
````

## D11 — Week 10 Lecture.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=14`
Строки (ID элементов): D11:p0014:u0001, D11:p0014:u0002, D11:p0014:u0003, D11:p0014:u0004, D11:p0014:u0005, D11:p0014:u0006, D11:p0014:u0007, D11:p0014:u0008, D11:p0014:u0009, D11:p0014:u0010, D11:p0014:u0011, D11:p0014:u0012, D11:p0014:u0013

````text
Tournament
- A number of different manners are held for the construction of the challengers
- At random (single tournament)
- Groups of N (double tournament)
- Pick a group of 𝑁creatures and take the single most fit one as a parent, repeating the process
with a new group of 𝑁creatures to get a second parent
- Each of the structures in a tournament is compared and the most fit continues
on to breed
- Fighting solutions
- Selection Pressure (the likelihood of only selecting from the higher fitness cohorts
is a controllable feature)
- Small Tournaments
- Larger Tournaments
````


---

# AI-07-05 — Хромосома и генетический алгоритм

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Закодируй решение в хромосому и покажи полный цикл GA.
**Пункты РПД:** RPD-27

**Связанные страницы:** 9; **символов извлечённого текста:** 1476.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D11 — Week 10 Lecture.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=15`
Строки (ID элементов): D11:p0015:u0001, D11:p0015:u0002, D11:p0015:u0003, D11:p0015:u0004, D11:p0015:u0005, D11:p0015:u0006, D11:p0015:u0007, D11:p0015:u0008, D11:p0015:u0009, D11:p0015:u0010
**Общая страница с:** AI-07-01

````text
Genetic Algorithms (GA)
- Representation
- Data Structure (commonly a discrete string)
- Selection
- Fitness Proportional or Tournament
- Crossover
- Yes. Data Structure Dependent
- Mutation
- Yes. Data Structure Dependent, commonly a small change to a percentage of
symbols in the string
````

## D11 — Week 10 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=16`
Строки (ID элементов): D11:p0016:u0001, D11:p0016:u0002, D11:p0016:u0003, D11:p0016:u0004, D11:p0016:u0005, D11:p0016:u0006, D11:p0016:u0007, D11:p0016:u0008, D11:p0016:u0009, D11:p0016:u0010, D11:p0016:u0014, D11:p0016:u0015, D11:p0016:u0016, D11:p0016:u0018, D11:p0016:u0023, D11:p0016:u0024, D11:p0016:u0029, D11:p0016:u0034, D11:p0016:u0043, D11:p0016:u0044, D11:p0016:u0051, D11:p0016:u0053
**Общая страница с:** AI-07-06
**Непроверенные OCR/формулы:** 17 исключённых из основного текста кандидатов; см. JSON.

````text
Crossover in Biology
- Process of Meiosis
- Creation of gamete cells
- Sex cells
- From Greek for ‘wife’
- Haploid creatures have
chromosome pairs
- Biological crossover is NOT a
representation of the actions
happening in EAs
Prophase |
chromatids
Nonsister
Tetrad
site of
over
Metaphase |
Metaphase Il
cells
Daughter
Recombinant
chromosomes
````

## D11 — Week 10 Lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=17`
Строки (ID элементов): D11:p0017:u0001, D11:p0017:u0004
**Общая страница с:** AI-07-06

````text
Crossover in a GA on Strings
Two parent strings
````

## D11 — Week 10 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=18`
Строки (ID элементов): D11:p0018:u0001, D11:p0018:u0002, D11:p0018:u0003, D11:p0018:u0004, D11:p0018:u0007
**Общая страница с:** AI-07-06
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Crossover in a GA on Strings
One Point – Select One
Point at Random and
Swap
Two parent strings
````

## D11 — Week 10 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=19`
Строки (ID элементов): D11:p0019:u0001, D11:p0019:u0002, D11:p0019:u0003, D11:p0019:u0004, D11:p0019:u0005, D11:p0019:u0006, D11:p0019:u0007, D11:p0019:u0010
**Общая страница с:** AI-07-06
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Crossover in a GA on Strings
One Point – Select One
Point at Random and
Swap
Two Point – Select Two
Points at Random and
Swap
Two parent strings
````

## D11 — Week 10 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=20`
Строки (ID элементов): D11:p0020:u0001, D11:p0020:u0002, D11:p0020:u0003, D11:p0020:u0004, D11:p0020:u0005, D11:p0020:u0006, D11:p0020:u0007, D11:p0020:u0008, D11:p0020:u0009, D11:p0020:u0012
**Общая страница с:** AI-07-06
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Crossover in a GA on Strings
One Point – Select One
Point at Random and
Swap
Two Point – Select Two
Points at Random and
Swap
Uniform Order – Swap all
with Probability of 0.5
Two parent strings
````

## D11 — Week 10 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=21`
Строки (ID элементов): D11:p0021:u0001, D11:p0021:u0002, D11:p0021:u0003, D11:p0021:u0004, D11:p0021:u0005, D11:p0021:u0008
**Общая страница с:** AI-07-06

````text
Mutation in a GA on Strings
A
a
B
b
Two separate strings
````

## D11 — Week 10 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=22`
Строки (ID элементов): D11:p0022:u0001, D11:p0022:u0002, D11:p0022:u0003, D11:p0022:u0004, D11:p0022:u0005, D11:p0022:u0006, D11:p0022:u0007, D11:p0022:u0008, D11:p0022:u0009, D11:p0022:u0010, D11:p0022:u0011, D11:p0022:u0012, D11:p0022:u0015
**Общая страница с:** AI-07-06

````text
Mutation in a GA on Strings
A
a
B
b
a
a
B
B
Point Mutation – Change
the Symbol at a Loci to
Some Other Symbol
Two separate strings
````

## D11 — Week 10 Lecture.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=23`
Строки (ID элементов): D11:p0023:u0001, D11:p0023:u0002, D11:p0023:u0003, D11:p0023:u0004, D11:p0023:u0005, D11:p0023:u0006, D11:p0023:u0007, D11:p0023:u0008, D11:p0023:u0009, D11:p0023:u0010, D11:p0023:u0011, D11:p0023:u0012, D11:p0023:u0013, D11:p0023:u0014, D11:p0023:u0015, D11:p0023:u0016, D11:p0023:u0017, D11:p0023:u0018, D11:p0023:u0021
**Общая страница с:** AI-07-06

````text
Mutation in a GA on Strings
A
a
B
b
a
a
B
B
a
A
b
B
Point Mutation – Change
the Symbol at a Loci to
Some Other Symbol
Swap Mutation – Swap
Two Loci in the String
Two separate strings
````


---

# AI-07-06 — Кроссовер и мутация строковых хромосом

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Построй детей после одноточечного кроссовера и мутации с сохранением допустимости.
**Пункты РПД:** RPD-27

**Связанные страницы:** 8; **символов извлечённого текста:** 1188.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D11 — Week 10 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=16`
Строки (ID элементов): D11:p0016:u0001, D11:p0016:u0002, D11:p0016:u0003, D11:p0016:u0004, D11:p0016:u0005, D11:p0016:u0006, D11:p0016:u0007, D11:p0016:u0008, D11:p0016:u0009, D11:p0016:u0010, D11:p0016:u0014, D11:p0016:u0015, D11:p0016:u0016, D11:p0016:u0018, D11:p0016:u0023, D11:p0016:u0024, D11:p0016:u0029, D11:p0016:u0034, D11:p0016:u0043, D11:p0016:u0044, D11:p0016:u0051, D11:p0016:u0053
**Общая страница с:** AI-07-05
**Непроверенные OCR/формулы:** 17 исключённых из основного текста кандидатов; см. JSON.

````text
Crossover in Biology
- Process of Meiosis
- Creation of gamete cells
- Sex cells
- From Greek for ‘wife’
- Haploid creatures have
chromosome pairs
- Biological crossover is NOT a
representation of the actions
happening in EAs
Prophase |
chromatids
Nonsister
Tetrad
site of
over
Metaphase |
Metaphase Il
cells
Daughter
Recombinant
chromosomes
````

## D11 — Week 10 Lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=17`
Строки (ID элементов): D11:p0017:u0001, D11:p0017:u0004
**Общая страница с:** AI-07-05

````text
Crossover in a GA on Strings
Two parent strings
````

## D11 — Week 10 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=18`
Строки (ID элементов): D11:p0018:u0001, D11:p0018:u0002, D11:p0018:u0003, D11:p0018:u0004, D11:p0018:u0007
**Общая страница с:** AI-07-05
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Crossover in a GA on Strings
One Point – Select One
Point at Random and
Swap
Two parent strings
````

## D11 — Week 10 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=19`
Строки (ID элементов): D11:p0019:u0001, D11:p0019:u0002, D11:p0019:u0003, D11:p0019:u0004, D11:p0019:u0005, D11:p0019:u0006, D11:p0019:u0007, D11:p0019:u0010
**Общая страница с:** AI-07-05
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Crossover in a GA on Strings
One Point – Select One
Point at Random and
Swap
Two Point – Select Two
Points at Random and
Swap
Two parent strings
````

## D11 — Week 10 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=20`
Строки (ID элементов): D11:p0020:u0001, D11:p0020:u0002, D11:p0020:u0003, D11:p0020:u0004, D11:p0020:u0005, D11:p0020:u0006, D11:p0020:u0007, D11:p0020:u0008, D11:p0020:u0009, D11:p0020:u0012
**Общая страница с:** AI-07-05
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Crossover in a GA on Strings
One Point – Select One
Point at Random and
Swap
Two Point – Select Two
Points at Random and
Swap
Uniform Order – Swap all
with Probability of 0.5
Two parent strings
````

## D11 — Week 10 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=21`
Строки (ID элементов): D11:p0021:u0001, D11:p0021:u0002, D11:p0021:u0003, D11:p0021:u0004, D11:p0021:u0005, D11:p0021:u0008
**Общая страница с:** AI-07-05

````text
Mutation in a GA on Strings
A
a
B
b
Two separate strings
````

## D11 — Week 10 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=22`
Строки (ID элементов): D11:p0022:u0001, D11:p0022:u0002, D11:p0022:u0003, D11:p0022:u0004, D11:p0022:u0005, D11:p0022:u0006, D11:p0022:u0007, D11:p0022:u0008, D11:p0022:u0009, D11:p0022:u0010, D11:p0022:u0011, D11:p0022:u0012, D11:p0022:u0015
**Общая страница с:** AI-07-05

````text
Mutation in a GA on Strings
A
a
B
b
a
a
B
B
Point Mutation – Change
the Symbol at a Loci to
Some Other Symbol
Two separate strings
````

## D11 — Week 10 Lecture.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=23`
Строки (ID элементов): D11:p0023:u0001, D11:p0023:u0002, D11:p0023:u0003, D11:p0023:u0004, D11:p0023:u0005, D11:p0023:u0006, D11:p0023:u0007, D11:p0023:u0008, D11:p0023:u0009, D11:p0023:u0010, D11:p0023:u0011, D11:p0023:u0012, D11:p0023:u0013, D11:p0023:u0014, D11:p0023:u0015, D11:p0023:u0016, D11:p0023:u0017, D11:p0023:u0018, D11:p0023:u0021
**Общая страница с:** AI-07-05

````text
Mutation in a GA on Strings
A
a
B
b
a
a
B
B
a
A
b
B
Point Mutation – Change
the Symbol at a Loci to
Some Other Symbol
Swap Mutation – Swap
Two Loci in the String
Two separate strings
````


---

# AI-07-07 — Деревья генетического программирования

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Изобрази GP-дерево выражения и проведи корректный кроссовер поддеревьев.
**Пункты РПД:** RPD-28

**Связанные страницы:** 8; **символов извлечённого текста:** 1008.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D11 — Week 10 Lecture.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=24`
Строки (ID элементов): D11:p0024:u0001, D11:p0024:u0002, D11:p0024:u0003, D11:p0024:u0004, D11:p0024:u0005, D11:p0024:u0006, D11:p0024:u0007, D11:p0024:u0008, D11:p0024:u0009, D11:p0024:u0010, D11:p0024:u0011, D11:p0024:u0012

````text
Genetic Programming (GP)
- Representation
- Tree-based
- Selection
- Fitness Proportional or Tournament
- Crossover
- Yes. Branches of the Trees are Exchanged
- Mutation
- Yes. Leaf value/Symbol Change or Operator Change
- Special Operations
- Yes. Removal of Extra Symbols called bloat. Functions may be defined as shorter
symbols (ADF - Automatically Defined Functions)
````

## D11 — Week 10 Lecture.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=25`
Строки (ID элементов): D11:p0025:u0001, D11:p0025:u0002, D11:p0025:u0003, D11:p0025:u0004, D11:p0025:u0005, D11:p0025:u0006, D11:p0025:u0007, D11:p0025:u0008, D11:p0025:u0009, D11:p0025:u0010

````text
GP Parse Trees and LISP
- The idea comes from the programming language of LISP
- (function, arg1, arg2, …, argN)
- Arguments are functions or terminals
- Terminals are literals (1, `x`) or variables (x, count)
- LISP allows for programs which manipulate code and run that code
- Other languages need to create a simulator
- Prefix notation e.g. (+ 1 (∗7 𝑥)) is 1 + 7𝑥
- No need for order of operations – all operations are explicitly ordered by
brackets
````

## D11 — Week 10 Lecture.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=26`
Строки (ID элементов): D11:p0026:u0001, D11:p0026:u0002, D11:p0026:u0003
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Crossover in a GP Tree
Branch
Swap
````

## D11 — Week 10 Lecture.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=27`
Строки (ID элементов): D11:p0027:u0001
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Crossover in a GP Tree
````

## D11 — Week 10 Lecture.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=28`
Строки (ID элементов): D11:p0028:u0001
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Mutation of a Terminal in a GP Tree
````

## D11 — Week 10 Lecture.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=29`
Строки (ID элементов): D11:p0029:u0001

````text
Mutation of an Operation in a GP Tree
````

## D11 — Week 10 Lecture.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=30`
Строки (ID элементов): D11:p0030:u0001
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Growing Operation in a GP Tree
````

## D11 — Week 10 Lecture.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=31`
Строки (ID элементов): D11:p0031:u0001
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Cut Operation in a GP Tree
````


---

# AI-07-08 — Ограничения типов и разрастание деревьев GP

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Найди bloat в GP-дереве и предложи ограничение сложности без потери решения.
**Пункты РПД:** —

**Связанные страницы:** 9; **символов извлечённого текста:** 2942.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D11 — Week 10 Lecture.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=32`
Строки (ID элементов): D11:p0032:u0001, D11:p0032:u0002, D11:p0032:u0003, D11:p0032:u0004, D11:p0032:u0005, D11:p0032:u0006, D11:p0032:u0007, D11:p0032:u0008
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
ADF Trees
- ADF – Automatically Defined Functions
- Many Times we have a tree computed again and again – repetition is
costly
- Allow for the construction of GPs with smaller GP trees – construct a
hierarchy
ADF
ADF
````

## D11 — Week 10 Lecture.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=33`
Строки (ID элементов): D11:p0033:u0001, D11:p0033:u0002, D11:p0033:u0003, D11:p0033:u0004, D11:p0033:u0005

````text
Rules on Functions in Trees
- All trees should produce `legal` programs
- Operations which produce common errors – such as divide by zero – should
have a protected version that explicitly maps those errors to a legal input
value – such as 0
````

## D11 — Week 10 Lecture.pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=34`
Строки (ID элементов): D11:p0034:u0001, D11:p0034:u0002, D11:p0034:u0003, D11:p0034:u0004, D11:p0034:u0005, D11:p0034:u0006, D11:p0034:u0007, D11:p0034:u0008

````text
Bloat
- A number of operations provide no change in the result
- Anything multiplied by 1
- Anything added to 0
- A number of operations cancel out parts of the tree
- Anything multiplied by 0
- An operation followed by its inverse
- Leads to larger trees which are equally as fit as shorter ones
````

## D11 — Week 10 Lecture.pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=35`
Строки (ID элементов): D11:p0035:u0001, D11:p0035:u0002, D11:p0035:u0003, D11:p0035:u0004, D11:p0035:u0005, D11:p0035:u0006, D11:p0035:u0007, D11:p0035:u0008, D11:p0035:u0009, D11:p0035:u0010, D11:p0035:u0011, D11:p0035:u0012, D11:p0035:u0015, D11:p0035:u0016, D11:p0035:u0017, D11:p0035:u0018, D11:p0035:u0019, D11:p0035:u0020, D11:p0035:u0021, D11:p0035:u0022, D11:p0035:u0023, D11:p0035:u0024, D11:p0035:u0025, D11:p0035:u0026, D11:p0035:u0027

````text
Why does Bloat exist?
- Imagine two trees which both add 5 to 6:
1.
3 nodes
2.
10 nodes which add a value multiplied by 0
- You require a minimum number of 3 nodes to implement (+ 5 6)
- One for each of the arguments
- One for the operand
- 7 nodes in the second tree are bloat
- What is the probability that a mutation operation (change
operand/argument) will affect the solution to the problem?
+
5
6
+
5
6
+
*
0
+
4
2
7
````

## D11 — Week 10 Lecture.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=36`
Строки (ID элементов): D11:p0036:u0001, D11:p0036:u0002, D11:p0036:u0003, D11:p0036:u0004, D11:p0036:u0005, D11:p0036:u0006, D11:p0036:u0007, D11:p0036:u0008, D11:p0036:u0009

````text
Bloat Saves Solutions
- In the first tree the changing of an operation or argument will completely
change the result, 100% of the time it will change the outcome
- In the bloated tree, 3 nodes are part of our solution, one to add, and two to
multiply by 0. Changing these nodes will lead to a different answer
- Yet 4 nodes are inconsequential to the answer – 40% of the time there will
be no change in fitness based on a mutation
- Heritability – A solution with more of these null mutations is likely to have its
children survive as they have the same fitness
````

## D11 — Week 10 Lecture.pdf, PDF-страница 37
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=37`
Строки (ID элементов): D11:p0037:u0001, D11:p0037:u0002, D11:p0037:u0003, D11:p0037:u0004, D11:p0037:u0005, D11:p0037:u0006, D11:p0037:u0007, D11:p0037:u0008

````text
Bloat in Biology
- Repetition of genes
- Repetition of genes
- Duplication of genes
- Transposon Elements
- Repetition of genes
- Transposon Elements
- Not to be confused with redundant systems – Example Weight Loss Pill Trials
````

## D11 — Week 10 Lecture.pdf, PDF-страница 38
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=38`
Строки (ID элементов): D11:p0038:u0001, D11:p0038:u0002, D11:p0038:u0003, D11:p0038:u0004, D11:p0038:u0005, D11:p0038:u0006, D11:p0038:u0007, D11:p0038:u0008, D11:p0038:u0009
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Fat Blocking Pill
- Idea – We want to create a
diet pill
- Block the regulatory system in
the human body which
makes you gain weight
- Step 1 – find system
- Step 2 – create blocking drug
- Step 3 – clinical Trials on Mice
````

## D11 — Week 10 Lecture.pdf, PDF-страница 39
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=39`
Строки (ID элементов): D11:p0039:u0001, D11:p0039:u0002, D11:p0039:u0003, D11:p0039:u0004, D11:p0039:u0005, D11:p0039:u0006, D11:p0039:u0007, D11:p0039:u0008

````text
Mice Got Fatter
- The clinical trial showed the mice not only gained weight – they gained
more weight than the control on the same diet!
- But we Blocked the Signals
- Ah – but did you block all the signals?
- Mammals have a secondary fat producing system which will come into
effect when our primary system is compromised
- Issue – this secondary system is not as refined
````

## D11 — Week 10 Lecture.pdf, PDF-страница 40
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=40`
Строки (ID элементов): D11:p0040:u0001, D11:p0040:u0002, D11:p0040:u0003, D11:p0040:u0004, D11:p0040:u0005, D11:p0040:u0006, D11:p0040:u0007, D11:p0040:u0008, D11:p0040:u0009, D11:p0040:u0010

````text
Parsimony
- We like things simple in design of solutions
- It seems that a perfect design is not one which one looks for things to add, but is
one where there is nothing left to remove
- Let the trees grow but trim them at the result
- Penalize Larger Trees!
- Reduction in fitness score
- Less chance to Breed
- Find a method which does not use a tree-based model for the
representation
````


---

# AI-07-09 — Декартово генетическое программирование

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Кодируй небольшую программу в виде CGP-графа и покажи допустимую мутацию.
**Пункты РПД:** —

**Связанные страницы:** 6; **символов извлечённого текста:** 866.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D11 — Week 10 Lecture.pdf, PDF-страница 41
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=41`
Строки (ID элементов): D11:p0041:u0001, D11:p0041:u0002, D11:p0041:u0003, D11:p0041:u0004, D11:p0041:u0005, D11:p0041:u0006, D11:p0041:u0007, D11:p0041:u0008, D11:p0041:u0009
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Other Representations
- Directed Acyclic Graphs (DAG)
- Cartesian Genetic Programming
- Function Stacks
- Instead of Evolving Trees – Representation is graph
- Repeated input branches are passed down the DAG representation
- Removes the need to recompute
- Expansion and Bloat is limited – fixed size data structure
- Operated upon as if it was a linear chromosome in a GA
````

## D11 — Week 10 Lecture.pdf, PDF-страница 42
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=42`
Строки (ID элементов): D11:p0042:u0001, D11:p0042:u0002, D11:p0042:u0003
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Cartesian Genetic Programming
- NxM grid of Operations connected by wires
- Think Printed Circuit Boards
````

## D11 — Week 10 Lecture.pdf, PDF-страница 43
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=43`
Строки (ID элементов): D11:p0043:u0001
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Data Structure
````

## D11 — Week 10 Lecture.pdf, PDF-страница 44
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=44`
Строки (ID элементов): D11:p0044:u0001, D11:p0044:u0002
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Mutations Can Affect Nodes and
Edges
````

## D11 — Week 10 Lecture.pdf, PDF-страница 45
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=45`
Строки (ID элементов): D11:p0045:u0001
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Flip Operations
````

## D11 — Week 10 Lecture.pdf, PDF-страница 46
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=46`
Строки (ID элементов): D11:p0046:u0001, D11:p0046:u0002, D11:p0046:u0003, D11:p0046:u0004, D11:p0046:u0005, D11:p0046:u0006, D11:p0046:u0007, D11:p0046:u0008

````text
Function Stack Representation
- Function Stacks have a linear chromosome consisting of nodes
- Node Contains
- Function of 0..N inputs
- Inputs – Either Previous Nodes in Order of the Chromosome or an input value
- An Ephemeral Constant
- Crossover as per a linear string in a GA
- Mutations change the operation or constants
````


---

# AI-07-10 — Эволюционное программирование и конечные автоматы

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Приведи FSM-хромосому и выполни оператор мутации из evolutionary programming.
**Пункты РПД:** RPD-29

**Связанные страницы:** 4; **символов извлечённого текста:** 1159.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D11 — Week 10 Lecture.pdf, PDF-страница 47
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=47`
Строки (ID элементов): D11:p0047:u0001, D11:p0047:u0002, D11:p0047:u0003, D11:p0047:u0004, D11:p0047:u0005, D11:p0047:u0006, D11:p0047:u0007, D11:p0047:u0008, D11:p0047:u0009, D11:p0047:u0010

````text
Evolutionary Programming
- Representation
- Finite State Machine
- Selection
- Replace with a member of a sample of mutants if better than parent
- Crossover
- No*
- Mutation
- Yes. Add or Remove a node, or Change transition, output, or starting node
- Note: Designed for use in an online setting for controller
````

## D11 — Week 10 Lecture.pdf, PDF-страница 48
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=48`
Строки (ID элементов): D11:p0048:u0001, D11:p0048:u0002, D11:p0048:u0003, D11:p0048:u0004, D11:p0048:u0005, D11:p0048:u0006, D11:p0048:u0007, D11:p0048:u0008, D11:p0048:u0009

````text
Finite State Machine
- A deterministic finite state machine is defined by a tuple <Q, Σ, O, δ, ω, q>
𝑄, Σ, 𝛿, 𝑞%, 𝐹where:
- 𝑄– finite set of states
- Σ – a finite set of input symbols called the alphabet
- 𝛿– transition function 𝛿: 𝑄×Σ ⟶𝑄
- 𝑞! – initial starting state where 𝑞! ∈𝑄
- 𝐹– a set of accepting states 𝐹∈𝑄
- You can also define it via a state transition diagram
````

## D11 — Week 10 Lecture.pdf, PDF-страница 49
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=49`
Строки (ID элементов): D11:p0049:u0001, D11:p0049:u0004, D11:p0049:u0005, D11:p0049:u0006, D11:p0049:u0007, D11:p0049:u0008, D11:p0049:u0009, D11:p0049:u0010, D11:p0049:u0011, D11:p0049:u0012, D11:p0049:u0013, D11:p0049:u0014, D11:p0049:u0015
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Representations of a FSM
0
1
𝒒𝟎
𝑞"
𝑞#
𝒒𝟏
𝑞%
𝑞#
𝒒𝟐
∗
𝑞%
𝑞#
````

## D11 — Week 10 Lecture.pdf, PDF-страница 50
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=50`
Строки (ID элементов): D11:p0050:u0001, D11:p0050:u0002, D11:p0050:u0003, D11:p0050:u0004, D11:p0050:u0005, D11:p0050:u0006, D11:p0050:u0007, D11:p0050:u0008

````text
Mutations in EP FSM
- Mutations are insertions, deletions, changes to a transition, changes to an
output, change starting node
- Insertions – add a node and its connectors, find some set of random transitions to
place into it (do not want it isolated)
- Deletions – select a random node, all incoming transitions sent to other nodes at
random
- Change transition, change output, change initial state are self-explanatory
````


---

# AI-07-11 — Эволюционные стратегии и вещественные векторы

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Опиши ES над вещественным вектором, включая гауссовы мутации и выбор лучшего.
**Пункты РПД:** RPD-30

**Связанные страницы:** 4; **символов извлечённого текста:** 1587.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D11 — Week 10 Lecture.pdf, PDF-страница 51
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=51`
Строки (ID элементов): D11:p0051:u0001, D11:p0051:u0002, D11:p0051:u0003, D11:p0051:u0004, D11:p0051:u0005, D11:p0051:u0006, D11:p0051:u0007, D11:p0051:u0008, D11:p0051:u0009

````text
Evolutionary Strategies
- Representation
- Vector of Real Values
- Selection
- Replace with a member of a sample of mutations if better than parent
- Crossover
- Originally No, but has been added in some variants
- Mutation
- Yes. Add small normally distributed parameter to a value
````

## D11 — Week 10 Lecture.pdf, PDF-страница 52
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=52`
Строки (ID элементов): D11:p0052:u0001, D11:p0052:u0002, D11:p0052:u0003, D11:p0052:u0004, D11:p0052:u0005, D11:p0052:u0006, D11:p0052:u0007, D11:p0052:u0008, D11:p0052:u0009, D11:p0052:u0010, D11:p0052:u0011, D11:p0052:u0012, D11:p0052:u0013, D11:p0052:u0014, D11:p0052:u0015

````text
ES Bracketed Notation
- Normally Distributed Function of mutation is applied to the string of real
numbers – some use log normal.
- Variants:
1.
(1+1)-ES – a mutant is tested against its parent and the fittest is retained
2.
(1+λ)-ES – λ mutants are tested against their parent with the fittest remaining, the
parent retained if the best
3.
(1,λ)-ES – λ mutants are tested against their parent, the parent is never retained,
only one of mutants will continue on
4.
(µ/ρ+, λ)-ES – A population is used where a group of mutants is made for each
and compete with the set of parents, this may also have a crossover operation
````

## D11 — Week 10 Lecture.pdf, PDF-страница 53
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=53`
Строки (ID элементов): D11:p0053:u0001, D11:p0053:u0002, D11:p0053:u0003, D11:p0053:u0004

````text
Small Mutations
- Pull from the Gaussian/Normal Distribution
- Many Mutations will make small changes in parameters, few will make large
changes
````

## D11 — Week 10 Lecture.pdf, PDF-страница 54
Источник в ZIP: `AI_course_cleaned/11_Week 10 Lecture/source.pdf#page=54`
Строки (ID элементов): D11:p0054:u0001, D11:p0054:u0002, D11:p0054:u0003, D11:p0054:u0004, D11:p0054:u0005, D11:p0054:u0006, D11:p0054:u0007, D11:p0054:u0008, D11:p0054:u0009, D11:p0054:u0010, D11:p0054:u0011, D11:p0054:u0012

````text
Which Should I Use?
- No Free Lunches Here
- Note the similarities between Genetic Algorithms and Genetic
Programming – Key Difference is the type of representation
- Similarly Evolutionary Programming and Evolutionary Strategies differ based
on representation
- How you can represent your problem has a big effect on which of these
methods are available (more on this next time in the representation lecture)
- Speed and cost
- Speed of evaluation becomes a factor
- Crossover is more expensive
- Fitness evaluation is ALWAYS more expensive
````


---

# AI-07-12 — Прямое и косвенное кодирование генотипа

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Сравни два кодирования одного решения и объясни влияние на пространство поиска.
**Пункты РПД:** RPD-31

**Связанные страницы:** 14; **символов извлечённого текста:** 3867.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D12 — Week 11 Lecture.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=4`
Строки (ID элементов): D12:p0004:u0001, D12:p0004:u0002, D12:p0004:u0003, D12:p0004:u0004, D12:p0004:u0005, D12:p0004:u0006, D12:p0004:u0007, D12:p0004:u0008, D12:p0004:u0009, D12:p0004:u0010, D12:p0004:u0011, D12:p0004:u0012, D12:p0004:u0013, D12:p0004:u0017, D12:p0004:u0018, D12:p0004:u0020, D12:p0004:u0021, D12:p0004:u0023, D12:p0004:u0024, D12:p0004:u0025, D12:p0004:u0026
**Непроверенные OCR/формулы:** 10 исключённых из основного текста кандидатов; см. JSON.

````text
Direct v. Indirect Representations
- Genetics – Genotype v.
Phenotype
- We may have a translation step
between our internal
representation in the system v.
the traits perceived by someone
- The genotype of an organism is its
complete set of genetic material
- Genotype contributes to
phenotype, the observable traits
and characteristics in an
individual or organism
B = Brown Body
E = Red Eyes
b = Black Body
e = Brown Eyes
alleles
Female parent
alleles
Male parent
````

## D12 — Week 11 Lecture.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=5`
Строки (ID элементов): D12:p0005:u0001, D12:p0005:u0002, D12:p0005:u0003, D12:p0005:u0004, D12:p0005:u0005, D12:p0005:u0006, D12:p0005:u0007

````text
Direct Representation in Problems
- Direct Representation
- When the genotype and phenotype are the same
- Examples
- Settings on a machine
- Creation of a FSM or other controller
- Majority of optimizations have a direct search for the outcome
````

## D12 — Week 11 Lecture.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=6`
Строки (ID элементов): D12:p0006:u0001, D12:p0006:u0002, D12:p0006:u0003, D12:p0006:u0004, D12:p0006:u0005, D12:p0006:u0006, D12:p0006:u0007

````text
Indirect Representation in Problems
- Indirect Representation
- When the evolved values allow for the construction of a solution to the problem
- Examples
- Evolving a program for the solution
- This is an interesting emerging method for looking at evolution of structures
which leads to solutions or for the entire system
````

## D12 — Week 11 Lecture.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=7`
Строки (ID элементов): D12:p0007:u0001, D12:p0007:u0002, D12:p0007:u0003, D12:p0007:u0004, D12:p0007:u0005, D12:p0007:u0014, D12:p0007:u0015
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Dungeon Levels
- Genotype – a tree of tuples
- Phenotype – a board with
placement of rooms
- Translation step is required
Figure 1: Example translation from tree structure
into map.
````

## D12 — Week 11 Lecture.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=8`
Строки (ID элементов): D12:p0008:u0001, D12:p0008:u0002, D12:p0008:u0003, D12:p0008:u0004, D12:p0008:u0005, D12:p0008:u0006, D12:p0008:u0021
**Непроверенные OCR/формулы:** 9 исключённых из основного текста кандидатов; см. JSON.

````text
Mendelian Genetics
- Discovered by Gregor Johann Mendel in 1865,
but not popularized until Thomas Hunt Morgan in 1915
- Ratios of Pea Pods always in divisions of 1/4s
- Dominant and recessive traits
- Punnett Squares:
G|Gg| Gg
````

## D12 — Week 11 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=9`
Строки (ID элементов): D12:p0009:u0001, D12:p0009:u0002, D12:p0009:u0003, D12:p0009:u0004, D12:p0009:u0005

````text
What doesn’t kill you
makes for an interesting feature
- Sickle-cell diseases lead to a resistance to Malaria (Nature vol. 515 no.
7526)
- Серповидноклеточная анемия приводит к устойчивости к малярии
````

## D12 — Week 11 Lecture.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=10`
Строки (ID элементов): D12:p0010:u0009, D12:p0010:u0010, D12:p0010:u0013, D12:p0010:u0288
**Непроверенные OCR/формулы:** 399 исключённых из основного текста кандидатов; см. JSON.

````text
{Sicle-cell disease is often fatal in low -income nations. But researchers are beginning
Migration has led to an increase in the occurrence of sickle-cell disease in countries with
previously low incidence of the disorder.
2
````

## D12 — Week 11 Lecture.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=11`
Строки (ID элементов): D12:p0011:u0001, D12:p0011:u0002, D12:p0011:u0003, D12:p0011:u0004, D12:p0011:u0005, D12:p0011:u0006, D12:p0011:u0007, D12:p0011:u0008, D12:p0011:u0009, D12:p0011:u0010

````text
EA Representation
- A data structure and its defined variation operators
- Choice of representation defines the search space
- Defines the possible solutions
- Data structure choice
- Defines the connection
- Variation Operation
- How we represent a problem is a key to a good EA
- Good representations allow smaller search spaces and faster searches
through the space
````

## D12 — Week 11 Lecture.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=12`
Строки (ID элементов): D12:p0012:u0001, D12:p0012:u0002, D12:p0012:u0003, D12:p0012:u0004, D12:p0012:u0005, D12:p0012:u0006, D12:p0012:u0007, D12:p0012:u0008, D12:p0012:u0009, D12:p0012:u0010, D12:p0012:u0011, D12:p0012:u0012, D12:p0012:u0013, D12:p0012:u0014, D12:p0012:u0015, D12:p0012:u0016, D12:p0012:u0017, D12:p0012:u0018, D12:p0012:u0019, D12:p0012:u0020, D12:p0012:u0021, D12:p0012:u0022, D12:p0012:u0023, D12:p0012:u0024, D12:p0012:u0025, D12:p0012:u0026, D12:p0012:u0027, D12:p0012:u0028, D12:p0012:u0029, D12:p0012:u0030, D12:p0012:u0031, D12:p0012:u0032, D12:p0012:u0033, D12:p0012:u0034, D12:p0012:u0035, D12:p0012:u0036, D12:p0012:u0037, D12:p0012:u0038, D12:p0012:u0039, D12:p0012:u0040, D12:p0012:u0041, D12:p0012:u0042

````text
Self-avoiding Walks
- Take an NxN grid, a Self-
avoiding walk of size N-1
is a walk with NxN steps
visiting every square
once
V
>
V
>
V
X
V
^
V
^
V
^
V
^
V
^
V
^
V
^
V
^
V
^
V
^
V
^
V
^
>
^
>
^
>
^
````

## D12 — Week 11 Lecture.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=13`
Строки (ID элементов): D12:p0013:u0001, D12:p0013:u0002, D12:p0013:u0003, D12:p0013:u0004, D12:p0013:u0005, D12:p0013:u0006, D12:p0013:u0007, D12:p0013:u0008, D12:p0013:u0009, D12:p0013:u0010, D12:p0013:u0011, D12:p0013:u0012

````text
How Can We Represent an Agent’s
Movement?
- Directionally – we could put each of the movement directions into a string
- UP, DOWN, LEFT, RIGHT or U, D, L, R respectively
- The previous example would be:
- Down Down Down Down Down Right Up Up Up Up Up Right Down Down Down
Down Down Right Up Up Up Up Up Right Down Down Down Down Down Right Up
Up Up Up Up
- OR
- Down - X5, Right, Up - X5, Right, Down - X5, Right, Up - X5, Right, Down - X5, Right,
Up - X5
- The size of the search space is 4 directions raised to N-1 steps
````

## D12 — Week 11 Lecture.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=14`
Строки (ID элементов): D12:p0014:u0001, D12:p0014:u0002, D12:p0014:u0003, D12:p0014:u0004, D12:p0014:u0005, D12:p0014:u0006, D12:p0014:u0007, D12:p0014:u0008, D12:p0014:u0009, D12:p0014:u0010, D12:p0014:u0011, D12:p0014:u0012, D12:p0014:u0013, D12:p0014:u0014, D12:p0014:u0015, D12:p0014:u0016, D12:p0014:u0017, D12:p0014:u0018, D12:p0014:u0019, D12:p0014:u0020, D12:p0014:u0021, D12:p0014:u0022, D12:p0014:u0023, D12:p0014:u0024, D12:p0014:u0025, D12:p0014:u0026, D12:p0014:u0027, D12:p0014:u0028, D12:p0014:u0029, D12:p0014:u0030, D12:p0014:u0031, D12:p0014:u0032, D12:p0014:u0033, D12:p0014:u0034, D12:p0014:u0035, D12:p0014:u0036, D12:p0014:u0037

````text
Can We Do Better?
D
R
D
R
D
X
D
U
D
U
D
U
D
U
D
U
D
U
D
U
D
U
D
U
D
U
D
U
D
U
R
U
R
U
R
U
````

## D12 — Week 11 Lecture.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=15`
Строки (ID элементов): D12:p0015:u0001, D12:p0015:u0002, D12:p0015:u0003, D12:p0015:u0004, D12:p0015:u0005, D12:p0015:u0006, D12:p0015:u0007, D12:p0015:u0008, D12:p0015:u0009, D12:p0015:u0010, D12:p0015:u0011, D12:p0015:u0012

````text
Agent with Direction Saved
- Lets have an agent which saves its current direction it faces in
- Now movements are:
1. Forward (F)
2. Turn Left + Forward (L)
3. Turn Right + Forward (R)
- The solution string from before is:
- F F F F F R R F F F F R R F F F F R R F F F F R R F F F F R R F F F F
- Only 3 symbols raised to the N-1
- Large reduction in the search space
- 3^5 = 243
- 4^5 = 1024
````

## D12 — Week 11 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=16`
Строки (ID элементов): D12:p0016:u0001, D12:p0016:u0002, D12:p0016:u0003, D12:p0016:u0004, D12:p0016:u0005, D12:p0016:u0006, D12:p0016:u0007, D12:p0016:u0008, D12:p0016:u0009, D12:p0016:u0010, D12:p0016:u0011, D12:p0016:u0012, D12:p0016:u0013, D12:p0016:u0014, D12:p0016:u0015, D12:p0016:u0016, D12:p0016:u0017, D12:p0016:u0018, D12:p0016:u0019, D12:p0016:u0020, D12:p0016:u0021, D12:p0016:u0022, D12:p0016:u0023, D12:p0016:u0024, D12:p0016:u0025, D12:p0016:u0026, D12:p0016:u0027, D12:p0016:u0028, D12:p0016:u0029, D12:p0016:u0030, D12:p0016:u0031, D12:p0016:u0032, D12:p0016:u0033, D12:p0016:u0034, D12:p0016:u0035, D12:p0016:u0036, D12:p0016:u0037

````text
What Do We Lose?
F
R
R
R
R
X
F
F
F
F
F
F
F
F
F
F
F
F
F
F
F
F
F
F
F
F
F
F
F
F
R
R
R
R
R
R
````

## D12 — Week 11 Lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=17`
Строки (ID элементов): D12:p0017:u0001, D12:p0017:u0002, D12:p0017:u0003, D12:p0017:u0004, D12:p0017:u0005, D12:p0017:u0006, D12:p0017:u0007

````text
Search Space has been Reduced
- All legal walks still retained in the Saved Direction
- Walks where we backtrack are removed – remember this is not a
movement we would be interested in
- The only walks we have reduced from the solution space where those who
would never provide a correct solution – reduction of the space without
negative consequence
````


---

# AI-07-13 — Эпистаз и взаимодействие генов

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Предложи пример эпистаза и объясни, почему одиночная мутация может иметь нелокальный эффект.
**Пункты РПД:** RPD-32

**Связанные страницы:** 4; **символов извлечённого текста:** 1422.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D12 — Week 11 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=18`
Строки (ID элементов): D12:p0018:u0001, D12:p0018:u0002, D12:p0018:u0003, D12:p0018:u0004, D12:p0018:u0005, D12:p0018:u0006, D12:p0018:u0007, D12:p0018:u0008, D12:p0018:u0009, D12:p0018:u0010, D12:p0018:u0011, D12:p0018:u0012, D12:p0018:u0013

````text
Epistasis
- Epistatic gene in genetics: a gene that determines whether or not a trait will be
expressed
- Epistatic gene in EAs: the actions made in earlier parts of the chromosome
having larger impacts on the fitness value of the chromosome
- Epistatic gene in Self-avoiding Walk: actions made early in the string will have
large impacts on the fitness
- For example, changing the first move to a R will run the walk off the stage,
giving it 0 fitness rather than 35, whereas changing the last symbol to a R will
only reduce the fitness by 1. Assume that each correct movement gives 1 points
- F F F F F R R F F F F R R F F F F R R F F F F R R F F F F R R F F F F -> f(x) = 35
- (F->R) F F F F R R F F F F R R F F F F R R F F F F R R F F F F R R F F F F -> f(x) = 0
- F F F F F R R F F F F R R F F F F R R F F F F R R F F F F R R F F F (F->R) -> f(x) = 34
````

## D12 — Week 11 Lecture.pdf, PDF-страница 50
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=50`
Строки (ID элементов): D12:p0050:u0001, D12:p0050:u0002, D12:p0050:u0003, D12:p0050:u0004, D12:p0050:u0005, D12:p0050:u0006, D12:p0050:u0007, D12:p0050:u0008, D12:p0050:u0009
**Общая страница с:** AI-07-20

````text
Representational Issues
- Position within the chromosome has a large effect on the range and the
damage
- Systems ‘go down’ in order
- Expendable systems at front
- Important systems near end
- Win condition is a disabling of drives – ensure at least one drive is at the end of
the string
- Epistatic – with importance on the end of the string
````

## D12 — Week 11 Lecture.pdf, PDF-страница 51
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=51`
Строки (ID элементов): D12:p0051:u0001, D12:p0051:u0002, D12:p0051:u0003, D12:p0051:u0004
**Общая страница с:** AI-07-20

````text
Sunburn
- What crossovers would make sense?
- What crossovers would disrupt structure?
- What about the preferred distance?
````

## D12 — Week 11 Lecture.pdf, PDF-страница 52
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=52`
Строки (ID элементов): D12:p0052:u0001, D12:p0052:u0002, D12:p0052:u0003, D12:p0052:u0004, D12:p0052:u0005

````text
Summary
- Direct v. Indirect representation
- Epistatic gene
- Partially-mapped crossover
- Examples
````


---

# AI-07-14 — Кроссовер для перестановок в TSP

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Покажи PMX на двух маршрутах и объясни, почему обычный кроссовер может нарушить перестановку.
**Пункты РПД:** —

**Связанные страницы:** 10; **символов извлечённого текста:** 1418.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D12 — Week 11 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=19`
Строки (ID элементов): D12:p0019:u0001, D12:p0019:u0002, D12:p0019:u0003

````text
TSP-Ordered Gene
- GA’s representation is the tour of cities
- Natural idea of ordering in gene
````

## D12 — Week 11 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=20`
Строки (ID элементов): D12:p0020:u0001, D12:p0020:u0004, D12:p0020:u0005, D12:p0020:u0006, D12:p0020:u0007, D12:p0020:u0008, D12:p0020:u0009, D12:p0020:u0010, D12:p0020:u0011, D12:p0020:u0012, D12:p0020:u0013, D12:p0020:u0014, D12:p0020:u0015, D12:p0020:u0016, D12:p0020:u0017, D12:p0020:u0018, D12:p0020:u0019, D12:p0020:u0020, D12:p0020:u0021, D12:p0020:u0022, D12:p0020:u0023, D12:p0020:u0024, D12:p0020:u0025, D12:p0020:u0026, D12:p0020:u0027, D12:p0020:u0028, D12:p0020:u0029, D12:p0020:u0030, D12:p0020:u0031, D12:p0020:u0032, D12:p0020:u0033, D12:p0020:u0034, D12:p0020:u0035, D12:p0020:u0036, D12:p0020:u0037, D12:p0020:u0038, D12:p0020:u0039, D12:p0020:u0040, D12:p0020:u0041, D12:p0020:u0042, D12:p0020:u0043, D12:p0020:u0044, D12:p0020:u0045
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Two Point Crossover
Two parent strings
Two children strings
2
6
7
1
9
0
5
4
8
3
7
5
6
3
0
9
8
1
2
4
2
6
6
3
0
9
8
1
8
3
7
5
7
1
9
0
5
4
2
4
````

## D12 — Week 11 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=21`
Строки (ID элементов): D12:p0021:u0001, D12:p0021:u0004, D12:p0021:u0005, D12:p0021:u0006, D12:p0021:u0007, D12:p0021:u0008, D12:p0021:u0009, D12:p0021:u0010, D12:p0021:u0011, D12:p0021:u0012, D12:p0021:u0013, D12:p0021:u0014, D12:p0021:u0015, D12:p0021:u0016, D12:p0021:u0017, D12:p0021:u0018, D12:p0021:u0019, D12:p0021:u0020, D12:p0021:u0021, D12:p0021:u0022, D12:p0021:u0023, D12:p0021:u0024, D12:p0021:u0025, D12:p0021:u0026, D12:p0021:u0027, D12:p0021:u0028, D12:p0021:u0029, D12:p0021:u0030, D12:p0021:u0031, D12:p0021:u0032, D12:p0021:u0033, D12:p0021:u0034, D12:p0021:u0035, D12:p0021:u0036, D12:p0021:u0037, D12:p0021:u0038, D12:p0021:u0039, D12:p0021:u0040, D12:p0021:u0041, D12:p0021:u0042, D12:p0021:u0043, D12:p0021:u0044, D12:p0021:u0045
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Partially-Mapped Crossover
Two parent strings
Two children strings
2
6
7
1
9
0
5
4
8
3
7
5
6
3
0
9
8
1
2
4
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
*
````

## D12 — Week 11 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=22`
Строки (ID элементов): D12:p0022:u0001, D12:p0022:u0004, D12:p0022:u0005, D12:p0022:u0006, D12:p0022:u0007, D12:p0022:u0008, D12:p0022:u0009, D12:p0022:u0010, D12:p0022:u0011, D12:p0022:u0012, D12:p0022:u0013, D12:p0022:u0014, D12:p0022:u0015, D12:p0022:u0016, D12:p0022:u0017, D12:p0022:u0018, D12:p0022:u0019, D12:p0022:u0020, D12:p0022:u0021, D12:p0022:u0022, D12:p0022:u0023, D12:p0022:u0024, D12:p0022:u0025, D12:p0022:u0026, D12:p0022:u0027, D12:p0022:u0028, D12:p0022:u0029, D12:p0022:u0030, D12:p0022:u0031, D12:p0022:u0032, D12:p0022:u0033, D12:p0022:u0034, D12:p0022:u0035, D12:p0022:u0036, D12:p0022:u0037, D12:p0022:u0038, D12:p0022:u0039, D12:p0022:u0040, D12:p0022:u0041, D12:p0022:u0042, D12:p0022:u0043, D12:p0022:u0044, D12:p0022:u0045
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Partially-Mapped Crossover
Two parent strings
Two children strings
2
6
7
1
9
0
5
4
8
3
7
5
6
3
0
9
8
1
2
4
*
*
7
1
9
0
5
4
*
*
*
*
6
3
0
9
8
1
*
*
````

## D12 — Week 11 Lecture.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=23`
Строки (ID элементов): D12:p0023:u0001, D12:p0023:u0004, D12:p0023:u0005, D12:p0023:u0006, D12:p0023:u0007, D12:p0023:u0008, D12:p0023:u0009, D12:p0023:u0010, D12:p0023:u0011, D12:p0023:u0012, D12:p0023:u0013, D12:p0023:u0014, D12:p0023:u0015, D12:p0023:u0016, D12:p0023:u0017, D12:p0023:u0018, D12:p0023:u0019, D12:p0023:u0020, D12:p0023:u0021, D12:p0023:u0022, D12:p0023:u0023, D12:p0023:u0024, D12:p0023:u0025, D12:p0023:u0026, D12:p0023:u0027, D12:p0023:u0028, D12:p0023:u0029, D12:p0023:u0030, D12:p0023:u0031, D12:p0023:u0032, D12:p0023:u0033, D12:p0023:u0034, D12:p0023:u0035, D12:p0023:u0036, D12:p0023:u0037, D12:p0023:u0038, D12:p0023:u0039, D12:p0023:u0040, D12:p0023:u0041, D12:p0023:u0042, D12:p0023:u0043, D12:p0023:u0044, D12:p0023:u0045
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Partially-Mapped Crossover
Two parent strings
Two children strings
2
6
7
1
9
0
5
4
8
3
7
5
6
3
0
9
8
1
2
4
*
*
7
1
9
0
5
4
2
*
2
*
6
3
0
9
8
1
*
*
````

## D12 — Week 11 Lecture.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=24`
Строки (ID элементов): D12:p0024:u0001, D12:p0024:u0004, D12:p0024:u0005, D12:p0024:u0006, D12:p0024:u0007, D12:p0024:u0008, D12:p0024:u0009, D12:p0024:u0010, D12:p0024:u0011, D12:p0024:u0012, D12:p0024:u0013, D12:p0024:u0014, D12:p0024:u0015, D12:p0024:u0016, D12:p0024:u0017, D12:p0024:u0018, D12:p0024:u0019, D12:p0024:u0020, D12:p0024:u0021, D12:p0024:u0022, D12:p0024:u0023, D12:p0024:u0024, D12:p0024:u0025, D12:p0024:u0026, D12:p0024:u0027, D12:p0024:u0028, D12:p0024:u0029, D12:p0024:u0030, D12:p0024:u0031, D12:p0024:u0032, D12:p0024:u0033, D12:p0024:u0034, D12:p0024:u0035, D12:p0024:u0036, D12:p0024:u0037, D12:p0024:u0038, D12:p0024:u0039, D12:p0024:u0040, D12:p0024:u0041, D12:p0024:u0042, D12:p0024:u0043, D12:p0024:u0044, D12:p0024:u0045
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Partially-Mapped Crossover
Two parent strings
Two children strings
2
6
7
1
9
0
5
4
8
3
7
5
6
3
0
9
8
1
2
4
7
5
7
1
9
0
5
4
2
4
2
6
6
3
0
9
8
1
8
3
````

## D12 — Week 11 Lecture.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=25`
Строки (ID элементов): D12:p0025:u0001, D12:p0025:u0002, D12:p0025:u0003, D12:p0025:u0004, D12:p0025:u0005, D12:p0025:u0006, D12:p0025:u0007, D12:p0025:u0008, D12:p0025:u0009, D12:p0025:u0010, D12:p0025:u0011, D12:p0025:u0012, D12:p0025:u0013, D12:p0025:u0014, D12:p0025:u0015, D12:p0025:u0016, D12:p0025:u0017, D12:p0025:u0018, D12:p0025:u0019, D12:p0025:u0020, D12:p0025:u0021, D12:p0025:u0022, D12:p0025:u0023, D12:p0025:u0024, D12:p0025:u0025, D12:p0025:u0026, D12:p0025:u0027, D12:p0025:u0028, D12:p0025:u0029, D12:p0025:u0030, D12:p0025:u0031, D12:p0025:u0032, D12:p0025:u0033, D12:p0025:u0034, D12:p0025:u0035, D12:p0025:u0036, D12:p0025:u0037, D12:p0025:u0038, D12:p0025:u0039, D12:p0025:u0040, D12:p0025:u0041, D12:p0025:u0044, D12:p0025:u0045
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Partially-Mapped Crossover
2
6
7
1
9
0
5
4
8
3
7
5
6
3
0
9
8
1
2
4
7→6
5→8
7
1
9
0
5
4
2
4→1
2
6→7
6
3
0
9
8
1
8→5
3→1
Two parent strings
Two children strings
````

## D12 — Week 11 Lecture.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=26`
Строки (ID элементов): D12:p0026:u0001, D12:p0026:u0002, D12:p0026:u0003, D12:p0026:u0004, D12:p0026:u0005, D12:p0026:u0006, D12:p0026:u0007, D12:p0026:u0008, D12:p0026:u0009, D12:p0026:u0010, D12:p0026:u0011, D12:p0026:u0012, D12:p0026:u0013, D12:p0026:u0014, D12:p0026:u0015, D12:p0026:u0016, D12:p0026:u0017, D12:p0026:u0018, D12:p0026:u0019, D12:p0026:u0020, D12:p0026:u0021, D12:p0026:u0022, D12:p0026:u0023, D12:p0026:u0024, D12:p0026:u0025, D12:p0026:u0026, D12:p0026:u0027, D12:p0026:u0028, D12:p0026:u0029, D12:p0026:u0030, D12:p0026:u0031, D12:p0026:u0032, D12:p0026:u0033, D12:p0026:u0034, D12:p0026:u0035, D12:p0026:u0036, D12:p0026:u0037, D12:p0026:u0038, D12:p0026:u0039, D12:p0026:u0040, D12:p0026:u0041, D12:p0026:u0044, D12:p0026:u0045
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Partially-Mapped Crossover
2
6
7
1
9
0
5
4
8
3
7
5
6
3
0
9
8
1
2
4
6
8
7
1
9
0
5
4
2
1
2
7
6
3
0
9
8
1
5
1
Two parent strings
Two children strings
````

## D12 — Week 11 Lecture.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=27`
Строки (ID элементов): D12:p0027:u0001, D12:p0027:u0002, D12:p0027:u0003, D12:p0027:u0004, D12:p0027:u0005, D12:p0027:u0006, D12:p0027:u0007, D12:p0027:u0008, D12:p0027:u0009, D12:p0027:u0010, D12:p0027:u0011, D12:p0027:u0012, D12:p0027:u0013, D12:p0027:u0014, D12:p0027:u0015, D12:p0027:u0016, D12:p0027:u0017, D12:p0027:u0018, D12:p0027:u0019, D12:p0027:u0020, D12:p0027:u0021, D12:p0027:u0022, D12:p0027:u0023, D12:p0027:u0024, D12:p0027:u0025, D12:p0027:u0026, D12:p0027:u0027, D12:p0027:u0028, D12:p0027:u0029, D12:p0027:u0030, D12:p0027:u0031, D12:p0027:u0032, D12:p0027:u0033, D12:p0027:u0034, D12:p0027:u0035, D12:p0027:u0036, D12:p0027:u0037, D12:p0027:u0038, D12:p0027:u0039, D12:p0027:u0040, D12:p0027:u0041, D12:p0027:u0044, D12:p0027:u0045
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Partially-Mapped Crossover
2
6
7
1
9
0
5
4
8
3
7
5
6
3
0
9
8
1
2
4
6
8
7
1
9
0
5
4
2
1→3
2
7
6
3
0
9
8
1
5
1→4
Two parent strings
Two children strings
````

## D12 — Week 11 Lecture.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=28`
Строки (ID элементов): D12:p0028:u0001, D12:p0028:u0002, D12:p0028:u0003, D12:p0028:u0004, D12:p0028:u0005, D12:p0028:u0006, D12:p0028:u0007, D12:p0028:u0008, D12:p0028:u0009, D12:p0028:u0010, D12:p0028:u0011, D12:p0028:u0012, D12:p0028:u0013, D12:p0028:u0014, D12:p0028:u0015, D12:p0028:u0016, D12:p0028:u0017, D12:p0028:u0018, D12:p0028:u0019, D12:p0028:u0020, D12:p0028:u0021, D12:p0028:u0022, D12:p0028:u0023, D12:p0028:u0024, D12:p0028:u0025, D12:p0028:u0026, D12:p0028:u0027, D12:p0028:u0028, D12:p0028:u0029, D12:p0028:u0030, D12:p0028:u0031, D12:p0028:u0032, D12:p0028:u0033, D12:p0028:u0034, D12:p0028:u0035, D12:p0028:u0036, D12:p0028:u0037, D12:p0028:u0038, D12:p0028:u0039, D12:p0028:u0040, D12:p0028:u0041, D12:p0028:u0044, D12:p0028:u0045
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Partially-Mapped Crossover
2
6
7
1
9
0
5
4
8
3
7
5
6
3
0
9
8
1
2
4
6
8
7
1
9
0
5
4
2
3
2
7
6
3
0
9
8
1
5
4
Two parent strings
Two children strings
````


---

# AI-07-15 — Вещественное и косвенное представление в EA

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Переведи кодирование решения между вещественным и косвенным представлением.
**Пункты РПД:** —

**Связанные страницы:** 3; **символов извлечённого текста:** 937.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D12 — Week 11 Lecture.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=29`
Строки (ID элементов): D12:p0029:u0001, D12:p0029:u0002, D12:p0029:u0003, D12:p0029:u0004, D12:p0029:u0005, D12:p0029:u0006, D12:p0029:u0007, D12:p0029:u0008, D12:p0029:u0009, D12:p0029:u0010, D12:p0029:u0011, D12:p0029:u0012, D12:p0029:u0013, D12:p0029:u0014, D12:p0029:u0015, D12:p0029:u0016, D12:p0029:u0017, D12:p0029:u0018, D12:p0029:u0019, D12:p0029:u0020, D12:p0029:u0021, D12:p0029:u0022, D12:p0029:u0023, D12:p0029:u0024, D12:p0029:u0025, D12:p0029:u0026, D12:p0029:u0027, D12:p0029:u0028, D12:p0029:u0029
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Indirect Real-Numbered
Representation
- Move from direct to indirect representation
- Real-valued string
- Crossover as per one and two point
- Mutation is now as per ES – add a random number from a distribution
- Mapping form
- Example of increasing numbers
- 9, 6, 5, 2, 0, 4, 1, 3, 7, 8.
0
1
2
3
4
5
6
7
8
9
34.3
53.1
22.1
65.5
34.5
12.4
0.7
66.3
96.2
0.12
````

## D12 — Week 11 Lecture.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=30`
Строки (ID элементов): D12:p0030:u0001, D12:p0030:u0002, D12:p0030:u0003, D12:p0030:u0004, D12:p0030:u0005, D12:p0030:u0006, D12:p0030:u0007, D12:p0030:u0008

````text
Indirect Real-Numbered
Representation
- Direct to Indirect method
- No longer need to worry about ordering
- Ordering is now taken care of in the list
- Sorting algorithms are fast
- Evolutionary Changes are less likely to numbers which are closer together
- Evolution also has a direct control on the heritability
````

## D12 — Week 11 Lecture.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=31`
Строки (ID элементов): D12:p0031:u0001, D12:p0031:u0002, D12:p0031:u0003, D12:p0031:u0004, D12:p0031:u0005, D12:p0031:u0006

````text
Selection of Representation
- Has a large impact on the outcome of the evolution
- Defines how your space will look – the search space in terms of the
connectivity on the space
- Genetic operations are defined by how they act upon the representation
of the problem
````


---

# AI-07-16 — Коэволюция и относительная приспособленность

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Объясни, как меняются оценки агентов при коэволюции в повторяющейся дилемме заключённых.
**Пункты РПД:** —

**Связанные страницы:** 7; **символов извлечённого текста:** 2398.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D12 — Week 11 Lecture.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=32`
Строки (ID элементов): D12:p0032:u0001, D12:p0032:u0002, D12:p0032:u0003, D12:p0032:u0004, D12:p0032:u0005, D12:p0032:u0006, D12:p0032:u0007, D12:p0032:u0012, D12:p0032:u0022
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
Iterated Prisoner’s Dilemma (IPD)
- Two player game
- Story of two convicts who are placed
in interrogation and played against
each other
- Exploitable player allows a score >3
against it
Player |
Player 2
````

## D12 — Week 11 Lecture.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=33`
Строки (ID элементов): D12:p0033:u0001, D12:p0033:u0002, D12:p0033:u0003, D12:p0033:u0004, D12:p0033:u0005, D12:p0033:u0006, D12:p0033:u0007, D12:p0033:u0008, D12:p0033:u0009, D12:p0033:u0010, D12:p0033:u0011

````text
Iterated Prisoner’s Dilemma
- Game playing agents
- Representations
- Function Stack Machines – FST
- Cellular Encoded FSM – CAT
- Finite State Machines – AUT
- Boolean Formulas – TRE
- Markov Chains – MKV
- Look-up Tables – LKT
- IF-ACTION-SKIP Lists - ISC
- Boolean Formula with Delays - DEL
````

## D12 — Week 11 Lecture.pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=34`
Строки (ID элементов): D12:p0034:u0001, D12:p0034:u0002, D12:p0034:u0003, D12:p0034:u0004, D12:p0034:u0005, D12:p0034:u0006, D12:p0034:u0007

````text
Co-evolution
- The fitness of the population is based not upon the target, but the other
members within the population
- Used to create game player agents
- For IPD
- Play each of the other players in the population once
- Score is what you make off of all the other members in the population
````

## D12 — Week 11 Lecture.pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=35`
Строки (ID элементов): D12:p0035:u0001, D12:p0035:u0005, D12:p0035:u0007, D12:p0035:u0008, D12:p0035:u0010, D12:p0035:u0011, D12:p0035:u0013, D12:p0035:u0015, D12:p0035:u0016, D12:p0035:u0017, D12:p0035:u0018, D12:p0035:u0019, D12:p0035:u0020, D12:p0035:u0021, D12:p0035:u0022, D12:p0035:u0023
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Cooperative Ability
P(Cooperative), Generation 250
FST
CAT
AUT
TRE
MKV
LKT
ISC
DEL
CNN
NNN
1
95% confidence interval
Fig. & Probabilities of essentially cooperative behavior in generation 250
for cach of the 10 representations tested.
````

## D12 — Week 11 Lecture.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=36`
Строки (ID элементов): D12:p0036:u0001, D12:p0036:u0002, D12:p0036:u0007, D12:p0036:u0008, D12:p0036:u0009, D12:p0036:u0010, D12:p0036:u0011, D12:p0036:u0012, D12:p0036:u0014, D12:p0036:u0016, D12:p0036:u0017, D12:p0036:u0018, D12:p0036:u0019, D12:p0036:u0020, D12:p0036:u0021, D12:p0036:u0022
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Play in the Population v. Random
Player
P(Better-than-random), Generation 250
FST
CAT
AUT
TRE
MKV
LKT
DEL
CNN
NNN
1
95% confidence interval
Fig. 9. Probabilities of better-than-random behavior in generation 250 for
cach of the 10 representations tested.
````

## D12 — Week 11 Lecture.pdf, PDF-страница 37
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=37`
Строки (ID элементов): D12:p0037:u0001, D12:p0037:u0002, D12:p0037:u0003, D12:p0037:u0004, D12:p0037:u0005, D12:p0037:u0006, D12:p0037:u0007, D12:p0037:u0008, D12:p0037:u0009, D12:p0037:u0010, D12:p0037:u0011, D12:p0037:u0012, D12:p0037:u0013, D12:p0037:u0014, D12:p0037:u0015, D12:p0037:u0016, D12:p0037:u0017

````text
Why?
1.
Initial Population
Random initialization of all of these techniques has some differences in the ability to
create an early cooperator
2.
Variation Operators with Different Probabilities of Creating “Stupid”
Offspring
May allow for offspring which are easy to exploit
3.
Fidelity of Reproduction
Differences in the ability to represent ones parents. Some reproduction rules lead to
drastically different children than parents
4.
Granularity of Reproduction
Cooperation must be valued to be sustained, if newer models are allowed in which
can be exploited it allows for exploiters to overrun the population
````

## D12 — Week 11 Lecture.pdf, PDF-страница 38
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=38`
Строки (ID элементов): D12:p0038:u0001, D12:p0038:u0002, D12:p0038:u0003, D12:p0038:u0004, D12:p0038:u0005, D12:p0038:u0006, D12:p0038:u0007, D12:p0038:u0008, D12:p0038:u0009, D12:p0038:u0010, D12:p0038:u0011, D12:p0038:u0012, D12:p0038:u0013

````text
String Players
- String of actions
- Actions made in a step-wise order or are representations of the player
- Have been used for a number of simulation ideas:
- Sunburn – Space Ships
- VIPs – Virtual Politician Simulator
- Lessons to a young man courting – Dating Simulator
- Dawn of the Dead - Government Responses to Zombies
- Co-evolution and Evolution to a target
- Sunburn – co-evolved
- VIPs – co-evolved
- Lessons – Based on a model of the potential date
- Dawn of the Dead – based on an epidemic model
````


---

# AI-07-17 — Поведенческие деревья: selector, sequence и decorator

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Нарисуй behaviour tree робота, поясни выбор ветвей и условия завершения.
**Пункты РПД:** —

**Связанные страницы:** 13; **символов извлечённого текста:** 2526.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D05 — Tutorial 09.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=3`
Строки (ID элементов): D05:p0003:u0001, D05:p0003:u0002, D05:p0003:u0003, D05:p0003:u0004, D05:p0003:u0010, D05:p0003:u0012
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
BT: Game Industry
-
Originated from Game Industry, as a powerful way to describe AI for “NPC”
 Halo, Bioshock, Spore
Combat
Weapon
````

## D05 — Tutorial 09.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=4`
Строки (ID элементов): D05:p0004:u0001, D05:p0004:u0002, D05:p0004:u0003, D05:p0004:u0004, D05:p0004:u0005, D05:p0004:u0006, D05:p0004:u0007, D05:p0004:u0008, D05:p0004:u0009, D05:p0004:u0010, D05:p0004:u0011, D05:p0004:u0012

````text
Behaviour Tree Architecture
- Mathematical Model of Plan Execution – describe
switching between a finite set of behaviours in a
modular fashion
- Properties
❏ Expressiveness
❏ Accuracy
❏one-way vs. two-way control transfer
(BTs are more modular than FSMs is that they
use a two-way control transfer)
❏Implementation (memory-less vs. memory-full
nodes)
````

## D05 — Tutorial 09.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=5`
Строки (ID элементов): D05:p0005:u0001, D05:p0005:u0002, D05:p0005:u0003, D05:p0005:u0004, D05:p0005:u0005, D05:p0005:u0006, D05:p0005:u0013, D05:p0005:u0014, D05:p0005:u0015, D05:p0005:u0016, D05:p0005:u0017, D05:p0005:u0018, D05:p0005:u0020, D05:p0005:u0021, D05:p0005:u0022, D05:p0005:u0023, D05:p0005:u0028, D05:p0005:u0030, D05:p0005:u0033, D05:p0005:u0035, D05:p0005:u0037, D05:p0005:u0038, D05:p0005:u0040, D05:p0005:u0041, D05:p0005:u0042, D05:p0005:u0043, D05:p0005:u0045, D05:p0005:u0047, D05:p0005:u0048, D05:p0005:u0052
**Непроверенные OCR/формулы:** 16 исключённых из основного текста кандидатов; см. JSON.

````text
Behaviour Tree Architecture (2)
BT is directed tree in which the nodes are classified as:
- 
Root, control flow nodes and execution nodes
- The execution of a BT starts from the root which sends ticks with a certain
frequency to its child.
Node Type
Symb.
Succeeds if
Fails if
Runs if
Root
tree S
tree F
tree R
Selector
Sequence
N chs
Parallel
=Schs
otherwise
Decorator
varies
varies
varies
Action n
Xn(t)€ Sn
Xn(t)€ Rn
Condition n
never
````

## D05 — Tutorial 09.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=6`
Строки (ID элементов): D05:p0006:u0001, D05:p0006:u0004
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Selector
Enter Building
````

## D05 — Tutorial 09.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=7`
Строки (ID элементов): D05:p0007:u0001, D05:p0007:u0004
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Sequence
Enter through Front Door
````

## D05 — Tutorial 09.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=8`
Строки (ID элементов): D05:p0008:u0001

````text
Parallel
````

## D05 — Tutorial 09.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=9`
Строки (ID элементов): D05:p0009:u0001, D05:p0009:u0004, D05:p0009:u0005, D05:p0009:u0006, D05:p0009:u0007, D05:p0009:u0008, D05:p0009:u0009, D05:p0009:u0010
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Decorator
Decorators are special nodes that can
have only a single child. The goal of the
decorator is to change the behavior of
the child by manipulating the returning
value or changing its ticking frequency
- Repeater
Ring Bell
````

## D05 — Tutorial 09.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=10`
Строки (ID элементов): D05:p0010:u0001, D05:p0010:u0002, D05:p0010:u0003, D05:p0010:u0004, D05:p0010:u0005, D05:p0010:u0006, D05:p0010:u0007, D05:p0010:u0008, D05:p0010:u0009, D05:p0010:u0010

````text
Execution Nodes
The execution nodes are the primitive building blocks of
the behaviour tree. They perform some computation and
return a state value (functional).
- Condition node checks whether a certain conditions
has been meet and returns TRUE or FALSE to its
parent
- Action node (behaviour in our case) performs
computations to change the agent state and returns
TRUE, FALSE or RUNNING to its parent.
````

## D05 — Tutorial 09.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=11`
Строки (ID элементов): D05:p0011:u0001
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Example BT
````

## D05 — Tutorial 09.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=12`
Строки (ID элементов): D05:p0012:u0001, D05:p0012:u0005, D05:p0012:u0006, D05:p0012:u0008, D05:p0012:u0009, D05:p0012:u0010, D05:p0012:u0011, D05:p0012:u0012, D05:p0012:u0013, D05:p0012:u0015, D05:p0012:u0016, D05:p0012:u0017, D05:p0012:u0019
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Modularity of BT
DoorClosed
Sequence
Fallback
Fallback
PassThroughDoor
OpenDoor
RetryUntilSuccessful
SmashDoor
num_attempts = 5
Inverter
DoorClosed
PickLock
````

## D05 — Tutorial 09.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=13`
Строки (ID элементов): D05:p0013:u0002, D05:p0013:u0003, D05:p0013:u0004, D05:p0013:u0005, D05:p0013:u0006, D05:p0013:u0007, D05:p0013:u0008, D05:p0013:u0009, D05:p0013:u0010, D05:p0013:u0011, D05:p0013:u0012, D05:p0013:u0013, D05:p0013:u0014, D05:p0013:u0015

````text
- 
Maintainability: transitions in BT are defined by the structure, not
by conditions inside the states. Because of this, nodes can be
designed independent from each other, thus, when adding or
removing new nodes (or even subtrees) in a small part of the tree,
it is not necessary to change other parts of the mode.
- 
Scalability: when a BT have many nodes, it can be decomposed
into small sub-trees saving the readability of the graphical model.
- 
Reusability: due to the independence of nodes in BT, the
subtrees are also independent. This allows the reuse of subtrees
among other trees or projects.
BENEFITS OF BT
````

## D05 — Tutorial 09.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=14`
Строки (ID элементов): D05:p0014:u0001
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Other examples
````

## D05 — Tutorial 09.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=15`
Строки (ID элементов): D05:p0015:u0001, D05:p0015:u0002, D05:p0015:u0003

````text
Example. Design Behaviour Tree (5 min)
1. Design a Behaviour Tree for a mobile robot
navigating in a supermarket.
````


---

# AI-07-18 — Эволюция структур поведенческих деревьев

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Проведи crossover и mutation корректного дерева поведения и проверь структуру.
**Пункты РПД:** —

**Связанные страницы:** 20; **символов извлечённого текста:** 2631.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D05 — Tutorial 09.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=16`
Строки (ID элементов): D05:p0016:u0001, D05:p0016:u0003, D05:p0016:u0004, D05:p0016:u0005, D05:p0016:u0006, D05:p0016:u0007, D05:p0016:u0008

````text
Genetic Algorithm Pseudocode
Algorithm 6: Pseudocode of a GA.
Randomly generate an initial population of J individuals.
Calculate cost of each individual i in the population.
Select individuals for next generation.
Change individuals randomly.
Repeat 2-4 until criteria is achieved.
````

## D05 — Tutorial 09.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=17`
Строки (ID элементов): D05:p0017:u0001
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
BT crossover
````

## D05 — Tutorial 09.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=18`
Строки (ID элементов): D05:p0018:u0001, D05:p0018:u0002, D05:p0018:u0003, D05:p0018:u0004, D05:p0018:u0005, D05:p0018:u0006, D05:p0018:u0007, D05:p0018:u0008, D05:p0018:u0009

````text
BT crossover
Crossover switches a subtree or a single leaf node of
a BT with another BT at random. The key is that all
parts of the BT can be switched, from single
behaviors to large subtrees. After selection, the
parents are randomly paired and a random node
from each BT is chosen. The crossover can be as easy
as switching two leaf nodes between two parents,
but can also be used to inherit large subtrees.
````

## D05 — Tutorial 09.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=19`
Строки (ID элементов): D05:p0019:u0001, D05:p0019:u0004, D05:p0019:u0005
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
BT crossover (2)
Figure 22: Result of a simple crossover. The parents before crossover can be seen to the left with
red circles surrounding the crossover parts. The right part of the tree shows the offspring result.
````

## D05 — Tutorial 09.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=20`
Строки (ID элементов): D05:p0020:u0001
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
BT mutations
````

## D05 — Tutorial 09.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=21`
Строки (ID элементов): D05:p0021:u0001, D05:p0021:u0002

````text
BT mutations
Adding, deleting and switching a node
````

## D05 — Tutorial 09.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=22`
Строки (ID элементов): D05:p0022:u0001, D05:p0022:u0002, D05:p0022:u0003, D05:p0022:u0004, D05:p0022:u0005, D05:p0022:u0006, D05:p0022:u0007, D05:p0022:u0008, D05:p0022:u0009, D05:p0022:u0010, D05:p0022:u0011

````text
Adding nodes
- Add leaf node: Since the size of the final BT is not known,
the mutation can add a random leaf node to any position
of the BT.
- Add control node: Adding a control node to the BT
requires it to have some children. The control node inherits
all the remaining nodes to the right of where it is added,
creating a subtree with all the nodes and subtrees of the
current level. If the current position that the control node
is added to does not have children to the right, a new
position is chosen randomly.
````

## D05 — Tutorial 09.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=23`
Строки (ID элементов): D05:p0023:u0001, D05:p0023:u0008
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Add a leaf node
Figure 19: Add a leaf node “b0” into sequence node.
````

## D05 — Tutorial 09.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=24`
Строки (ID элементов): D05:p0024:u0001, D05:p0024:u0010
**Непроверенные OCR/формулы:** 7 исключённых из основного текста кандидатов; см. JSON.

````text
Add a control node
Figure 38: Add control node, which inherits the remaining leaf nodes to the right of its parent.
````

## D05 — Tutorial 09.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=25`
Строки (ID элементов): D05:p0025:u0001, D05:p0025:u0002

````text
Add a control node (2)
The control node inherits the remaining nodes to the right of its parent.
````

## D05 — Tutorial 09.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=26`
Строки (ID элементов): D05:p0026:u0001, D05:p0026:u0002, D05:p0026:u0003

````text
Deleting nodes
- Deleting a leaf node
- Deleting a control node
````

## D05 — Tutorial 09.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=27`
Строки (ID элементов): D05:p0027:u0001, D05:p0027:u0002
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Delete a leaf node
Delete leaf node “a3”
````

## D05 — Tutorial 09.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=28`
Строки (ID элементов): D05:p0028:u0001, D05:p0028:u0002
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Delete a leaf node - Special case
When deleting the leaf node ”a2” that is the only child of a control node, also delete the control node.
````

## D05 — Tutorial 09.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=29`
Строки (ID элементов): D05:p0029:u0001, D05:p0029:u0002
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Delete control node
The parent keeps the control node’s children.
````

## D05 — Tutorial 09.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=30`
Строки (ID элементов): D05:p0030:u0001, D05:p0030:u0002, D05:p0030:u0003, D05:p0030:u0004, D05:p0030:u0005, D05:p0030:u0006

````text
Switching nodes
- Switch a leaf node into another leaf node
- Switch a control node into another control
node
- Switch a leaf note into a control node
- Switch a control node into a leaf node
````

## D05 — Tutorial 09.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=31`
Строки (ID элементов): D05:p0031:u0001, D05:p0031:u0002
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Switch a leaf node into
another leaf node
````

## D05 — Tutorial 09.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=32`
Строки (ID элементов): D05:p0032:u0001, D05:p0032:u0002
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Switch a control node into
another control node
````

## D05 — Tutorial 09.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=33`
Строки (ID элементов): D05:p0033:u0001, D05:p0033:u0002
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Switch a leaf node into a control node
The control node keeps the mutating leaf node and adds a random behavior
````

## D05 — Tutorial 09.pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=34`
Строки (ID элементов): D05:p0034:u0001, D05:p0034:u0002
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
Switch a control node into a leaf node
The bottom left control node is switched to a leaf node ”b0”.
````

## D05 — Tutorial 09.pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=35`
Строки (ID элементов): D05:p0035:u0001, D05:p0035:u0002
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Modifying the tree structure
Closing control nodes of the BT.
````


---

# AI-07-19 — Эволюция управления роботизированным роем

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Выбери fitness и схему эволюции контроллера роя для задачи сбора объектов.
**Пункты РПД:** —

**Связанные страницы:** 16; **символов извлечённого текста:** 6516.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D05 — Tutorial 09.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=36`
Строки (ID элементов): D05:p0036:u0001, D05:p0036:u0006, D05:p0036:u0048, D05:p0036:u0067, D05:p0036:u0097
**Непроверенные OCR/формулы:** 122 исключённых из основного текста кандидатов; см. JSON.

````text
Robot Swarms
eer
5
6
469
````

## D05 — Tutorial 09.pdf, PDF-страница 37
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=37`
Строки (ID элементов): D05:p0037:u0001, D05:p0037:u0002, D05:p0037:u0003, D05:p0037:u0004, D05:p0037:u0005, D05:p0037:u0006

````text
Robot Swarm(2)
• Robot swarm operates in a self-organized and
distributed manner
• Swarm collective behavior
– Robot-robot interaction
– Robot-environment interaction
````

## D05 — Tutorial 09.pdf, PDF-страница 38
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=38`
Строки (ID элементов): D05:p0038:u0001, D05:p0038:u0003, D05:p0038:u0004, D05:p0038:u0005, D05:p0038:u0006, D05:p0038:u0007, D05:p0038:u0008, D05:p0038:u0009, D05:p0038:u0010, D05:p0038:u0011, D05:p0038:u0012, D05:p0038:u0013

````text
Automatic Design Approach
Design Problem:
Swarm level
requirements
OPTIMIZATION
Problem
SOLUTION:
Control software for
an individual robot
Objective function
Optimization algorithm
transformed
````

## D05 — Tutorial 09.pdf, PDF-страница 39
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=39`
Строки (ID элементов): D05:p0039:u0001, D05:p0039:u0003, D05:p0039:u0004, D05:p0039:u0005, D05:p0039:u0006, D05:p0039:u0007

````text
Automatic Design Approach (2)
- Evolutionary swarm robotics
➢control software of each individual robot (Behaviour Tree,
FSM)
➢evolutionary algorithm optimizes a mission-specific
objective function (Fitness function)
````

## D05 — Tutorial 09.pdf, PDF-страница 40
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=40`
Строки (ID элементов): D05:p0040:u0001, D05:p0040:u0002

````text
Evolution of controllers in robot
swarms using GA
````

## D05 — Tutorial 09.pdf, PDF-страница 41
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=41`
Строки (ID элементов): D05:p0041:u0001, D05:p0041:u0003, D05:p0041:u0004, D05:p0041:u0005, D05:p0041:u0006, D05:p0041:u0007, D05:p0041:u0008, D05:p0041:u0010, D05:p0041:u0013, D05:p0041:u0014, D05:p0041:u0015, D05:p0041:u0016, D05:p0041:u0017, D05:p0041:u0018, D05:p0041:u0019, D05:p0041:u0020
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
® SpringerLink
Distributed Autonomous Robotic Systems pp 487-501 | Cite as
Evolving Behaviour Trees for Swarm Robotics
‘Simon Jones ©; Matthew Studley, Sabine Havert & Alan Winfield
Down
Chapter | First Online: 14 March 2018
2272 Accesses | 21 Citations
Part of the Springer Proceedings in Advanced Rabotics book series (SPAR,volume 6)
Abstract
Controllers for swarms of robots are hard to design as swarm behaviour emerges from the
interaction, and so controllers are often evolved. However, these evolved controllers are often
difficult to understand, limiting our ability to predict swarm behaviour. We suggest behaviour
Fig.
trees are a good control architecture for swarm robotics, as they are comprehensible and
promote modular reuse. We design a foraging task for kilobots and evolve a behaviour tree
capable of performina that task. both in simulation and reality, and show the controller is
````

## D05 — Tutorial 09.pdf, PDF-страница 42
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=42`
Строки (ID элементов): D05:p0042:u0001, D05:p0042:u0002, D05:p0042:u0003, D05:p0042:u0004, D05:p0042:u0005, D05:p0042:u0006, D05:p0042:u0007, D05:p0042:u0008, D05:p0042:u0009, D05:p0042:u0010, D05:p0042:u0011
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Kilobot Foraging Mission
-
Design of a behaviour tree controller architecture for a swarm of kilobots.
Kilobot Foraging mission:
https://www.youtube.com/watch?v=kioZR99hnU4
-
Automatically evolve behaviour trees in simulation to enable the swarm
to perform a collective foraging task.
-
The fittest behaviour tree is then evaluated in a swarm of real robots and
analysed
````

## D05 — Tutorial 09.pdf, PDF-страница 43
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=43`
Строки (ID элементов): D05:p0043:u0001, D05:p0043:u0002, D05:p0043:u0003, D05:p0043:u0004, D05:p0043:u0005
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Experimental setup
Foraging mission explanation: At the centre of the arena is a circular nest region. Surrounding this is a
gap, then beyond that is the food region. A kilobot which moves into the food region is regarded as having
picked up an item of food, a kilobot which is carrying an item of food that enters the nest region is
regarded as depositing the food in the nest.
````

## D05 — Tutorial 09.pdf, PDF-страница 44
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=44`
Строки (ID элементов): D05:p0044:u0001, D05:p0044:u0002, D05:p0044:u0003, D05:p0044:u0004, D05:p0044:u0005, D05:p0044:u0006, D05:p0044:u0007
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Fitness Function
The fitness of the swarm is related to the total amount of food returned to the
nest within the test time. The maximum possible number of food items depends
on the starting spatial distribution of the kilobots.
Let 𝑓𝑜𝑜𝑑𝑚𝑎𝑥 be the maximum food items,  𝑡𝑡𝑒𝑠𝑡 be the test time, 𝑣𝑎𝑣𝑔 be the average
linear velocity of the kilobots, n be the number of kilobots,  𝑓𝑛𝑑𝑖𝑠𝑡 be the shortest
(radial) distance between the food and nest regions:
````

## D05 — Tutorial 09.pdf, PDF-страница 45
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=45`
Строки (ID элементов): D05:p0045:u0001, D05:p0045:u0002, D05:p0045:u0003, D05:p0045:u0004, D05:p0045:u0005, D05:p0045:u0006, D05:p0045:u0007, D05:p0045:u0008, D05:p0045:u0017, D05:p0045:u0023
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
Fitness Function (2)
Let 𝑓𝑜𝑜𝑑𝑚𝑎𝑥 be the maximum food items,  𝑡𝑡𝑒𝑠𝑡 be the test time, 𝑣𝑎𝑣𝑔 be the average
linear velocity of the kilobots, n be the number of kilobots,  𝑓𝑛𝑑𝑖𝑠𝑡 be the shortest
(radial) distance between the food and nest regions:
We normalise the actual collected food items within the time of the test to
give a fitness value
Where k is a derating factor used to exert selection pressure towards smaller
behaviour trees
f00d max
f00d max
````

## D05 — Tutorial 09.pdf, PDF-страница 46
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=46`
Строки (ID элементов): D05:p0046:u0001, D05:p0046:u0002, D05:p0046:u0003, D05:p0046:u0004, D05:p0046:u0005, D05:p0046:u0006, D05:p0046:u0007, D05:p0046:u0008, D05:p0046:u0009

````text
BT Controller
- To control a robot with a behaviour tree, they
define the interface between the behaviour
tree action nodes and the robot, and the
action nodes that act on the interface. This
interface is known as the blackboard.
- There is a trade-off between the capabilities
that we choose to hard code and those that
we hope will evolve in the BT.
````

## D05 — Tutorial 09.pdf, PDF-страница 47
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=47`
Строки (ID элементов): D05:p0047:u0001, D05:p0047:u0003, D05:p0047:u0004, D05:p0047:u0005, D05:p0047:u0006, D05:p0047:u0007, D05:p0047:u0008, D05:p0047:u0009, D05:p0047:u0011, D05:p0047:u0012, D05:p0047:u0014, D05:p0047:u0015, D05:p0047:u0016, D05:p0047:u0017, D05:p0047:u0019, D05:p0047:u0020, D05:p0047:u0022, D05:p0047:u0023, D05:p0047:u0025, D05:p0047:u0028, D05:p0047:u0029, D05:p0047:u0030, D05:p0047:u0031, D05:p0047:u0033, D05:p0047:u0034, D05:p0047:u0035, D05:p0047:u0036, D05:p0047:u0038
**Непроверенные OCR/формулы:** 9 исключённых из основного текста кандидатов; см. JSON.

````text
BT Actions
Table 1 Behaviour tree blackboard, defining interface between the behaviour tree and the robot
Index
Name
Access
Description
0
motors
0 = off, 1= left turn, 2 = right turn, 3 = forward
1
scratchpad
Arbitrary state storage
2
send_signal
>0.5 = Send a signal flag
received_signal
1 =A signal flag has been received
detected_food
1 = Light sensor showing food region
1 = Carrying food
density
Density of kilobots in local region
Adensity
Change in density
Adist food
Change in distance to food
AdiStnest
Change in distance to nest
````

## D05 — Tutorial 09.pdf, PDF-страница 48
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=48`
Строки (ID элементов): D05:p0048:u0001, D05:p0048:u0002, D05:p0048:u0003, D05:p0048:u0004, D05:p0048:u0005, D05:p0048:u0006, D05:p0048:u0007, D05:p0048:u0008, D05:p0048:u0009, D05:p0048:u0010, D05:p0048:u0011, D05:p0048:u0012, D05:p0048:u0013, D05:p0048:u0014, D05:p0048:u0015, D05:p0048:u0016, D05:p0048:u0017

````text
Evolution procedure
- The population of 𝑛𝑝𝑜𝑝 is evaluated for fitness by running 10 simulations for each
individual, each simulation with a different starting configuration. The starting position is
always a 5×5 grid with 50 mm spacing in the centre of the nest region, but the orientation
is randomly chosen from interval (−𝜋,𝜋) radians. The simulation runs for 300 simulated
seconds
- An elite of 𝑛𝑒𝑙𝑖𝑡𝑒 is transferred unchanged to the next generation.
- The remainder are chosen by tournament selection with size 𝑡𝑠𝑖𝑧𝑒.
- A tree crossover operator is applied with probability 𝑝𝑥𝑜𝑣𝑒𝑟 to all pairs of non-elite, then
three different mutation operators are applied to the non-elite individuals.
- Firstly, with probability 𝑝𝑚𝑢𝑡𝑢, a node in the tree is selected at random and the
subtree at that point is replaced with a randomly generated one.
- Next, with probability 𝑝𝑚𝑢𝑡𝑠, a branch is chosen randomly and replaced with one of
its terminals.
- Next, with probability 𝑝𝑚𝑢𝑡𝑛 a node is picked at random and replaced with another
node with the same argument types.
- Lastly, with probability 𝑝𝑚𝑢𝑡𝑒, a constant is picked randomly and its value changed
````

## D05 — Tutorial 09.pdf, PDF-страница 49
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=49`
Строки (ID элементов): D05:p0049:u0001, D05:p0049:u0002, D05:p0049:u0003, D05:p0049:u0004, D05:p0049:u0005, D05:p0049:u0006, D05:p0049:u0007, D05:p0049:u0008, D05:p0049:u0010, D05:p0049:u0011, D05:p0049:u0013, D05:p0049:u0014, D05:p0049:u0015, D05:p0049:u0018, D05:p0049:u0019, D05:p0049:u0022, D05:p0049:u0024, D05:p0049:u0025, D05:p0049:u0028, D05:p0049:u0031, D05:p0049:u0034
**Непроверенные OCR/формулы:** 13 исключённых из основного текста кандидатов; см. JSON.

````text
Table 3 Parameters for a single evolutionary run
From: Evolving Behaviour Trees for Swarm Robotics
Parameter
Value
Description
een
200
Generations
300
Test length in seconds
25
Population
3
3
Tournament size
Crossover probability
0.05
Probability of subtree replacement
Probability of subtree shrink
Probability of node replacement
Probability of ephemeral constant replacement
````

## D05 — Tutorial 09.pdf, PDF-страница 50
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=50`
Строки (ID элементов): D05:p0050:u0001, D05:p0050:u0002, D05:p0050:u0003, D05:p0050:u0004, D05:p0050:u0005, D05:p0050:u0006, D05:p0050:u0007, D05:p0050:u0008, D05:p0050:u0010, D05:p0050:u0011, D05:p0050:u0012, D05:p0050:u0013, D05:p0050:u0014, D05:p0050:u0015, D05:p0050:u0016, D05:p0050:u0017, D05:p0050:u0018, D05:p0050:u0019, D05:p0050:u0021, D05:p0050:u0022, D05:p0050:u0024, D05:p0050:u0029, D05:p0050:u0032, D05:p0050:u0040
**Непроверенные OCR/формулы:** 16 исключённых из основного текста кандидатов; см. JSON.

````text
Table 4 Individuals from top five lineages and their usage of the blackboard
and behaviour tree constructs. All individuals use at least the forward and one
other of the motor action nodes. Usage is after redundant or unreachable
nodes have been removed
From: Evolving Behaviour Trees for Swarm Robotics
Rank
Fitness
Blackboard entry
1
2
3
4
5
6
SEQ
SEL
PROB
REPEAT
SET
0.104
0.0873
0.0853
0.0723
0.0710
````

## D05 — Tutorial 09.pdf, PDF-страница 51
Источник в ZIP: `AI_course_cleaned/05_Tutorial 09/source.pdf#page=51`
Строки (ID элементов): D05:p0051:u0001, D05:p0051:u0002, D05:p0051:u0009, D05:p0051:u0011, D05:p0051:u0013, D05:p0051:u0014, D05:p0051:u0021, D05:p0051:u0023, D05:p0051:u0024, D05:p0051:u0025, D05:p0051:u0029, D05:p0051:u0031, D05:p0051:u0032, D05:p0051:u0033, D05:p0051:u0035, D05:p0051:u0036, D05:p0051:u0037, D05:p0051:u0039, D05:p0051:u0041, D05:p0051:u0043, D05:p0051:u0044, D05:p0051:u0045, D05:p0051:u0047, D05:p0051:u0049, D05:p0051:u0050, D05:p0051:u0051, D05:p0051:u0055, D05:p0051:u0057, D05:p0051:u0059, D05:p0051:u0061, D05:p0051:u0062, D05:p0051:u0063, D05:p0051:u0065, D05:p0051:u0066, D05:p0051:u0067, D05:p0051:u0069, D05:p0051:u0070, D05:p0051:u0072, D05:p0051:u0073, D05:p0051:u0074
**Непроверенные OCR/формулы:** 34 исключённых из основного текста кандидатов; см. JSON.

````text
selm3 (
1
fge(0, detected_food) ,
seqm3 (
Turn and forward until out of food}
seqm3 (
9
10
ifgevar (Adistjooa, scratchpad) ,
10
seqm2 (
12
seqm3 (
12
13
seqm3 (
13
14
14
15
15
ifgevar (Adistes, Adistest) »
16
16
repeat (5,
17
18
18
19
20
seqm3 (
21
22
repeat (5,
23
—0.058530) ) ,
24
Fig.5 Fittest behaviour tree. Left shows the code as evolved. Right shows the code with redundant
lines removed by hand, the seqm nodes condensed, and conditionals simplified. Boxes highlight
the three functional clauses
````


---

# AI-07-20 — Проектирование хромосомы в конкурентной симуляции

**Раздел РПД:** 7. Эволюционные вычисления
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Предложи представление агента Sunburn и объясни, какие операторы нарушат смысл расположения генов.
**Пункты РПД:** —

**Связанные страницы:** 13; **символов извлечённого текста:** 2818.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D12 — Week 11 Lecture.pdf, PDF-страница 39
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=39`
Строки (ID элементов): D12:p0039:u0001, D12:p0039:u0002, D12:p0039:u0003, D12:p0039:u0004, D12:p0039:u0005, D12:p0039:u0006, D12:p0039:u0007

````text
Sunburn
- Space Warfare Simulation
- Student Project by John Walker
- Ships are represented by a string which is an indirect method of building a
starships
- Ships compete in a gladiatorial tournament selection method
- Ships have a distance measure from each other – 1 dimension
````

## D12 — Week 11 Lecture.pdf, PDF-страница 40
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=40`
Строки (ID элементов): D12:p0040:u0001, D12:p0040:u0002, D12:p0040:u0003, D12:p0040:u0004, D12:p0040:u0005, D12:p0040:u0006, D12:p0040:u0007, D12:p0040:u0008, D12:p0040:u0009, D12:p0040:u0010, D12:p0040:u0011, D12:p0040:u0012, D12:p0040:u0013

````text
Sunburn Ship
- Length N string of characters
- (S)hields – Take a hit of damage before dropping
- Weapons
- (G)uns – Short Range Physical Projectiles which drop in effectiveness as distance
increases. Slow moving and able to dodge
- (L)asers – Can be equally effective at any range
- (M)issiles – Guided missiles which take some time in order to ensure a lock. They have a
better long range effectiveness as they track their targets
- (D)rives – allow a ship to move one space
- String kept in order – Shields are moved to front of string and tripled. Each
system is worth one point of damage
- Ships have a preferred distance
````

## D12 — Week 11 Lecture.pdf, PDF-страница 41
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=41`
Строки (ID элементов): D12:p0041:u0001, D12:p0041:u0002, D12:p0041:u0003, D12:p0041:u0004, D12:p0041:u0005, D12:p0041:u0006, D12:p0041:u0007, D12:p0041:u0008, D12:p0041:u0009

````text
Weapon Effectiveness
- A weapon hitting does one system worth of damage
- A damaged system cannot be used
- Weapons are probabilistic in their effect
- Hit based upon the weapon effectiveness curve – a function based on the
current range
- PG(r) = 0.6 - (r - 1)/38
- PL(r) = 0.35
- PM(r) = 0.1 + (r - 1)/38
````

## D12 — Week 11 Lecture.pdf, PDF-страница 42
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=42`
Строки (ID элементов): D12:p0042:u0005, D12:p0042:u0006, D12:p0042:u0019, D12:p0042:u0031, D12:p0042:u0041
**Непроверенные OCR/формулы:** 34 исключённых из основного текста кандидатов; см. JSON.

````text
02
2
2
2
Fig. 4.8. From the top, gun, laser, and missle weapons’ effectiveness curves,
````

## D12 — Week 11 Lecture.pdf, PDF-страница 43
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=43`
Строки (ID элементов): D12:p0043:u0001, D12:p0043:u0002, D12:p0043:u0003, D12:p0043:u0004, D12:p0043:u0005, D12:p0043:u0006

````text
Example Ship Translation
- SGLMSDSMGSLD,16
- Systems with shields in the chromosome
- Translation moves these to the front and triples them
- 4 shield nodes buys you 12 shields
- SSSS SSSS SSSS GLMDMGLD,16
````

## D12 — Week 11 Lecture.pdf, PDF-страница 44
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=44`
Строки (ID элементов): D12:p0044:u0001, D12:p0044:u0002, D12:p0044:u0003, D12:p0044:u0004, D12:p0044:u0005, D12:p0044:u0006

````text
Ship Controllers
- Ships activate their drives in unison one at a time with the goal of moving to
their key range
- Ships fire weapons one at a time in unison, based-on their order in the string
LLGML
FIRE! - LASER, LASER, GUN, MISSILE, LASER
````

## D12 — Week 11 Lecture.pdf, PDF-страница 45
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=45`
Строки (ID элементов): D12:p0045:u0001
**Непроверенные OCR/формулы:** 18 исключённых из основного текста кандидатов; см. JSON.

````text
Gladiatorial Selection
````

## D12 — Week 11 Lecture.pdf, PDF-страница 46
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=46`
Строки (ID элементов): D12:p0046:u0001, D12:p0046:u0002, D12:p0046:u0003, D12:p0046:u0004, D12:p0046:u0005, D12:p0046:u0006, D12:p0046:u0007, D12:p0046:u0008, D12:p0046:u0009, D12:p0046:u0010, D12:p0046:u0011, D12:p0046:u0012, D12:p0046:u0013, D12:p0046:u0014, D12:p0046:u0015, D12:p0046:u0016, D12:p0046:u0017, D12:p0046:u0018, D12:p0046:u0019, D12:p0046:u0020

````text
Gladiatorial Fights
- Steady State Population
1.
Pull out two ships from the population
2.
Simulate their battle
3.
If there is a winner – keep for breeding
4.
Else return to step 1
5.
Pull out two ships from the population
6.
Simulate their battle
7.
If there is a winner – keep for breeding
8.
Else return to step 5
9.
Breeding Step
````

## D12 — Week 11 Lecture.pdf, PDF-страница 47
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=47`
Строки (ID элементов): D12:p0047:u0001, D12:p0047:u0002, D12:p0047:u0003, D12:p0047:u0004

````text
Win Conditions
- A ship without any points remaining is destroyed
- 100 Turns without damage - Draw
- Are there any others?
````

## D12 — Week 11 Lecture.pdf, PDF-страница 48
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=48`
Строки (ID элементов): D12:p0048:u0001, D12:p0048:u0002, D12:p0048:u0003, D12:p0048:u0004
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Starbases
- Strip down to one drive in the final
position
- Load up on Missiles and Shields
````

## D12 — Week 11 Lecture.pdf, PDF-страница 49
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=49`
Строки (ID элементов): D12:p0049:u0001, D12:p0049:u0002, D12:p0049:u0003
**Непроверенные OCR/формулы:** 7 исключённых из основного текста кандидатов; см. JSON.

````text
Gunrunners
- Lots of drives
- MORE GUN
````

## D12 — Week 11 Lecture.pdf, PDF-страница 50
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=50`
Строки (ID элементов): D12:p0050:u0001, D12:p0050:u0002, D12:p0050:u0003, D12:p0050:u0004, D12:p0050:u0005, D12:p0050:u0006, D12:p0050:u0007, D12:p0050:u0008, D12:p0050:u0009
**Общая страница с:** AI-07-13

````text
Representational Issues
- Position within the chromosome has a large effect on the range and the
damage
- Systems ‘go down’ in order
- Expendable systems at front
- Important systems near end
- Win condition is a disabling of drives – ensure at least one drive is at the end of
the string
- Epistatic – with importance on the end of the string
````

## D12 — Week 11 Lecture.pdf, PDF-страница 51
Источник в ZIP: `AI_course_cleaned/12_Week 11 Lecture/source.pdf#page=51`
Строки (ID элементов): D12:p0051:u0001, D12:p0051:u0002, D12:p0051:u0003, D12:p0051:u0004
**Общая страница с:** AI-07-13

````text
Sunburn
- What crossovers would make sense?
- What crossovers would disrupt structure?
- What about the preferred distance?
````


---

# AI-08-01 — Искусственный нейрон как взвешенная функция

**Раздел РПД:** 8. Искусственные нейронные сети
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Вычисли выход нейрона по входам, весам, смещению и активации.
**Пункты РПД:** RPD-33

**Связанные страницы:** 6; **символов извлечённого текста:** 1932.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D13 — Week 12 Lecture.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=4`
Строки (ID элементов): D13:p0004:u0001, D13:p0004:u0002, D13:p0004:u0003, D13:p0004:u0004, D13:p0004:u0005, D13:p0004:u0006, D13:p0004:u0007, D13:p0004:u0008, D13:p0004:u0009, D13:p0004:u0010, D13:p0004:u0011, D13:p0004:u0012, D13:p0004:u0013, D13:p0004:u0014, D13:p0004:u0015, D13:p0004:u0016

````text
Artificial Neural Networks
- Again – biological inspiration
- Neurons in the brain
- First models from 1957
- F. Rosenblatt on contract to US Navy
- Intended to be hardware machines
- Implemented in software to prototype
- Now seen in both software and hardware forms
- “the embryo of an electronic computer that [the Navy] expects will be able to walk, talk, see,
write, reproduce itself and be conscious of its existence” – NY Times
- 1969 saw the death of many of these connectiveness models (Minsky-
Perceptrons)
- XOR could not be developed via such a model
- Research funder saw the dream of AI to be a farce and pulled back money
- AI Winter
- Funding now returning – we are in an “AI Spring”?
````

## D13 — Week 12 Lecture.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=5`
Строки (ID элементов): D13:p0005:u0001, D13:p0005:u0002, D13:p0005:u0003, D13:p0005:u0004, D13:p0005:u0005, D13:p0005:u0006, D13:p0005:u0007, D13:p0005:u0008, D13:p0005:u0009, D13:p0005:u0012, D13:p0005:u0013, D13:p0005:u0014, D13:p0005:u0016, D13:p0005:u0017, D13:p0005:u0022, D13:p0005:u0024
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Biology
- Neuron Cell
- Information
- Processing
- Message Passing
- Input from the dendrites
- Output from the synapse
- Electrical message passing model
- Spike models from 1907 have been investigated
lendrites
synapse
axon
myelin
soma
presynaptic
terminal
````

## D13 — Week 12 Lecture.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=6`
Строки (ID элементов): D13:p0006:u0001, D13:p0006:u0002, D13:p0006:u0003, D13:p0006:u0004, D13:p0006:u0005, D13:p0006:u0006, D13:p0006:u0007, D13:p0006:u0008, D13:p0006:u0009, D13:p0006:u0010, D13:p0006:u0011, D13:p0006:u0012, D13:p0006:u0013, D13:p0006:u0014, D13:p0006:u0015, D13:p0006:u0016

````text
ANN
- Specified by:
- Architecture
- How are the connections made
- What Neurons are connected to others
- Feedforward
- Recurrent
- Neuron Model
- What functions can the neurons take as inputs
- Can restrict the learning algorithm (backpropagation requires the functions to be differentiable)
- Learning Algorithm
- Connected Neurons have weights in their connections
- How do we make the updates to weights?
- Backpropagation of errors
- Evolutionary methods
- Supervised or Unsupervised
````

## D13 — Week 12 Lecture.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=7`
Строки (ID элементов): D13:p0007:u0001, D13:p0007:u0002, D13:p0007:u0003, D13:p0007:u0004, D13:p0007:u0005, D13:p0007:u0006, D13:p0007:u0007, D13:p0007:u0008, D13:p0007:u0009

````text
(Un)Supervised Learning
Supervised
- Tasks with outcomes
- Tasks
- Classification
Unsupervised
- Task inputs with no expected output
- Tasks
- Clustering and Data understanding
````

## D13 — Week 12 Lecture.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=8`
Строки (ID элементов): D13:p0008:u0001, D13:p0008:u0002, D13:p0008:u0003, D13:p0008:u0004, D13:p0008:u0005, D13:p0008:u0006, D13:p0008:u0007

````text
ANN Usage Fields
- Speech recognition
- Computer vision
- Music, art generation
- Classification
- Non-linear tasks
- etc.
````

## D13 — Week 12 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=9`
Строки (ID элементов): D13:p0009:u0001, D13:p0009:u0002, D13:p0009:u0003, D13:p0009:u0004, D13:p0009:u0011, D13:p0009:u0012, D13:p0009:u0013
**Общая страница с:** AI-08-02
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Perceptron
- Single layer feedforward networks
- Simplest version of a neural model
- 𝑜𝑢𝑡𝑝𝑢𝑡= 𝑠𝑡𝑒𝑝! ∑𝑤"𝑥" , 𝑤ℎ𝑒𝑟𝑒𝑠𝑡𝑒𝑝! 𝑚= 1 𝑖𝑓𝑚> 0 𝑎𝑛𝑑0 𝑜𝑡ℎ𝑒𝑟𝑤𝑖𝑠𝑒
inputs weights
weighted sum
step function
````


---

# AI-08-02 — Перцептрон Розенблатта и линейная разделимость

**Раздел РПД:** 8. Искусственные нейронные сети
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Построй классифицирующий перцептрон и поясни границу его выразимости.
**Пункты РПД:** RPD-34

**Связанные страницы:** 6; **символов извлечённого текста:** 976.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D13 — Week 12 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=9`
Строки (ID элементов): D13:p0009:u0001, D13:p0009:u0002, D13:p0009:u0003, D13:p0009:u0004, D13:p0009:u0011, D13:p0009:u0012, D13:p0009:u0013
**Общая страница с:** AI-08-01
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Perceptron
- Single layer feedforward networks
- Simplest version of a neural model
- 𝑜𝑢𝑡𝑝𝑢𝑡= 𝑠𝑡𝑒𝑝! ∑𝑤"𝑥" , 𝑤ℎ𝑒𝑟𝑒𝑠𝑡𝑒𝑝! 𝑚= 1 𝑖𝑓𝑚> 0 𝑎𝑛𝑑0 𝑜𝑡ℎ𝑒𝑟𝑤𝑖𝑠𝑒
inputs weights
weighted sum
step function
````

## D13 — Week 12 Lecture.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=15`
Строки (ID элементов): D13:p0015:u0001, D13:p0015:u0002, D13:p0015:u0003, D13:p0015:u0006, D13:p0015:u0007, D13:p0015:u0008, D13:p0015:u0009, D13:p0015:u0010, D13:p0015:u0011, D13:p0015:u0012, D13:p0015:u0013, D13:p0015:u0014, D13:p0015:u0015, D13:p0015:u0016, D13:p0015:u0017, D13:p0015:u0018, D13:p0015:u0019, D13:p0015:u0020, D13:p0015:u0021, D13:p0015:u0022, D13:p0015:u0023, D13:p0015:u0024, D13:p0015:u0025, D13:p0015:u0026, D13:p0015:u0027, D13:p0015:u0028, D13:p0015:u0029, D13:p0015:u0030, D13:p0015:u0031, D13:p0015:u0032, D13:p0015:u0033, D13:p0015:u0034, D13:p0015:u0035, D13:p0015:u0036, D13:p0015:u0037, D13:p0015:u0038, D13:p0015:u0039, D13:p0015:u0040, D13:p0015:u0052
**Общая страница с:** AI-08-03
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
AND Perceptron
- Activation function: 𝑓𝑥= 81, ∑𝑤"𝑥" + 𝑏> 0
0, ∑𝑤"𝑥" + 𝑏≤0
b
w1
w2
x1
x2
wixi+b
Activation
-1
1
1
0
0
-1
0
-1
1
1
0
1
0
0
-1
1
1
1
0
0
0
-1
1
1
1
1
1
1
AND
````

## D13 — Week 12 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=16`
Строки (ID элементов): D13:p0016:u0001, D13:p0016:u0002, D13:p0016:u0003, D13:p0016:u0006, D13:p0016:u0007, D13:p0016:u0008, D13:p0016:u0009, D13:p0016:u0010, D13:p0016:u0011, D13:p0016:u0012, D13:p0016:u0013, D13:p0016:u0014, D13:p0016:u0015, D13:p0016:u0016, D13:p0016:u0017, D13:p0016:u0018, D13:p0016:u0019, D13:p0016:u0020, D13:p0016:u0021, D13:p0016:u0022, D13:p0016:u0023, D13:p0016:u0024, D13:p0016:u0025, D13:p0016:u0026, D13:p0016:u0027, D13:p0016:u0028, D13:p0016:u0029, D13:p0016:u0030, D13:p0016:u0031, D13:p0016:u0032, D13:p0016:u0033, D13:p0016:u0034, D13:p0016:u0035, D13:p0016:u0036, D13:p0016:u0037, D13:p0016:u0038, D13:p0016:u0039, D13:p0016:u0040
**Общая страница с:** AI-08-03
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
OR Perceptron
- Activation function: 𝑓𝑥= 81, ∑𝑤"𝑥" + 𝑏> 0
0, ∑𝑤"𝑥" + 𝑏≤0
b
w1
w2
x1
x2
wixi+b
Activation
-1
2
2
0
0
-1
0
-1
2
2
0
1
1
1
-1
2
2
1
0
1
1
-1
2
2
1
1
3
1
````

## D13 — Week 12 Lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=17`
Строки (ID элементов): D13:p0017:u0001, D13:p0017:u0002, D13:p0017:u0003, D13:p0017:u0006, D13:p0017:u0007, D13:p0017:u0008, D13:p0017:u0009, D13:p0017:u0010, D13:p0017:u0011, D13:p0017:u0012, D13:p0017:u0013, D13:p0017:u0014, D13:p0017:u0015, D13:p0017:u0016, D13:p0017:u0017, D13:p0017:u0018, D13:p0017:u0019, D13:p0017:u0020
**Общая страница с:** AI-08-03

````text
NOT Perceptron
- Activation function: 𝑓𝑥= 81, ∑𝑤"𝑥" + 𝑏> 0
0, ∑𝑤"𝑥" + 𝑏≤0
b
w1
x1
wixi+b
Activation
1
-1
0
1
1
1
-1
1
0
0
````

## D13 — Week 12 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=18`
Строки (ID элементов): D13:p0018:u0001, D13:p0018:u0002, D13:p0018:u0003, D13:p0018:u0006, D13:p0018:u0007, D13:p0018:u0008, D13:p0018:u0009, D13:p0018:u0010, D13:p0018:u0011, D13:p0018:u0012, D13:p0018:u0013, D13:p0018:u0014, D13:p0018:u0015, D13:p0018:u0016, D13:p0018:u0017, D13:p0018:u0018, D13:p0018:u0019, D13:p0018:u0020, D13:p0018:u0021, D13:p0018:u0022, D13:p0018:u0023, D13:p0018:u0024, D13:p0018:u0025, D13:p0018:u0026, D13:p0018:u0027, D13:p0018:u0028, D13:p0018:u0029, D13:p0018:u0030, D13:p0018:u0031, D13:p0018:u0032, D13:p0018:u0033, D13:p0018:u0034, D13:p0018:u0035, D13:p0018:u0036, D13:p0018:u0037, D13:p0018:u0038, D13:p0018:u0039, D13:p0018:u0040, D13:p0018:u0051
**Общая страница с:** AI-08-03
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
NAND Perceptron
- Activation function: 𝑓𝑥= 81, ∑𝑤"𝑥" + 𝑏> 0
0, ∑𝑤"𝑥" + 𝑏≤0
b
w1
w2
x1
x2
wixi+b
Activation
2
-1
-1
0
0
2
1
2
-1
-1
0
1
1
1
2
-1
-1
1
0
1
1
2
-1
-1
1
1
0
0
NAND
````

## D13 — Week 12 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=19`
Строки (ID элементов): D13:p0019:u0001, D13:p0019:u0002, D13:p0019:u0003, D13:p0019:u0004, D13:p0019:u0005, D13:p0019:u0006, D13:p0019:u0018
**Общая страница с:** AI-08-04
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
XOR Perceptron
- Activation function: 𝑓𝑥= 81, ∑𝑤"𝑥" + 𝑏> 0
0, ∑𝑤"𝑥" + 𝑏≤0
- Not each task can be
solved by a single perceptron
- XOR is one of those tasks
AND
````


---

# AI-08-03 — Логические операции AND, OR, NOT, NAND в перцептроне

**Раздел РПД:** 8. Искусственные нейронные сети
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Подбери веса и порог для заданной логической операции и проверь таблицу истинности.
**Пункты РПД:** —

**Связанные страницы:** 4; **символов извлечённого текста:** 631.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D13 — Week 12 Lecture.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=15`
Строки (ID элементов): D13:p0015:u0001, D13:p0015:u0002, D13:p0015:u0003, D13:p0015:u0006, D13:p0015:u0007, D13:p0015:u0008, D13:p0015:u0009, D13:p0015:u0010, D13:p0015:u0011, D13:p0015:u0012, D13:p0015:u0013, D13:p0015:u0014, D13:p0015:u0015, D13:p0015:u0016, D13:p0015:u0017, D13:p0015:u0018, D13:p0015:u0019, D13:p0015:u0020, D13:p0015:u0021, D13:p0015:u0022, D13:p0015:u0023, D13:p0015:u0024, D13:p0015:u0025, D13:p0015:u0026, D13:p0015:u0027, D13:p0015:u0028, D13:p0015:u0029, D13:p0015:u0030, D13:p0015:u0031, D13:p0015:u0032, D13:p0015:u0033, D13:p0015:u0034, D13:p0015:u0035, D13:p0015:u0036, D13:p0015:u0037, D13:p0015:u0038, D13:p0015:u0039, D13:p0015:u0040, D13:p0015:u0052
**Общая страница с:** AI-08-02
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
AND Perceptron
- Activation function: 𝑓𝑥= 81, ∑𝑤"𝑥" + 𝑏> 0
0, ∑𝑤"𝑥" + 𝑏≤0
b
w1
w2
x1
x2
wixi+b
Activation
-1
1
1
0
0
-1
0
-1
1
1
0
1
0
0
-1
1
1
1
0
0
0
-1
1
1
1
1
1
1
AND
````

## D13 — Week 12 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=16`
Строки (ID элементов): D13:p0016:u0001, D13:p0016:u0002, D13:p0016:u0003, D13:p0016:u0006, D13:p0016:u0007, D13:p0016:u0008, D13:p0016:u0009, D13:p0016:u0010, D13:p0016:u0011, D13:p0016:u0012, D13:p0016:u0013, D13:p0016:u0014, D13:p0016:u0015, D13:p0016:u0016, D13:p0016:u0017, D13:p0016:u0018, D13:p0016:u0019, D13:p0016:u0020, D13:p0016:u0021, D13:p0016:u0022, D13:p0016:u0023, D13:p0016:u0024, D13:p0016:u0025, D13:p0016:u0026, D13:p0016:u0027, D13:p0016:u0028, D13:p0016:u0029, D13:p0016:u0030, D13:p0016:u0031, D13:p0016:u0032, D13:p0016:u0033, D13:p0016:u0034, D13:p0016:u0035, D13:p0016:u0036, D13:p0016:u0037, D13:p0016:u0038, D13:p0016:u0039, D13:p0016:u0040
**Общая страница с:** AI-08-02
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
OR Perceptron
- Activation function: 𝑓𝑥= 81, ∑𝑤"𝑥" + 𝑏> 0
0, ∑𝑤"𝑥" + 𝑏≤0
b
w1
w2
x1
x2
wixi+b
Activation
-1
2
2
0
0
-1
0
-1
2
2
0
1
1
1
-1
2
2
1
0
1
1
-1
2
2
1
1
3
1
````

## D13 — Week 12 Lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=17`
Строки (ID элементов): D13:p0017:u0001, D13:p0017:u0002, D13:p0017:u0003, D13:p0017:u0006, D13:p0017:u0007, D13:p0017:u0008, D13:p0017:u0009, D13:p0017:u0010, D13:p0017:u0011, D13:p0017:u0012, D13:p0017:u0013, D13:p0017:u0014, D13:p0017:u0015, D13:p0017:u0016, D13:p0017:u0017, D13:p0017:u0018, D13:p0017:u0019, D13:p0017:u0020
**Общая страница с:** AI-08-02

````text
NOT Perceptron
- Activation function: 𝑓𝑥= 81, ∑𝑤"𝑥" + 𝑏> 0
0, ∑𝑤"𝑥" + 𝑏≤0
b
w1
x1
wixi+b
Activation
1
-1
0
1
1
1
-1
1
0
0
````

## D13 — Week 12 Lecture.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=18`
Строки (ID элементов): D13:p0018:u0001, D13:p0018:u0002, D13:p0018:u0003, D13:p0018:u0006, D13:p0018:u0007, D13:p0018:u0008, D13:p0018:u0009, D13:p0018:u0010, D13:p0018:u0011, D13:p0018:u0012, D13:p0018:u0013, D13:p0018:u0014, D13:p0018:u0015, D13:p0018:u0016, D13:p0018:u0017, D13:p0018:u0018, D13:p0018:u0019, D13:p0018:u0020, D13:p0018:u0021, D13:p0018:u0022, D13:p0018:u0023, D13:p0018:u0024, D13:p0018:u0025, D13:p0018:u0026, D13:p0018:u0027, D13:p0018:u0028, D13:p0018:u0029, D13:p0018:u0030, D13:p0018:u0031, D13:p0018:u0032, D13:p0018:u0033, D13:p0018:u0034, D13:p0018:u0035, D13:p0018:u0036, D13:p0018:u0037, D13:p0018:u0038, D13:p0018:u0039, D13:p0018:u0040, D13:p0018:u0051
**Общая страница с:** AI-08-02
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
NAND Perceptron
- Activation function: 𝑓𝑥= 81, ∑𝑤"𝑥" + 𝑏> 0
0, ∑𝑤"𝑥" + 𝑏≤0
b
w1
w2
x1
x2
wixi+b
Activation
2
-1
-1
0
0
2
1
2
-1
-1
0
1
1
1
2
-1
-1
1
0
1
1
2
-1
-1
1
1
0
0
NAND
````


---

# AI-08-04 — Неразделимость XOR одним перцептроном

**Раздел РПД:** 8. Искусственные нейронные сети
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Объясни невозможность XOR в одном линейном перцептроне и предложи двухслойное решение.
**Пункты РПД:** —

**Связанные страницы:** 3; **символов извлечённого текста:** 638.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D13 — Week 12 Lecture.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=19`
Строки (ID элементов): D13:p0019:u0001, D13:p0019:u0002, D13:p0019:u0003, D13:p0019:u0004, D13:p0019:u0005, D13:p0019:u0006, D13:p0019:u0018
**Общая страница с:** AI-08-02
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
XOR Perceptron
- Activation function: 𝑓𝑥= 81, ∑𝑤"𝑥" + 𝑏> 0
0, ∑𝑤"𝑥" + 𝑏≤0
- Not each task can be
solved by a single perceptron
- XOR is one of those tasks
AND
````

## D13 — Week 12 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=20`
Строки (ID элементов): D13:p0020:u0001, D13:p0020:u0005, D13:p0020:u0006, D13:p0020:u0007, D13:p0020:u0008, D13:p0020:u0047
**Общая страница с:** AI-08-06
**Непроверенные OCR/формулы:** 39 исключённых из основного текста кандидатов; см. JSON.

````text
Feedforward Network
Input
First Layer
Second Layer
Third Layer
as =f3 (LWs2a2+bs)
````

## D13 — Week 12 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=21`
Строки (ID элементов): D13:p0021:u0001, D13:p0021:u0002, D13:p0021:u0003, D13:p0021:u0004, D13:p0021:u0005, D13:p0021:u0006, D13:p0021:u0007, D13:p0021:u0008, D13:p0021:u0009, D13:p0021:u0010
**Общая страница с:** AI-08-06, AI-08-07

````text
Backpropagation on a Network
- Single layer can only deal with linearly separable problems
- To deal with multiple dimensions the network needs to expand in the
number of layers
- Increase the dimensionality; everything in a high dimensional space BECOMES
linearly separable
- As this expands larger and larger the type of problems which can be faced
expands
- Deep Learning
- Beware of Overtraining
````


---

# AI-08-05 — Активации ReLU, Leaky ReLU, PReLU, Softplus

**Раздел РПД:** 8. Искусственные нейронные сети
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Вычисли четыре активации для данного входа и объясни различия градиентов.
**Пункты РПД:** —

**Связанные страницы:** 5; **символов извлечённого текста:** 884.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D13 — Week 12 Lecture.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=10`
Строки (ID элементов): D13:p0010:u0001, D13:p0010:u0002, D13:p0010:u0003, D13:p0010:u0004, D13:p0010:u0005, D13:p0010:u0006, D13:p0010:u0007, D13:p0010:u0008, D13:p0010:u0016, D13:p0010:u0017, D13:p0010:u0019, D13:p0010:u0020, D13:p0010:u0029, D13:p0010:u0030, D13:p0010:u0037, D13:p0010:u0038, D13:p0010:u0039, D13:p0010:u0043, D13:p0010:u0048, D13:p0010:u0049, D13:p0010:u0057, D13:p0010:u0058
**Непроверенные OCR/формулы:** 21 исключённых из основного текста кандидатов; см. JSON.

````text
Activation Functions
- Generally non-linear
- Otherwise output is input
- Required to be differentiable
in backpropagation training
- Uses a calculation of error
- Needs to get the integration of
the differentiation to find error
a= purelin(n)
a = hardlims(n)
Linear Transfer Function
Symmetric Hard Limit Trans. Funct.
0
1
a = tansig(n)
Satlin Transfer Function
Tan-Sigmoid Transfer Function
10
0.833
+0.833
Log-Sigmoid Transfer Function
Radial Basis Function
````

## D13 — Week 12 Lecture.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=11`
Строки (ID элементов): D13:p0011:u0001, D13:p0011:u0002, D13:p0011:u0003, D13:p0011:u0004, D13:p0011:u0008
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Rectified Linear Unit (ReLU)
- Where u is an input to neuron
- One of the most popular activation
functions
f(u) = max(0, uw)
````

## D13 — Week 12 Lecture.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=12`
Строки (ID элементов): D13:p0012:u0001, D13:p0012:u0002, D13:p0012:u0003, D13:p0012:u0004, D13:p0012:u0005, D13:p0012:u0010, D13:p0012:u0013
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Leaky ReLU
- More advanced ReLU
- 𝛼is a hyperparameter chosen and
fixed initially
- Usually, small value
fla)
f(a) = mazx(aa, a)
````

## D13 — Week 12 Lecture.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=13`
Строки (ID элементов): D13:p0013:u0001, D13:p0013:u0002, D13:p0013:u0003, D13:p0013:u0011
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Parametric ReLU
- Advanced Leaky ReLU
- 𝛼parameter can be trained
= max(aa, a)
````

## D13 — Week 12 Lecture.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=14`
Строки (ID элементов): D13:p0014:u0001, D13:p0014:u0002, D13:p0014:u0003, D13:p0014:u0004, D13:p0014:u0005, D13:p0014:u0015, D13:p0014:u0022, D13:p0014:u0025, D13:p0014:u0026, D13:p0014:u0027
**Непроверенные OCR/формулы:** 9 исключённых из основного текста кандидатов; см. JSON.

````text
Softplus
- Softplus is a
approximation to a
ReLU which is
f(u) = ln(1+eu)
— Rectifier
2
1
2
3
````


---

# AI-08-06 — Многослойный перцептрон и прямой проход

**Раздел РПД:** 8. Искусственные нейронные сети
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Вычисли численный прямой проход через двухслойную сеть.
**Пункты РПД:** RPD-35

**Связанные страницы:** 4; **символов извлечённого текста:** 1101.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D13 — Week 12 Lecture.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=20`
Строки (ID элементов): D13:p0020:u0001, D13:p0020:u0005, D13:p0020:u0006, D13:p0020:u0007, D13:p0020:u0008, D13:p0020:u0047
**Общая страница с:** AI-08-04
**Непроверенные OCR/формулы:** 39 исключённых из основного текста кандидатов; см. JSON.

````text
Feedforward Network
Input
First Layer
Second Layer
Third Layer
as =f3 (LWs2a2+bs)
````

## D13 — Week 12 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=21`
Строки (ID элементов): D13:p0021:u0001, D13:p0021:u0002, D13:p0021:u0003, D13:p0021:u0004, D13:p0021:u0005, D13:p0021:u0006, D13:p0021:u0007, D13:p0021:u0008, D13:p0021:u0009, D13:p0021:u0010
**Общая страница с:** AI-08-04, AI-08-07

````text
Backpropagation on a Network
- Single layer can only deal with linearly separable problems
- To deal with multiple dimensions the network needs to expand in the
number of layers
- Increase the dimensionality; everything in a high dimensional space BECOMES
linearly separable
- As this expands larger and larger the type of problems which can be faced
expands
- Deep Learning
- Beware of Overtraining
````

## D13 — Week 12 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=22`
Строки (ID элементов): D13:p0022:u0001, D13:p0022:u0002, D13:p0022:u0003, D13:p0022:u0004, D13:p0022:u0005, D13:p0022:u0006, D13:p0022:u0007, D13:p0022:u0008, D13:p0022:u0009, D13:p0022:u0010, D13:p0022:u0011, D13:p0022:u0012, D13:p0022:u0013
**Общая страница с:** AI-08-07

````text
Basic Training Algorithm
- Initialize the weights in the network (often randomly)
- repeat
- for each example e in the training set do
- O = neural-net-output(network, e); // forward pass
- T = teacher output for e;
- Calculate error (T - O) at the output units;
- Compute wj = wj +a * Err * Ij for all weights from hidden layer to output layer; // backward pass
- Compute wj = wj +a * Err * Ij for all weights from input layer to hidden layer;
- Update the weights in the network to the new weights;
- End for
- until all examples classified correctly or stopping criteria met
- return(network)
````

## D13 — Week 12 Lecture.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=36`
Строки (ID элементов): D13:p0036:u0001, D13:p0036:u0006, D13:p0036:u0007
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Libraries
Keras
TensorFlow
````


---

# AI-08-07 — Обучение обратным распространением ошибки

**Раздел РПД:** 8. Искусственные нейронные сети
**Статус исходной разметки:** частично; ядро
**Диагностический вопрос (черновик):** Проведи один шаг обучения простой сети и покажи, как ошибка меняет веса.
**Пункты РПД:** RPD-33

**Связанные страницы:** 4; **символов извлечённого текста:** 1558.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D13 — Week 12 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=21`
Строки (ID элементов): D13:p0021:u0001, D13:p0021:u0002, D13:p0021:u0003, D13:p0021:u0004, D13:p0021:u0005, D13:p0021:u0006, D13:p0021:u0007, D13:p0021:u0008, D13:p0021:u0009, D13:p0021:u0010
**Общая страница с:** AI-08-04, AI-08-06

````text
Backpropagation on a Network
- Single layer can only deal with linearly separable problems
- To deal with multiple dimensions the network needs to expand in the
number of layers
- Increase the dimensionality; everything in a high dimensional space BECOMES
linearly separable
- As this expands larger and larger the type of problems which can be faced
expands
- Deep Learning
- Beware of Overtraining
````

## D13 — Week 12 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=22`
Строки (ID элементов): D13:p0022:u0001, D13:p0022:u0002, D13:p0022:u0003, D13:p0022:u0004, D13:p0022:u0005, D13:p0022:u0006, D13:p0022:u0007, D13:p0022:u0008, D13:p0022:u0009, D13:p0022:u0010, D13:p0022:u0011, D13:p0022:u0012, D13:p0022:u0013
**Общая страница с:** AI-08-06

````text
Basic Training Algorithm
- Initialize the weights in the network (often randomly)
- repeat
- for each example e in the training set do
- O = neural-net-output(network, e); // forward pass
- T = teacher output for e;
- Calculate error (T - O) at the output units;
- Compute wj = wj +a * Err * Ij for all weights from hidden layer to output layer; // backward pass
- Compute wj = wj +a * Err * Ij for all weights from input layer to hidden layer;
- Update the weights in the network to the new weights;
- End for
- until all examples classified correctly or stopping criteria met
- return(network)
````

## D13 — Week 12 Lecture.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=23`
Строки (ID элементов): D13:p0023:u0001, D13:p0023:u0002, D13:p0023:u0003, D13:p0023:u0004, D13:p0023:u0005, D13:p0023:u0006, D13:p0023:u0007, D13:p0023:u0008, D13:p0023:u0009, D13:p0023:u0010, D13:p0023:u0011, D13:p0023:u0012, D13:p0023:u0013, D13:p0023:u0014, D13:p0023:u0015, D13:p0023:u0016, D13:p0023:u0017, D13:p0023:u0018, D13:p0023:u0019, D13:p0023:u0020, D13:p0023:u0021, D13:p0023:u0022, D13:p0023:u0023, D13:p0023:u0024, D13:p0023:u0025, D13:p0023:u0026, D13:p0023:u0027, D13:p0023:u0028, D13:p0023:u0029, D13:p0023:u0030, D13:p0023:u0031, D13:p0023:u0032, D13:p0023:u0033

````text
Calculating Error in Backpropagation
- Each node is considered to be part of the error in the overall function
based on its weight in the input
!"
#$%&
$'()'("
*("
&++$+"
"
"(,&
-.
"
"
/,&+&
"
"0"
#$%&
,-%%&#"
"
$1
&++$+"
!
"
!
!
#$%&$%'
!
!(
δ
δ
∑
∈
=
````

## D13 — Week 12 Lecture.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=24`
Строки (ID элементов): D13:p0024:u0001, D13:p0024:u0002, D13:p0024:u0003, D13:p0024:u0004, D13:p0024:u0005, D13:p0024:u0006
**Общая страница с:** AI-08-08

````text
Issues with Backpropagation Networks
- Black Box (all ANN)
- How did you get the answer – can we form any rules?
- I had the program run and this thing was made
- Have to change it into a lookup table and figure out why it has those weights
- Large training samples needed for backpropagation to work effectively
````


---

# AI-08-08 — Интерпретируемость и ограничения нейросетей

**Раздел РПД:** 8. Искусственные нейронные сети
**Статус исходной разметки:** частично; ядро
**Диагностический вопрос (черновик):** Разбери случай ошибочного предсказания и объясни трудности интерпретации ANN.
**Пункты РПД:** —

**Связанные страницы:** 2; **символов извлечённого текста:** 755.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D13 — Week 12 Lecture.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=24`
Строки (ID элементов): D13:p0024:u0001, D13:p0024:u0002, D13:p0024:u0003, D13:p0024:u0004, D13:p0024:u0005, D13:p0024:u0006
**Общая страница с:** AI-08-07

````text
Issues with Backpropagation Networks
- Black Box (all ANN)
- How did you get the answer – can we form any rules?
- I had the program run and this thing was made
- Have to change it into a lookup table and figure out why it has those weights
- Large training samples needed for backpropagation to work effectively
````

## D13 — Week 12 Lecture.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=27`
Строки (ID элементов): D13:p0027:u0001, D13:p0027:u0002, D13:p0027:u0003, D13:p0027:u0004, D13:p0027:u0005, D13:p0027:u0006, D13:p0027:u0007, D13:p0027:u0008, D13:p0027:u0009, D13:p0027:u0010

````text
Deep Learning
- Not a new topic – the biggest developments were done in the 1970s
- Issue – AI Winter
- Issue – Lack of High Performance Computing (HPC) infrastructures
- Removal of these problems has lead to a boom in Deep Learning Research
- AI Winter – funding in AI is returning and expanding
- HPC is now affordable to even start-ups for reasonable costs
- Cloud Computing
- Funding from government interests
- Moves by Google/Amazon etc.
````


---

# AI-08-09 — Нейроэволюция и поиск весов

**Раздел РПД:** 8. Искусственные нейронные сети
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Покажи, как веса нейросети можно оптимизировать эволюционным алгоритмом.
**Пункты РПД:** —

**Связанные страницы:** 2; **символов извлечённого текста:** 741.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D13 — Week 12 Lecture.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=25`
Строки (ID элементов): D13:p0025:u0001, D13:p0025:u0002, D13:p0025:u0003, D13:p0025:u0004, D13:p0025:u0005, D13:p0025:u0006, D13:p0025:u0007, D13:p0025:u0008

````text
Other Trainings and Connection
Methods
- Neural Evolutionary Models
- Have a GA train the network – even allow the GA to assemble the network
- NeuroEvolution of Augmenting Topologies (NEAT)
- Hopfield Networks
- Train much like perceptron
- Not connected in a linear manner
````

## D13 — Week 12 Lecture.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=26`
Строки (ID элементов): D13:p0026:u0001, D13:p0026:u0002, D13:p0026:u0003, D13:p0026:u0004, D13:p0026:u0005, D13:p0026:u0006, D13:p0026:u0007, D13:p0026:u0008, D13:p0026:u0009, D13:p0026:u0010

````text
Neural Evolution
- Treat the weights as being the elements of the chromosome
- The fitness function is the amount of error
- This allows for the use of non-differentiable functions in the elements
- We do not need to rationalize the error caused by each node
- This allows for problems without clear gradients to be attacked with neural
methods
- Can also evolve the structure and connections within the network and
build new infrastructures
- Information propagation
````


---

# AI-08-10 — Практическая классификация датасета Moons

**Раздел РПД:** 8. Искусственные нейронные сети
**Статус исходной разметки:** не найдено; ядро
**Диагностический вопрос (черновик):** Обоснуй архитектуру и проверь качество сети на двух полумесяцах.
**Пункты РПД:** RPD-48

**Исходный текст не найден.** В текущей карте отсутствуют ссылки на учебные материалы.
Текст не генерировался и не заменялся сведениями из РПД.


---

# AI-08-11 — Практическая классификация MNIST

**Раздел РПД:** 8. Искусственные нейронные сети
**Статус исходной разметки:** не найдено; ядро
**Диагностический вопрос (черновик):** Опиши обработку изображений цифр, обучение и проверку нейронной сети.
**Пункты РПД:** RPD-49

**Исходный текст не найден.** В текущей карте отсутствуют ссылки на учебные материалы.
Текст не генерировался и не заменялся сведениями из РПД.


---

# AI-08-12 — AlphaGo как пример сочетания обучения и игрового поиска

**Раздел РПД:** 8. Искусственные нейронные сети
**Статус исходной разметки:** частично; расширение
**Диагностический вопрос (черновик):** Объясни, зачем в сложной игре сочетать нейросетевую оценку и поиск по дереву.
**Пункты РПД:** —

**Связанные страницы:** 4; **символов извлечённого текста:** 1740.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D13 — Week 12 Lecture.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=28`
Строки (ID элементов): D13:p0028:u0001, D13:p0028:u0002, D13:p0028:u0003, D13:p0028:u0004, D13:p0028:u0005, D13:p0028:u0006, D13:p0028:u0007, D13:p0028:u0008, D13:p0028:u0009, D13:p0028:u0010, D13:p0028:u0011

````text
Attacking the Unassailable
- GO
- If chess is a hard problem, then GO is an improbable problem
- Chess n-focation of tree bounded by at most all moves that can be made by 16
pieces – each piece between 3 (pawn on non-home square) and 4*7 moves
allowed to it (queen able to visit all other squares in a rank, file, or two diagonals),
worst case upper bound is 16*4*7 open moves on a turn (note very generous
overage assuming all pawns are now queens)
- In GO, upper bound of moves is to place a stone in one of a 64 by 64 board,
64*64 nodes to visit
- How?
````

## D13 — Week 12 Lecture.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=29`
Строки (ID элементов): D13:p0029:u0001, D13:p0029:u0002, D13:p0029:u0003, D13:p0029:u0004, D13:p0029:u0005, D13:p0029:u0006, D13:p0029:u0007

````text
Research into GO
- Lots of work has been done on the problem of GO due to its complexity
- Full special sessions and Journal articles have been dedicated to
advancements in play
- Many of these look at higher level structures rather than individual plays
- Eyes (places you cannot put an enemy stone as it would be captured)
- Board edges (Again building from the uncapturable nature of these squares)
````

## D13 — Week 12 Lecture.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=30`
Строки (ID элементов): D13:p0030:u0001, D13:p0030:u0002, D13:p0030:u0003, D13:p0030:u0004, D13:p0030:u0005, D13:p0030:u0006, D13:p0030:u0007, D13:p0030:u0008, D13:p0030:u0009, D13:p0030:u0010, D13:p0030:u0011

````text
Why is GO so important – it is only a
game!
- Games provide interesting surrogate problems for real world issues
- GO is a game of structures and a game with huge number of potential
moves
- We are very interested in this problem as developments in this game
demonstrate perhaps methods we could use to investigate other completive
structures and look at other huge move problems
- Cancer cells
- Protein arrangements
- Molecules
````

## D13 — Week 12 Lecture.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=31`
Строки (ID элементов): D13:p0031:u0001, D13:p0031:u0002, D13:p0031:u0003, D13:p0031:u0004, D13:p0031:u0005, D13:p0031:u0006, D13:p0031:u0007, D13:p0031:u0008

````text
Alpha GO
- Developed in X by Google
- World leading method for the playing of GO
- Uses deep learning (large many multiple layer Neural networks trained by
hours and hours worth of Go playing) in order to develop patterns in the
play, and learn the correct structures
- MCTS is then used to produce the plays with the deep network as the
evaluation method
````


---

# AI-09-01 — Модель частицы, её позиция и скорость в PSO

**Раздел РПД:** 9. Метод роя частиц и муравьиные алгоритмы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Задай состояние частицы и объясни смысл personal best и global best.
**Пункты РПД:** RPD-36

**Связанные страницы:** 8; **символов извлечённого текста:** 2728.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D14 — Week 13 Lecture.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=3`
Строки (ID элементов): D14:p0003:u0001, D14:p0003:u0003

````text
Particle Swarm Optimization
3
````

## D14 — Week 13 Lecture.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=4`
Строки (ID элементов): D14:p0004:u0001, D14:p0004:u0002, D14:p0004:u0003, D14:p0004:u0004, D14:p0004:u0005, D14:p0004:u0006, D14:p0004:u0007, D14:p0004:u0008, D14:p0004:u0009

````text
Artificial Life
- Implementation of Biological Organisms on the Macro Scale
- Two areas where this study focuses:
- Using computational techniques to further the study of biology
- Using these biological techniques to advance computational methods
- Karl Sims Creatures
- Evolutionary Biology – Alife
- Particle Swarm Optimization (PSO)
- Social interactions of birds flocking and fish schooling
````

## D14 — Week 13 Lecture.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=5`
Строки (ID элементов): D14:p0005:u0001, D14:p0005:u0002, D14:p0005:u0003, D14:p0005:u0004, D14:p0005:u0005, D14:p0005:u0006, D14:p0005:u0007, D14:p0005:u0008, D14:p0005:u0009

````text
PSO
- PSO was first introduced by J. Kennedy and R. Eberhart in 1995
- Not intended as a search technique originally
- Simulation of Flocking behaviours of birds
- Areas of food and without food
- High and low areas of fitness
- Communication between members of the flock
- Instant
- Accurate
````

## D14 — Week 13 Lecture.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=6`
Строки (ID элементов): D14:p0006:u0001, D14:p0006:u0002, D14:p0006:u0003, D14:p0006:u0004, D14:p0006:u0005, D14:p0006:u0006, D14:p0006:u0007, D14:p0006:u0008, D14:p0006:u0009, D14:p0006:u0010, D14:p0006:u0011, D14:p0006:u0014, D14:p0006:u0017, D14:p0006:u0018, D14:p0006:u0020, D14:p0006:u0021, D14:p0006:u0023, D14:p0006:u0025, D14:p0006:u0027, D14:p0006:u0029
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
PSO
- Used for real number optimization
- Single points moving over a space
- Compare to ES
- Parallel Search
- Flocks of particles over the space
- All individual search points
- Particles have a location and a velocity
- Velocity based on their momentum, their tendency to fly to the best
location they personally have seen, and to the best location of the
flock
Evolutionary Strategies
Representation
®™ Vector of Real Values
Selection
= Replace with a member of a sample of mutations if better than parent
Crossover
® Originally No, but has been added in some variants
Mutation
© Yes. Add small normally distributed parameter to a value
````

## D14 — Week 13 Lecture.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=7`
Строки (ID элементов): D14:p0007:u0001, D14:p0007:u0002, D14:p0007:u0003, D14:p0007:u0004, D14:p0007:u0005, D14:p0007:u0006, D14:p0007:u0007, D14:p0007:u0008, D14:p0007:u0009, D14:p0007:u0010, D14:p0007:u0011

````text
PSO Usage Fields
- Neural networks
- Image recognition
- Optimization of non-linear N-dimensional problems
- Designing
- Movies
- Biomechanics
- Biochemistry
- Match Processing
- Data Mining
- etc.
````

## D14 — Week 13 Lecture.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=8`
Строки (ID элементов): D14:p0008:u0001, D14:p0008:u0002, D14:p0008:u0003, D14:p0008:u0004, D14:p0008:u0005, D14:p0008:u0006, D14:p0008:u0007, D14:p0008:u0008
**Общая страница с:** AI-09-03

````text
Controls on Exploration and
Exploitation
- Explore
- More emphases on momentum
- Wider Circles about known optimums
- Exploitation
- Local Best/Global Best pull the particles back into the high-valued
positions
````

## D14 — Week 13 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=9`
Строки (ID элементов): D14:p0009:u0001, D14:p0009:u0002, D14:p0009:u0003, D14:p0009:u0004, D14:p0009:u0005, D14:p0009:u0006, D14:p0009:u0007, D14:p0009:u0008, D14:p0009:u0009, D14:p0009:u0010, D14:p0009:u0011, D14:p0009:u0012
**Общая страница с:** AI-09-02

````text
Particle Update
- Particle
- Pos[] – current position of the particle
- V[] – current velocity vector
- myBest[] – best position found by the particle
- Flock has a best
- globalBest[] – best position found by any member of the flock
- Particle’s new velocity is
- V[t+1] = m*V[t] + c1*rand[0,1]*(myBest[]-Pos[t]) + c2*rand[0,1]*(globalBest[]-Pos[t]) (1)
- m – momentum value (usually 1)
- Particle update is
- Pos[t+1] = Pos[t] + V[t+1] (2)
````

## D14 — Week 13 Lecture.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=10`
Строки (ID элементов): D14:p0010:u0001, D14:p0010:u0002, D14:p0010:u0003, D14:p0010:u0004, D14:p0010:u0005, D14:p0010:u0006, D14:p0010:u0007, D14:p0010:u0008, D14:p0010:u0009, D14:p0010:u0010, D14:p0010:u0011, D14:p0010:u0012, D14:p0010:u0013, D14:p0010:u0014, D14:p0010:u0015, D14:p0010:u0016
**Общая страница с:** AI-09-02

````text
PSO Loop
- For each particle
Initialize particle (usually random position and velocity)
END
Do
For each particle
Calculate fitness value
If the fitness value is better than the best fitness value (pBest) in history,
set current value as the new pBest
END
Choose the particle with the best fitness value of all the particles as the gBest
For each particle
Calculate particle velocity according equation (1)
Update particle position according equation (2)
END
While maximum iterations or minimum error criteria is not attained
````


---

# AI-09-02 — Формула обновления скорости и положения PSO

**Раздел РПД:** 9. Метод роя частиц и муравьиные алгоритмы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Вычисли следующий шаг частицы при заданных коэффициентах, случайных значениях и pBest/gBest.
**Пункты РПД:** RPD-36

**Связанные страницы:** 5; **символов извлечённого текста:** 1904.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D14 — Week 13 Lecture.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=9`
Строки (ID элементов): D14:p0009:u0001, D14:p0009:u0002, D14:p0009:u0003, D14:p0009:u0004, D14:p0009:u0005, D14:p0009:u0006, D14:p0009:u0007, D14:p0009:u0008, D14:p0009:u0009, D14:p0009:u0010, D14:p0009:u0011, D14:p0009:u0012
**Общая страница с:** AI-09-01

````text
Particle Update
- Particle
- Pos[] – current position of the particle
- V[] – current velocity vector
- myBest[] – best position found by the particle
- Flock has a best
- globalBest[] – best position found by any member of the flock
- Particle’s new velocity is
- V[t+1] = m*V[t] + c1*rand[0,1]*(myBest[]-Pos[t]) + c2*rand[0,1]*(globalBest[]-Pos[t]) (1)
- m – momentum value (usually 1)
- Particle update is
- Pos[t+1] = Pos[t] + V[t+1] (2)
````

## D14 — Week 13 Lecture.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=10`
Строки (ID элементов): D14:p0010:u0001, D14:p0010:u0002, D14:p0010:u0003, D14:p0010:u0004, D14:p0010:u0005, D14:p0010:u0006, D14:p0010:u0007, D14:p0010:u0008, D14:p0010:u0009, D14:p0010:u0010, D14:p0010:u0011, D14:p0010:u0012, D14:p0010:u0013, D14:p0010:u0014, D14:p0010:u0015, D14:p0010:u0016
**Общая страница с:** AI-09-01

````text
PSO Loop
- For each particle
Initialize particle (usually random position and velocity)
END
Do
For each particle
Calculate fitness value
If the fitness value is better than the best fitness value (pBest) in history,
set current value as the new pBest
END
Choose the particle with the best fitness value of all the particles as the gBest
For each particle
Calculate particle velocity according equation (1)
Update particle position according equation (2)
END
While maximum iterations or minimum error criteria is not attained
````

## D14 — Week 13 Lecture.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=11`
Строки (ID элементов): D14:p0011:u0001, D14:p0011:u0002, D14:p0011:u0003, D14:p0011:u0004, D14:p0011:u0005, D14:p0011:u0006
**Общая страница с:** AI-09-05

````text
Stopping Criteria
- Number of iterations
- For how long gBest wasn’t updated
- Swarm radius threshold
- Vanishing sum of velocities
- etc.
````

## D14 — Week 13 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=21`
Строки (ID элементов): D14:p0021:u0001, D14:p0021:u0002, D14:p0021:u0003, D14:p0021:u0004, D14:p0021:u0005, D14:p0021:u0006, D14:p0021:u0007, D14:p0021:u0008, D14:p0021:u0009, D14:p0021:u0010, D14:p0021:u0011
**Общая страница с:** AI-09-03

````text
Parameters
- V[t+1] = m*V[t] +                                        // Inertia term
+ c1*rand[0,1]*(myBest[]-Position[t]) +    // Cognitive component
+ c2*rand[0,1]*(globalBest[]-Position[t]) // Social component
- m – intertia or momentum
- c1 – personal (cognitive) acceleration coefficient
- c2 – global (social) acceleration coefficient
- Position[] – current position of the particle
- V[] – current velocity vector
- myBest[] – best position found by the particle
- globalBest[] – best position found by any member of the flock
````

## D14 — Week 13 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=22`
Строки (ID элементов): D14:p0022:u0001, D14:p0022:u0004, D14:p0022:u0005, D14:p0022:u0006, D14:p0022:u0007
**Общая страница с:** AI-09-03

````text
Parameters
- The PSO parameters can also be tuned by using another overlaying
optimizer, a concept known as meta-optimization, or even fine-
tuned during the optimization, e.g., by means of fuzzy logic
- Population amount and amount of iterations should be chosen too
````


---

# AI-09-03 — Инерция и управление exploration-exploitation в PSO

**Раздел РПД:** 9. Метод роя частиц и муравьиные алгоритмы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Предскажи последствия изменения инерции и коэффициентов притяжения на движение роя.
**Пункты РПД:** —

**Связанные страницы:** 3; **символов извлечённого текста:** 1011.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D14 — Week 13 Lecture.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=8`
Строки (ID элементов): D14:p0008:u0001, D14:p0008:u0002, D14:p0008:u0003, D14:p0008:u0004, D14:p0008:u0005, D14:p0008:u0006, D14:p0008:u0007, D14:p0008:u0008
**Общая страница с:** AI-09-01

````text
Controls on Exploration and
Exploitation
- Explore
- More emphases on momentum
- Wider Circles about known optimums
- Exploitation
- Local Best/Global Best pull the particles back into the high-valued
positions
````

## D14 — Week 13 Lecture.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=21`
Строки (ID элементов): D14:p0021:u0001, D14:p0021:u0002, D14:p0021:u0003, D14:p0021:u0004, D14:p0021:u0005, D14:p0021:u0006, D14:p0021:u0007, D14:p0021:u0008, D14:p0021:u0009, D14:p0021:u0010, D14:p0021:u0011
**Общая страница с:** AI-09-02

````text
Parameters
- V[t+1] = m*V[t] +                                        // Inertia term
+ c1*rand[0,1]*(myBest[]-Position[t]) +    // Cognitive component
+ c2*rand[0,1]*(globalBest[]-Position[t]) // Social component
- m – intertia or momentum
- c1 – personal (cognitive) acceleration coefficient
- c2 – global (social) acceleration coefficient
- Position[] – current position of the particle
- V[] – current velocity vector
- myBest[] – best position found by the particle
- globalBest[] – best position found by any member of the flock
````

## D14 — Week 13 Lecture.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=22`
Строки (ID элементов): D14:p0022:u0001, D14:p0022:u0004, D14:p0022:u0005, D14:p0022:u0006, D14:p0022:u0007
**Общая страница с:** AI-09-02

````text
Parameters
- The PSO parameters can also be tuned by using another overlaying
optimizer, a concept known as meta-optimization, or even fine-
tuned during the optimization, e.g., by means of fuzzy logic
- Population amount and amount of iterations should be chosen too
````


---

# AI-09-04 — Топологии gbest и lbest

**Раздел РПД:** 9. Метод роя частиц и муравьиные алгоритмы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Сравни обновление частиц при двух топологиях и объясни компромисс скорость-разнообразие.
**Пункты РПД:** RPD-50

**Связанные страницы:** 5; **символов извлечённого текста:** 2495.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D14 — Week 13 Lecture.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=23`
Строки (ID элементов): D14:p0023:u0001, D14:p0023:u0002, D14:p0023:u0003, D14:p0023:u0004, D14:p0023:u0005, D14:p0023:u0006, D14:p0023:u0007, D14:p0023:u0008, D14:p0023:u0009, D14:p0023:u0010, D14:p0023:u0011, D14:p0023:u0012

````text
Different PSO Types
- gbest – global best
- lbest – local best
- Canonical PSO
- Kenedy and Eberhart developed canonical PSO by altering velocity term into a
probability threshold
- Inertia Weighted PSO
- Fully Informed Particle Swarm
- Time-Varying Inertia Weighted PSO
- According to this PSO type inertia can be not only positive constant, it can be
negative, also it can be changed during optimization
- etc.
````

## D14 — Week 13 Lecture.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=24`
Строки (ID элементов): D14:p0024:u0001, D14:p0024:u0002, D14:p0024:u0003, D14:p0024:u0004, D14:p0024:u0005, D14:p0024:u0006, D14:p0024:u0007

````text
GBEST – Global Best
- Originally parameters have next values:
- m = 1
- c1 = 2
- c2 = 2
- Parameters can be changed and need to be changed for better
results
````

## D14 — Week 13 Lecture.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=25`
Строки (ID элементов): D14:p0025:u0001, D14:p0025:u0002, D14:p0025:u0003, D14:p0025:u0004, D14:p0025:u0005, D14:p0025:u0006, D14:p0025:u0007, D14:p0025:u0008, D14:p0025:u0009, D14:p0025:u0010, D14:p0025:u0011, D14:p0025:u0012, D14:p0025:u0013
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
LBEST – Local Best
- In the GBEST swarm, all the particles are neighbors of each other.
Thus, the position of the best overall particle in the swarm is used in
the social term of the velocity update equation. It is assumed that
GBEST swarms converge fast, as all the particles are attracted
simultaneously to the best part of the search space. However, if the
global optimum is not close to the best particle, it may be
impossible to the swarm to explore other areas; this means that the
swarm can be trapped in local optima
- In the LBEST swarm, only a specific number of particles (neighbor
count) can affect the velocity of a given particle. The swarm will
converge slower but can locate the global optimum with a greater
chance
````

## D14 — Week 13 Lecture.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=26`
Строки (ID элементов): D14:p0026:u0001, D14:p0026:u0002, D14:p0026:u0003, D14:p0026:u0004, D14:p0026:u0005, D14:p0026:u0006, D14:p0026:u0007, D14:p0026:u0008, D14:p0026:u0009, D14:p0026:u0010, D14:p0026:u0011, D14:p0026:u0012, D14:p0026:u0013, D14:p0026:u0014, D14:p0026:u0015, D14:p0026:u0016, D14:p0026:u0017, D14:p0026:u0018, D14:p0026:u0019, D14:p0026:u0020
**Непроверенные OCR/формулы:** 6 исключённых из основного текста кандидатов; см. JSON.

````text
Other PSO Topologies (1)
- The following additional topologies were
tested:
- Random
- Von Neumann, a two dimensional grid
with neighbors to the N, E, W and S
- Pyramid, a three-dimensional triangular
grid
- Star, all the particles connected to a
central particle
- Heterogeneous, particles are grouped in
several cliques
A flattened representation of the
Von Neumann neighborhood (top
left), three-dimensional
representation of the Von
Neumann neighborhood (bottom
left), the star (top right) and the
pyramid (bottom right)
neighborhoods
````

## D14 — Week 13 Lecture.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=27`
Строки (ID элементов): D14:p0027:u0001, D14:p0027:u0002, D14:p0027:u0003, D14:p0027:u0004, D14:p0027:u0005, D14:p0027:u0006, D14:p0027:u0007, D14:p0027:u0008, D14:p0027:u0009, D14:p0027:u0010, D14:p0027:u0011, D14:p0027:u0012

````text
Other PSO Topologies (2)
- The swarms with the different neighborhoods were used to optimize
several known functions and an statistical analysis was carried out
over several dependents: best result at 1000 iterations, number of
iterations needed to meet the stopping criteria, and whether the
stopping criteria were met or not
- The conclusions depended on the variable selected, but a
combined measure selected the Von Neumann and Pyramid
neighborhoods as the best, and the star and gbest as the worst.
Other conclusions were that higher k favored performance (good
exploration), while lower k favored the chance of meeting the
criteria (good exploitation)
````


---

# AI-09-05 — Остановка, дискретизация и параллельность PSO

**Раздел РПД:** 9. Метод роя частиц и муравьиные алгоритмы
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Предложи критерии остановки PSO и адаптацию для дискретной задачи.
**Пункты РПД:** —

**Связанные страницы:** 5; **символов извлечённого текста:** 1237.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D14 — Week 13 Lecture.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=11`
Строки (ID элементов): D14:p0011:u0001, D14:p0011:u0002, D14:p0011:u0003, D14:p0011:u0004, D14:p0011:u0005, D14:p0011:u0006
**Общая страница с:** AI-09-02

````text
Stopping Criteria
- Number of iterations
- For how long gBest wasn’t updated
- Swarm radius threshold
- Vanishing sum of velocities
- etc.
````

## D14 — Week 13 Lecture.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=12`
Строки (ID элементов): D14:p0012:u0001, D14:p0012:u0005, D14:p0012:u0014, D14:p0012:u0016
**Непроверенные OCR/формулы:** 32 исключённых из основного текста кандидатов; см. JSON.

````text
Graphical Simulation
20
15
10
````

## D14 — Week 13 Lecture.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=13`
Строки (ID элементов): D14:p0013:u0001, D14:p0013:u0002, D14:p0013:u0003, D14:p0013:u0004, D14:p0013:u0005, D14:p0013:u0006, D14:p0013:u0007, D14:p0013:u0008, D14:p0013:u0009, D14:p0013:u0010

````text
Comparison to Evolutionary
Techniques
- Bio-inspired
- Population-based
- Idea of Fitness
- Optimization via search
- Swarms can have physical realities
- Swarm Robot Intelligence
- Intelligent Agents
- PSO has memory, EAs don’t
````

## D14 — Week 13 Lecture.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=14`
Строки (ID элементов): D14:p0014:u0001, D14:p0014:u0002, D14:p0014:u0003, D14:p0014:u0004, D14:p0014:u0005, D14:p0014:u0006

````text
PSO for Discrete Problems
- Quantization of the space
- Map the values in the real space onto real valued grid
- Map can be a simple rounding or a more complicated mapping
- Might want to use the same kind of ordered selection mapping
based on the real values as we did for ordered gene problems
````

## D14 — Week 13 Lecture.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=15`
Строки (ID элементов): D14:p0015:u0001, D14:p0015:u0002, D14:p0015:u0003, D14:p0015:u0004, D14:p0015:u0005, D14:p0015:u0006, D14:p0015:u0007, D14:p0015:u0008, D14:p0015:u0009, D14:p0015:u0010, D14:p0015:u0011, D14:p0015:u0012, D14:p0015:u0013, D14:p0015:u0014, D14:p0015:u0015, D14:p0015:u0016, D14:p0015:u0017, D14:p0015:u0018, D14:p0015:u0019

````text
Distributing Particles
- 
Multiple computational elements
- Cluster-based computing
- 
Each node has its own flock of particles
- 
Flocks of Flocks
- Higher level particles which take on their starting positions to be the global best of one of the
flocks – moved to that position as time changes
- 
Distributed Best
- The best of all global bests
- Updated to all the flocks
- Particles see this as another factor in their equation
- 
Search space can be divided among the flocks
- No fly zones
- Anything outside of the zone has 0 fitness by fiat
````


---

# AI-09-06 — Муравьиная оптимизация и стигмергия

**Раздел РПД:** 9. Метод роя частиц и муравьиные алгоритмы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Объясни, как локальное оставление феромона приводит к коллективному поиску маршрута.
**Пункты РПД:** RPD-37

**Связанные страницы:** 25; **символов извлечённого текста:** 4662.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D14 — Week 13 Lecture.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=28`
Строки (ID элементов): D14:p0028:u0001, D14:p0028:u0003
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Ant Colony Optimization
28
````

## D14 — Week 13 Lecture.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=29`
Строки (ID элементов): D14:p0029:u0001, D14:p0029:u0002, D14:p0029:u0003, D14:p0029:u0004, D14:p0029:u0005, D14:p0029:u0006, D14:p0029:u0007, D14:p0029:u0008, D14:p0029:u0009, D14:p0029:u0010, D14:p0029:u0011, D14:p0029:u0012, D14:p0029:u0013
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Ant Colony Optimization
- First algorithm was initially proposed by Colorni, Dorigo and Maniezzo
in 1992
- Based on idea of stigmergy - a mechanism of indirect coordination
between agents or actions, in which the aftereffects of one action
guide a subsequent action
- Ant Colony Optimization (ACO) is a population-based, general search
technique for the solution of difficult combinatorial problems, which is
inspired by the pheromone trail laying behavior of real ant colonies
- In ACO, a set of software agents called artificial ants search for good
solutions to a given optimization problem. To apply ACO, the
optimization problem is transformed into the problem of finding the
best path on a weighted graph
````

## D14 — Week 13 Lecture.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=30`
Строки (ID элементов): D14:p0030:u0001, D14:p0030:u0002, D14:p0030:u0003, D14:p0030:u0004, D14:p0030:u0005
**Общая страница с:** AI-09-10

````text
ACO Advantages
- ACO has an advantage over simulated annealing and genetic
algorithm approaches of similar problems when the graph may
change dynamically; the ant colony algorithm can be run
continuously and adapt to changes in real time
````

## D14 — Week 13 Lecture.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=31`
Строки (ID элементов): D14:p0031:u0001, D14:p0031:u0004, D14:p0031:u0005, D14:p0031:u0006, D14:p0031:u0007, D14:p0031:u0008, D14:p0031:u0009, D14:p0031:u0010, D14:p0031:u0011, D14:p0031:u0012, D14:p0031:u0013, D14:p0031:u0014, D14:p0031:u0015, D14:p0031:u0016, D14:p0031:u0017, D14:p0031:u0018, D14:p0031:u0019, D14:p0031:u0020, D14:p0031:u0021, D14:p0031:u0022, D14:p0031:u0023, D14:p0031:u0024, D14:p0031:u0025, D14:p0031:u0026, D14:p0031:u0027, D14:p0031:u0028, D14:p0031:u0029, D14:p0031:u0030, D14:p0031:u0031, D14:p0031:u0032, D14:p0031:u0033, D14:p0031:u0034
**Общая страница с:** AI-09-10

````text
Family of ACO Algorithms
Algorithm
Authors
Year
Ant System (AS)
Dorigo et al.
1991
Elitist AS
Dorigo et al.
1992
Ant-Q
Gamdardella & Dorigo
1995
Ant Colony System (ACS)
Dorigo & Gamdardella
1996
Max-Min AS
Stützle & Hoos
1996
Rank-based AS
Bullnheimer et al.
1997
Ants
Maniezzo
1999
BWAS
Cordon et al.
2000
Hyper-cube AS
Blum et al.
2001
- Here is non-exhaustive list of ACO algorithms
````

## D14 — Week 13 Lecture.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=32`
Строки (ID элементов): D14:p0032:u0001, D14:p0032:u0006, D14:p0032:u0008, D14:p0032:u0019, D14:p0032:u0020
**Непроверенные OCR/формулы:** 11 исключённых из основного текста кандидатов; см. JSON.

````text
How do ants forage for food?
Antenna
DO a WANT ANTS?
BECAUSE THAT'
OW,YOU GET ANTS
````

## D14 — Week 13 Lecture.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=33`
Строки (ID элементов): D14:p0033:u0001, D14:p0033:u0014, D14:p0033:u0016
**Непроверенные OCR/формулы:** 21 исключённых из основного текста кандидатов; см. JSON.

````text
Trails of Smell - Pheromones
Obstacle
Nest
````

## D14 — Week 13 Lecture.pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=34`
Строки (ID элементов): D14:p0034:u0001, D14:p0034:u0002, D14:p0034:u0003, D14:p0034:u0004, D14:p0034:u0005, D14:p0034:u0006, D14:p0034:u0007

````text
Algorithm
- Step 1: Represent the solution space by a construction graph
- Step 2: Initialize ACO parameters
- Step 3: Generate random solutions from each ant’s random walk
- Step 4: Update pheromone intensities
- Step 5: Go to Step 3, and repeat until convergence or a stopping
condition is satisfied
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=5`
Строки (ID элементов): D15:p0005:u0001, D15:p0005:u0003, D15:p0005:u0004, D15:p0005:u0005, D15:p0005:u0007, D15:p0005:u0009, D15:p0005:u0010, D15:p0005:u0012

````text
Ant Colony Optimization (ACO)
The study of artificial systems modeled after the behavior of
real ant colonies and are useful in solving discrete optimization
problems
Introduced in 1992 by Marco Dorigo
It is a population-based metaheuristic used to find
approximate solutions to difficult optimization problems
https://www.youtube.com/watch?v=qfeymoF8pb4
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=6`
Строки (ID элементов): D15:p0006:u0001, D15:p0006:u0003, D15:p0006:u0005, D15:p0006:u0007, D15:p0006:u0009, D15:p0006:u0010, D15:p0006:u0012, D15:p0006:u0014, D15:p0006:u0015

````text
Artificial Ants
A set of software agents
Stochastic
Based on the pheromone model
Pheromones are used by real ants to mark paths.  Ants follow
these paths (i.e., trail-following behaviors)
Incrementally build solutions by moving on a graph
Constraints of the problem are built into the heuristics of the
ants
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=7`
Строки (ID элементов): D15:p0007:u0001, D15:p0007:u0002, D15:p0007:u0003, D15:p0007:u0004, D15:p0007:u0005, D15:p0007:u0006, D15:p0007:u0007, D15:p0007:u0008

````text
A key concept:  Stigmergy
Stigmergy is:
indirect communication via interaction with the environment.
 A problem gets solved bit by bit ..
 Individuals communicate with each other in the above way, affecting what each
other does on the task.
 Individuals leave markers or messages – these don’t solve the problem in themselves,
but they affect other individuals in a way that helps them solve the problem …
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=8`
Строки (ID элементов): D15:p0008:u0001, D15:p0008:u0002, D15:p0008:u0004, D15:p0008:u0005
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
Naturally Observed Ant Behavior
All is well in the world of the ant.
Nest
Food
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=9`
Строки (ID элементов): D15:p0009:u0001, D15:p0009:u0002, D15:p0009:u0003, D15:p0009:u0006
**Непроверенные OCR/формулы:** 7 исключённых из основного текста кандидатов; см. JSON.

````text
Naturally Observed Ant Behavior
Oh no! An obstacle has blocked our
path!
Food
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=10`
Строки (ID элементов): D15:p0010:u0001, D15:p0010:u0002, D15:p0010:u0003, D15:p0010:u0005, D15:p0010:u0007, D15:p0010:u0015
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
Naturally Observed Ant Behavior
Where do we go? Everybody, ﬂip a
coin.
Nest
Food
Obstacle
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=11`
Строки (ID элементов): D15:p0011:u0001, D15:p0011:u0002, D15:p0011:u0005, D15:p0011:u0007, D15:p0011:u0016
**Непроверенные OCR/формулы:** 10 исключённых из основного текста кандидатов; см. JSON.

````text
Naturally Observed Ant Behavior
Shorter path reinforced.
Nest
Food
Obstacle
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=12`
Строки (ID элементов): нет
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

*На привязанной странице нет текста в категории educational; проверь изображение слайда.*

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=13`
Строки (ID элементов): D15:p0013:u0001, D15:p0013:u0002, D15:p0013:u0003, D15:p0013:u0004, D15:p0013:u0005, D15:p0013:u0006, D15:p0013:u0007, D15:p0013:u0008, D15:p0013:u0009, D15:p0013:u0010, D15:p0013:u0011

````text
Stigmergy in Ants
Ants are behaviorally unsophisticated, but
collectively they can perform complex tasks.
Ants have highly developed sophisticated
sign-based stigmergy
 They communicate using pheromones;
 They lay trails of pheromone that can be followed
by other ants.
 If an ant has a choice of two pheromone trails
to follow, one to the NW, one to the NE, but the
NW one is stronger – which one will it follow?
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=14`
Строки (ID элементов): D15:p0014:u0001, D15:p0014:u0002, D15:p0014:u0003, D15:p0014:u0004, D15:p0014:u0005, D15:p0014:u0006, D15:p0014:u0007, D15:p0014:u0008, D15:p0014:u0009
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Pheromone Trails
Individual ants lay pheromone trails while travelling
from the nest, to the nest or possibly in both
directions.
The pheromone trail gradually evaporates over time.
But pheromone trail strength accumulate with
multiple ants using path.
Food source
Nest
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 15
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=15`
Строки (ID элементов): D15:p0015:u0001, D15:p0015:u0002, D15:p0015:u0003, D15:p0015:u0004, D15:p0015:u0005, D15:p0015:u0006, D15:p0015:u0007, D15:p0015:u0008, D15:p0015:u0009, D15:p0015:u0010

````text
* Properties of the pheromone:
— The pheromone is olfactive and volatile.
— The pheromone is stronger if more ants go along
the same path (reinforced by number).
— The pheromone is stronger if the path from the
nest to the food is shorter
(less evaporation).
After a while, the
shortest path will be
found automatically!
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=16`
Строки (ID элементов): D15:p0016:u0001, D15:p0016:u0002, D15:p0016:u0003, D15:p0016:u0004, D15:p0016:u0005, D15:p0016:u0006, D15:p0016:u0007, D15:p0016:u0008, D15:p0016:u0017, D15:p0016:u0018, D15:p0016:u0020, D15:p0016:u0022, D15:p0016:u0031, D15:p0016:u0032, D15:p0016:u0033, D15:p0016:u0034, D15:p0016:u0035, D15:p0016:u0036
**Непроверенные OCR/формулы:** 19 исключённых из основного текста кандидатов; см. JSON.

````text
τ = 30
τ = 30
τ = 15
τ = 15
Initial
state:
no ants
Pheromone Trails continued
30 ants
30 ants
5 ants
20 ants
15 ants
15 ants
10 ants
20 ants
30 ants
30 ants
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 28
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=28`
Строки (ID элементов): D15:p0028:u0002, D15:p0028:u0003, D15:p0028:u0004, D15:p0028:u0006
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Ant foraging
Cooperative search by pheromone trails
( Nest)
Food
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 29
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=29`
Строки (ID элементов): D15:p0029:u0002, D15:p0029:u0003
**Непроверенные OCR/формулы:** 5 исключённых из основного текста кандидатов; см. JSON.

````text
Ant foraging
Cooperative search by pheromone trails
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=30`
Строки (ID элементов): D15:p0030:u0002, D15:p0030:u0003, D15:p0030:u0005
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Ant foraging
Cooperative search by pheromone trails
Food
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=31`
Строки (ID элементов): D15:p0031:u0002, D15:p0031:u0003, D15:p0031:u0004
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
Ant foraging
Cooperative search by pheromone trails
Food,
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=32`
Строки (ID элементов): D15:p0032:u0002, D15:p0032:u0003, D15:p0032:u0005
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Ant foraging
Cooperative search by pheromone trails
(Food
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=33`
Строки (ID элементов): D15:p0033:u0002, D15:p0033:u0003
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Ant foraging
Cooperative search by pheromone trails
````


---

# AI-09-07 — Вероятностный выбор следующего ребра в ACO

**Раздел РПД:** 9. Метод роя частиц и муравьиные алгоритмы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Рассчитай вероятности перехода муравья по двум рёбрам по феромону и эвристике.
**Пункты РПД:** RPD-37

**Связанные страницы:** 7; **символов извлечённого текста:** 2457.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D14 — Week 13 Lecture.pdf, PDF-страница 40
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=40`
Строки (ID элементов): D14:p0040:u0001, D14:p0040:u0002, D14:p0040:u0003, D14:p0040:u0004, D14:p0040:u0005, D14:p0040:u0006, D14:p0040:u0007, D14:p0040:u0008, D14:p0040:u0009, D14:p0040:u0010, D14:p0040:u0011, D14:p0040:u0029
**Общая страница с:** AI-09-09
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Probability of Path Picking
- 𝛼, β – coefficients to balance 𝜏!,#
and 𝜂!,#, may be considered as 1
- 𝜏!,# – the amount of pheromone
deposited for a state transition i -> j
- 𝜂!,# – distance between i -> j. Can
be ignored, if only pheromone level
is considered
- Li,j – path cost of i -> j edge
- Pi,j is 0 for TSP, if the city was already
visited
Lij
````

## D14 — Week 13 Lecture.pdf, PDF-страница 41
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=41`
Строки (ID элементов): D14:p0041:u0001, D14:p0041:u0004, D14:p0041:u0005, D14:p0041:u0006, D14:p0041:u0008, D14:p0041:u0013, D14:p0041:u0021, D14:p0041:u0022, D14:p0041:u0023, D14:p0041:u0028, D14:p0041:u0037, D14:p0041:u0040, D14:p0041:u0045, D14:p0041:u0049, D14:p0041:u0050
**Общая страница с:** AI-09-09
**Непроверенные OCR/формулы:** 36 исключённых из основного текста кандидатов; см. JSON.

````text
AS EXAMPLE (Path Picking)
- Let us assume 𝛼= 𝛽= 1 and go 1 step back to pick path’s first step
for a new yellow ant. Assume that green and purple ants don’t exist
4
1
1
1
1xt
1
1
= 0.0506
Lij
4
1
= 0.1899
````

## D14 — Week 13 Lecture.pdf, PDF-страница 42
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=42`
Строки (ID элементов): D14:p0042:u0001, D14:p0042:u0002, D14:p0042:u0003, D14:p0042:u0004, D14:p0042:u0005
**Общая страница с:** AI-09-09
**Непроверенные OCR/формулы:** 10 исключённых из основного текста кандидатов; см. JSON.

````text
AS EXAMPLE (Path Picking)
- To make a choice use a roulette wheel. Higher probability indicates more
interest to that direction
- The next move for TSP will not consider going to the node the ant has been
before, but for the algorithm in general may be possible
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=34`
Строки (ID элементов): D15:p0034:u0001, D15:p0034:u0002, D15:p0034:u0003, D15:p0034:u0004, D15:p0034:u0005, D15:p0034:u0006, D15:p0034:u0007, D15:p0034:u0008, D15:p0034:u0009, D15:p0034:u0010, D15:p0034:u0011, D15:p0034:u0012, D15:p0034:u0013, D15:p0034:u0014, D15:p0034:u0015, D15:p0034:u0029
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
Characteristics of the algorithm
The probability of moving from Point A to Point B
depends on the attractiveness of the move and the
trail level.
Attractiveness - an a priori desirability (typically
based on the inverse distance) of the move.
Trail level - an a posteriori, computed attractiveness.
This is computed after an ant completes a solution,
increasing or decreasing the desirabilities of
components of a solution.
Ant Colony Optimization
A
B
C
?
Prob
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=35`
Строки (ID элементов): D15:p0035:u0001, D15:p0035:u0002, D15:p0035:u0003, D15:p0035:u0004, D15:p0035:u0005, D15:p0035:u0006, D15:p0035:u0007, D15:p0035:u0008, D15:p0035:u0009, D15:p0035:u0010, D15:p0035:u0011, D15:p0035:u0012, D15:p0035:u0013, D15:p0035:u0014, D15:p0035:u0015, D15:p0035:u0016, D15:p0035:u0017, D15:p0035:u0018
**Общая страница с:** AI-09-08

````text
Characteristics of the algorithm
Amounts of pheromones are updated after
a solution has been generated.
(1-p) prior pheromone + Δpheromone
Where:
p = a coefficient related to the evaporation rate.
if A→B path is used, pheromone levels increase
Δpheromone = Q / Lk
Where:
Q = a constant
Lk = solution length
Else pheromone levels decrease, since in this case
Δpheromone = 0
Ant Colony Optimization
A
B
C
?
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=36`
Строки (ID элементов): D15:p0036:u0001, D15:p0036:u0002, D15:p0036:u0003, D15:p0036:u0004, D15:p0036:u0005, D15:p0036:u0006, D15:p0036:u0007
**Общая страница с:** AI-09-08

````text
Necessary parameters
1) The initial population of ants (an ant cycle).
2) The total number of tours.
3) The evaporation rate.
4) The amount of pheromone applied to a section of a cycle or solution.
5) The constant Q.
Ant Colony Optimization
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 37
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=37`
Строки (ID элементов): D15:p0037:u0001, D15:p0037:u0002, D15:p0037:u0003, D15:p0037:u0004, D15:p0037:u0005, D15:p0037:u0006, D15:p0037:u0007, D15:p0037:u0008, D15:p0037:u0009, D15:p0037:u0010, D15:p0037:u0011, D15:p0037:u0029
**Общая страница с:** AI-09-08
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
The transition rule
is the amount of pheromone currently on the path that goes
directly from city i to city j.
is the heuristic value of this link – in the classic TSP
application, this is chosen to be 1/distance(i,j)  -- i.e. the shorter
the distance, the higher the heuristic value.
is the probability that ant  k will choose the link that goes
from i to j
State Transition Probability:
Where our ant is at city i, and j is a city as yet unvisited on its
tour, and the summation is over all of k’s unvisited cities
unvisited cities SetU
````


---

# AI-09-08 — Обновление феромона, испарение и подкрепление

**Раздел РПД:** 9. Метод роя частиц и муравьиные алгоритмы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Обнови матрицу феромонов после одного тура и объясни эффект испарения.
**Пункты РПД:** —

**Связанные страницы:** 11; **символов извлечённого текста:** 3383.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D14 — Week 13 Lecture.pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=35`
Строки (ID элементов): D14:p0035:u0001, D14:p0035:u0002, D14:p0035:u0005, D14:p0035:u0006, D14:p0035:u0007, D14:p0035:u0008, D14:p0035:u0009, D14:p0035:u0010, D14:p0035:u0011, D14:p0035:u0012, D14:p0035:u0013, D14:p0035:u0014, D14:p0035:u0015, D14:p0035:u0016, D14:p0035:u0017, D14:p0035:u0018, D14:p0035:u0019, D14:p0035:u0020, D14:p0035:u0021, D14:p0035:u0022, D14:p0035:u0023, D14:p0035:u0024, D14:p0035:u0025, D14:p0035:u0026, D14:p0035:u0027, D14:p0035:u0028, D14:p0035:u0029, D14:p0035:u0030, D14:p0035:u0031, D14:p0035:u0032, D14:p0035:u0033, D14:p0035:u0034, D14:p0035:u0035, D14:p0035:u0036

````text
Ant System (AS) Formulas for
Pheromones
Δ𝜏!,#
$ = $
𝑄
𝐿$
0
, kth ant used edge i -> j
, otherwise
𝜏!,# = (
$%&
'
Δ𝜏!,#
$
Without vaporization
𝜏!,# = 1 −𝜌𝜏!,# + (
$%&
'
Δ𝜏!,#
$
With vaporization
- Q - constant
- i - initial path node
- j – ending path node
- k – index of ant
- Lk – path cost passed by ant k
- m – number of ants
- Δ𝜏!,#
$ – the amount of pheromone
deposited by kth ant for a state
transition i -> j
- 𝜏!,# – the amount of pheromone
deposited for a state transition i -> j
- 𝜌- pheromone evaporation coefficient
````

## D14 — Week 13 Lecture.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=36`
Строки (ID элементов): D14:p0036:u0001, D14:p0036:u0004, D14:p0036:u0007, D14:p0036:u0008, D14:p0036:u0009, D14:p0036:u0010, D14:p0036:u0011, D14:p0036:u0013, D14:p0036:u0018, D14:p0036:u0019, D14:p0036:u0020, D14:p0036:u0021, D14:p0036:u0023, D14:p0036:u0024, D14:p0036:u0032, D14:p0036:u0037, D14:p0036:u0040
**Общая страница с:** AI-09-09
**Непроверенные OCR/формулы:** 23 исключённых из основного текста кандидатов; см. JSON.

````text
AS Example without Vaporization
- Let us apply Ant System for Travelling Salesman Problem. Assume Q=1
Cost graph
Pheromone graph
Cost graph
Pheromone graph
1/14 + 1/31
0.07 + 0.03
0.03
1/14
0.07
1/14
0.07
0.03
Ati; ia
Ati, =
31
````

## D14 — Week 13 Lecture.pdf, PDF-страница 37
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=37`
Строки (ID элементов): D14:p0037:u0001, D14:p0037:u0004, D14:p0037:u0008, D14:p0037:u0009, D14:p0037:u0010, D14:p0037:u0011, D14:p0037:u0012, D14:p0037:u0015, D14:p0037:u0017, D14:p0037:u0018, D14:p0037:u0019, D14:p0037:u0020, D14:p0037:u0021, D14:p0037:u0022
**Общая страница с:** AI-09-09
**Непроверенные OCR/формулы:** 25 исключённых из основного текста кандидатов; см. JSON.

````text
AS Example without Vaporization
- Let us apply Ant System for Travelling Salesman Problem. Assume Q=1
Cost graph
Pheromone graph
Cost graph
Pheromone graph
0.07 + 0.03
«0.03
0.07
0.07
0.07
0.07
0.03
0.03
````

## D14 — Week 13 Lecture.pdf, PDF-страница 38
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=38`
Строки (ID элементов): D14:p0038:u0001, D14:p0038:u0004, D14:p0038:u0007, D14:p0038:u0008, D14:p0038:u0009, D14:p0038:u0010
**Общая страница с:** AI-09-09
**Непроверенные OCR/формулы:** 30 исключённых из основного текста кандидатов; см. JSON.

````text
AS Example with Vaporization
- Let us assume 𝜌=0.5
Cost graph
Pheromone graph
Cost graph
Pheromone graph
````

## D14 — Week 13 Lecture.pdf, PDF-страница 39
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=39`
Строки (ID элементов): D14:p0039:u0001, D14:p0039:u0004, D14:p0039:u0007, D14:p0039:u0008, D14:p0039:u0009, D14:p0039:u0010, D14:p0039:u0013, D14:p0039:u0016, D14:p0039:u0017, D14:p0039:u0018, D14:p0039:u0020, D14:p0039:u0021, D14:p0039:u0027, D14:p0039:u0035
**Общая страница с:** AI-09-09
**Непроверенные OCR/формулы:** 33 исключённых из основного текста кандидатов; см. JSON.

````text
AS Example with Vaporization
- Let us assume 𝜌=0.5
Cost graph
Pheromone graph
Cost graph
Pheromone graph
5*1+1/144+1/31 @ =
0.53
0.57
0.5*1+1/14
0.57
0.53
VAS
0.5*1+1/14+1/31
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=17`
Строки (ID элементов): D15:p0017:u0001, D15:p0017:u0002, D15:p0017:u0003, D15:p0017:u0004, D15:p0017:u0005, D15:p0017:u0006, D15:p0017:u0007, D15:p0017:u0008, D15:p0017:u0009, D15:p0017:u0010, D15:p0017:u0011
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
ACO Algorithm
Set all parameters and initialize the pheromone trails
Loop
Sub-Loop
Construct solutions based on the state transition rule
Apply the online pheromone update rule
Continue until all ants have been generated
Apply Local Search
Evaluate all solutions and record the best solution so far
Apply the offline pheromone update rule
Continue until the stopping criterion is reached
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=18`
Строки (ID элементов): D15:p0018:u0001, D15:p0018:u0002, D15:p0018:u0003, D15:p0018:u0004, D15:p0018:u0005, D15:p0018:u0006, D15:p0018:u0007, D15:p0018:u0008, D15:p0018:u0009, D15:p0018:u0010, D15:p0018:u0011, D15:p0018:u0012, D15:p0018:u0013, D15:p0018:u0014, D15:p0018:u0015, D15:p0018:u0016
**Общая страница с:** AI-09-09
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Ant Systems Algorithm for TSP
Initialize
Place each ant in a randomly chosen city
Choose NextCity(For Each Ant)
more cities
to visit
For Each Ant
Return to the initial cities
Update pheromone level using the tour cost for each ant
Print Best tour
yes
No
Stopping
criteria
yes
No
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=35`
Строки (ID элементов): D15:p0035:u0001, D15:p0035:u0002, D15:p0035:u0003, D15:p0035:u0004, D15:p0035:u0005, D15:p0035:u0006, D15:p0035:u0007, D15:p0035:u0008, D15:p0035:u0009, D15:p0035:u0010, D15:p0035:u0011, D15:p0035:u0012, D15:p0035:u0013, D15:p0035:u0014, D15:p0035:u0015, D15:p0035:u0016, D15:p0035:u0017, D15:p0035:u0018
**Общая страница с:** AI-09-07

````text
Characteristics of the algorithm
Amounts of pheromones are updated after
a solution has been generated.
(1-p) prior pheromone + Δpheromone
Where:
p = a coefficient related to the evaporation rate.
if A→B path is used, pheromone levels increase
Δpheromone = Q / Lk
Where:
Q = a constant
Lk = solution length
Else pheromone levels decrease, since in this case
Δpheromone = 0
Ant Colony Optimization
A
B
C
?
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=36`
Строки (ID элементов): D15:p0036:u0001, D15:p0036:u0002, D15:p0036:u0003, D15:p0036:u0004, D15:p0036:u0005, D15:p0036:u0006, D15:p0036:u0007
**Общая страница с:** AI-09-07

````text
Necessary parameters
1) The initial population of ants (an ant cycle).
2) The total number of tours.
3) The evaporation rate.
4) The amount of pheromone applied to a section of a cycle or solution.
5) The constant Q.
Ant Colony Optimization
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 37
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=37`
Строки (ID элементов): D15:p0037:u0001, D15:p0037:u0002, D15:p0037:u0003, D15:p0037:u0004, D15:p0037:u0005, D15:p0037:u0006, D15:p0037:u0007, D15:p0037:u0008, D15:p0037:u0009, D15:p0037:u0010, D15:p0037:u0011, D15:p0037:u0029
**Общая страница с:** AI-09-07
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
The transition rule
is the amount of pheromone currently on the path that goes
directly from city i to city j.
is the heuristic value of this link – in the classic TSP
application, this is chosen to be 1/distance(i,j)  -- i.e. the shorter
the distance, the higher the heuristic value.
is the probability that ant  k will choose the link that goes
from i to j
State Transition Probability:
Where our ant is at city i, and j is a city as yet unvisited on its
tour, and the summation is over all of k’s unvisited cities
unvisited cities SetU
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 38
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=38`
Строки (ID элементов): D15:p0038:u0001, D15:p0038:u0002, D15:p0038:u0003, D15:p0038:u0004, D15:p0038:u0005, D15:p0038:u0006, D15:p0038:u0007, D15:p0038:u0008, D15:p0038:u0009, D15:p0038:u0028, D15:p0038:u0029, D15:p0038:u0037
**Непроверенные OCR/формулы:** 14 исключённых из основного текста кандидатов; см. JSON.

````text
Global pheromone update
is  amount of pheromone added to the (i, j) link by ant k.
NA           is the number of ants
is a parameter called the pheromone decay rate.
Lk              is the length of the tour completed by ant k
at the next iteration becomes:
Where
Pheromone
evaporation
new
old
or AG =
````


---

# AI-09-09 — Ant System для коммивояжёра

**Раздел РПД:** 9. Метод роя частиц и муравьиные алгоритмы
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Проведи один цикл Ant System на четырёх городах и выбери следующий маршрут.
**Пункты РПД:** —

**Связанные страницы:** 20; **символов извлечённого текста:** 4217.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D14 — Week 13 Lecture.pdf, PDF-страница 36
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=36`
Строки (ID элементов): D14:p0036:u0001, D14:p0036:u0004, D14:p0036:u0007, D14:p0036:u0008, D14:p0036:u0009, D14:p0036:u0010, D14:p0036:u0011, D14:p0036:u0013, D14:p0036:u0018, D14:p0036:u0019, D14:p0036:u0020, D14:p0036:u0021, D14:p0036:u0023, D14:p0036:u0024, D14:p0036:u0032, D14:p0036:u0037, D14:p0036:u0040
**Общая страница с:** AI-09-08
**Непроверенные OCR/формулы:** 23 исключённых из основного текста кандидатов; см. JSON.

````text
AS Example without Vaporization
- Let us apply Ant System for Travelling Salesman Problem. Assume Q=1
Cost graph
Pheromone graph
Cost graph
Pheromone graph
1/14 + 1/31
0.07 + 0.03
0.03
1/14
0.07
1/14
0.07
0.03
Ati; ia
Ati, =
31
````

## D14 — Week 13 Lecture.pdf, PDF-страница 37
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=37`
Строки (ID элементов): D14:p0037:u0001, D14:p0037:u0004, D14:p0037:u0008, D14:p0037:u0009, D14:p0037:u0010, D14:p0037:u0011, D14:p0037:u0012, D14:p0037:u0015, D14:p0037:u0017, D14:p0037:u0018, D14:p0037:u0019, D14:p0037:u0020, D14:p0037:u0021, D14:p0037:u0022
**Общая страница с:** AI-09-08
**Непроверенные OCR/формулы:** 25 исключённых из основного текста кандидатов; см. JSON.

````text
AS Example without Vaporization
- Let us apply Ant System for Travelling Salesman Problem. Assume Q=1
Cost graph
Pheromone graph
Cost graph
Pheromone graph
0.07 + 0.03
«0.03
0.07
0.07
0.07
0.07
0.03
0.03
````

## D14 — Week 13 Lecture.pdf, PDF-страница 38
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=38`
Строки (ID элементов): D14:p0038:u0001, D14:p0038:u0004, D14:p0038:u0007, D14:p0038:u0008, D14:p0038:u0009, D14:p0038:u0010
**Общая страница с:** AI-09-08
**Непроверенные OCR/формулы:** 30 исключённых из основного текста кандидатов; см. JSON.

````text
AS Example with Vaporization
- Let us assume 𝜌=0.5
Cost graph
Pheromone graph
Cost graph
Pheromone graph
````

## D14 — Week 13 Lecture.pdf, PDF-страница 39
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=39`
Строки (ID элементов): D14:p0039:u0001, D14:p0039:u0004, D14:p0039:u0007, D14:p0039:u0008, D14:p0039:u0009, D14:p0039:u0010, D14:p0039:u0013, D14:p0039:u0016, D14:p0039:u0017, D14:p0039:u0018, D14:p0039:u0020, D14:p0039:u0021, D14:p0039:u0027, D14:p0039:u0035
**Общая страница с:** AI-09-08
**Непроверенные OCR/формулы:** 33 исключённых из основного текста кандидатов; см. JSON.

````text
AS Example with Vaporization
- Let us assume 𝜌=0.5
Cost graph
Pheromone graph
Cost graph
Pheromone graph
5*1+1/144+1/31 @ =
0.53
0.57
0.5*1+1/14
0.57
0.53
VAS
0.5*1+1/14+1/31
````

## D14 — Week 13 Lecture.pdf, PDF-страница 40
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=40`
Строки (ID элементов): D14:p0040:u0001, D14:p0040:u0002, D14:p0040:u0003, D14:p0040:u0004, D14:p0040:u0005, D14:p0040:u0006, D14:p0040:u0007, D14:p0040:u0008, D14:p0040:u0009, D14:p0040:u0010, D14:p0040:u0011, D14:p0040:u0029
**Общая страница с:** AI-09-07
**Непроверенные OCR/формулы:** 4 исключённых из основного текста кандидатов; см. JSON.

````text
Probability of Path Picking
- 𝛼, β – coefficients to balance 𝜏!,#
and 𝜂!,#, may be considered as 1
- 𝜏!,# – the amount of pheromone
deposited for a state transition i -> j
- 𝜂!,# – distance between i -> j. Can
be ignored, if only pheromone level
is considered
- Li,j – path cost of i -> j edge
- Pi,j is 0 for TSP, if the city was already
visited
Lij
````

## D14 — Week 13 Lecture.pdf, PDF-страница 41
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=41`
Строки (ID элементов): D14:p0041:u0001, D14:p0041:u0004, D14:p0041:u0005, D14:p0041:u0006, D14:p0041:u0008, D14:p0041:u0013, D14:p0041:u0021, D14:p0041:u0022, D14:p0041:u0023, D14:p0041:u0028, D14:p0041:u0037, D14:p0041:u0040, D14:p0041:u0045, D14:p0041:u0049, D14:p0041:u0050
**Общая страница с:** AI-09-07
**Непроверенные OCR/формулы:** 36 исключённых из основного текста кандидатов; см. JSON.

````text
AS EXAMPLE (Path Picking)
- Let us assume 𝛼= 𝛽= 1 and go 1 step back to pick path’s first step
for a new yellow ant. Assume that green and purple ants don’t exist
4
1
1
1
1xt
1
1
= 0.0506
Lij
4
1
= 0.1899
````

## D14 — Week 13 Lecture.pdf, PDF-страница 42
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=42`
Строки (ID элементов): D14:p0042:u0001, D14:p0042:u0002, D14:p0042:u0003, D14:p0042:u0004, D14:p0042:u0005
**Общая страница с:** AI-09-07
**Непроверенные OCR/формулы:** 10 исключённых из основного текста кандидатов; см. JSON.

````text
AS EXAMPLE (Path Picking)
- To make a choice use a roulette wheel. Higher probability indicates more
interest to that direction
- The next move for TSP will not consider going to the node the ant has been
before, but for the algorithm in general may be possible
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 2
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=2`
Строки (ID элементов): D15:p0002:u0001, D15:p0002:u0004, D15:p0002:u0005, D15:p0002:u0006, D15:p0002:u0017, D15:p0002:u0018, D15:p0002:u0020, D15:p0002:u0025, D15:p0002:u0031, D15:p0002:u0032, D15:p0002:u0034, D15:p0002:u0036, D15:p0002:u0037, D15:p0002:u0047, D15:p0002:u0048, D15:p0002:u0052, D15:p0002:u0056, D15:p0002:u0057, D15:p0002:u0058, D15:p0002:u0059, D15:p0002:u0060
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Непроверенные OCR/формулы:** 33 исключённых из основного текста кандидатов; см. JSON.

````text
Traveling Salesman Problem (TSP)
"Given a list of cities and the distances between each pair of cities, what is the
shortest possible route that visits each city exactly once and returns to the origin
city?"
fashingt
Montana
Montreal
‘wyoming
Rho
Connecti
‘New Je
Matyland
Delaware
Georgia
Columbia
1
Gulf of
Florida
Mexico
49 872
Mexico
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=3`
Строки (ID элементов): D15:p0003:u0001, D15:p0003:u0004, D15:p0003:u0005, D15:p0003:u0013, D15:p0003:u0014, D15:p0003:u0015, D15:p0003:u0016, D15:p0003:u0018, D15:p0003:u0019, D15:p0003:u0020, D15:p0003:u0021, D15:p0003:u0023, D15:p0003:u0024, D15:p0003:u0025, D15:p0003:u0026, D15:p0003:u0028, D15:p0003:u0029, D15:p0003:u0030, D15:p0003:u0031, D15:p0003:u0033, D15:p0003:u0034, D15:p0003:u0035, D15:p0003:u0036
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Непроверенные OCR/формулы:** 10 исключённых из основного текста кандидатов; см. JSON.

````text
Traveling Salesman Problem (2)
The solution can be written as C2->C5->C1->C4->C3->C2. An itinerary that begins
and ends at the same city and visits each city once is called a tour.
132
217
164
158
132
290
201
719
217
290
113
303
164
201
113
196
158
719
303
196
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=4`
Строки (ID элементов): D15:p0004:u0001, D15:p0004:u0005, D15:p0004:u0006, D15:p0004:u0007
**Добавлено при аудите:** страница отсутствовала в первоначальной разметке.
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
TSP – Graph Representation
10
18
18
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 18
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=18`
Строки (ID элементов): D15:p0018:u0001, D15:p0018:u0002, D15:p0018:u0003, D15:p0018:u0004, D15:p0018:u0005, D15:p0018:u0006, D15:p0018:u0007, D15:p0018:u0008, D15:p0018:u0009, D15:p0018:u0010, D15:p0018:u0011, D15:p0018:u0012, D15:p0018:u0013, D15:p0018:u0014, D15:p0018:u0015, D15:p0018:u0016
**Общая страница с:** AI-09-08
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
Ant Systems Algorithm for TSP
Initialize
Place each ant in a randomly chosen city
Choose NextCity(For Each Ant)
more cities
to visit
For Each Ant
Return to the initial cities
Update pheromone level using the tour cost for each ant
Print Best tour
yes
No
Stopping
criteria
yes
No
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 19
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=19`
Строки (ID элементов): D15:p0019:u0001, D15:p0019:u0002, D15:p0019:u0003, D15:p0019:u0004, D15:p0019:u0005, D15:p0019:u0006, D15:p0019:u0007, D15:p0019:u0008, D15:p0019:u0009
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
E.g. A 4-city TSP
A
B
C
D
Pheromone
Ant
AB: 10,   AC: 10,   AD, 30,    BC, 40,    CD 20
Initially, random levels of pheromone are scattered on the edges
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 20
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=20`
Строки (ID элементов): D15:p0020:u0001, D15:p0020:u0002, D15:p0020:u0003, D15:p0020:u0004, D15:p0020:u0005, D15:p0020:u0006, D15:p0020:u0007, D15:p0020:u0008, D15:p0020:u0009
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
E.g. A 4-city TSP
A
B
C
D
Pheromone
Ant
AB: 10,   AC: 10,   AD, 30,    BC, 40,    CD 20
An ant is placed at a random node
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 21
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=21`
Строки (ID элементов): D15:p0021:u0001, D15:p0021:u0002, D15:p0021:u0003, D15:p0021:u0004, D15:p0021:u0005, D15:p0021:u0006, D15:p0021:u0007, D15:p0021:u0008, D15:p0021:u0009, D15:p0021:u0010, D15:p0021:u0011, D15:p0021:u0012, D15:p0021:u0013, D15:p0021:u0014
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
E.g. A 4-city TSP
A
B
C
D
Pheromone
Ant
AB: 10,   AC: 10,   AD, 30,    BC, 40,    CD 20
The ant decides where to go from that node,
based on probabilities
calculated from:
- pheromone strengths,
- next-hop distances.
Suppose this one chooses BC
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 22
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=22`
Строки (ID элементов): D15:p0022:u0001, D15:p0022:u0002, D15:p0022:u0003, D15:p0022:u0004, D15:p0022:u0005, D15:p0022:u0006, D15:p0022:u0007, D15:p0022:u0008, D15:p0022:u0009, D15:p0022:u0010, D15:p0022:u0011, D15:p0022:u0012, D15:p0022:u0013, D15:p0022:u0014, D15:p0022:u0015, D15:p0022:u0016
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
E.g. A 4-city TSP
A
B
C
D
Pheromone
Ant
AB: 10,   AC: 10,   AD, 30,    BC, 40,    CD 20
The ant is now at C, and has a `tour memory’ = {B, C} – so he cannot
visit B or C again.
Again, he decides next hop
(from those allowed) based
on pheromone strength
and distance;
suppose he chooses
CD
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 23
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=23`
Строки (ID элементов): D15:p0023:u0001, D15:p0023:u0002, D15:p0023:u0003, D15:p0023:u0004, D15:p0023:u0005, D15:p0023:u0006, D15:p0023:u0007, D15:p0023:u0008, D15:p0023:u0009, D15:p0023:u0010
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
E.g. A 4-city TSP
A
B
C
D
Pheromone
Ant
AB: 10,   AC: 10,   AD, 30,    BC, 40,    CD 20
The ant is now at D, and has a `tour memory’ = {B, C, D}
There is only one place he can go now:
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 24
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=24`
Строки (ID элементов): D15:p0024:u0001, D15:p0024:u0002, D15:p0024:u0003, D15:p0024:u0004, D15:p0024:u0005, D15:p0024:u0006, D15:p0024:u0007, D15:p0024:u0008, D15:p0024:u0009, D15:p0024:u0010
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
E.g. A 4-city TSP
A
B
C
D
Pheromone
Ant
AB: 10,   AC: 10,   AD, 30,    BC, 40,    CD 20
So, he has nearly finished his tour, having gone over the links:
BC, CD, and DA.
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 25
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=25`
Строки (ID элементов): D15:p0025:u0001, D15:p0025:u0002, D15:p0025:u0003, D15:p0025:u0004, D15:p0025:u0005, D15:p0025:u0006, D15:p0025:u0007, D15:p0025:u0008, D15:p0025:u0009, D15:p0025:u0010, D15:p0025:u0011, D15:p0025:u0012, D15:p0025:u0013
**Непроверенные OCR/формулы:** 2 исключённых из основного текста кандидатов; см. JSON.

````text
E.g. A 4-city TSP
A
B
C
D
Pheromone
Ant
AB: 10,   AC: 10,   AD, 30,    BC, 40,    CD 20
So, he has nearly finished his tour, having gone over the links:
BC, CD, and DA. AB is added to complete the round trip.
Now, pheromone on the tour
is increased, in line with the
fitness of that tour.
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 26
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=26`
Строки (ID элементов): D15:p0026:u0001, D15:p0026:u0002, D15:p0026:u0003, D15:p0026:u0004, D15:p0026:u0005, D15:p0026:u0006, D15:p0026:u0007, D15:p0026:u0008, D15:p0026:u0009, D15:p0026:u0010, D15:p0026:u0011, D15:p0026:u0012
**Непроверенные OCR/формулы:** 1 исключённых из основного текста кандидатов; см. JSON.

````text
E.g. A 4-city TSP
A
B
C
D
Pheromone
Ant
AB: 10,   AC: 10,   AD, 30,    BC, 40,    CD 20
Next, pheromone everywhere
is decreased a little, to model
decay of trail strength over
time
````

## D15 — Week 13. Tutorial.pptx.pdf, PDF-страница 27
Источник в ZIP: `AI_course_cleaned/15_Week 13. Tutorial.pptx/source.pdf#page=27`
Строки (ID элементов): D15:p0027:u0001, D15:p0027:u0002, D15:p0027:u0003, D15:p0027:u0004, D15:p0027:u0005, D15:p0027:u0006, D15:p0027:u0007, D15:p0027:u0008, D15:p0027:u0009, D15:p0027:u0010
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
E.g. A 4-city TSP
B
C
D
Pheromone
Ant
AB: 10,   AC: 10,   AD, 30,    BC, 40,    CD 20
We start again, with another ant in a random position.
Where will he go?
A
````


---

# AI-09-10 — Семейства муравьиных алгоритмов

**Раздел РПД:** 9. Метод роя частиц и муравьиные алгоритмы
**Статус исходной разметки:** частично; ядро
**Диагностический вопрос (черновик):** Сравни перечисленные варианты ACO и укажи, в чём меняется правило поиска.
**Пункты РПД:** —

**Связанные страницы:** 2; **символов извлечённого текста:** 622.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D14 — Week 13 Lecture.pdf, PDF-страница 30
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=30`
Строки (ID элементов): D14:p0030:u0001, D14:p0030:u0002, D14:p0030:u0003, D14:p0030:u0004, D14:p0030:u0005
**Общая страница с:** AI-09-06

````text
ACO Advantages
- ACO has an advantage over simulated annealing and genetic
algorithm approaches of similar problems when the graph may
change dynamically; the ant colony algorithm can be run
continuously and adapt to changes in real time
````

## D14 — Week 13 Lecture.pdf, PDF-страница 31
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=31`
Строки (ID элементов): D14:p0031:u0001, D14:p0031:u0004, D14:p0031:u0005, D14:p0031:u0006, D14:p0031:u0007, D14:p0031:u0008, D14:p0031:u0009, D14:p0031:u0010, D14:p0031:u0011, D14:p0031:u0012, D14:p0031:u0013, D14:p0031:u0014, D14:p0031:u0015, D14:p0031:u0016, D14:p0031:u0017, D14:p0031:u0018, D14:p0031:u0019, D14:p0031:u0020, D14:p0031:u0021, D14:p0031:u0022, D14:p0031:u0023, D14:p0031:u0024, D14:p0031:u0025, D14:p0031:u0026, D14:p0031:u0027, D14:p0031:u0028, D14:p0031:u0029, D14:p0031:u0030, D14:p0031:u0031, D14:p0031:u0032, D14:p0031:u0033, D14:p0031:u0034
**Общая страница с:** AI-09-06

````text
Family of ACO Algorithms
Algorithm
Authors
Year
Ant System (AS)
Dorigo et al.
1991
Elitist AS
Dorigo et al.
1992
Ant-Q
Gamdardella & Dorigo
1995
Ant Colony System (ACS)
Dorigo & Gamdardella
1996
Max-Min AS
Stützle & Hoos
1996
Rank-based AS
Bullnheimer et al.
1997
Ants
Maniezzo
1999
BWAS
Cordon et al.
2000
Hyper-cube AS
Blum et al.
2001
- Here is non-exhaustive list of ACO algorithms
````


---

# AI-09-11 — Моделирование коллективного движения и flocking

**Раздел РПД:** 9. Метод роя частиц и муравьиные алгоритмы
**Статус исходной разметки:** частично; расширение
**Диагностический вопрос (черновик):** Предложи локальные правила движения множества агентов и объясни эффект на уровне всей группы.
**Пункты РПД:** —

**Связанные страницы:** 2; **символов извлечённого текста:** 527.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D14 — Week 13 Lecture.pdf, PDF-страница 16
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=16`
Строки (ID элементов): D14:p0016:u0001, D14:p0016:u0002, D14:p0016:u0003, D14:p0016:u0004, D14:p0016:u0005, D14:p0016:u0006, D14:p0016:u0007, D14:p0016:u0008

````text
Movies
- Number of hard to make effects shots with large crowds or battles
- Cost of extras is high
- Casting
- Administration
- Wages
- Catering
- Special effects software for CGI assets
````

## D14 — Week 13 Lecture.pdf, PDF-страница 17
Источник в ZIP: `AI_course_cleaned/14_Week 13 Lecture/source.pdf#page=17`
Строки (ID элементов): D14:p0017:u0001, D14:p0017:u0002, D14:p0017:u0003, D14:p0017:u0004, D14:p0017:u0005, D14:p0017:u0006, D14:p0017:u0007, D14:p0017:u0008, D14:p0017:u0009, D14:p0017:u0010, D14:p0017:u0011, D14:p0017:u0012, D14:p0017:u0037, D14:p0017:u0038
**Непроверенные OCR/формулы:** 19 исключённых из основного текста кандидатов; см. JSON.

````text
Movies
- Flocking Agent Simulator for LARGE
crowds
- First Developed for Lord of the Rings:
Return of the King and has been seen in
movies such as:
- I, Robot – Robots
- Happy Feet – Dancing Penguins
- Fast and the Furious: Tokyo Drift – Cars
- Hugo – Population in a Train Station
- Avatar - Creatures
- World War Z - Zombies
THE ART O
THE
````


---

# AI-10-01 — Генеративные и дискриминативные модели

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Для нескольких задач объясни, нужен ли генеративный или дискриминативный подход и почему.
**Пункты РПД:** RPD-51

**Связанные страницы:** 5; **символов извлечённого текста:** 1949.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D01 — 14 Tutorial.pdf, PDF-страница 3
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=3`
Строки (ID элементов): D01:p0003:u0001, D01:p0003:u0002, D01:p0003:u0003, D01:p0003:u0004, D01:p0003:u0005, D01:p0003:u0006, D01:p0003:u0007

````text
What is Generative AI?
- AI systems that generate new content: text, images, code,
audio, video
- Trained on huge datasets; learns patterns and
probabilities
- Generates outputs that were not explicitly seen during
training
````

## D01 — 14 Tutorial.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=4`
Строки (ID элементов): D01:p0004:u0001, D01:p0004:u0002, D01:p0004:u0003, D01:p0004:u0004, D01:p0004:u0005, D01:p0004:u0006

````text
Classic AI vs Generative AI
- Classic AI: rules, logic, search, optimization; outputs decisions/labels
- Examples: path planning, chess engines, spam filters
- Generative AI: predicts next token to create new content
- Examples: ChatGPT answers, code completion, story generators
- They are complementary, not competing approaches
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=4`
Строки (ID элементов): D16:p0004:u0001, D16:p0004:u0002, D16:p0004:u0003, D16:p0004:u0004, D16:p0004:u0005, D16:p0004:u0006, D16:p0004:u0007, D16:p0004:u0008, D16:p0004:u0009, D16:p0004:u0010, D16:p0004:u0011, D16:p0004:u0012, D16:p0004:u0013, D16:p0004:u0014, D16:p0004:u0015, D16:p0004:u0016, D16:p0004:u0017, D16:p0004:u0018, D16:p0004:u0019, D16:p0004:u0020, D16:p0004:u0021, D16:p0004:u0022, D16:p0004:u0023
**Общая страница с:** AI-10-02

````text
Generative AI History
- 
1957: Frank Rosenblatt’s Perceptron
- 
1961: the first historical example of GenAI ELIZA by Joseph Weizenbaum
- 
1970s: backpropagation was proposed
- 
Till 2013th mostly discriminative were applied due to the difficulty of generative models
- 
2013: VAE by Diederik P. Kingma and Max Welling
- 
2014: GAN by Ian Goodfellow
- 
2015: Diffusion Models introduced by Sohl-Dicktein et al.
- 
2017: Transformer network by Google researchers
- 
2018: OpenAI intoruduced GPT-1 (Generative Pre-trained Transformer)
- 
2020s: GenAI Boom
- 
2022: public release of ChatGPT for general-purpose text-based tasks
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=5`
Строки (ID элементов): D16:p0005:u0001, D16:p0005:u0002, D16:p0005:u0003, D16:p0005:u0004, D16:p0005:u0005, D16:p0005:u0006, D16:p0005:u0007, D16:p0005:u0008, D16:p0005:u0009, D16:p0005:u0010, D16:p0005:u0011, D16:p0005:u0012, D16:p0005:u0013, D16:p0005:u0017, D16:p0005:u0020, D16:p0005:u0023, D16:p0005:u0024, D16:p0005:u0029, D16:p0005:u0032, D16:p0005:u0033, D16:p0005:u0035, D16:p0005:u0037, D16:p0005:u0043, D16:p0005:u0046, D16:p0005:u0048, D16:p0005:u0050
**Непроверенные OCR/формулы:** 9 исключённых из основного текста кандидатов; см. JSON.

````text
- Machine Learning (ML) is a field of study in AI
concerned with the development and study
of statistical algorithms that can learn from
data and generalise to unseen data, and
thus perform tasks without explicit instructions
- Deep Learning (DL) is a part of ML
- DL focuses on utilizing multilayered neural
networks to perform tasks such as
classification, regression, and representation
learning
- ML uses both discriminative models and
generative models to predict data
Machine Learning
Discriminative Neural Network
0.03 Bird
0.05
Dog
Output
Inpu
Generative Neural Network
“photo of a
tabby cat"
tab.
cat
Input
Output
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=6`
Строки (ID элементов): D16:p0006:u0001, D16:p0006:u0002, D16:p0006:u0003, D16:p0006:u0004, D16:p0006:u0005, D16:p0006:u0006
**Общая страница с:** AI-10-03

````text
Generative AI Types
- Variational Autoencoders (VAE)
- Generative Adversarial Networks (GAN)
- Diffusion Models (DM)
- Large Language Models (LLM)
- …
````


---

# AI-10-02 — Исторические этапы генеративного ИИ

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** частично; ядро
**Диагностический вопрос (черновик):** Свяжи основные подходы генерации с этапами развития и объясни смену возможностей.
**Пункты РПД:** RPD-38

**Связанные страницы:** 1; **символов извлечённого текста:** 624.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 4
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=4`
Строки (ID элементов): D16:p0004:u0001, D16:p0004:u0002, D16:p0004:u0003, D16:p0004:u0004, D16:p0004:u0005, D16:p0004:u0006, D16:p0004:u0007, D16:p0004:u0008, D16:p0004:u0009, D16:p0004:u0010, D16:p0004:u0011, D16:p0004:u0012, D16:p0004:u0013, D16:p0004:u0014, D16:p0004:u0015, D16:p0004:u0016, D16:p0004:u0017, D16:p0004:u0018, D16:p0004:u0019, D16:p0004:u0020, D16:p0004:u0021, D16:p0004:u0022, D16:p0004:u0023
**Общая страница с:** AI-10-01

````text
Generative AI History
- 
1957: Frank Rosenblatt’s Perceptron
- 
1961: the first historical example of GenAI ELIZA by Joseph Weizenbaum
- 
1970s: backpropagation was proposed
- 
Till 2013th mostly discriminative were applied due to the difficulty of generative models
- 
2013: VAE by Diederik P. Kingma and Max Welling
- 
2014: GAN by Ian Goodfellow
- 
2015: Diffusion Models introduced by Sohl-Dicktein et al.
- 
2017: Transformer network by Google researchers
- 
2018: OpenAI intoruduced GPT-1 (Generative Pre-trained Transformer)
- 
2020s: GenAI Boom
- 
2022: public release of ChatGPT for general-purpose text-based tasks
````


---

# AI-10-03 — Вариационные автоэнкодеры VAE

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** частично; ядро
**Диагностический вопрос (черновик):** Объясни, как кодировщик, латентное распределение и декодировщик участвуют в генерации.
**Пункты РПД:** RPD-39

**Связанные страницы:** 2; **символов извлечённого текста:** 728.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=6`
Строки (ID элементов): D16:p0006:u0001, D16:p0006:u0002, D16:p0006:u0003, D16:p0006:u0004, D16:p0006:u0005, D16:p0006:u0006
**Общая страница с:** AI-10-01

````text
Generative AI Types
- Variational Autoencoders (VAE)
- Generative Adversarial Networks (GAN)
- Diffusion Models (DM)
- Large Language Models (LLM)
- …
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=7`
Строки (ID элементов): D16:p0007:u0001, D16:p0007:u0002, D16:p0007:u0003, D16:p0007:u0004, D16:p0007:u0005, D16:p0007:u0006, D16:p0007:u0007, D16:p0007:u0008, D16:p0007:u0009, D16:p0007:u0010, D16:p0007:u0011, D16:p0007:u0018, D16:p0007:u0019, D16:p0007:u0020, D16:p0007:u0021, D16:p0007:u0022, D16:p0007:u0023
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
VAE
- Variational autoencoder is an ANN architecture introduced by
Diederik P. Kingma and Max Welling in 2013
- Encoder transforms input data into parameter distributions
- Decoder takes a sampled vector from the latent distribution and
reconstructs the data
- Due to random sampling, even for the same input data the result will vary,
which provides variety in generation
- Considered to be a bridge between Classic Autoencoders and GAN
- Its strength lies in its ability to model data distributions rather than simply
copying examples
Encoder
Latent
Decoder
Input
Space
Output
````


---

# AI-10-04 — Генеративно-состязательные сети GAN

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Покажи взаимодействие генератора и дискриминатора и критерий остановки обучения.
**Пункты РПД:** RPD-39

**Связанные страницы:** 5; **символов извлечённого текста:** 2963.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D13 — Week 12 Lecture.pdf, PDF-страница 32
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=32`
Строки (ID элементов): D13:p0032:u0001, D13:p0032:u0002, D13:p0032:u0003, D13:p0032:u0004, D13:p0032:u0005, D13:p0032:u0006, D13:p0032:u0007, D13:p0032:u0008, D13:p0032:u0009, D13:p0032:u0010

````text
Adversarial Networks
- Say we are not interested in classification, but in creation of objects which
are close in style to an artist
- Images of Cats
- Music
- We know how to make good classifiers for a problem
- We can say it is a cat or not a cat
- We can say it is music or noise
- The generator’s job is to become so good that our classifier says its output is
in the right class
````

## D13 — Week 12 Lecture.pdf, PDF-страница 33
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=33`
Строки (ID элементов): D13:p0033:u0001, D13:p0033:u0002, D13:p0033:u0003, D13:p0033:u0004, D13:p0033:u0005, D13:p0033:u0006, D13:p0033:u0007, D13:p0033:u0008, D13:p0033:u0009, D13:p0033:u0010, D13:p0033:u0011, D13:p0033:u0012, D13:p0033:u0013

````text
Forgers and Detectives
- The detective begins his work, looking at a number of real notes coming
from the treasury department, he studies them. He also studies a group of
randomly coloured sheets of paper
- Once the detective can distinguish between banknotes (YES) and scraps of
coloured paper (NO) to a sufficient extent he is given a badge and goes on the
hunt
- The forger now begins its work, taking random scraps of paper as input
(random strings) the forger outputs some fake currency
- The detective now looks at the work of the forger
- If the forger fools the detective then they can spend the fake currency and are
reward a point
- If the forged bill is detected then the forger gets nothing
````

## D13 — Week 12 Lecture.pdf, PDF-страница 34
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=34`
Строки (ID элементов): D13:p0034:u0001, D13:p0034:u0002, D13:p0034:u0003, D13:p0034:u0004, D13:p0034:u0005, D13:p0034:u0006, D13:p0034:u0007, D13:p0034:u0008, D13:p0034:u0009, D13:p0034:u0010, D13:p0034:u0011, D13:p0034:u0012

````text
Forgers and Detectives (cont.)
- After seeing where the forger was correct or not, the forger trains based on
this outcome, attempting to ensure that all these forgeries are not
detected
- The forger over time will become better and better at fooling the detective
- Once the forger is fooling the detective enough then the detective goes
back to the crime lab and studies the current set of forgeries which are
passing them and a new set of examples of real currency
- The detective over time will become better then at not being fooled
- This process continues of training each to defeat the other in a zero sum
game
- The better the forger is, the worse the detective has become and vice versa
````

## D13 — Week 12 Lecture.pdf, PDF-страница 35
Источник в ZIP: `AI_course_cleaned/13_Week 12 Lecture/source.pdf#page=35`
Строки (ID элементов): D13:p0035:u0001, D13:p0035:u0002, D13:p0035:u0003, D13:p0035:u0004, D13:p0035:u0005, D13:p0035:u0006, D13:p0035:u0007, D13:p0035:u0008, D13:p0035:u0009, D13:p0035:u0010

````text
How Does this Now Generate Stuff
- We can remove the detective and then look at the forgeries
- As they are training against one and other and the network is sufficiently
large, i.e. can build very large equations and add in new terms without
disrupting other structures, it is likely that forgers become good enough to
fool not just the detective but humans
- There is a risk of overtraining the network though and just producing the
input reality sets
- This is fixed by rotating and modifying the training samples and having enough
representative samples
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=8`
Строки (ID элементов): D16:p0008:u0001, D16:p0008:u0002, D16:p0008:u0003, D16:p0008:u0004, D16:p0008:u0005, D16:p0008:u0006, D16:p0008:u0007, D16:p0008:u0008, D16:p0008:u0009, D16:p0008:u0010, D16:p0008:u0024, D16:p0008:u0025, D16:p0008:u0028, D16:p0008:u0029, D16:p0008:u0030, D16:p0008:u0032, D16:p0008:u0034, D16:p0008:u0036, D16:p0008:u0037
**Непроверенные OCR/формулы:** 3 исключённых из основного текста кандидатов; см. JSON.

````text
GAN
- The GAN concept was initially developed by Ian Goodfellow and his
colleagues in June 2014
- In a GAN, two neural networks, the generator and the discriminator,
compete with each other in the form of a zero-sum game, where one
agent's gain is another agent's loss
- The generator creates synthetic data by transforming random noise into
samples that resemble the training dataset
- The discriminator is trained to distinguish the authentic data from synthetic
data produced by the generator
1
Backpropagation
Discriminator, D | /
Multilayer neural
network
Generator, G
Multilayer
Generated ‘fake’ samples
Backpropagation
````


---

# AI-10-05 — Диффузионные генеративные модели

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** частично; ядро
**Диагностический вопрос (черновик):** Объясни прямой и обратный процессы диффузии на примере генерации изображения.
**Пункты РПД:** RPD-39

**Связанные страницы:** 1; **символов извлечённого текста:** 704.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=9`
Строки (ID элементов): D16:p0009:u0001, D16:p0009:u0002, D16:p0009:u0003, D16:p0009:u0004, D16:p0009:u0012, D16:p0009:u0013, D16:p0009:u0017, D16:p0009:u0022, D16:p0009:u0023, D16:p0009:u0024, D16:p0009:u0025, D16:p0009:u0026, D16:p0009:u0027
**Непроверенные OCR/формулы:** 8 исключённых из основного текста кандидатов; см. JSON.

````text
Diffusion Models
- Diffusion Models were introduced by Sohl-Dicktein et al
- DM creates data by sequentially reconstructing structure from random
noise. Unlike GANs and VAEs, DMs operate on a "chaos → order" principle.
Data
Destructing data by adding noise ———~> Noise
Score function
Data <——— Generating samples by denoising
Noise
‘One denoising step
Fig. 2. Diffusion models smoothly perturb data by adding noise, then reverse this process to generate new data from noise. Each
denoising step in the reverse process typically requires estimating the score function (see the illustrative figure on the right), which is
a gradient pointing to the directions of data with higher likelihood and less noise.
````


---

# AI-10-06 — Языковые модели LLM и предсказание токенов

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Разбери пошаговую генерацию текста из токенов и объясни роль контекста.
**Пункты РПД:** RPD-39

**Связанные страницы:** 3; **символов извлечённого текста:** 1044.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D01 — 14 Tutorial.pdf, PDF-страница 5
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=5`
Строки (ID элементов): D01:p0005:u0001, D01:p0005:u0002, D01:p0005:u0003, D01:p0005:u0004, D01:p0005:u0005

````text
Large Language Models (LLMs)
- Neural networks trained on massive text corpora
- Learn statistical patterns of language
- Generate outputs token by token
- Key idea: Given previous text, predict the most likely next token
````

## D01 — 14 Tutorial.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=6`
Строки (ID элементов): D01:p0006:u0001, D01:p0006:u0002, D01:p0006:u0003, D01:p0006:u0004, D01:p0006:u0005, D01:p0006:u0006
**Общая страница с:** AI-10-07

````text
What Can LLMs Do?
- Answer questions and explain concepts
- Summarize articles and papers
- Translate between languages
- Generate and complete code
- Role-play: tutor, event assistant, reviewer, etc.
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=10`
Строки (ID элементов): D16:p0010:u0001, D16:p0010:u0002, D16:p0010:u0003, D16:p0010:u0004, D16:p0010:u0005, D16:p0010:u0006, D16:p0010:u0007, D16:p0010:u0008, D16:p0010:u0009, D16:p0010:u0010, D16:p0010:u0011, D16:p0010:u0012, D16:p0010:u0013, D16:p0010:u0014, D16:p0010:u0026, D16:p0010:u0028, D16:p0010:u0036, D16:p0010:u0037, D16:p0010:u0039, D16:p0010:u0041, D16:p0010:u0044, D16:p0010:u0049, D16:p0010:u0054
**Непроверенные OCR/формулы:** 15 исключённых из основного текста кандидатов; см. JSON.

````text
LLM
- LLM is a language model trained with self-
supervised ML on a vast amount of text,
designed for natural language processing
tasks, especially language generation
- They consist of billions to trillions of parameters
and operate as general-purpose sequence
models, generating, summarizing, translating,
and reasoning over text
- Since 2023, many LLMs have been trained to
be multimodal, having the ability to also
process or generate other types of data, such
as images, audio, or 3D mesh. These LLMs are
also called large multimodal models (LMMs)
Feed
Forward
Masked
Positional
ead
Encoding
Embedding
Embedding
Output
````


---

# AI-10-07 — Возможности и сферы применения генеративного ИИ

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Выбери генеративную модель под задачу создания контента и обоснуй ограничения.
**Пункты РПД:** —

**Связанные страницы:** 3; **символов извлечённого текста:** 791.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D01 — 14 Tutorial.pdf, PDF-страница 6
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=6`
Строки (ID элементов): D01:p0006:u0001, D01:p0006:u0002, D01:p0006:u0003, D01:p0006:u0004, D01:p0006:u0005, D01:p0006:u0006
**Общая страница с:** AI-10-06

````text
What Can LLMs Do?
- Answer questions and explain concepts
- Summarize articles and papers
- Translate between languages
- Generate and complete code
- Role-play: tutor, event assistant, reviewer, etc.
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=11`
Строки (ID элементов): D16:p0011:u0001, D16:p0011:u0002, D16:p0011:u0003, D16:p0011:u0004, D16:p0011:u0005, D16:p0011:u0006, D16:p0011:u0007, D16:p0011:u0008, D16:p0011:u0009, D16:p0011:u0010, D16:p0011:u0011, D16:p0011:u0012, D16:p0011:u0013, D16:p0011:u0014, D16:p0011:u0015, D16:p0011:u0016, D16:p0011:u0017, D16:p0011:u0018, D16:p0011:u0019, D16:p0011:u0020, D16:p0011:u0021, D16:p0011:u0022, D16:p0011:u0023, D16:p0011:u0024, D16:p0011:u0025, D16:p0011:u0026, D16:p0011:u0027, D16:p0011:u0028, D16:p0011:u0029

````text
Applications
- 
Text
- 
creating articles, scripts, marketing materials, translations
- 
Images
- 
design, advertising, concept art, fashion
- 
Sound and music
- 
speech synthesis, melodic generation, voiceover
- 
Video
- 
creating animated avatars, special effects, editing
- 
Programming
- 
code completion
- 
Science
- 
molecular modeling, protein structure prediction
- 
Games
- 
generating textures, locations, and dialogue.
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=12`
Строки (ID элементов): D16:p0012:u0001, D16:p0012:u0002, D16:p0012:u0003, D16:p0012:u0004, D16:p0012:u0005, D16:p0012:u0006
**Общая страница с:** AI-01-10, AI-10-12

````text
Advantages
- Decreases the costs
- Increases effectiveness and efficiency
- Expanding creative possibilities
- Accessibility and democratization of technology
- …
````


---

# AI-10-08 — Галлюцинации и проверка достоверности

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Найди уязвимости в выданном LLM ответе и составь план проверки его утверждений.
**Пункты РПД:** —

**Связанные страницы:** 2; **символов извлечённого текста:** 608.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D01 — 14 Tutorial.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=9`
Строки (ID элементов): D01:p0009:u0001, D01:p0009:u0002, D01:p0009:u0003, D01:p0009:u0004, D01:p0009:u0005, D01:p0009:u0006
**Общая страница с:** AI-01-12, AI-10-12

````text
Limitations of Generative AI
- No real understanding – pattern matching, not reasoning like
humans
- Can hallucinate: invents facts, references, dates, locations
- Sensitive to prompt phrasing and hidden biases in training data
- Needs careful use and evaluation, especially in critical contexts
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=13`
Строки (ID элементов): D16:p0013:u0001, D16:p0013:u0002, D16:p0013:u0003, D16:p0013:u0004, D16:p0013:u0005, D16:p0013:u0006, D16:p0013:u0007, D16:p0013:u0008, D16:p0013:u0009, D16:p0013:u0010, D16:p0013:u0011, D16:p0013:u0012, D16:p0013:u0013, D16:p0013:u0014, D16:p0013:u0015, D16:p0013:u0016, D16:p0013:u0017, D16:p0013:u0018, D16:p0013:u0019, D16:p0013:u0020, D16:p0013:u0021, D16:p0013:u0022
**Общая страница с:** AI-01-10, AI-01-12, AI-10-12

````text
Issues
- 
Quality and reliability of generated content
- Hallucinations
- 
Ethical issues
- Deepfakes
- 
Legal uncertainties
- 
Bias and discrimination
- 
Technical and resource limitations
- 
Overtraining and generalization
- 
Safety and Abuse
- 
Verification and trust issues
- Watermarks?
- 
Human substitution
````


---

# AI-10-09 — Проектирование промпта для LLM

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Улучши неоднозначный запрос, задав цель, контекст, роль и формат, и обоснуй выбор.
**Пункты РПД:** —

**Связанные страницы:** 2; **символов извлечённого текста:** 565.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D01 — 14 Tutorial.pdf, PDF-страница 7
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=7`
Строки (ID элементов): D01:p0007:u0001, D01:p0007:u0002, D01:p0007:u0003, D01:p0007:u0004, D01:p0007:u0005

````text
Prompting: Talking to LLMs
- A prompt is the instruction you give the model
- Good prompts specify a role, context, and desired format
- Prompt quality strongly affects output quality
- Think of prompts as programming with natural language
````

## D01 — 14 Tutorial.pdf, PDF-страница 8
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=8`
Строки (ID элементов): D01:p0008:u0001, D01:p0008:u0002, D01:p0008:u0003, D01:p0008:u0004, D01:p0008:u0005, D01:p0008:u0006, D01:p0008:u0007

````text
Example: Prompt Improvement
- Bad: "Tell me about the conference."
- Better: "You are an assistant for the 'ICSE 2026' conference.
In 5 bullet points, describe the event (date, location, main
topics, target audience, registration deadline)."
- Activity: Propose ways to improve this prompt further
(tone, length limits, etc.).
````


---

# AI-10-10 — RAG и опора на проверяемые источники

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Предложи схему retrieval плюс generation для чат-бота и объясни, почему меньше галлюцинаций.
**Пункты РПД:** —

**Связанные страницы:** 1; **символов извлечённого текста:** 308.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D01 — 14 Tutorial.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=10`
Строки (ID элементов): D01:p0010:u0001, D01:p0010:u0002, D01:p0010:u0003, D01:p0010:u0004, D01:p0010:u0005, D01:p0010:u0006, D01:p0010:u0007, D01:p0010:u0008
**Общая страница с:** AI-01-12, AI-10-12

````text
Grounding the Model (RAG)
- Instead of letting the model invent answers, give it trusted
data
- Use event schedule, venue info, FAQs as context
- Retrieval-Augmented Generation (RAG):
- 1. Retrieve relevant documents
- 2. Feed them into the prompt as context
- 3. Ask the LLM to answer only from that context
````


---

# AI-10-11 — LLM-агенты с инструментами и состоянием

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** явно; расширение
**Диагностический вопрос (черновик):** Спроектируй LLM-агента с вызовами инструментов, входом и выходом, обработкой ошибки.
**Пункты РПД:** —

**Связанные страницы:** 4; **символов извлечённого текста:** 2231.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D01 — 14 Tutorial.pdf, PDF-страница 11
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=11`
Строки (ID элементов): D01:p0011:u0001, D01:p0011:u0002, D01:p0011:u0003, D01:p0011:u0004, D01:p0011:u0005, D01:p0011:u0006

````text
From Chatbots to Agents
- Agent = LLM + goal + tools + memory/state
- Can call functions/APIs (e.g., check room availability)
- Can use a knowledge base (RAG) to stay grounded
- Can plan multi-step tasks to reach a goal
- In our context: an event management assistant agent
````

## D01 — 14 Tutorial.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=12`
Строки (ID элементов): D01:p0012:u0001, D01:p0012:u0002, D01:p0012:u0003, D01:p0012:u0004, D01:p0012:u0005, D01:p0012:u0006, D01:p0012:u0007, D01:p0012:u0008, D01:p0012:u0009, D01:p0012:u0010, D01:p0012:u0011, D01:p0012:u0012, D01:p0012:u0013, D01:p0012:u0014, D01:p0012:u0015, D01:p0012:u0016, D01:p0012:u0017

````text
Event Management AI projects
Your goal is to design, implement, and document one AI agent that supports a specific task of event
management for the fictional conference ICSE 2026. All agents will share a common interface (defined in
common/agent_base.py) and will be testable through a shared orchestrator (orchestrator/coordinator.py).
The conference at hand: https://conf.researchr.org/home/icse-2026
Github code: https://github.com/darkobozhinoski/event-management-agents
By completing this assignment, you will:
- 
Build a modular AI agent that solves a real event-management task
- 
Use a Large Language Model (via the provided llm_wrapper.py)
- 
Work with prompts, grounding, and structured outputs
- 
Understand how multiple AI agents can fit together in a larger system
- 
Practice collaborative software development using GitHub
````

## D01 — 14 Tutorial.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=13`
Строки (ID элементов): D01:p0013:u0001, D01:p0013:u0002, D01:p0013:u0003, D01:p0013:u0004, D01:p0013:u0005, D01:p0013:u0006, D01:p0013:u0007, D01:p0013:u0008, D01:p0013:u0009, D01:p0013:u0010, D01:p0013:u0011, D01:p0013:u0012, D01:p0013:u0013, D01:p0013:u0014, D01:p0013:u0015, D01:p0013:u0016, D01:p0013:u0017, D01:p0013:u0018, D01:p0013:u0019, D01:p0013:u0020, D01:p0013:u0021, D01:p0013:u0022, D01:p0013:u0023, D01:p0013:u0024, D01:p0013:u0025, D01:p0013:u0026, D01:p0013:u0027, D01:p0013:u0028, D01:p0013:u0029, D01:p0013:u0030, D01:p0013:u0031, D01:p0013:u0032, D01:p0013:u0033, D01:p0013:u0034, D01:p0013:u0035

````text
Technical Requirements
Each student creates at least one agent that:
- 
Extends a common Agent base class
- 
Takes a structured Python dict as input
- 
Returns a structured Python dict with:
○
success (bool)
○
message (str)
○
data (dict or None)
- 
Optionally uses the provided LLM wrapper
- 
Is registered in the shared coordinator.py
Each agent must:
1.
Live in its own folder under agents/
Implement:
○
name
○
description
○
run(request: dict) -> dict
2.
Handle invalid inputs gracefully
Return structured outputs
3.
Include a README with examples
4.
Be registered in orchestrator/coordinator.py
````

## D01 — 14 Tutorial.pdf, PDF-страница 14
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=14`
Строки (ID элементов): D01:p0014:u0001, D01:p0014:u0002, D01:p0014:u0003, D01:p0014:u0004, D01:p0014:u0005, D01:p0014:u0006, D01:p0014:u0007, D01:p0014:u0008, D01:p0014:u0009, D01:p0014:u0010, D01:p0014:u0011, D01:p0014:u0012, D01:p0014:u0013, D01:p0014:u0014, D01:p0014:u0015, D01:p0014:u0016, D01:p0014:u0017, D01:p0014:u0018, D01:p0014:u0019, D01:p0014:u0020, D01:p0014:u0021, D01:p0014:u0022, D01:p0014:u0023, D01:p0014:u0024, D01:p0014:u0025, D01:p0014:u0026, D01:p0014:u0027, D01:p0014:u0028, D01:p0014:u0029, D01:p0014:u0030, D01:p0014:u0031, D01:p0014:u0032

````text
Choose an Agent from this list
Phase A — Pre-event
- 
Call-for-Papers Assistant
- 
Sponsor Pitch Writer
- 
Talk/Track Classifier
Phase B — Registration & Promotion
- 
Registration FAQ Agent
- 
Marketing Content Generator
Phase C — Logistics & Scheduling
- 
Session Scheduler Helper
- 
Room/Capacity Checker
- 
Speaker Reminder Assistant
Phase D — During Event
- 
Speaker Reminder Assistant
- 
On-site Helpdesk Chatbot
- 
Issue Triage Agent
Phase E — Post-event
- 
Feedback Summarizer
- 
Certificate/Follow-up Email Generator
````


---

# AI-10-12 — Риски, преимущества и ограничения генеративного ИИ

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** явно; ядро
**Диагностический вопрос (черновик):** Оцени внедрение генеративного сервиса по качеству, рискам и эффекту для пользователей.
**Пункты РПД:** RPD-40

**Связанные страницы:** 4; **символов извлечённого текста:** 1078.

> Ниже приведён весь очищенный текст, классифицированный как учебный, со страниц, привязанных к этой теме на предыдущем шаге. Границы отрывков пока соответствуют страницам, поэтому на общих страницах может встречаться текст соседних тем. Схемы и формулы в виде изображений не транскрибированы повторно.

## D01 — 14 Tutorial.pdf, PDF-страница 9
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=9`
Строки (ID элементов): D01:p0009:u0001, D01:p0009:u0002, D01:p0009:u0003, D01:p0009:u0004, D01:p0009:u0005, D01:p0009:u0006
**Общая страница с:** AI-01-12, AI-10-08

````text
Limitations of Generative AI
- No real understanding – pattern matching, not reasoning like
humans
- Can hallucinate: invents facts, references, dates, locations
- Sensitive to prompt phrasing and hidden biases in training data
- Needs careful use and evaluation, especially in critical contexts
````

## D01 — 14 Tutorial.pdf, PDF-страница 10
Источник в ZIP: `AI_course_cleaned/01_14 Tutorial/source.pdf#page=10`
Строки (ID элементов): D01:p0010:u0001, D01:p0010:u0002, D01:p0010:u0003, D01:p0010:u0004, D01:p0010:u0005, D01:p0010:u0006, D01:p0010:u0007, D01:p0010:u0008
**Общая страница с:** AI-01-12, AI-10-10

````text
Grounding the Model (RAG)
- Instead of letting the model invent answers, give it trusted
data
- Use event schedule, venue info, FAQs as context
- Retrieval-Augmented Generation (RAG):
- 1. Retrieve relevant documents
- 2. Feed them into the prompt as context
- 3. Ask the LLM to answer only from that context
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 12
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=12`
Строки (ID элементов): D16:p0012:u0001, D16:p0012:u0002, D16:p0012:u0003, D16:p0012:u0004, D16:p0012:u0005, D16:p0012:u0006
**Общая страница с:** AI-01-10, AI-10-07

````text
Advantages
- Decreases the costs
- Increases effectiveness and efficiency
- Expanding creative possibilities
- Accessibility and democratization of technology
- …
````

## D16 — Week 14 Lecture Slides.pdf, PDF-страница 13
Источник в ZIP: `AI_course_cleaned/16_Week 14 Lecture Slides/source.pdf#page=13`
Строки (ID элементов): D16:p0013:u0001, D16:p0013:u0002, D16:p0013:u0003, D16:p0013:u0004, D16:p0013:u0005, D16:p0013:u0006, D16:p0013:u0007, D16:p0013:u0008, D16:p0013:u0009, D16:p0013:u0010, D16:p0013:u0011, D16:p0013:u0012, D16:p0013:u0013, D16:p0013:u0014, D16:p0013:u0015, D16:p0013:u0016, D16:p0013:u0017, D16:p0013:u0018, D16:p0013:u0019, D16:p0013:u0020, D16:p0013:u0021, D16:p0013:u0022
**Общая страница с:** AI-01-10, AI-01-12, AI-10-08

````text
Issues
- 
Quality and reliability of generated content
- Hallucinations
- 
Ethical issues
- Deepfakes
- 
Legal uncertainties
- 
Bias and discrimination
- 
Technical and resource limitations
- 
Overtraining and generalization
- 
Safety and Abuse
- 
Verification and trust issues
- Watermarks?
- 
Human substitution
````


---

# AI-10-13 — Полноценный жизненный цикл этически ответственного ИИ

**Раздел РПД:** 10. Введение в генеративный искусственный интеллект
**Статус исходной разметки:** не найдено; ядро
**Диагностический вопрос (черновик):** Построй схему этического анализа данных, модели, внедрения и мониторинга с ответственными лицами.
**Пункты РПД:** —

**Исходный текст не найден.** В текущей карте отсутствуют ссылки на учебные материалы.
Текст не генерировался и не заменялся сведениями из РПД.


---

