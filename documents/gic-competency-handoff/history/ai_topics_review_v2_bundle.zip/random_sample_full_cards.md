# Четыре воспроизводимо случайные карточки (seed=20261015)

## AI-02-06 — Рефлексный агент с внутренней моделью

**Раздел:** Агенты

**Связь с РПД:** RPD-11

**Качество источника:** thin_source

**Вопрос:** В частично наблюдаемом мире опиши две последовательности наблюдений с одинаковым текущим percept и объясни, как внутреннее состояние позволяет агенту принимать разные решения.

**provides**

- поддерживать внутреннее состояние агента при изменении среды
- объяснять необходимость модели мира

**requires**

- рефлексный агент
- частичная наблюдаемость среды

**assessment_criteria**

- Названа информация, сохраняемая из предыдущих наблюдений
- Объяснено, почему агент без памяти не может различить случаи

**Полный текст привязанных страниц:**

```text
[D19 | Week 3 Lecture.pdf | с.19 | core]
Model-based Reflex Agents
What the world
( How the world evolves }-——a>
is like now
What action I
should do now
gent

[D19 | Week 3 Lecture.pdf | с.20 | core]
Model-based Reflex Agents
- Work better in partially observable environment because of keeping track
of the world
- Internal state exists
- In partially observable environment not always possible to answer “What
the world is like now?”. Sometimes agent tries to guess
- Still, too many condition-action rules may be required
- Not flexible enough
```

## AI-02-05 — Простой рефлексный агент

**Раздел:** Агенты

**Связь с РПД:** RPD-11

**Качество источника:** thin_source

**Вопрос:** Для робота-пылесоса составь три правила condition→action по текущим ощущениям и приведи два неразличимых наблюдения, при которых одинаковое действие будет неверным хотя бы в одном случае.

**provides**

- строить condition-action правила рефлексного агента
- объяснять ограничения при частичной наблюдаемости

**requires**

- агентная функция и текущее восприятие
- условные правила

**assessment_criteria**

- Каждое правило сопоставляет только текущий percept и действие
- Приведены два состояния среды с одинаковым percept, но требующие разных действий

**Полный текст привязанных страниц:**

```text
[D19 | Week 3 Lecture.pdf | с.16 | core]
Types of Agents
1. Simple reflex agents
2. Model-based reflex agents
3. Goal-based agents
4. Utility-based agents

[D19 | Week 3 Lecture.pdf | с.17 | core]
Simple Reflex Agents
Agent
What the world
is like now
What action I
should do now

[D19 | Week 3 Lecture.pdf | с.18 | core]
Simple Reflex Agents
- Only current percept matters
- Work only in fully observable environment
- Too many condition-action rules may be required
```

## AI-06-06 — Получение и проверка плана PDDL-планировщиком

**Раздел:** Язык определения проблемной области планирования (PDDL)

**Связь с РПД:** 

**Качество источника:** shared_only_review_required

**Вопрос:** В задаче с переключателями проверь план из трёх действий: для каждого шага рассчитай состояние, найди недопустимый переход и установи, выполнена ли цель.

**provides**

- проверять выполнимость действий в плане и достижимость цели
- диагностировать неверный план

**requires**

- предусловия и эффекты PDDL
- начальное и целевое состояние

**assessment_criteria**

- Для каждого действия отмечены удовлетворённые и нарушенные предусловия
- Конечное состояние вычислено после add/delete-эффектов и сопоставлено с goal

**Полный текст привязанных страниц:**

```text
[D04 | PDDL (Lecture +Tutorial).pdf | с.13 | shared]
PDDL - Solvers
13
How to find a plan to achieve a goal?
• Solvers take as input a domain.pddl and problem.pddl, and generate a
plan
• The planning problem can be seen as network of states, where actions
represent transitions.
• It is a search problem: MCTS, A*…

[D04 | PDDL (Lecture +Tutorial).pdf | с.19 | shared]
Classic PDDL - Example
19
A plan for a classical planning problem is a sequence of actions that are
applicable from the initial state and lead to a a state that satisfies the goal
(switch_on s1)
(switch_on s2)
PLAN:
(:goal (and (on s1)
(on s2)
(on s3))
)
OFF
OFF
ON

[D04 | PDDL (Lecture +Tutorial).pdf | с.20 | shared]
Classic PDDL - Example
20
A plan for a classical planning problem is a sequence of actions that are
applicable from the initial state and lead to a a state that satisfies the goal
Online PDDL Editor: to write and solve PDDL planning problems:
Ik File ~
® Session v
4 Solve ¥F Plugins
domain.pddl
C:requirements :typing)
C:types switch)
problem.pddl
C:predicates (off ?s - switch)
Con ?s - switch))
C:action switch_on
:parameters (?s - switch)
:precondition Coff ?s)
:effect Cand (not Coff ?s))
10
Con ?s)))

[D04 | PDDL (Lecture +Tutorial).pdf | с.21 | shared]
Did you create the switch_off action?
21
(:action switch_off
:parameters (?s - switch)
:precondition (on ?s)
:effect (and (not (on ?s))
(off ?s))))
http://editor.planning.domains/#edit_session=wQgyhJKiR0wyquH

[D04 | PDDL (Lecture +Tutorial).pdf | с.22 | shared]
Add and delete effects
22
switch1 off: FALSE
switch1 on: FALSE
switch1 off: TRUE
switch1 on: FALSE
switch1 off: FALSE
switch1 on: TRUE
switch1 off: TRUE
switch1 on: TRUE
switch_on
switch_off
Valid set
```

## AI-07-04 — Ранговый и турнирный отбор

**Раздел:** Эволюционные вычисления

**Связь с РПД:** 

**Качество источника:** source_present_visuals_unverified

**Вопрос:** Для четырёх кандидатов с заданными fitness и двумя случайно сформированными турнирами рассчитай ранговые вероятности, выбери победителей турниров и объясни влияние их размера.

**provides**

- выполнять ранговый и турнирный отбор
- объяснять влияние размера турнира на селективность

**requires**

- оценка приспособленности
- ранжирование кандидатов

**assessment_criteria**

- Ранги упорядочены по fitness, вероятности нормированы на сумму рангов
- Турниры выбраны по максимуму внутри каждой группы и описан эффект увеличения размера группы

**Полный текст привязанных страниц:**

```text
[D11 | Week 10 Lecture.pdf | с.12 | core]
Rank Selection
- Rank selection works in a fashion similar to
roulette wheel selection except that the
creatures are ordered by fitness (ascending
order) and then selected by their rank instead
of their fitness
- If creature 𝑖has rank 𝑓!, then the probability of
being picked is
"!
#, where 𝐹is the sum of the
ranks of the entire population
- The least fit creature is given a rank of 1 so as
to give it the smallest chance of being picked.
Pointer

[D11 | Week 10 Lecture.pdf | с.13 | core]
Roulette vs Rank Selection
- An advantage of rank-based selection can be seen in the fact that it also
gives worse individuals a higher chance to reproduce and thus to improve
- If there is a strong fitness gradient, then roulette wheel selection gives a
stronger fitness bias than rank selection and, hence, tends to take the
population to a nearly uniform type faster
Creature # | Fitness
Rank | P(chosen) | P(chosen)
Rank
0.099
0.048
0.169
0.238
0.333
0.286
0.113
0.095
0.164
0.190
0.122
0.143

[D11 | Week 10 Lecture.pdf | с.14 | core]
Tournament
- A number of different manners are held for the construction of the challengers
- At random (single tournament)
- Groups of N (double tournament)
- Pick a group of 𝑁creatures and take the single most fit one as a parent, repeating the process
with a new group of 𝑁creatures to get a second parent
- Each of the structures in a tournament is compared and the most fit continues
on to breed
- Fighting solutions
- Selection Pressure (the likelihood of only selecting from the higher fitness cohorts
is a controllable feature)
- Small Tournaments
- Larger Tournaments
```

